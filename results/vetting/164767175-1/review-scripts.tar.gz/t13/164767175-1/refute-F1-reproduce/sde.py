import os, pandas as pd, numpy as np
s = pd.read_parquet(os.environ['SEARCH_RUN'] + '/signals.parquet')
print(s.columns.tolist())
r = s[s.tic == 164767175]
print(r[[c for c in ['tic','rank','sde','depth_snr','period','depth','duration'] if c in s.columns]].to_string())
names = sorted(os.listdir(os.environ['VET2_RUN'] + '/signals'))
print(len(names), names)
rows = []
for n in names:
    tic, rk = n.split('-')
    m = s[(s.tic == int(tic)) & (s['rank'] == int(rk))]
    if len(m) != 1:
        print('no unique row', n, len(m)); continue
    rows.append((n, float(m.sde.iloc[0]), float(m.depth_snr.iloc[0])))
print('by SDE')
for x in sorted(rows, key=lambda x: x[1]): print(x)
print('by depth_snr')
for x in sorted(rows, key=lambda x: x[2]): print(x)
d = np.array([162.67112566947795,145.34954402167788,177.99024232223460])
e = np.array([63.89518783488469,62.41276028988985,61.83335621594621])
w = 1/e**2
m = (w*d).sum()/w.sum(); me = w.sum()**-0.5
print('without S97: %.1f +- %.1f ppm, %.2f sigma' % (m, me, m/me))
d4 = np.append(d, 273.2275911582205); e4 = np.append(e, 43.07757641537571); w4=1/e4**2
print('all four: %.1f +- %.1f' % ((w4*d4).sum()/w4.sum(), w4.sum()**-0.5))
mj = 3/317.83; P = 5.83926/365.25
print('K = %.3f m/s' % (28.4*mj*P**(-1/3)*0.84**(-2/3)))
