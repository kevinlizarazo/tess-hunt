"""For each transit of 164767175-1 (density-prior ephemeris): quality flags near it, the nearest momentum dump
(bit 32), the background (SAP_BKG) in the core against the local baseline, and the SAP and PDCSAP core depths."""
import glob
import numpy as np
from astropy.io import fits

P, T0, DUR = 5.839259321251369, 1387.25965808129, 0.12485015931513758
rows = []
for f in sorted(glob.glob("/tmp/t13/164767175-1/fits/*.fits")):
    with fits.open(f) as h:
        d = h[1].data
        sec = h[0].header["SECTOR"]
        t = np.array(d["TIME"], float); q = np.array(d["QUALITY"], int)
        pdc = np.array(d["PDCSAP_FLUX"], float); sap = np.array(d["SAP_FLUX"], float); bkg = np.array(d["SAP_BKG"], float)
    dumps = t[(q & 32) > 0]
    dumps = dumps[np.isfinite(dumps)]
    # collapse consecutive flagged cadences into events
    ev = dumps[np.r_[True, np.diff(dumps) > 0.05]] if len(dumps) else dumps
    print(f"S{sec}: {len(ev)} momentum-dump events: {np.round(ev, 2).tolist()}")
    good = (q == 0) & np.isfinite(pdc) & np.isfinite(t)
    n0 = int(np.ceil((t[np.isfinite(t)].min() - T0) / P)); n1 = int(np.floor((t[np.isfinite(t)].max() - T0) / P))
    for n in range(n0, n1 + 1):
        tm = T0 + n * P
        ph = t - tm
        core = good & (np.abs(ph) < 0.25 * DUR)
        base = good & (np.abs(ph) > 0.75 * DUR) & (np.abs(ph) < 2.5 * DUR)
        near = np.isfinite(t) & (np.abs(ph) < 0.5)
        flags = sorted(set(int(x) for x in q[near] if x))
        nd = ev[np.argmin(np.abs(ev - tm))] - tm if len(ev) else np.nan
        if core.sum() < 5 or base.sum() < 20:
            print(f"   epoch {n}: t {tm:.3f} core {core.sum()} base {base.sum()} (too few); flags within 0.5 d {flags}; nearest dump {nd*24:+.1f} h")
            continue
        def dep(x):
            b = np.median(x[base]); return (b - np.mean(x[core])) / b * 1e6
        bk = (np.mean(bkg[core]) - np.median(bkg[base]))
        bkrel = bk / np.median(sap[base]) * 1e6
        print(f"   epoch {n}: t {tm:.3f} pdc {dep(pdc):7.1f} ppm  sap {dep(sap):7.1f} ppm  bkg excess {bkrel:+7.1f} ppm-of-star  "
              f"nearest dump {nd*24:+6.1f} h  flags within 0.5 d {flags}")
