import sys,re,glob,pypdf
pat=re.compile(r'(TOI[- ]?266\b|HIP ?8152|164767175|HIP8152|BD-19 ?302)')
for f in sorted(glob.glob('papers/*.pdf')):
    try:
        r=pypdf.PdfReader(f)
        t='\n'.join((p.extract_text() or '') for p in r.pages)
    except Exception as e:
        print(f,'ERR',e); continue
    open(f+'.txt','w').write(t)
    ms=list(pat.finditer(t))
    print('=====',f,len(r.pages),'pages', len(ms),'matches')
    for m in ms[:12]:
        s=max(0,m.start()-300); print('   ...',t[s:m.end()+400].replace('\n',' '),'\n')
