import json, numpy as np
d = json.load(open('/tmp/t13/164767175-1/pix_detail.json'))[0]
for r in d['per_sector']:
    if 'error' in r:
        print(r); continue
    f = r['fit']; tb = r['target_box']
    nulls = [n for n in r['nulls'] if n.get('ok') and n['phase'] != 0.0]
    nz = np.array([n['target_diff'] for n in nulls])
    z = (tb['diff'] - np.mean(nz)) / np.std(nz) if len(nz) > 2 else float('nan')
    q_ge = sum(1 for n in nulls if n['quality'] >= f['quality'])
    noff = [round(n['offset'], 1) for n in nulls]
    print(f"S{r['sector']} cam{r['camera']} ccd{r['ccd']}: offset {f['offset']:.1f} (E {f['east']:+.1f}, N {f['north']:+.1f}) q {f['quality']:.2f}; "
          f"dcol {f['dcol']:+.2f} drow {f['drow']:+.2f}; transits used {r['transits_used']} of {r['transits_in_sector']}; n_in {r['n_in']}")
    print(f"   target box: depth {tb['depth']*1e6:.0f} ppm (ratio to LC {r['depth_ratio']:.2f}); box z vs {len(nulls)} nulls {z:.2f}; "
          f"expected z {r['expected_snr']:.2f}; nulls with quality >= transit's: {q_ge} of {len(nulls)}; null offsets {noff}")
    print(f"   near fit: {[(n['tic'], round(n['tmag'],1), round(n['sep_from_fit'],1), round(n['sep_from_target'],1)) for n in r['near_fit']]}")
    print(f"   reproduces saved image: {[n.get('reproduces_saved_image') for n in r['nulls'] if n['phase']==0.0]}")
fits_ = [r['fit'] for r in d['per_sector'] if 'fit' in r]
q = np.array([f['quality'] for f in fits_]); E = np.array([f['east'] for f in fits_]); N = np.array([f['north'] for f in fits_])
mE, mN = np.sum(q*E)/q.sum(), np.sum(q*N)/q.sum()
scat = np.sqrt(np.mean((E-mE)**2 + (N-mN)**2))
print(f"quality-weighted mean fit position E {mE:+.1f} N {mN:+.1f} ({np.hypot(mE,mN):.1f}\"), sky scatter {scat:.1f}\", "
      f"mean offset in standard errors {np.hypot(mE,mN)/(scat/np.sqrt(len(E))):.2f}")
