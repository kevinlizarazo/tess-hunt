"""Noise of the core-depth statistic at the signal's period: phase offsets on a grid one core-width apart (independent
boxes), robust spread, and the same per sector. Also the period-scramble: the best phase at random periods 3-9 d."""
import json
import numpy as np
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days

D = "$TESS_HUNT_DATA/runs/20261020T174317Z-vetting-run-61b5944-2d70/signals/164767175-1/checks.json"
checks = json.load(open(D))
crit = load_criteria("~/code/tess-hunt/criteria/search-v2.toml")
lc = LightCurve.load("$TESS_HUNT_DATA/lc/164767175.npz")
flat = detrend(lc, crit["detrend"], [Ephemeris(**m) for m in checks["masked"]])
fp = checks["fit_prior"]["ephemeris"]
dur = checks["window_duration"]["days"]
P, T0 = fp["period"]["median"], fp["t0"]["median"]
t, f, s = flat.time, flat.flux - 1.0, flat.sector

def stat(P, t0, sel=None):
    ph = phase_days(t, Ephemeris(P, t0, dur))
    c = np.abs(ph) < 0.25 * dur
    o = (np.abs(ph) > 0.75 * dur) & (np.abs(ph) < 2.5 * dur)
    if sel is not None:
        c &= sel; o &= sel
    if c.sum() < 10:
        return np.nan
    return (np.mean(f[o]) - np.mean(f[c])) * 1e6

real = stat(P, T0)
step = 0.5 * dur
offs = np.arange(3 * dur, P - 3 * dur, step)
vals = np.array([stat(P, T0 + o) for o in offs])
mad = 1.4826 * np.median(np.abs(vals - np.median(vals)))
print(f"real {real:.1f} ppm; {len(vals)} independent phase boxes: mean {vals.mean():.1f}, sd {vals.std():.1f}, MAD-sd {mad:.1f}")
print("  top 5 scramble values:", np.round(np.sort(vals)[-5:], 1), " bottom 5:", np.round(np.sort(vals)[:5], 1))
print(f"  real/sd {real/vals.std():.2f}, real/MAD-sd {real/mad:.2f}")
for sec in np.unique(s):
    sel = s == sec
    r = stat(P, T0, sel)
    v = np.array([stat(P, T0 + o, sel) for o in offs])
    v = v[np.isfinite(v)]
    print(f"  S{sec}: real {r:.1f}; scramble sd {v.std():.1f}, MAD-sd {1.4826*np.median(np.abs(v-np.median(v))):.1f}, real/sd {r/v.std():.2f}")

# Period scramble: random periods in 3-9 d away from 0.97-1.03 of the signal's period and of b and c's harmonics.
rng = np.random.default_rng(7)
best = []
avoid = [P, 10.751, 19.6056, 10.751 / 2, 19.6056 / 3, 19.6056 / 4, 1.389]
while len(best) < 300:
    p = rng.uniform(3, 9)
    if any(abs(p / a - 1) < 0.03 for a in avoid):
        continue
    ph0 = np.arange(0, p, step)
    v = np.array([stat(p, T0 + o) for o in ph0])
    best.append(np.nanmax(v))
best = np.array(best)
print(f"\nperiod scramble, 300 random periods 3-9 d, best box over phase: median {np.median(best):.1f}, "
      f"95th {np.percentile(best,95):.1f}, 99th {np.percentile(best,99):.1f}, max {best.max():.1f}; fraction >= real {np.mean(best>=real):.3f}")
