"""Is the dip in the background? Per sector, the folded core-minus-baseline of SAP_BKG (in units of the star's
SAP flux), SAP_FLUX and PDCSAP_FLUX at the signal's ephemeris, each against 60 independent phase offsets of the same
period (quality 0 cadences, the masked rows of HIP 8152 b and c left out at two durations)."""
import glob, json
import numpy as np
from astropy.io import fits

P, T0, DUR = 5.839259321251369, 1387.25965808129, 0.12485015931513758
chk = json.load(open("$TESS_HUNT_DATA/runs/20261020T174317Z-vetting-run-61b5944-2d70/signals/164767175-1/checks.json"))
masks = chk["masked"]

def masked(t):
    m = np.zeros(len(t), bool)
    for k in masks:
        ph = (t - k["t0"] + 0.5 * k["period"]) % k["period"] - 0.5 * k["period"]
        m |= np.abs(ph) < k["duration"]  # two durations wide, as known_mask_width 2.0
    return m

def stat(t, x, norm, t0):
    ph = (t - t0 + 0.5 * P) % P - 0.5 * P
    c = np.abs(ph) < 0.25 * DUR
    b = (np.abs(ph) > 0.75 * DUR) & (np.abs(ph) < 2.5 * DUR)
    # per transit: core mean minus local baseline median, then averaged over transits
    ep = np.round((t - t0) / P)
    vals = []
    for e in np.unique(ep[c]):
        ce, be = c & (ep == e), b & (ep == e)
        if ce.sum() >= 10 and be.sum() >= 40:
            vals.append((np.mean(x[ce]) - np.median(x[be])) / norm)
    return np.mean(vals) * 1e6 if vals else np.nan

allr = {}
for f in sorted(glob.glob("/tmp/t13/164767175-1/fits/*.fits")):
    with fits.open(f) as h:
        d = h[1].data; sec = h[0].header["SECTOR"]
        t = np.array(d["TIME"], float); q = np.array(d["QUALITY"], int)
        cols = {k: np.array(d[k], float) for k in ("PDCSAP_FLUX", "SAP_FLUX", "SAP_BKG")}
    g = (q == 0) & np.isfinite(t) & np.isfinite(cols["PDCSAP_FLUX"]) & ~masked(t)
    t = t[g]; cols = {k: v[g] for k, v in cols.items()}
    norm = np.median(cols["SAP_FLUX"]); normp = np.median(cols["PDCSAP_FLUX"])
    # detrend fluxes lightly: divide by a 1.2-d running median so the core-vs-baseline sees only short features
    out = []
    offs = np.arange(3 * DUR, P - 3 * DUR, (P - 6 * DUR) / 60)
    for k, nrm in (("PDCSAP_FLUX", normp), ("SAP_FLUX", norm), ("SAP_BKG", norm)):
        x = cols[k]
        real = stat(t, x, nrm, T0)
        null = np.array([stat(t, x, nrm, T0 + o) for o in offs])
        null = null[np.isfinite(null)]
        out.append(f"{k}: {real:+8.1f} ppm (nulls sd {null.std():6.1f}, z {(real-null.mean())/null.std():+5.2f})")
    print(f"S{sec}: " + "; ".join(out))
