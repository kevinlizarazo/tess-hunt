"""The vet's own signal_present statistic (vet.py: detrend around the masked rows, beta-scaled errors, box_depth over
the core) at the signal's ephemeris, then at independent phase offsets of the same period and at random periods."""
import json
import numpy as np
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.checks.photometry import red_noise_beta, with_red_noise, box_depth

D = "$TESS_HUNT_DATA/runs/20261020T174317Z-vetting-run-61b5944-2d70/signals/164767175-1/checks.json"
checks = json.load(open(D))
cs = load_criteria("~/code/tess-hunt/criteria/search-v2.toml")
cv = load_criteria("~/code/tess-hunt/criteria/vet-v3.toml")
lc = LightCurve.load("$TESS_HUNT_DATA/lc/164767175.npz")
e = checks["ephemeris"]
eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
flat = detrend(lc, cs["detrend"], [Ephemeris(**m) for m in checks["masked"]])
core = cv["depth"]["core_fraction"]
betas = red_noise_beta(flat, eph, core * eph.duration, cv["red_noise"])
print("betas", {k: round(v["beta"], 3) for k, v in betas.items()})
noisy = with_red_noise(flat, betas)
d, err, n = box_depth(noisy.time, noisy.flux, noisy.flux_err, eph, core)
print(f"signal_present at the signal's ephemeris: depth {d*1e6:.1f} ppm, err {err*1e6:.1f}, snr {d/err:.2f}, n {n} "
      f"(checks.json: {checks['checks'][5]['evidence']})")
step = 0.5 * eph.duration
offs = np.arange(3 * eph.duration, eph.period - 3 * eph.duration, step)
snr = []
for o in offs:
    dd, ee, nn = box_depth(noisy.time, noisy.flux, noisy.flux_err, Ephemeris(eph.period, eph.t0 + o, eph.duration), core)
    snr.append(dd / ee)
snr = np.array(snr)
print(f"{len(offs)} independent phase offsets: snr mean {snr.mean():.2f}, sd {snr.std():.2f}, max {snr.max():.2f}, min {snr.min():.2f}")
print(f"  real snr over the scramble's sd: {(d/err - snr.mean())/snr.std():.2f}")
rng = np.random.default_rng(11)
best = []
avoid = [eph.period, 10.751, 19.6056, 1.389]
periods = []
while len(best) < 300:
    p = rng.uniform(3.0, 9.0)
    if any(abs(p / a - k) < 0.02 for a in avoid for k in (0.5, 1, 2, 1/3, 3)):
        continue
    vals = []
    for o in np.arange(0, p, step):
        dd, ee, nn = box_depth(noisy.time, noisy.flux, noisy.flux_err, Ephemeris(p, eph.t0 + o, eph.duration), core)
        if nn >= 100:
            vals.append(dd / ee)
    best.append(max(vals)); periods.append(p)
best = np.array(best)
print(f"300 random periods 3-9 d, best snr over phase: median {np.median(best):.2f}, 90th {np.percentile(best,90):.2f}, "
      f"99th {np.percentile(best,99):.2f}, max {best.max():.2f} at P={periods[int(np.argmax(best))]:.4f}; "
      f"fraction >= {d/err:.2f}: {np.mean(best >= d/err):.3f}; fraction >= 7: {np.mean(best >= 7):.3f}")
