import sys,re,pypdf
pat=re.compile(r'(TOI[- ]?266\b|HIP ?8152|164767175|HIP8152|BD-19 ?302)')
for f in sys.argv[1:]:
    r=pypdf.PdfReader(f)
    t='\n'.join((p.extract_text() or '') for p in r.pages)
    open(f+'.txt','w').write(t)
    t1=t[:1500].replace('\n',' ')
    ms=list(pat.finditer(t))
    print('=====',f,len(r.pages),'pages',len(ms),'matches |',t1[:300])
    for m in ms[:8]:
        s=max(0,m.start()-400); print('   ...',t[s:m.end()+500].replace('\n',' '),'\n')
