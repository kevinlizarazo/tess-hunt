"""Per-transit and per-sector core depths of 164767175-1, on the light curve vet-v3 saw (rebuilt as vetting._plots
does), plus a phase-scramble of the combined depth at the same period. Read-only."""
import json, sys
import numpy as np
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days, epoch_numbers

D = "$TESS_HUNT_DATA/runs/20261020T174317Z-vetting-run-61b5944-2d70/signals/164767175-1/checks.json"
checks = json.load(open(D))
crit = load_criteria("~/code/tess-hunt/criteria/search-v2.toml")
lc = LightCurve.load("$TESS_HUNT_DATA/lc/164767175.npz")
seen = lc.select(~np.isin(lc.sector, checks["dropped_suspect"]))
flat = detrend(seen, crit["detrend"], [Ephemeris(**m) for m in checks["masked"]])
fp = checks["fit_prior"]["ephemeris"]
dur = checks["window_duration"]["days"]
eph = Ephemeris(fp["period"]["median"], fp["t0"]["median"], dur)
t, f, s = flat.time, flat.flux, flat.sector
print("raw cadences", len(lc.time), "flat", len(t))
for sec in np.unique(lc.sector):
    m = lc.sector == sec
    print(f"S{sec}: raw {lc.time[m].min():.3f} to {lc.time[m].max():.3f}, n={m.sum()}")
ph = phase_days(t, eph)
ep = epoch_numbers(t, eph)
core = np.abs(ph) < 0.25 * dur
oot = (np.abs(ph) > 0.75 * dur) & (np.abs(ph) < 2.5 * dur)
rows = []
print("\nepoch sector t_mid  n_core depth_ppm err_ppm snr  local_base_ppm  gap_before_h gap_after_h")
for e in np.unique(ep[core]):
    mc = core & (ep == e)
    mo = oot & (ep == e)
    sec = int(np.unique(s[mc])[0])
    sc = np.std(f[s == sec]) 
    base = np.mean(f[mo]) if mo.sum() > 5 else np.nan
    depth = (base - np.mean(f[mc])) if np.isfinite(base) else (1 - np.mean(f[mc]))
    err = sc / np.sqrt(mc.sum())
    tm = eph.t0 + e * eph.period
    ts = np.sort(lc.time[lc.sector == sec])
    # largest gap within +-0.5 d of mid-transit
    w = (ts > tm - 0.5) & (ts < tm + 0.5)
    tw = ts[w]
    gaps = np.diff(tw) * 24 if len(tw) > 1 else np.array([np.nan])
    big = gaps.max() if len(gaps) else np.nan
    rows.append((e, sec, tm, mc.sum(), depth * 1e6, err * 1e6))
    print(f"{e:5d} S{sec:<4d} {tm:10.4f} {mc.sum():4d} {depth*1e6:8.1f} {err*1e6:7.1f} {depth/err:5.2f} {base*1e6-1e6 if np.isfinite(base) else float('nan'):8.1f} maxgap_in_1d_window_h={big:.2f} first_t={ts.min():.3f} last_t={ts.max():.3f}")
rows = np.array(rows)
w = 1 / rows[:, 5] ** 2
comb = np.sum(rows[:, 4] * w) / np.sum(w)
cerr = 1 / np.sqrt(np.sum(w))
print(f"\ncombined core depth {comb:.1f} +- {cerr:.1f} ppm, snr {comb/cerr:.2f} over {len(rows)} transits (white errors)")
for i in range(len(rows)):
    k = np.arange(len(rows)) != i
    c = np.sum(rows[k, 4] * w[k]) / np.sum(w[k]); ce = 1 / np.sqrt(np.sum(w[k]))
    print(f"  without epoch {int(rows[i,0])}: {c:.1f} +- {ce:.1f}, snr {c/ce:.2f}")
for sec in np.unique(rows[:, 1]):
    k = rows[:, 1] == sec
    c = np.sum(rows[k, 4] * w[k]) / np.sum(w[k]); ce = 1 / np.sqrt(np.sum(w[k]))
    print(f"S{int(sec)}: {k.sum()} transits, {c:.1f} +- {ce:.1f}, snr {c/ce:.2f}")
k = rows[:, 1] != 97
c = np.sum(rows[k, 4] * w[k]) / np.sum(w[k]); ce = 1 / np.sqrt(np.sum(w[k]))
print(f"all but S97: {c:.1f} +- {ce:.1f}, snr {c/ce:.2f}")

# Phase scramble: the same core-depth statistic at random phase offsets of the same period, away from the transit.
rng = np.random.default_rng(1)
offs = rng.uniform(0.1, 0.9, 2000) * eph.period
vals = []
for o in offs:
    e2 = Ephemeris(eph.period, eph.t0 + o, dur)
    p2 = phase_days(t, e2)
    c2 = np.abs(p2) < 0.25 * dur
    o2 = (np.abs(p2) > 0.75 * dur) & (np.abs(p2) < 2.5 * dur)
    vals.append(np.mean(f[o2]) - np.mean(f[c2]))
vals = np.array(vals) * 1e6
real = np.mean(f[oot]) - np.mean(f[core])
print(f"\nphase scramble (2000 offsets 0.1-0.9 P): mean {vals.mean():.1f} ppm, sd {vals.std():.1f} ppm; "
      f"real {real*1e6:.1f} ppm = {(real*1e6 - vals.mean())/vals.std():.2f} sd; fraction >= real {np.mean(vals >= real*1e6):.4f}")
