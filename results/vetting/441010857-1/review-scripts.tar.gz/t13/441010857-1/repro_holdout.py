"""Rebuild vet-v3's holdout inputs for 441010857-1 and test the season-1 refit."""
import json, os
import numpy as np
from astropy.timeseries import BoxLeastSquares
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.ephemeris import Ephemeris, phase_days, epoch_numbers
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.checks.photometry import red_noise_beta, with_red_noise, box_depth
from tess_hunt.checks.holdout import season_labels, refit_ephemeris, holdout
from tess_hunt.detrend import detrend

cs = load_criteria("criteria/search-v2.toml").values
cv = load_criteria("criteria/vet-v3.toml").values
chk = json.load(open(os.environ["VET_RUN"] + "/signals/441010857-1/checks.json"))
e = chk["ephemeris"]
eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
lc = good_timestamps(LightCurve.load(lc_dir() / "441010857.npz"))
flat = detrend(lc, cs["detrend"], [])
core = cv["depth"]["core_fraction"]
betas = red_noise_beta(flat, eph, core * eph.duration, cv["red_noise"])
noisy = with_red_noise(flat, betas)
h = holdout(noisy, eph, cv["holdout"], core, cv["families"]).to_dict()
print("holdout reproduced:", h["outcome"], h["reason"])
for s in h["evidence"]["seasons"]:
    print("  season", s["season"], s["status"], "P", s.get("predicted_period"), "t0", s.get("predicted_t0"), "depth", s.get("depth"), "n", s.get("n"))

# Coverage of each sector and of each possible transit (search ephemeris and the flat fit's median)
f = chk["fit"]
fit_eph = Ephemeris(f["period"]["median"], f["t0"]["median"], eph.duration, eph.depth)
print("fit ephemeris", fit_eph.period, fit_eph.t0)
for sec in np.unique(noisy.sector):
    m = noisy.sector == sec
    t = noisy.time[m]
    gaps = np.where(np.diff(t) > 0.25)[0]
    print(f"S{sec}: {t.min():.3f} to {t.max():.3f}, gaps >6h:", [(round(t[i],3), round(t[i+1],3)) for i in gaps])
    n0, n1 = int(np.ceil((t.min() - fit_eph.t0) / fit_eph.period)), int(np.floor((t.max() - fit_eph.t0) / fit_eph.period))
    for n in range(n0, n1 + 1):
        tc = fit_eph.t0 + n * fit_eph.period
        near = np.abs(t - tc)
        print(f"   epoch {n} at {tc:.4f}: cadences within 0.25 d {int((near < 0.25).sum())}, within half-duration {int((near < 0.5*eph.duration).sum())}, nearest {near.min()*24:.2f} h")

labels = season_labels(noisy.time, cv["holdout"]["season_gap_days"])
print("season labels by sector:", {int(s): sorted(set(labels[noisy.sector == s].tolist())) for s in np.unique(noisy.sector)})

# Season 1 held out: what the refit sees
train = noisy.select(labels != 1)
pred = refit_ephemeris(train, eph, cv["holdout"])
print("season-1 refit:", pred)
for n in (30, 31):
    tp, tf = pred.t0 + n * pred.period, fit_eph.t0 + n * fit_eph.period
    print(f"  epoch {n}: predicted {tp:.4f}, flat fit {tf:.4f}, offset {(tp-tf)*24:.2f} h; core half-width {0.5*core*pred.duration*24:.2f} h")
tr_tc = [fit_eph.t0 + n * fit_eph.period for n in range(-1, 70)]
tt = train.time
covered = [n for n, tc in zip(range(-1, 70), tr_tc) if (np.abs(tt - tc) < 0.5 * core * eph.duration).sum() > 0]
print("training epochs with core cadences at the flat-fit ephemeris:", covered)

# How flat is the refit's likelihood over its own period grid?
cfg = cv["holdout"]
baseline = float(train.time.max() - train.time.min())
hw = cfg["refit_resolutions"] * eph.period * eph.duration / max(baseline, eph.period)
periods = np.linspace(eph.period - hw, eph.period + hw, cfg["refit_points"])
durs = eph.duration * np.asarray(cfg["refit_duration_factors"], float)
r = BoxLeastSquares(train.time, train.flux, dy=train.flux_err).power(periods, durs, objective="likelihood")
best = r.power.max()
print(f"grid {periods[0]:.6f} to {periods[-1]:.6f}, best power {best:.3f}")
for d in (0.5, 1.0, 2.0):
    ok = r.power >= best - d
    pp = r.period[ok]
    tps = r.transit_time[ok] + 30 * r.period[ok]
    print(f"  periods within {d} of best log-likelihood: {ok.sum()} of {len(periods)}, P {pp.min():.6f} to {pp.max():.6f}, predicted epoch-30 time {tps.min():.4f} to {tps.max():.4f}")
i_true = np.argmin(np.abs(r.period - fit_eph.period))
print(f"  at the grid period nearest the flat fit ({r.period[i_true]:.6f}): power {r.power[i_true]:.3f}, best minus this {best - r.power[i_true]:.3f}")

# Season-1 depth at the flat-fit ephemeris, same core window and errors
s1 = labels == 1
for name, ep in (("flat fit", fit_eph), ("search", eph), ("holdout refit", pred)):
    d, er, n = box_depth(noisy.time[s1], noisy.flux[s1], noisy.flux_err[s1], Ephemeris(ep.period, ep.t0, eph.duration, eph.depth), core)
    print(f"season-1 core depth at the {name} ephemeris: {d*1e6:.0f} +- {er*1e6:.0f} ppm, n {n}, {d/er:.1f} sigma")
