"""Compare the rerun holdout with checks.json field by field (NaN read as null), and season 2's epoch-60 offset."""
import json, os, math
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.checks.families import good_timestamps
from tess_hunt.checks.photometry import red_noise_beta, with_red_noise
from tess_hunt.checks.holdout import holdout
from tess_hunt.detrend import detrend
cs = load_criteria("criteria/search-v2.toml").values; cv = load_criteria("criteria/vet-v3.toml").values
core = cv["depth"]["core_fraction"]; raw = LightCurve.load(lc_dir() / "441010857.npz")
def norm(o):
    if isinstance(o, dict): return {k: norm(v) for k, v in o.items()}
    if isinstance(o, list): return [norm(v) for v in o]
    if isinstance(o, float) and math.isnan(o): return None
    if isinstance(o, (np.floating,)): return norm(float(o))
    if isinstance(o, (np.integer,)): return int(o)
    return o
def diff(a, b, p=""):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in set(a) | set(b): diff(a.get(k, "<missing>"), b.get(k, "<missing>"), p + "." + k)
    elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for i, (x, y) in enumerate(zip(a, b)): diff(x, y, p + f"[{i}]")
    elif a != b: print("   differs", p, a, b)
for run, sus in (("VET_RUN", False), ("VET_SUSPECT_RUN", True)):
    chk = json.load(open(os.environ[run] + "/signals/441010857-1/checks.json"))
    e = chk["ephemeris"]; eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
    lc = raw if sus else good_timestamps(raw)
    flat = detrend(lc, cs["detrend"], [Ephemeris(**m) for m in chk["masked"]])
    noisy = with_red_noise(flat, red_noise_beta(flat, eph, core * eph.duration, cv["red_noise"]))
    mine = norm(json.loads(json.dumps(holdout(noisy, eph, cv["holdout"], core, chk["families"]).to_dict(), default=float)))
    stored = next(c for c in chk["checks"] if c["check"] == "holdout")
    print(run, "identical after NaN->null:", mine == stored); diff(mine, stored)
    if not sus:
        s2 = stored["evidence"]["seasons"][2]; f = chk["fit"]
        t60 = s2["predicted_t0"] + 60 * s2["predicted_period"]; f60 = f["t0"]["median"] + 60 * f["period"]["median"]
        print(f"  season 2 refit epoch 60 {t60:.5f}, flat fit {f60:.5f}, offset {(t60 - f60) * 1440:.2f} min")
