"""JSON screen of a vetting run: tested holdout seasons whose training seasons hold fewer than two transit-bearing
seasons, counting a season as transit-bearing when its own held-out row has n >= 5 core cadences."""
import json, os, sys, glob
run = os.environ[sys.argv[1]]
for f in sorted(glob.glob(run + "/signals/*/checks.json")):
    c = json.load(open(f)); name = f.split("/")[-2]
    h = next(x for x in c["checks"] if x["check"] == "holdout")
    seasons = h["evidence"]["seasons"]
    nmap = {s["season"]: s.get("n") for s in seasons}
    bearing = {k for k, v in nmap.items() if v is not None and v >= 5}
    unknown = {k for k, v in nmap.items() if v is None}
    rows = []
    for s in seasons:
        if s["status"] in ("predicted", "missed"):
            tr = [k for k in nmap if k != s["season"]]
            nb = len([k for k in tr if k in bearing])
            nu = len([k for k in tr if k in unknown])
            rows.append((s["season"], s["status"], s["training_seasons"], nb, nu))
    flag = [r for r in rows if r[3] < 2]
    print(f"{name:14s} holdout {h['outcome']:12s} season n {nmap}  tested (season,status,training,bearing,unknown) {rows}{'  <-- one-bearing' if flag else ''}")
