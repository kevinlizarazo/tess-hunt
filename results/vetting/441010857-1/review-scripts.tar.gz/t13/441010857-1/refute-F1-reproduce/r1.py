"""Refuter 1, F1 of 441010857-1: rebuild vet.py's holdout inputs for both runs and recompute F1's numbers."""
import json, os, sys
import numpy as np
from astropy.timeseries import BoxLeastSquares
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.ephemeris import Ephemeris, in_transit
from tess_hunt.checks.families import good_timestamps
from tess_hunt.checks.photometry import red_noise_beta, with_red_noise, box_depth
from tess_hunt.checks.holdout import season_labels, refit_ephemeris, holdout
from tess_hunt.detrend import detrend

cs = load_criteria("criteria/search-v2.toml").values
cv = load_criteria("criteria/vet-v3.toml").values
H = cv["holdout"]; core = cv["depth"]["core_fraction"]
raw = LightCurve.load(lc_dir() / "441010857.npz")

def build(run, suspect):
    chk = json.load(open(os.environ[run] + "/signals/441010857-1/checks.json"))
    e = chk["ephemeris"]; eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
    lc = raw if suspect else good_timestamps(raw)
    flat = detrend(lc, cs["detrend"], [Ephemeris(**m) for m in chk["masked"]])
    noisy = with_red_noise(flat, red_noise_beta(flat, eph, core * eph.duration, cv["red_noise"]))
    return chk, eph, noisy

for run, suspect in (("VET_RUN", False), ("VET_SUSPECT_RUN", True)):
    chk, eph, lc = build(run, suspect)
    f = chk["fit"]; fit = Ephemeris(f["period"]["median"], f["t0"]["median"], eph.duration, eph.depth)
    print(f"===== {run}: sectors {sorted(set(lc.sector.tolist()))}, n {len(lc.time)}")
    mine = holdout(lc, eph, H, core, chk["families"]).to_dict()
    stored = next(c for c in chk["checks"] if c["check"] == "holdout")
    same = json.dumps(mine, sort_keys=True, default=float) == json.dumps(stored, sort_keys=True, default=float)
    print("holdout rerun identical to checks.json:", same, "|", mine["outcome"], mine["reason"])
    if not same:
        for a, b in zip(mine["evidence"]["seasons"], stored["evidence"]["seasons"]):
            print("  mine", a.get("status"), a.get("predicted_period"), a.get("depth"), " stored", b.get("status"), b.get("predicted_period"), b.get("depth"))
    labels = season_labels(lc.time, H["season_gap_days"])
    # per sector: span, gaps > 0.25 d, and core cadences at each epoch of the flat fit
    hw_core = 0.5 * core * eph.duration
    for sec in sorted(set(lc.sector.tolist())):
        t = np.sort(lc.time[lc.sector == sec])
        g = np.where(np.diff(t) > 0.25)[0]
        print(f" S{sec} season {sorted(set(labels[lc.sector == sec].tolist()))}: {t.min():.3f} to {t.max():.3f}, gaps", [(round(t[i], 3), round(t[i + 1], 3)) for i in g])
        for n in range(int(np.floor((t.min() - fit.t0) / fit.period)), int(np.ceil((t.max() - fit.t0) / fit.period)) + 1):
            tc = fit.t0 + n * fit.period
            d = np.abs(t - tc)
            print(f"   epoch {n} at {tc:.4f}: core cadences {(d < hw_core).sum()}, full-duration {(d < 0.5 * eph.duration).sum()}, nearest {d.min() * 24:.1f} h")
    # season 1 held out
    train = lc.select(labels != 1)
    print(" season-1 training seasons:", sorted(set(labels[labels != 1].tolist())))
    pred = refit_ephemeris(train, eph, H)
    print(f" season-1 refit: P {pred.period:.6f}, t0 {pred.t0:.4f}, duration {pred.duration:.5f}, core half-width {0.5 * core * pred.duration * 24:.3f} h")
    base = float(train.time.max() - train.time.min())
    hw = H["refit_resolutions"] * eph.period * eph.duration / max(base, eph.period)
    P = np.linspace(eph.period - hw, eph.period + hw, H["refit_points"])
    r = BoxLeastSquares(train.time, train.flux, dy=train.flux_err).power(P, eph.duration * np.asarray(H["refit_duration_factors"]), objective="likelihood")
    best = r.power.max(); ib = int(np.argmax(r.power))
    print(f" grid {P[0]:.6f} to {P[-1]:.6f} ({len(P)}), best at index {ib} P {r.period[ib]:.6f}")
    for dl in (0.5, 1.0, 2.0):
        ok = r.power >= best - dl
        t30 = r.transit_time[ok] + 30 * r.period[ok]
        t60 = r.transit_time[ok] + 60 * r.period[ok]
        print(f"  within {dl} of best: {ok.sum()} periods, P {r.period[ok].min():.6f} to {r.period[ok].max():.6f}, epoch-30 {t30.min():.3f} to {t30.max():.3f}, epoch-60 {t60.min():.4f} to {t60.max():.4f}")
    j = int(np.argmin(np.abs(P - fit.period)))
    print(f"  at grid P nearest the flat fit {P[j]:.6f}: best minus power {best - r.power[j]:.3f}")
    # which training epochs carry core cadences under the refit itself
    for n in range(-2, 110):
        tc = pred.t0 + n * pred.period
        k = (np.abs(train.time - tc) < 0.5 * core * pred.duration).sum()
        if k: print(f"  training epoch {n} at {tc:.4f}: {k} core cadences under the refit")
    for n in (30, 31):
        tp, tf = pred.t0 + n * pred.period, fit.t0 + n * fit.period
        print(f"  epoch {n}: refit {tp:.4f}, flat fit {tf:.4f}, offset {(tp - tf) * 24:.2f} h")
    s1 = labels == 1
    for name, ep in (("flat fit", fit), ("refit", pred)):
        d, er, n = box_depth(lc.time[s1], lc.flux[s1], lc.flux_err[s1], Ephemeris(ep.period, ep.t0, eph.duration, eph.depth), core)
        print(f"  season-1 core depth at {name} (search duration): {d * 1e6:.0f} +- {er * 1e6:.0f} ppm, n {n}, {d / er:.1f} sigma")
    d, er, n = box_depth(lc.time[s1], lc.flux[s1], lc.flux_err[s1], pred, core)
    print(f"  season-1 core depth at refit (its own duration, as the check): {d * 1e6:.0f} +- {er * 1e6:.0f} ppm, n {n}")
