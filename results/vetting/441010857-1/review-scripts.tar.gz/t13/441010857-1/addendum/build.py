"""Builds the 0034/0035 addendum for 441010857-1's review from the old review.json."""
import json
from pathlib import Path

old = json.loads(Path("/tmp/t13/out/441010857-1/review.json").read_text())
f1, f2 = (dict(f) for f in old["findings"])
assert old["summary"].startswith("vet-v3 killed this signal on holdout and density. The holdout fail is an artefact: ")

s_old2 = ("The holdout fail is an artefact: S11's only transit sits in its mid-sector gap, so season 1 was predicted from "
          "one transit in S64, the case decision 0004's training-season guard exists to stop, and at the fitted ephemeris "
          "season 1 holds an 11.8 sigma transit.")
s3 = old["summary"].split(s_old2 + " ")[1]
summary = ("vet-v3 kills this signal on density; the first runs also failed it on holdout. That holdout fail was an "
           "artefact: S11's only transit sits in its mid-sector gap, so season 1 was predicted from one transit in S64, "
           "the case decision 0004's training-season guard exists to stop, and at the fitted ephemeris season 1 holds an "
           "11.8 sigma transit. Decision 0035 fixed the check, and on the rerun holdout is inconclusive. "
           + s3 + " Updated 2026-10-21 for the 0034/0035 rerun.")
assert old["summary"] == "vet-v3 killed this signal on holdout and density. " + s_old2 + " " + s3

r1 = {
    "id": "F1", "lens": f1["lens"], "rating": "note",
    "claim": ("On the first runs (vetting 20261020T010149Z-vetting-run-62882b5-c3ee and its evidence-only twin "
              "20261020T011247Z-vetting-run-62882b5-d92b) this finding reported that the holdout kill was wrong, because "
              "S11 counted as a training season though its only transit falls in its data gap, so season 1 was predicted "
              "from S64's single transit and missed; decision 0035 fixed the check, and on the rerun holdout is "
              "inconclusive and kills nothing."),
    "evidence": ("Original claim: \"" + f1["claim"] + "\" Both refuters reproduced it and neither refuted it. Decision 0035 "
                 "(docs/decisions/0035-holdout-training-seasons.md) counts a training season only when its own cadences "
                 "hold at least min_points cadences inside the transits predicted at the check's input ephemeris. Rerun "
                 "vetting 20261020T174317Z-vetting-run-61b5944-2d70 (signals/441010857-1/checks.json, holdout): "
                 "inconclusive, \"0 season(s) could be tested; need 2\". Season 0 (S11, BTJD 1601.391 to 1623.349) is "
                 "no_predicted_transit_in_data with n 0 and training_seasons_with_transits 2. Seasons 1 and 2 are "
                 "untestable, training_seasons 2 and training_seasons_with_transits 1, reason \"1 of 2 training seasons "
                 "hold a transit in their data, need 2: one season can't predict a season a year away\"; season 1's "
                 "missed refit (P 24.04896, t0 1614.1389, depth 342 ppm, n 8) is gone. Evidence-only rerun "
                 "20261020T175536Z-vetting-run-61b5944-7f4e: inconclusive with the same reason, seasons 1 and 2 "
                 "untestable (1 of 3 training seasons hold a transit), seasons 0 and 3 (S102) "
                 "no_predicted_transit_in_data. The dossier (drafts/m3-r2/441010857-1/dossier.md) shows holdout "
                 "inconclusive in both vets. An inconclusive kills nothing (decision 0028); the density fail still kills "
                 "the signal (F2)."),
    "status": "resolved",
    "why": ("Diffed old and new checks.json and checks-with-suspect.json field by field (addendum/leafdiff.py, drafts m3 "
            "against m3-r2, which match the two rerun vetting runs): holdout's season 1 refit is gone, seasons 1 and 2 "
            "are untestable under 0035 and the outcome is inconclusive in both vets, so what F1 reported is fixed."),
}

old_sep = "(the 10.4 arcsec Gaia DR3 6122183689530020736,"
assert f2["evidence"].count(old_sep) == 1
r2 = {
    "id": "F2", "lens": f2["lens"], "rating": f2["rating"], "claim": f2["claim"],
    "evidence": (f2["evidence"].replace(old_sep, "(the 9.8 arcsec Gaia DR3 6122183689530020736,")
                 + " Updated 2026-10-21 for the 0034/0035 rerun: the neighbour's separation, now measured from the "
                 "target's Gaia DR3 position at J2016.0 (decision 0034; rerun checks.json neighbours centre \"Gaia DR3 "
                 "6122183689530591488, J2016.0\"), 10.4 arcsec to 9.8 arcsec (sep_arcsec 10.391 to 9.773)."),
    "status": "updated",
    "why": ("Reran repro_density.py with VET_RUN set to 20261020T174317Z-vetting-run-61b5944-2d70 "
            "(addendum/repro_density_new.out: tension 3.577, percentiles 0.439/0.678/1.127/1.670, 19.7%, 270 cadences, "
            "chi2 307.86, 333.79, 390.09 all match) and addendum/durations.py on its checks.json (a/R* 24.4, T14 7.85 h, "
            "5.95 h, 1.29 h; the 112.7 comes from the rounded median 1.670, 112.65 unrounded, the same on both runs); "
            "read its star, fit, fit_prior, red_noise, signal_present and density fields; fit_samples.npz, "
            "fit_prior_samples.npz and the draft's plots/transits.png are byte-identical to the old run's; "
            "neighbours.csv moves the 4.17% (BP-RP 1.64) host from 10.39 to 9.77 arcsec, which I recomputed from both "
            "stars' Gaia DR3 positions (addendum/dr3_pair.csv)."),
}

out = {"signal": old["signal"], "summary": summary, "findings": [r1, r2], "hits_flagged": old["hits_flagged"]}
Path("/tmp/t13/441010857-1/addendum/findings.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out))
