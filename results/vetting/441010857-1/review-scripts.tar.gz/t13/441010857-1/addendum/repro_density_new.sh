#!/bin/bash
# repro_density.py, unchanged, pointed at the rerun's vetting run
cd ~/code/tess-hunt
export VET_RUN=$TESS_HUNT_DATA/runs/20261020T174317Z-vetting-run-61b5944-2d70
uv run python /tmp/t13/441010857-1/repro_density.py
