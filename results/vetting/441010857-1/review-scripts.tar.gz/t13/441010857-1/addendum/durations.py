"""F2's durations from the rerun's checks.json: a/R* from density (a_rs_from_density, g/cm3), circular T14."""
import json, sys
import numpy as np
from tess_hunt.transit import a_rs_from_density
d = json.load(open(sys.argv[1]))
P = d["fit"]["period"]["median"]; k = d["fit"]["rp_rs"]["median"]
den = next(c for c in d["checks"] if c["check"] == "density")["evidence"]
def t14(a, b):
    return P / np.pi * np.arcsin(np.sqrt((1 + k) ** 2 - b ** 2) / (a * np.sqrt(1 - (b / a) ** 2))) * 24
print("P", round(P, 6), "k", round(k, 4))
for name, rho in (("TIC", den["tic_rho_gcc"]), ("flat median", den["fit_rho_gcc"])):
    a = a_rs_from_density(rho, P)
    print(f"{name}: rho {rho:.3f} g/cm3, a/R* {a:.1f}, T14 b0 {t14(a,0):.2f} h, b0.68 {t14(a,0.68):.2f} h")
