"""441010857-1: the density check's posterior, the likelihood at the TIC density, and the eccentricity it would take."""
import json, os
import numpy as np
from scipy.optimize import minimize
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.ephemeris import Ephemeris, phase_days
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.fit import NAMES
from tess_hunt.transit import a_rs_from_density, light_curve

run = os.environ["VET_RUN"] + "/signals/441010857-1/"
chk = json.load(open(run + "checks.json"))
cs = load_criteria("criteria/search-v2.toml").values
cv = load_criteria("criteria/vet-v3.toml").values
e = chk["ephemeris"]
eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
log_tic = chk["checks"][7]["evidence"]["tic_log_rho"]
assert chk["checks"][7]["check"] == "density"

flat_s = np.load(run + "fit_samples.npz")["samples"]
prior_s = np.load(run + "fit_prior_samples.npz")["samples"]
lr, b, k = flat_s[:, 4], flat_s[:, 3], flat_s[:, 2]
print("flat-fit samples", flat_s.shape)
print("log_rho percentiles 0.15/2.5/16/50/84/97.5:", np.round(np.percentile(lr, [0.15, 2.5, 16, 50, 84, 97.5]), 3))
print("fraction of samples with log_rho above 1.9 (prior bound 2.0):", round(float(np.mean(lr > 1.9)), 3))
for thr in (log_tic, 0.0, 0.5, 1.0):
    m = lr < thr
    print(f"P(log_rho < {thr:.3f}) = {m.mean():.5f}; b of those, median {np.median(b[m]) if m.any() else float('nan'):.3f}")
print("grazing fraction (b + k > 1):", round(float(np.mean(b + k > 1)), 4))

def emin(ratio_dex):
    g = 10 ** (ratio_dex / 3)
    return (g**2 - 1) / (g**2 + 1)
mid, lo = np.percentile(lr, 50), np.percentile(lr, 16)
sd = np.hypot(mid - lo, chk["checks"][7]["evidence"]["tic_log_rho_sd"])
print(f"tension recomputed {abs(mid-log_tic)/sd:.3f}")
print("minimum e (omega 90 deg) to reach the TIC density from:")
for name, val in (("median", mid), ("16th pct", lo), ("2.5th pct", np.percentile(lr, 2.5)), ("check's 3-sigma line", mid - 3 * sd)):
    print(f"  {name}: log_rho {val:.3f}, rho_circ/rho_tic {10**(val-log_tic):.2f}, e_min {emin(max(val-log_tic,0)):.3f}")

# Rebuild the fit's light curve (PDCSAP family, no suspect sectors, same window)
lc = good_timestamps(LightCurve.load(lc_dir() / "441010857.npz"))
flat = detrend(lc, cs["detrend"], [])
fit_lc = split(flat, cv["families"])["pdcsap"]
near = np.abs(phase_days(fit_lc.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, er, ex = fit_lc.time[near], fit_lc.flux[near], fit_lc.flux_err[near], fit_lc.exposure_days()[near]
print("fit cadences", len(t), "sectors", np.unique(fit_lc.sector[near]))

def chi2(theta):
    t0, P, kk, bb, lrho, q1, q2 = theta
    if not (0.001 < kk < 1 and 0 <= bb < 1 + kk and 0 < q1 < 1 and 0 < q2 < 1 and -3 < lrho < 2):
        return 1e12
    a = a_rs_from_density(10**lrho, P)
    if bb >= a:
        return 1e12
    u1, u2 = 2 * np.sqrt(q1) * q2, np.sqrt(q1) * (1 - 2 * q2)
    return float(np.sum(((f - light_curve(t, ex, t0, P, kk, a, bb, u1, u2)) / er) ** 2))

rng = np.random.default_rng(0)
best = {}
for name, s in (("flat", flat_s), ("prior", prior_s)):
    idx = rng.choice(len(s), 3000, replace=False)
    c = np.array([chi2(s[i]) for i in idx])
    j = idx[np.argmin(c)]
    best[name] = s[j]
    print(f"{name}-fit samples: min chi2 {c.min():.2f} at", dict(zip(NAMES, np.round(s[j], 4))))
null = float(np.sum(((f - 1) / er) ** 2))
print("chi2 of no transit", round(null, 2))

# Best fit with log_rho held at the TIC value, from grazing and non-grazing starts
def fixed(x, lrho):
    t0, P, kk, bb, q1, q2 = x
    return chi2([t0, P, kk, bb, lrho, q1, q2])
starts = {
    "non-grazing (b 0.9, k 0.045)": [eph.t0, eph.period, 0.045, 0.9, 0.3, 0.3],
    "near-grazing (b 1.0, k 0.06)": [eph.t0, eph.period, 0.06, 1.0, 0.3, 0.3],
    "prior-fit best": list(best["prior"][[0, 1, 2, 3, 5, 6]]),
}
for name, x0 in starts.items():
    r = minimize(fixed, x0, args=(log_tic,), method="Nelder-Mead", options={"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4})
    print(f"TIC density fixed, start {name}: chi2 {r.fun:.2f}, b {r.x[3]:.3f}, k {r.x[2]:.4f}, b+k {r.x[3]+r.x[2]:.3f}")
r = minimize(chi2, best["flat"], method="Nelder-Mead", options={"maxiter": 40000, "maxfev": 40000, "xatol": 1e-7, "fatol": 1e-4})
print(f"free density from flat-fit best: chi2 {r.fun:.2f}, log_rho {r.x[4]:.3f}, b {r.x[3]:.3f}, k {r.x[2]:.4f}")
# Non-grazing ceiling: best chi2 at the TIC density with b + k <= 1
def ng(x):
    t0, P, kk, bb, q1, q2 = x
    return fixed(x, log_tic) if bb + kk <= 1 else 1e12
r = minimize(ng, [eph.t0, eph.period, 0.042, 0.94, 0.3, 0.3], method="Nelder-Mead", options={"maxiter": 20000, "maxfev": 20000})
print(f"TIC density, non-grazing only: chi2 {r.fun:.2f}, b {r.x[3]:.3f}, k {r.x[2]:.4f}")
