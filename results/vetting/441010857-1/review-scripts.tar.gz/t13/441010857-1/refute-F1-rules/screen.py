import json, os, sys
run = sys.argv[1]
for name in sorted(os.listdir(f"{run}/signals")):
    d = json.load(open(f"{run}/signals/{name}/checks.json"))
    h = next(c for c in d["checks"] if c["check"] == "holdout")
    seasons = h["evidence"]["seasons"]
    bearing = {s["season"] for s in seasons if (s.get("n") or 0) >= 5}
    out = []
    for s in seasons:
        if s["status"] in ("predicted", "missed"):
            tb = len(bearing - {s["season"]})
            out.append((s["season"], s["status"], s["training_seasons"], tb))
    flag = any(tb < 2 for *_, tb in out)
    print(name, h["outcome"], "bearing", sorted(bearing), "tested", out, "<- one-bearing-season training" if flag else "")
