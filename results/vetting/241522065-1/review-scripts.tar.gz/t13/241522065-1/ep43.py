"""Coverage, gaps, raw and flattened flux around each primary event of 241522065-1 (fit_prior ephemeris), and the
SPOC quality flags and momentum dumps from the FFI pixel time series (second list's tdi pickles)."""
import json, pickle, sys
from pathlib import Path
import numpy as np
from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

RUN, TDI = Path(sys.argv[1]), Path(sys.argv[2])
checks = json.loads((RUN / "signals/241522065-1/checks.json").read_text())
crit = load_criteria("criteria/search-v2.toml")
lc = LightCurve.load(Path.home() / ".cache/tess-hunt/lc/241522065.npz")
print("LightCurve fields:", [k for k in vars(lc)])
fp = checks["fit_prior"]
P, t0 = fp["ephemeris"]["period"]["median"], fp["ephemeris"]["t0"]["median"]
dur = checks["window_duration"]["days"]
flat = detrend(lc.select(~np.isin(lc.sector, checks["dropped_suspect"])), crit["detrend"], [])
for s in sorted(set(lc.sector.tolist())):
    m = lc.sector == s
    t = lc.time[m]
    gaps = np.where(np.diff(t) > 0.1)[0]
    print(f"S{s}: {t.min():.3f}-{t.max():.3f}, gaps>0.1d {[(round(t[i],3), round(t[i+1],3)) for i in gaps]}")
for n in (0, 1, 41, 42, 43):
    tc = t0 + n * P
    m = np.abs(flat.time - tc) < dur / 2
    s = int(flat.sector[m][0])
    tt = flat.time[np.abs(flat.time - tc) < dur]
    gaps = np.diff(tt)
    big = np.where(gaps > 2.5 * np.median(gaps))[0]
    print(f"\nepoch {n} S{s} tc {tc:.4f}: in-window {m.sum()}; gaps within +-1 dur: "
          f"{[(round(tt[i],4), round(tt[i+1],4), round(gaps[i]*1440)) for i in big]}")
    # binned flattened flux, 30-min bins across +-0.4 d
    edges = np.arange(-0.4, 0.4001, 1 / 48)
    rel = flat.time - tc
    row = []
    for a, b in zip(edges[:-1], edges[1:]):
        k = (rel >= a) & (rel < b)
        row.append("%+.2f:%s" % ((a + b) / 2, ("%5.0f" % ((flat.flux[k].mean() - 1) * 1e6)) if k.sum() else "   --"))
    print("  30-min bins (d: ppm):", " ".join(row))
for s in (64, 65):
    with open(TDI / f"imageData_241522065.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, *_ = pickle.load(fh)
    t, q = np.asarray(pix["time"]), np.asarray(pix["quality"]).astype(int)
    dumps = t[(q & 32) != 0]
    print(f"\nS{s} FFI cadences {len(t)}; momentum dumps {np.round(dumps,3).tolist()}")
    for n in (41, 42, 43):
        tc = t0 + n * P
        if not (t.min() - 0.5 < tc < t.max() + 0.5):
            continue
        w = np.abs(t - tc) < dur / 2 + 0.25
        flags = sorted(set(q[w][q[w] != 0].tolist()))
        print(f"   epoch {n} at {tc:.3f}: flagged in window +-0.25 d {np.sum(q[w] != 0)} (flags {flags}); "
              f"nearest dump {np.min(np.abs(dumps - tc)):.3f} d")
