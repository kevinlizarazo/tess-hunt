"""TIC rows for the target and the ARTIFACT 241522064 (MAST, public), and the Gaia DR3 sources near the artifact's
position from the draft's neighbours.csv."""
import csv, math, sys
from astroquery.mast import Catalogs
t = Catalogs.query_criteria(catalog="Tic", ID=[241522065, 241522064])
cols = ["ID", "disposition", "objType", "typeSrc", "ra", "dec", "RA_orig", "Dec_orig", "epoch", "Tmag", "Jmag", "Hmag",
        "Kmag", "Vmag", "GAIA", "GAIAmag", "TWOMASS", "TWOMflag", "contratio", "pmRA", "pmDEC", "dstArcSec"]
for r in t:
    print({c: (r[c] if c in t.colnames else None) for c in cols})
a = [r for r in t if str(r["ID"]) == "241522064"][0]
g = [r for r in t if str(r["ID"]) == "241522065"][0]
dec0 = math.radians(g["dec"])
sep = math.hypot((a["ra"] - g["ra"]) * math.cos(dec0) * 3600, (a["dec"] - g["dec"]) * 3600)
pa = math.degrees(math.atan2((a["ra"] - g["ra"]) * math.cos(dec0), a["dec"] - g["dec"])) % 360
print(f"artifact vs target (TIC ra/dec): sep {sep:.2f}\", PA {pa:.0f} deg")
for row in csv.DictReader(open(sys.argv[1])):
    ra, de = float(row["ra"]), float(row["dec"])
    d = math.hypot((ra - a["ra"]) * math.cos(dec0) * 3600, (de - a["dec"]) * 3600)
    if d < 10:
        print("Gaia DR3 within 10\" of the artifact:", row["source_id"], "G", row["phot_g_mean_mag"], f"{d:.2f}\"")
