"""Pixel fits of 241522065-1 (E, N, quality per sector from /tmp/pixel-diag/summary_second.txt) against the
TRICERATOPS NFPP carriers (positions from tric.txt): all five sectors, and S64 and S65 alone (not timing-suspect)."""
import math
fits = {102: (-0.5, 4.2, 0.81), 101: (-10.1, -14.0, 0.52), 99: (2.3, -0.3, 0.90), 65: (3.1, -4.8, 0.62), 64: (-17.2, 1.6, 0.40)}
hosts = {"241522102": (-12.4, -34.9), "241522037": (-6.1, 32.8), "241522032": (-32.7, 37.0), "241522126": (-5.6, -71.2)}
for label, secs in (("all five", [102, 101, 99, 65, 64]), ("S64+S65", [64, 65])):
    w = sum(fits[s][2] for s in secs)
    E = sum(fits[s][0] * fits[s][2] for s in secs) / w
    N = sum(fits[s][1] * fits[s][2] for s in secs) / w
    rms = math.sqrt(sum((fits[s][0] - E) ** 2 + (fits[s][1] - N) ** 2 for s in secs) / len(secs))
    se = rms / math.sqrt(len(secs))
    print(f"{label}: mean E {E:+.1f} N {N:+.1f} ({math.hypot(E, N):.1f}\" from target, {math.hypot(E, N) / se:.1f} SE); "
          f"sky scatter {rms:.1f}\", SE {se:.1f}\"")
    for h, (hE, hN) in hosts.items():
        dd = math.hypot(hE - E, hN - N)
        print(f"   TIC {h}: {dd:.1f}\" from the mean, {dd / se:.1f} SE")
    print("   ARTIFACT 241522064 (E -7.4, N +0.4):", f"{math.hypot(-7.42 - E, 0.39 - N):.1f}\" from the mean")
