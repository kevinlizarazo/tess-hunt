"""241522065-1's TRICERATOPS record: who carries NFPP and FPP in probs.csv (the last of the 10 runs), and the share of
the bound-companion scenarios that put the dip on the companion."""
import csv, json, math, sys
D = sys.argv[1]
d = json.load(open(f"{D}/triceratops.json"))
e = d["evidence"]
print("mean FPP", e["fpp_mean"], "sd", e["fpp_sd"], "| mean NFPP", e["nfpp_mean"], "sd", e["nfpp_sd"])
print("dropped_stars", [(s["ID"], s["disposition"], s["duplicate_id"]) for s in e["dropped_stars"]])
rows = list(csv.DictReader(open(f"{D}/probs.csv")))
p = {}
for r in rows:
    p[(r["ID"], r["scenario"])] = float(r["prob"])
tgt = "241522065"
sc = lambda *names: sum(p.get((tgt, n), 0) for n in names)
nfpp = sum(v for (i, s), v in p.items() if s in ("NTP", "NEB", "NEBx2P"))
print(f"last run: NFPP {nfpp:.3g}; FPP {1 - sc('TP', 'PTP', 'DTP'):.4f}")
for n in ("TP", "PTP", "DTP", "STP", "SEB", "SEBx2P", "BTP", "BEB", "BEBx2P", "EB", "EBx2P", "PEB", "PEBx2P", "DEB", "DEBx2P"):
    print(f"   {n} {sc(n):.3g}")
P = sc("PTP", "PEB", "PEBx2P")
S = sc("STP", "SEB", "SEBx2P")
print(f"bound-companion scenarios: P {P:.4f}, S {S:.4f}; S share {S / (P + S):.3f}; SEB+SEBx2P share {sc('SEB', 'SEBx2P') / (P + S):.4f}")
st = {s["ID"]: s for s in e["stars"]}
t = e["stars"][0]
by = {}
for (i, s), v in p.items():
    if s in ("NTP", "NEB", "NEBx2P"):
        by[i] = by.get(i, 0) + v
for i, v in sorted(by.items(), key=lambda x: -x[1]):
    s = st[i]
    dE = (s["ra"] - t["ra"]) * math.cos(math.radians(t["dec"])) * 3600
    dN = (s["dec"] - t["dec"]) * 3600
    print(f"   TIC {i}: NFPP share {v / nfpp:.3f} ({v:.2g}), sep {math.hypot(dE, dN):.1f}\" (E {dE:+.1f}, N {dN:+.1f}), "
          f"T {s['Tmag']}, tdepth {s['tdepth']:.4f}")
near = [(math.hypot((s["ra"] - t["ra"]) * math.cos(math.radians(t["dec"])) * 3600, (s["dec"] - t["dec"]) * 3600), s)
        for s in e["stars"][1:]]
print("kept stars within 30\" with tdepth > 0:", [(s["ID"], round(r, 1)) for r, s in near if r < 30 and s["tdepth"] > 0])
print("nearest kept star:", min(near, key=lambda x: x[0])[0])
