"""Unflattened PDCSAP flux around epochs 41, 42 and 43 of 241522065-1: 30-min bins relative to the median of the
pre-ingress stretch -0.40 to -0.10 d, with a line fit to -0.6 to -0.1 d to show the local slope."""
import json, sys
from pathlib import Path
import numpy as np
from tess_hunt.lightcurve import LightCurve
checks = json.loads((Path(sys.argv[1]) / "signals/241522065-1/checks.json").read_text())
fp = checks["fit_prior"]["ephemeris"]
P, t0 = fp["period"]["median"], fp["t0"]["median"]
lc = LightCurve.load(Path.home() / ".cache/tess-hunt/lc/241522065.npz")
for n in (41, 42, 43):
    tc = t0 + n * P
    rel = lc.time - tc
    w = np.abs(rel) < 0.8
    pre = (rel > -0.6) & (rel < -0.1)
    c = np.polyfit(rel[pre], lc.flux[pre], 1)
    base = np.polyval(c, rel)
    out = []
    for a in np.arange(-0.4, 0.4, 1 / 24):
        k = w & (rel >= a) & (rel < a + 1 / 24)
        out.append("%+.2f:%s" % (a + 1 / 48, ("%5.0f" % ((np.mean(lc.flux[k] / base[k]) - 1) * 1e6)) if k.sum() else "   --"))
    inn = w & (np.abs(rel) < 0.084)
    print(f"epoch {n} tc {tc:.3f}: pre-ingress slope {c[0] * 1e6:.0f} ppm/d; in-transit mean vs pre-ingress line "
          f"{(np.mean(lc.flux[inn] / base[inn]) - 1) * 1e6:.0f} ppm over {inn.sum()} cadences")
    print("   1-h bins:", " ".join(out))
