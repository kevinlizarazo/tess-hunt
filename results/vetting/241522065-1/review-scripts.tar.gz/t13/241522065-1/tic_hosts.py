"""TIC rows (MAST, public) for the stars TRICERATOPS weighs as hosts of 241522065-1: the NFPP carriers and the two
bright giants that could make the depth but get almost no weight."""
from astroquery.mast import Catalogs

ids = [241522102, 241522037, 241522032, 241522126, 241522097, 241522028]
t = Catalogs.query_criteria(catalog="Tic", ID=ids)
for r in t:
    print(r["ID"], "Tmag", r["Tmag"], "Teff", r["Teff"], "rad", r["rad"], "mass", r["mass"], "logg", r["logg"],
          r["lumclass"], "plx", r["plx"], "+-", r["e_plx"], "d", r["d"], "disposition", r["disposition"], "GAIA", r["GAIA"])
