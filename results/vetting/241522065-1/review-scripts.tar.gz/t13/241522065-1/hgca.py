"""HIP 67102 in the HGCA EDR3 (hgca.tsv, saved from VizieR J/ApJS/254/42/catalog): the chi-square's significance for
2 degrees of freedom, each proper-motion component's difference, and the tangential-velocity change it implies."""
import math
from scipy import stats

rows = [l.split("\t") for l in open("/tmp/t13/241522065-1/hgca.tsv") if l.strip() and not l.startswith("#")]
head, data = rows[0], rows[-1]
r = {k.strip(): v.strip() for k, v in zip(head, data)}
f = lambda k: float(r[k])
chi2 = f("chi2")
p = stats.chi2.sf(chi2, 2)
print(f"chi2 {chi2}: p {p:.2e}, {stats.norm.isf(p / 2):.2f} sigma; 3 sigma is chi2 {stats.chi2.isf(2 * stats.norm.sf(3), 2):.2f}")
dra, dde = f("pmRAhg") - f("pmRA"), f("pmDEhg") - f("pmDE")
print(f"pmRA HG - Gaia {dra:+.3f} ({dra / math.hypot(f('e_pmRAhg'), f('e_pmRA')):+.1f} sigma); "
      f"pmDE {dde:+.3f} ({dde / math.hypot(f('e_pmDEhg'), f('e_pmDE')):+.1f} sigma)")
print(f"tangential velocity change at plx 10.1419 mas: {math.hypot(dra, dde) / 10.1419 * 4.74047 * 1000:.0f} m/s")
