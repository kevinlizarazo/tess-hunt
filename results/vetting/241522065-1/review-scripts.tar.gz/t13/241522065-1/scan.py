"""241522065-1: per-event primary depths, the ModShift phases, a dip scan over phase, odd/even by event, and the
5.58 d second signal, on the light curve rebuilt as the checks rebuild it (PDCSAP 38, 64, 65) and on all six sectors."""

import json
import sys
from pathlib import Path

import numpy as np

from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

RUN = Path(sys.argv[1])
checks = json.loads((RUN / "signals/241522065-1/checks.json").read_text())
crit = load_criteria("criteria/search-v2.toml")
lc = LightCurve.load(Path.home() / ".cache/tess-hunt/lc/241522065.npz")
fp = checks["fit_prior"]
P = fp["ephemeris"]["period"]["median"]
t0 = fp["ephemeris"]["t0"]["median"]
dur = checks["window_duration"]["days"]
es = checks["ephemeris"]
ms = checks["modshift"]
print(f"fit_prior P {P:.6f} t0 {t0:.4f} dur {dur:.4f}; search P {es['period']:.6f} t0 {es['t0']:.4f} dur {es['duration']}")
# ModShift phases are on the search ephemeris (LEO's epo = search t0); convert to the fit's phase.
off = (es["t0"] - t0) / P
print("phase offset of search t0 from fit t0:", round(off, 5))


def flat_of(drop):
    seen = lc.select(~np.isin(lc.sector, drop))
    return detrend(seen, crit["detrend"], [Ephemeris(**m) for m in checks["masked"]])


def box(time, flux, tc, half):
    dt = time - tc
    inn = np.abs(dt) < half
    out = (np.abs(dt) > 1.5 * dur) & (np.abs(dt) < 1.5 * dur + 0.5)
    if inn.sum() < 5 or out.sum() < 10:
        return None
    d = np.median(flux[out]) - np.mean(flux[inn])
    err = np.std(flux[out]) / np.sqrt(inn.sum())
    return d * 1e6, err * 1e6, int(inn.sum())


def events(flat, phase, per=P, ref=t0, half=None):
    half = dur / 2 if half is None else half
    rows = []
    n0 = int(np.floor((flat.time.min() - ref) / per)) - 1
    n1 = int(np.ceil((flat.time.max() - ref) / per)) + 1
    for n in range(n0, n1 + 1):
        tc = ref + (n + phase) * per
        r = box(flat.time, flat.flux, tc, half)
        if r is None:
            continue
        m = np.abs(flat.time - tc) < half
        rows.append((n, round(tc, 3), int(flat.sector[m][0]), r[2], r[0], r[1]))
    return rows


def combined(rows):
    if not rows:
        return np.nan, np.nan
    d = np.array([r[4] for r in rows])
    w = 1 / np.array([r[5] for r in rows]) ** 2
    return np.sum(d * w) / np.sum(w), 1 / np.sqrt(np.sum(w))


for label, drop in (("pdcsap 38 64 65 (the checks' light curve)", checks["dropped_suspect"]), ("all six sectors", [])):
    flat = flat_of(drop)
    print(f"\n== {label}: {len(flat.time)} cadences, sectors {sorted(set(flat.sector.tolist()))}")
    for name, ph in (("primary", 0.0), ("ModShift sec", ms["phs_sec"] + off), ("ModShift ter", ms["phs_ter"] + off),
                     ("ModShift pos", ms["phs_pos"] + off), ("phase 0.5", 0.5)):
        rows = events(flat, ph)
        print(f"-- {name} (phase {ph:.4f})")
        for r in rows:
            print("   epoch %d  t %.3f  S%d  n %d  depth %.0f +- %.0f ppm" % r)
        m, s = combined(rows)
        print(f"   combined {m:.0f} +- {s:.0f} ppm ({m / s:.1f} sigma, white)")
    prim = events(flat, 0.0)
    odd = [r for r in prim if r[0] % 2]
    even = [r for r in prim if not r[0] % 2]
    mo, so = combined(odd)
    me, se = combined(even)
    print(f"-- odd {mo:.0f} +- {so:.0f} ({len(odd)} events), even {me:.0f} +- {se:.0f} ({len(even)}), "
          f"diff {(mo - me) / np.hypot(so, se):.1f} sigma")
    grid = np.arange(0.02, 0.98, 0.002)
    sig = []
    for ph in grid:
        rows = events(flat, ph)
        if len(rows) < 3:
            sig.append(np.nan)
            continue
        m, s = combined(rows)
        sig.append(m / s)
    sig = np.array(sig)
    order = np.argsort(-np.nan_to_num(sig, nan=-99))
    print("-- strongest box dips away from the primary (phase, sigma):",
          [(round(grid[i], 3), round(sig[i], 1)) for i in order[:8]])
    print("-- strongest box rises (phase, sigma):",
          [(round(grid[i], 3), round(sig[i], 1)) for i in np.argsort(np.nan_to_num(sig, nan=99))[:5]])
    print(f"-- box sigma over phases 0.02-0.98: sd {np.nanstd(sig):.2f}, n {np.isfinite(sig).sum()}")
    # The search's rank-2 signal at 5.58 d.
    o = checks["other_signals"][0]
    rows2 = events(flat, 0.0, per=o["period"], ref=o["t0"], half=o["duration"] / 2)
    m2, s2 = combined(rows2)
    by = {}
    for r in rows2:
        by.setdefault(r[2], []).append(r)
    print(f"-- 5.58 d signal: {len(rows2)} events, combined {m2:.0f} +- {s2:.0f} ppm ({m2 / s2:.1f} sigma); by sector:",
          {k: (len(v), round(combined(v)[0]), round(combined(v)[1])) for k, v in by.items()})
    # Does any 5.58 d event fall on a 17.44 d transit?
    tp = [r[1] for r in prim]
    clash = [(r[1], t) for r in rows2 for t in tp if abs(r[1] - t) < dur]
    print("-- 5.58 d events within one duration of a 17.44 d transit:", clash)
