"""Per-event boxes at the PDCSAP scan's strongest dip (phase 0.802) and rise (0.104), same rebuild as scan.py."""
import sys
sys.argv = sys.argv[:2]
exec(open("/tmp/t13/241522065-1/scan.py").read().split("for label, drop in")[0])
flat = flat_of(checks["dropped_suspect"])
for ph in (0.802, 0.366, 0.104, 0.022):
    rows = events(flat, ph)
    m, s = combined(rows)
    print(f"phase {ph}: " + "; ".join("ep %d t %.3f S%d %.0f+-%.0f" % (r[0], r[1], r[2], r[4], r[5]) for r in rows)
          + f" | combined {m:.0f} +- {s:.0f}")
