"""From multi_star's fits: could a named neighbour carry the loss? If star N hosted the dip, its PRF amplitude in the
difference image would be at least the loss the target's aperture shows, A_min = depth x FLFRCSAP x F_target (N's
aperture share is at most 1). depth: 448 ppm (signals file, conservative) or 570 ppm (PDCSAP core depth, checks.json);
FLFRCSAP 0.83 (the lowest of S12 0.865, S39 0.828, S65 0.867, used for every sector). F_target: the fit's target flux.
Prints, per sector and pooled (inverse variance), each star's amplitude, its null sd, and how many null sds it sits
below A_min; and the target's amplitude against the amplitude the light-curve depth predicts on it (570 ppm x F)."""
import json, sys
import numpy as np
fits = json.load(open(sys.argv[1]))
for depth in (448e-6, 570e-6):
    print(f"== depth {depth*1e6:.0f} ppm, FLFRCSAP 0.83")
    tics = [s["tic"] for s in fits[0]["stars"]]
    for k, tic in enumerate(tics):
        rows, gap, w = [], [], []
        for r in fits:
            st = r["stars"][k]; ft = r["stars"][0]["flux"]
            amin = depth * 0.83 * ft
            rows.append(f'S{r["sector"]} {st["amp"]:6.1f}+-{st["null_sd"]:5.1f} (A_min {amin:4.1f}: {(amin - st["amp"]) / st["null_sd"]:4.1f} sd)')
        # pooled: amplitudes over A_min per sector, inverse-variance
        a = np.array([r["stars"][k]["amp"] / (depth * 0.83 * r["stars"][0]["flux"]) for r in fits])
        e = np.array([r["stars"][k]["null_sd"] / (depth * 0.83 * r["stars"][0]["flux"]) for r in fits])
        def pool(m):
            ww = 1 / e[m] ** 2; mu = np.sum(ww * a[m]) / np.sum(ww); se = 1 / np.sqrt(np.sum(ww)); return mu, se
        allm = np.ones(len(fits), bool); ns = np.array([r["sector"] not in (102, 103) for r in fits])
        mu, se = pool(allm); mu2, se2 = pool(ns)
        print(f"TIC {tic}: " + "; ".join(rows))
        print(f"   pooled amp / A_min: all {mu:.2f} +- {se:.2f} ({(1 - mu) / se:.1f} sd below 1); without S102, S103 {mu2:.2f} +- {se2:.2f} ({(1 - mu2) / se2:.1f} sd below 1)")
print("== target amplitude against 570 ppm x F_target")
for r in fits:
    t = r["stars"][0]
    print(f'S{r["sector"]}: amp {t["amp"]:.1f} +- {t["null_sd"]:.1f}, predicted {570e-6 * t["flux"]:.1f}')
