"""Read-only: the S65 TESS-SPOC aperture as tricera.fits_aperture reads it, and the cached light curve's layout."""
import numpy as np
from astropy.io import fits
p = "$TESS_HUNT_DATA/lc_fits/hlsp_tess-spoc_tess_phot_0000000423100454-s0065_tess_v1_lc.fits"
with fits.open(p) as h:
    ap = h["APERTURE"]
    bits = np.asarray(ap.data, dtype=int)
    print("APERTURE shape", bits.shape, "CRVAL1P", ap.header["CRVAL1P"], "CRVAL2P", ap.header["CRVAL2P"])
    rows, cols = np.nonzero(bits & 2)
    print("bit-2 pixels", len(rows), sorted(zip((cols + ap.header["CRVAL1P"]).tolist(), (rows + ap.header["CRVAL2P"]).tolist())))
    print("header CROWDSAP", h[1].header.get("CROWDSAP"), "FLFRCSAP", h[1].header.get("FLFRCSAP"), "1CRV4P?", h[1].header.get("1CRV4P"))
    print("primary TESSMAG", h[0].header.get("TESSMAG"), "CAMERA", h[0].header.get("CAMERA"), "CCD", h[0].header.get("CCD"))
d = np.load("$TESS_HUNT_DATA/lc/423100454.npz", allow_pickle=True)
print({k: d[k].shape for k in d.files})
