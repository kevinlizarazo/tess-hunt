#!/bin/bash
# Public catalogue reads used in the 423100454-1 review (Gaia DR3 TAP, VizieR, MAST S3 listing, Exoplanet Archive).
G=https://gea.esac.esa.int/tap-server/tap/sync
q() { curl -s --data-urlencode "QUERY=$1" -d REQUEST=doQuery -d LANG=ADQL -d FORMAT=csv $G; echo; }
q "SELECT source_id, phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag, phot_g_n_obs, phot_rp_n_obs, astrometric_params_solved, duplicated_source, ruwe, phot_variable_flag, radial_velocity, radial_velocity_error, rv_nb_transits, rv_chisq_pvalue, rv_renormalised_gof, rv_amplitude_robust, ipd_frac_multi_peak, ipd_gof_harmonic_amplitude FROM gaiadr3.gaia_source WHERE source_id IN (5836452847014268800, 5836452881314264576, 5836546649077319168)"
q "SELECT source_id, best_class_name, best_class_score FROM gaiadr3.vari_classifier_result WHERE source_id=5836546649077319168"
q "SELECT source_id, std_dev_mag_g_fov, range_mag_g_fov, in_vari_ms_oscillator FROM gaiadr3.vari_summary WHERE source_id=5836546649077319168"
V='https://vizier.cds.unistra.fr/viz-bin/asu-tsv'
curl -s "$V?-source=B/vsx/vsx&-c=240.06543-55.56350&-c.rs=180&-out=_r,Name,Type,max,min,Period&-sort=_r" | grep -v '^#'
curl -s "$V?-source=J/A+A/657/A7/tablea1&HIP=78393&-out=HIP,RUWE,snrPMaH2EG3b,BinH2EG3b" | grep -v '^#'
curl -s "$V?-source=J/ApJS/254/42/catalog&HIP=78393&-out.all" | grep -v '^#' | tail -2
curl -s "$V?-source=V/117&-c=240.06543-55.56350&-c.rs=30&-out=HIP,fb,o_RVel,dT,P(chi2)" | grep -v '^#'
curl -s "$V?-source=B/wds/wds&-c=240.06543-55.56350&-c.rs=60&-out.all" | grep -v '^#'
curl -s "$V?-source=J/MNRAS/427/343&-c=240.06543-55.56350&-c.rs=10&-out=HIP,EIR" | grep -v '^#'
curl -s "https://stpubdata.s3.amazonaws.com/?list-type=2&prefix=tess/public/tid/s0012/0000/0004/2310/0454/" | grep -o '<Key>[^<]*</Key>'
curl -s 'https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=select+toi,tid,tfopwg_disp,pl_orbper+from+toi+where+tid=423100454&format=csv'
