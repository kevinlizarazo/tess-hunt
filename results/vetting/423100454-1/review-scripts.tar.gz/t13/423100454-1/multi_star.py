"""Fixed-position PRF fit with several named stars at once, on 423100454-1's saved difference images.

Read-only. Same PRF model, null images and solve as /tmp/pixel-diag/two_star.py, but with the target, the stars
TRICERATOPS's NFPP rests on (TIC 423100450, 423100455), the brightest possible host near the target
(TIC 423100457, 423105440) and the variable star (TIC 423100496) fitted together, plus a constant. Each star's
amplitude is put in standard deviations of the same fit to the null images (z) and in depth of its own flux
(from the same fit to the mean out-of-transit image).

Usage: multi_star.py OUT.json [TIC ...], the target first
"""
import json
import pickle
import sys
import warnings

import numpy as np

sys.path.insert(0, "/tmp/pixel-diag")
from sector_detail import null_images, prf_model  # noqa: E402
from two_star import solve, unit_prf  # noqa: E402

warnings.filterwarnings("ignore")
STAR_DIR = ("$TESS_HUNT_DATA/runs/20261020T180844Z-vetting-second-list-61b5944-7096/tdi/"
            "423100454-1/tic423100454")
SECTORS = [103, 102, 65, 39, 12]
STARS = [int(a) for a in sys.argv[2:]] or [423100454, 423100450, 423100457, 423105440, 423100455, 423100496]


def main():
    out = []
    for s in SECTORS:
        with open(f"{STAR_DIR}/imageData_423100454.1_sector{s}.pickle", "rb") as fh:
            images, cat, pix, _, _, _, planet = pickle.load(fh)
        ids = np.asarray(cat["ticID"]).astype(int)
        idx = [int(np.where(ids == t)[0][0]) for t in STARS]
        prf = prf_model(images, cat, pix)
        basis = [unit_prf(prf, cat, cat["ticColPix"][j], cat["ticRowPix"][j]) for j in idx]
        flux = solve(images["meanOutTransit"], basis)[:-1]
        real = solve(images["diffImage"], basis)[:-1]
        nulls = []
        for phase, _, img in null_images(pix, planet):
            if phase == 0.0 or not img or np.isnan(np.sum(img["diffImage"])):
                continue
            nulls.append(solve(img["diffImage"], basis)[:-1])
        nulls = np.array(nulls)
        sd = np.std(nulls, axis=0, ddof=1)
        rec = {"sector": s, "n_nulls": len(nulls), "stars": []}
        for k, t in enumerate(STARS):
            j = idx[k]
            rec["stars"].append({
                "tic": t, "tmag": float(np.ma.filled(cat["ticMag"][j], np.nan)),
                "sep": float(np.ma.filled(cat["separation"][j], np.nan)),
                "flux": float(flux[k]), "amp": float(real[k]), "null_sd": float(sd[k]),
                "z": float(real[k] / sd[k]), "depth": float(real[k] / flux[k]) if flux[k] > 0 else None,
            })
        out.append(rec)
        print(f"S{s} ({len(nulls)} nulls)")
        for r in rec["stars"]:
            dep = "nan" if r["depth"] is None else f'{r["depth"] * 1e6:9.0f} ppm'
            print(f'   TIC {r["tic"]} T{r["tmag"]:.2f} at {r["sep"]:6.1f}": amp {r["amp"]:8.1f} '
                  f'(null sd {r["null_sd"]:6.1f}, z {r["z"]:5.1f}) flux {r["flux"]:9.0f} depth {dep}')
    json.dump(out, open(sys.argv[1], "w"), indent=1)
    # Pooled over sectors: inverse-variance mean of each star's depth, with the null scatter as its error.
    print("pooled (inverse-variance, null-scatter errors)")
    for k, t in enumerate(STARS):
        d = np.array([r["stars"][k]["amp"] / r["stars"][k]["flux"] for r in out])
        e = np.array([r["stars"][k]["null_sd"] / r["stars"][k]["flux"] for r in out])
        w = 1 / e**2
        m, me = float(np.sum(w * d) / np.sum(w)), float(1 / np.sqrt(np.sum(w)))
        print(f"   TIC {t}: depth {m * 1e6:9.0f} +- {me * 1e6:7.0f} ppm (z {m / me:5.1f})")
        for exclude in ([102, 103],):
            keep = np.array([r["sector"] not in exclude for r in out])
            mk = float(np.sum(w[keep] * d[keep]) / np.sum(w[keep]))
            ek = float(1 / np.sqrt(np.sum(w[keep])))
            print(f"      without S102, S103: {mk * 1e6:9.0f} +- {ek * 1e6:7.0f} ppm (z {mk / ek:5.1f})")


if __name__ == "__main__":
    main()
