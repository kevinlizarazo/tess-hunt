"""SPOC's S12 DV difference image for TIC 423100454 (dvr.xml on MAST, pipeline run 00219): each pixel's
(out - in) flux difference over its uncertainty, the brightest out-of-transit pixel and the largest-loss pixel.
Usage: spoc_map.py DVR.xml"""
import re, sys
import numpy as np
x = open(sys.argv[1]).read()
i = x.find('<dv:differenceImageResults'); j = x.find('</dv:differenceImageResults>', i); blk = x[i:j]
print(re.search(r'<dv:qualityMetric[^>]*>', blk).group(0))
pix = re.findall(r'<dv:differenceImagePixelData ccdRow="(\d+)" ccdColumn="(\d+)">\s*<dv:meanFluxInTransit value="([^"]+)" '
                 r'uncertainty="([^"]+)"/>\s*<dv:meanFluxOutOfTransit value="([^"]+)" uncertainty="([^"]+)"/>\s*'
                 r'<dv:meanFluxDifference value="([^"]+)" uncertainty="([^"]+)"/>', blk)
rows = sorted({int(p[0]) for p in pix}); cols = sorted({int(p[1]) for p in pix})
D = np.full((len(rows), len(cols)), np.nan); S = D.copy(); O = D.copy()
for r, c, fi, efi, fo, efo, fd, efd in pix:
    a, b = rows.index(int(r)), cols.index(int(c)); D[a, b] = float(fd); S[a, b] = float(efd); O[a, b] = float(fo)
for a, r in enumerate(rows):
    print(r, ' '.join('%5.1f' % v for v in D[a] / S[a]))
k = np.nanargmax(O); print('brightest out-of-transit pixel (row, col)', rows[k // len(cols)], cols[k % len(cols)])
k = np.nanargmax(D / S); print('largest loss pixel (row, col)', rows[k // len(cols)], cols[k % len(cols)], 'SNR %.1f' % np.nanmax(D / S))
