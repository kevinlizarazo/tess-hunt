import json

D = "~/.cache/tess-hunt/drafts/m3-r2/423100454-1"
S = "/tmp/t13/423100454-1"
findings = [
    {"id": "F1", "lens": "on_star", "rating": "hold",
     "claim": "TRICERATOPS can't pass this row on the public data even with its blocker cleared: the mean NFPP of 0.0067 sits between the 0.001 pass bar and the 0.1 fail bar, and 95% of it is one dwarf 34\" out, TIC 423100450, which the pixels argue against but TRICERATOPS can't take in; seeing-limited ground-based photometry of a predicted transit would decide it.",
     "evidence": (
         f"{D}/triceratops.json: nfpp_mean 0.006695 (sd 0.00085), fpp_mean 0.0353; criteria/vet-v3.toml [triceratops] nfpp_pass 0.001, nfpp_fail 0.1, fpp_pass 0.5; "
         "src/tess_hunt/tricera.py:85-121 gives inconclusive between the bars with no blocker, and decision 0028's bar 3 needs a TRICERATOPS pass. "
         f"{D}/probs.csv is the tenth run (NFPP 0.006485, the last value of nfpp): summing prob by ID gives TIC 423100450 NTP 0.003805 + NEB 0.002330 + NEBx2P 4.4e-7 = 0.006135 (94.6%), TIC 423100455 0.000341 (5.3%), the rest under 1e-5. "
         "TIC 423100450 is Gaia DR3 5836453499849306752: 34.1\" in neighbours.csv, Tmag 11.96, required depth 0.96% (neighbours.csv) and 1.31% (TRICERATOPS tdepth); Gaia DR3 parallax 2.71 mas (S/N 199), Teff 5955 K, logg 4.18, radius 1.22 Rsun (gaiadr3.gaia_source joined with astrophysical_parameters on the Gaia TAP): a dwarf that can host a 4.3 h transit at 14.19 d. "
         "The other bright stars near the target are giants and get about 1e-52 in probs.csv: TIC 423105440 (15.0\", Gaia DR3 5836453499849301760, parallax 0.267 mas, logg 2.0, radius_flame 18.4 Rsun) and TIC 423100457 (37.7\", Gaia DR3 5836452842610251392, parallax 0.399 mas, G 11.99, BP-RP 1.96). Inside 15\" the only other possible host, Gaia DR3 5836452846954130944 (8.4\", needs 84%), gets zero depth in TRICERATOPS. "
         "Pixels, outside the pipeline (a fixed-position PRF fit like the diagnosis's two_star.py, with the target, TIC 423100450, 423100457, 423100455 and 423100496 held at their catalogue positions plus a constant, errors from the same fit to each sector's null images): "
         f"MSYS_NO_PATHCONV=1 wsl.exe -d Ubuntu-26.04 --cd {S} -- /tmp/t13/heavy.sh ~/code/tess-hunt/.venv/bin/python multi_star.py multi_no5440.json 423100454 423100450 423100457 423100455 423100496, then .venv/bin/python exclude.py multi_no5440.json (outputs {S}/multi_no5440.txt and .json; the saved difference images of SECOND2_RUN, the sha256s in pixels.json). "
         "TIC 423100450's amplitude is 1.7 +- 3.3, 1.8 +- 11.9, 2.6 +- 5.2, -3.5 +- 13.7, -2.2 +- 11.1 e-/s in S103, S102, S65, S39, S12, against the 19.6, 24.3, 12.6, 19.7, 19.2 e-/s it would need as the host (the loss the target's aperture sees, 448 ppm x FLFRCSAP 0.83 x the fitted target flux; its aperture share is at most 1): pooled 0.08 +- 0.14 of that minimum (6.5 null sds below), 0.04 +- 0.30 (3.2 sds) from S12, S39 and S65 alone; TIC 423100455 5.4 and 1.9 sds. "
         "The target's amplitudes, 38.3 +- 11.1, 33.3 +- 11.0, 19.4 +- 16.5, 34.9 +- 62.1, 39.3 +- 35.9 e-/s, match the 30.1, 37.2, 19.3, 30.2, 29.4 that the PDCSAP depth (570 ppm) predicts on it. "
         "What would decide it: ground-based seeing-limited photometry at a predicted transit (checks.json windows, e.g. S113 BTJD 4426.145 and 4440.331, sd 10.2 min, or any epoch of the density-prior ephemeris) showing no 0.96 to 1.31% eclipse on TIC 423100450 and no 3.9 to 6.3% eclipse on TIC 423100455 (38.4\"), or the dip on the target.")},
    {"id": "F2", "lens": "on_star", "rating": "note",
     "claim": "TRICERATOPS's inputs hold up: the star without a G magnitude can't host the dip, so the blocker changes nothing; S65's aperture is the one the S65 photometry used; and the 62 dropped TIC rows don't matter.",
     "evidence": (
         f"The no-G star is Gaia DR3 5836452881314264576 ({D}/checks.json neighbours.evidence.no_g; neighbours.csv: 49.8\" out, tmag_from none). Gaia DR3 ({S}/queries.sh): phot_g_n_obs 0, no BP, RP 19.504 from 6 RP observations, astrometric_params_solved 3 (no parallax or proper motion). "
         "Stassun et al. eq. 1 (src/tess_hunt/neighbours.py:40-43) with Gaia's G-RP colours puts T within about 0.1 mag of RP for BP-RP 0 to 3, so T is about 19.4 to 19.6. It would need T 17.00 or brighter to need even a total eclipse (8.6228 + 2.5 log10(1/0.000448)); at T 19.4 it needs 920% (448 ppm x 10^(0.4 x (19.4 - 8.6228))). Without the blocker TRICERATOPS stays inconclusive on NFPP (F1). "
         "S65: tricera.apertures (src/tess_hunt/tricera.py:333-368) takes SPOC 2-min sectors from TRICERATOPS's get_spoc_apertures and TESS-SPOC sectors from the light-curve file's APERTURE extension (bit 2). The run log's 'No SPOC aperture for sector(s) 65' (~/.cache/tess-hunt/logs/m3-rerun-tric3-five.log lines 16 and 40) is get_spoc_apertures' warning, which the code doesn't use for a TESS-SPOC sector. "
         f"Read through heavy.sh ({S}/peek_lc.py): hlsp_tess-spoc_tess_phot_0000000423100454-s0065_tess_v1_lc.fits has CRVAL1P 416, CRVAL2P 613 and 14 bit-2 pixels, the same 14 (column, row) pairs as triceratops.json apertures.65.ccd_pixels, and its CROWDSAP 0.79285467 is the one checks.json records; target_in_aperture is true in both sectors. S12 took its 12-pixel SPOC aperture; S39 (600 s) was left out as slower than the 200 s group. "
         "Dropped: triceratops.json dropped_stars holds 61 DUPLICATE rows, each naming the kept TIC it duplicates, and one ARTIFACT, TIC 423100507, which the MAST TIC (Mast.Catalogs.Filtered.Tic) gives as Tmag 15.6, 62.8\" from the target, no Gaia id: outside the 1' table and too faint to matter.")},
    {"id": "F3", "lens": "on_star", "rating": "note",
     "claim": "The pixel fail measured a catalogued variable star, as the diagnosis says: TIC 423100496 is Gaia DR3 VARIABLE (a DSCT|GDOR|SXPHE candidate, period 5.37 d in VSX), and in the two sectors that fail, its PRF carries a large loss while the target's carries the transit.",
     "evidence": (
         "MAST TIC (Mast.Catalogs.Filtered.Tic) gives TIC 423100496 as Gaia DR3 5836546649077319168, Tmag 9.958, 118.3\" from the target's TIC position. Gaia DR3 (queries.sh): phot_variable_flag VARIABLE; vari_classifier_result best_class_name DSCT|GDOR|SXPHE (score 0.026); vari_summary std_dev_mag_g_fov 0.0141, range_mag_g_fov 0.073, in_vari_ms_oscillator true. "
         "VSX (VizieR B/vsx/vsx, 3' cone sorted by distance, in queries.sh) lists it at 118.32\" as DSCT|GDOR|SXPHE, G 10.24 to 10.32, period 5.3725 d, not commensurate with 14.186 d (ratio 2.64). "
         f"The fixed fit ({S}/multi_no5440.txt) gives TIC 423100496 202.5 +- 100.2 e-/s in S102 and 114.6 +- 41.3 in S65, against -7.0, -2.4 and 11.2 in S103, S39 and S12, and /tmp/pixel-diag/nulls_423.py shows a no-transit image landing on it with a larger loss in each failing sector (S102 phase 0.625: amp 385.5, q 0.97; S65 phase 0.375: amp 170.1, q 0.94). "
         f"It can't make the dip: TRICERATOPS gives it tdepth 0.0 ({D}/triceratops.json stars), and the target's own amplitudes match the light curve (F1).")},
    {"id": "F4", "lens": "on_star", "rating": "note",
     "claim": "The fits seeded on the target in S102 and S65 put nothing on the target; the pixels that place the dip on or near the target come mostly from S103 and S102, which are timing-suspect only as QLP light curves, so the three sectors vet-v3 keeps localize it only weakly; the fail doesn't hinge on S102.",
     "evidence": (
         "Seeded fits (/tmp/pixel-diag/seed_check.txt): S102 7.3\" at quality 0.12, S65 7.0\" at 0.17. The same sectors' no-transit images reach higher qualities (/tmp/pixel-diag/nulls_423.py: S102 up to 0.29 at phase 0.575 and 0.27 at 0.850; S65 up to 0.44 at 0.850, 0.38, 0.36, 0.34), so those seeded fits are no more PRF-like than noise. "
         "The check's own fits that sit near the target: S103 (+3.8\" E, +4.3\" N) 5.7\" at q 0.52, above all 14 nulls (best 0.34); S39 (+3.7, -4.5) 5.8\" at q 0.73, nulls best 0.37; S12 (+3.2, -8.1) 8.7\" at q 0.57, nulls best 0.49. "
         f"Fixed fit ({S}/multi_no5440.txt): target z 3.5 (S103), 3.0 (S102), 1.2 (S65), 0.6 (S39), 1.1 (S12); pooled 599 +- 124 ppm (z 4.8) with all five, 638 +- 378 ppm (z 1.7) without S102 and S103. The diagnosis's box z at the star (section 2): 4.7, 5.4, 3.2, 1.9, 1.5 against 3.7, 6.6, 3.5, 1.6, 1.4 expected (S103, S102, S65, S39, S12). "
         "S102 and S103 are flagged because QLP's barycentric timestamps are wrong there (decisions 0010, 0022); the pixel check builds its images from TESScut FFI cutouts (t13/pixel-epoch.md, code path), not from QLP, so the flag does not reach them, and their box z matching the expected z shows the windows sit on transits. "
         f"The outcome: {D}/pixels.json gives S102 quality 0.91653 and S65 0.91611; without S102, S65's 115.7\" is the best-quality sector and the check fails the same way. The 'would pass if seeded' reading in pixel-epoch.md rests on S39 (5.8\", q 0.73), whose image holds a weak transit.")},
    {"id": "F5", "lens": "on_star", "rating": "note",
     "claim": "SPOC found this signal as a TCE in S12 and published a DV report that puts the difference-image centroid 15.3\" from the target, but SPOC rates that image below its own quality threshold and the image's largest loss is on the target's brightest pixel; the second list's table says 'no SPOC TCE' because the snapshot's S12 TCE table lacks the row.",
     "evidence": (
         "MAST lists DV products for TIC 423100454 in S12 (https://stpubdata.s3.amazonaws.com/?list-type=2&prefix=tess/public/tid/s0012/0000/0004/2310/0454/, in queries.sh): dvr.xml, dvr.pdf, dvs.pdf for TCE 01, pipeline run 00219. "
         f"{S}/spoc/tess2019141104532-s0012-s0012-0000000423100454-00219_dvr.xml (sha256 4adc6ea031b0b4dbb5829b556447dcd46d8d6d3b86d6ea59abfad532ceba92e3): period 14.206939 d, epoch 1631.4706, MES 8.22 over 2 transits, suspectedEclipsingBinary false, odd-even statistic 0.457; ticCentroidOffsets skyOffset 15.26\" +- 1.25\" (RA +5.63\", Dec -14.18\"; the multi-sector mean's error is 2.79\"), controlCentroidOffsets 13.23\" +- 1.25\"; qualityMetric 0.611 against qualityThreshold 0.7, numberOfGoodMetrics 0; weak secondary MES 3.1 at 5.81 d (phase 0.41), 219 +- 74 ppm; ghost core 0.35, halo 1.58. "
         f"Per pixel (.venv/bin/python {S}/spoc_map.py <the xml>): the largest loss, 8.6 sigma, is at row 774, column 490, the brightest out-of-transit pixel, and the adjacent pixel (row 773, column 490) shows a 6.3-sigma gain, which drags a one-PRF centroid off the star. "
         "The nearest possible host in that direction, Gaia DR3 5836452739540607232 (16.8\" at +5.1\" E, -16.0\" N, Tmag 16.59, neighbours.csv), would need a 69.5% eclipse and gets 6.9e-54 in probs.csv. "
         "SECOND2_RUN second-list.md and second-list.csv say 'no SPOC TCE at the period' for this row, and decision 0033's table repeats 'none'; grep 423100454 ~/.cache/tess-hunt/catalogs/2026-10-17T142814Z/raw/SPOC-TCE/*.csv finds nothing, including tess2019141104532-s0012-s0012_dvr-tcestats.csv. The ExoMiner rows novelty matched (423100454-1-S12, 2-min) are ExoMiner's scores of this SPOC TCE.")},
    {"id": "F6", "lens": "on_star", "rating": "note",
     "claim": "Nothing points to a bound companion or a visual double: RUWE, Gaia's image parameters, two proper-motion-anomaly catalogues and WDS are all clean; the 0.026 that a planet on an unresolved companion (STP) adds to the FPP is a prior, which high-resolution imaging would cut, but FPP already passes.",
     "evidence": (
         f"{D}/checks.json star.ruwe 0.745; Gaia DR3 ipd_frac_multi_peak 0, ipd_gof_harmonic_amplitude 0.0064 (queries.sh). Kervella et al. 2022 (VizieR J/A+A/657/A7/tablea1): snrPMaH2EG3b 0.72, BinH2EG3b 0; its CPM tables A2 and A3 list no companion for HIP 78393. Kervella et al. 2019 (J/A+A/623/A72): PMa S/N 0.12, BinG2 0. Brandt 2021 HGCA (J/ApJS/254/42/catalog): chisq 0.866. "
         "WDS (B/wds/wds): no entry within 1'. neighbours.csv: the nearest Gaia DR3 star is 5.5\" out at G 19.33. "
         "probs.csv (tenth run): FPP 0.0325, of which STP 0.0260; fpp_mean 0.0353 < fpp_pass 0.5.")},
    {"id": "F7", "lens": "planet", "rating": "note",
     "claim": "An eclipsing binary on the target is ruled out: the target's radial velocities are constant to about 1 km/s across Gaia's 12 epochs and the older surveys, where even a 0.02 solar-mass companion on this orbit would swing 1.7 km/s, and the transit is U-shaped with a 2.3 Earth-radius depth.",
     "evidence": (
         "Gaia DR3 (queries.sh): radial_velocity -35.61 +- 0.17 km/s, rv_nb_transits 12, rv_chisq_pvalue 0.44, rv_renormalised_gof -0.41, rv_amplitude_robust 1.33 km/s. Nordstrom et al. 2004 (VizieR V/117): 2 RVs over 293 d, P(chi2) 0.837, binary flag blank; Holmberg et al. 2009 (V/130/gcs3) fb 0; Kervella 2022 lists RV -35.73 +- 0.20 (ref H07). "
         "Kepler's law for a 1.0 Msun star at P 14.186 d, edge-on: K = 8.25 km/s for 0.1 Msun, 1.74 km/s for 0.02 Msun (python one-liner, G 6.674e-11). "
         f"{D}/checks.json: shape grazing probability 0.0, b 0.45 (flat fit) and 0.21 (density-prior fit); density tension 0.9 sigma; Rp 2.33 and 2.27 Earth radii. probs.csv: EB 1.4e-43, EBx2P 2.8e-28.")},
    {"id": "F8", "lens": "planet", "rating": "note",
     "claim": "ModShift's 3-sigma secondary at phase 0.81 and the search's rank-2 signal at 25.27 d are not an eclipsing binary's: the rank-2 signal's first event sits at that phase, and its other events sit at data-gap edges or show a brightening; the phase-0.81 windows don't repeat a dip.",
     "evidence": (
         f"{D}/checks.json modshift: phs_sec 0.810, sig_sec 3.00, Fred 1.25 (3.00/1.25 = 2.4), dep_sec 97 +- 32 ppm; other_signals: P 25.2677 d, t0 1643.0609, SDE 11.2, depth 216 ppm, duration 10.0 h, ratio 1.781. "
         f"/tmp/t13/heavy.sh .venv/bin/python {S}/lc_events.py (the cached light curve ~/.cache/tess-hunt/lc/423100454.npz; local depth = central quarter-duration window against a line fitted 1 to 3 durations out; white-noise errors): "
         "rank-2 events at BTJD 1643.061 (S12, 239 +- 56 ppm, primary phase 0.817), 2375.826 (S39, inside the end of the 2374.86 to 2375.87 gap), 3083.322 (S65, 0.16 d before the 3083.48 gap), 4144.568 (S102, -1 +- 80), 4169.836 (S103, -462 +- 116, a brightening). "
         "Phase 0.81 windows: 146, 171 (S12), -55, 262 (S39), -7, 381 (S65, 0.31 d before the 3090.26 gap), 1, 105 (S103) ppm, each +- 79 to 100. "
         "SPOC's S12 DV weak secondary is at a different phase (0.41, MES 3.1; F5). A 97 ppm occultation is out of reach for a 2.3 Earth-radius planet at 14 d, so a real one would point to a blend, but none is established.")},
    {"id": "F9", "lens": "real_new", "rating": "note",
     "claim": "The transits are fully covered and spread evenly (two per sector, none near a gap), but the depths scatter: S39 is the deepest sector and S65's two transits differ by about 2.4 sigma; the QLP depths are about 0.8 of PDCSAP's, as 0010's QLP dilution allows.",
     "evidence": (
         f"lc_events.py (F8's command): E0 642 +- 90, E1 489 +- 82 (S12); E52 781 +- 80, E53 738 +- 83 (S39); E102 366 +- 79, E103 754 +- 84 (S65); evidence only: E176 465 +- 69, E177 404 +- 74 (S102), E178 618 +- 86 (S103) ppm. E102 minus E103 is 388 ppm, 3.4 sigma white, about 2.4 with S65's red-noise beta 1.41 ({D}/checks.json red_noise). "
         "Gaps printed by the same script: every vet-kept transit sits at least 2.1 d from a gap and 3.9 d from a sector edge. "
         "checks.json sector_depth: S12 479 +- 77, S39 706 +- 67, S65 474 +- 79 ppm, p 0.030 (bar 0.001); holdout tensions 1.26, 2.42, 1.56 (bar 3.0). CROWDSAP 0.840, 0.858, 0.793; TIC contratio 0.252. "
         f"{D}/checks-with-suspect.json: QLP S102 369 +- 115, S103 565 +- 120 ppm (mean 462, p 0.24), 0.81 of the PDCSAP mean 570; decision 0010 found QLP depths at 0.60 to 0.99 of SPOC's on crowded stars. The scatter fits 0031's causes (crowding, red noise) and decides nothing.")},
    {"id": "F10", "lens": "real_new", "rating": "note",
     "claim": "No paper names the star a planet host, eclipsing binary, variable or multiple, no TOI or CTOI exists, and the signal is public only as SPOC's S12 TCE and ExoMiner's planet-candidate rows.",
     "evidence": (
         "literature.json in LIT3_RUN (signals/423100454-1) equals the draft's (sorted-key diff); its 24 hits all came from ADS's object search, and arXiv, OpenAlex and Zenodo found 0 for all six names; every source's result there carries from_run 20261020T091938Z (LIT_RUN), so these searches date from 2026-10-20. None names the star as a host, binary, variable or multiple. "
         "Those whose dismissal isn't obvious from the title: 2019A&A...623A..72K and Kervella 2022 (no proper-motion anomaly, no CPM companion; F6); 2021ApJS..254...42B (HGCA chisq 0.866); 2004A&A...418..989N and 2009A&A...501..941H (no binary flag, 2 RVs, P(chi2) 0.837; F7); 2006AstL...32..759G and 2012A&A...546A..61D (RV compilations); 2016ApJ...826..171G (a row of its metallicity sample, [Fe/H] 0.03, VizieR J/ApJ/826/171); 2012MNRAS.427..343M (EIR 1.004, no infrared excess, J/MNRAS/427/343); 2017AJ....154..115H (its photon-sail trajectories cover about 22,000 stars within about 300 ly, per arXiv 1704.03871's abstract; the star is at 69 pc). "
         "ExoFOP read live on 2026-10-21 returned a maintenance page ('System Calibration in Progress'), so the dossier's ExoFOP read (LIT3_RUN, status ok, no TOI, CTOI or planet) is the latest; NASA Exoplanet Archive TAP, toi table where tid=423100454: no rows (queries.sh). SIMBAD lists HD 142959 as PM*, G6IV/V, with no binary or variable type. "
         f"Public detections: SPOC's S12 TCE 01 with DV products on MAST (F5) and ExoMiner rows 423100454-1-S12 (v1 and v2 2-min) and 423100454-1-S39 (v2 FFI, score 0.785, PC) ({D}/checks.json novelty). Decision 0033's promotion names the ExoMiner row; the SPOC TCE is missing from the second list's table (F5).")},
]
out = {
    "signal": "423100454-1",
    "summary": (
        "I tested the pixel fail's attribution, TRICERATOPS's blocker, NFPP and apertures, the star's companions and radial velocities, the secondary and second signal, the transit depths, SPOC's own S12 DV report and the literature. "
        "The pixel fail measured a catalogued variable star (Gaia DR3 VARIABLE, 2' away), the target's PRF carries the transit in every sector, and nothing shows an eclipsing binary, a companion or a prior claim. "
        "The row still can't pass TRICERATOPS: its NFPP of 0.0067, almost all from the dwarf TIC 423100450 34\" out, sits between the bars whatever the blocker does, and ground-based photometry of a transit would decide it."),
    "findings": findings,
    "hits_flagged": [],
}
s = json.dumps(out, indent=1, ensure_ascii=False)
assert "—" not in s and "–" not in s
with open("/tmp/t13/423100454-1/findings.json", "w") as fh:
    fh.write(s + "\n")
print(len(findings), [f["rating"] for f in findings])
