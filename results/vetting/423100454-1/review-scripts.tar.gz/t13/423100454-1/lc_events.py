"""Read-only look at the cached light curve of TIC 423100454: sector spans and gaps, each transit's local depth and
its distance from a gap, and the events at the ModShift secondary's phase (0.81) and at the rank-2 signal's times.
Local depth: mean of the central half of the window minus a line fitted to the flux 1 to 3 durations either side."""
import numpy as np
d = np.load("$TESS_HUNT_DATA/lc/423100454.npz", allow_pickle=True)
t, f, e, s = d["time"], d["flux"], d["flux_err"], d["sector"]
import json; src = json.loads(str(d["sources"]))
P, T0, DUR = 14.18618565695737, 1631.466216777106, 0.18076414222867132   # density-prior fit (checks.json fit_prior)
P2, T02, DUR2 = 14.18618565695737 * 1.781142847681614, 1643.060860514742, 0.4166666666666667  # other_signals[0]
P2 = 25.26774643142208
for sec in np.unique(s):
    m = s == sec
    tt = t[m]
    gaps = [(round(a, 2), round(b, 2)) for a, b in zip(tt[:-1], tt[1:]) if b - a > 0.2]
    print(f"S{sec}: {tt.min():.2f} to {tt.max():.2f}, {m.sum()} cadences, {src[str(sec)]['provenance']}, gaps > 0.2 d {gaps}")

def local(tc, dur):
    w = np.abs(t - tc)
    core = w < dur / 4
    side = (w > dur) & (w < 3 * dur)
    if core.sum() < 3 or side.sum() < 10:
        return None
    a = np.polyfit(t[side] - tc, f[side], 1)
    base = np.polyval(a, 0.0)
    resid_side = f[side] - np.polyval(a, t[side] - tc)
    sd = np.std(resid_side) / np.sqrt(core.sum())
    dep = base - np.mean(f[core])
    # nearest gap edge: largest time step within +-1 d of the event
    near = np.abs(t - tc) < 1.0
    tt = t[near]
    edge = min([abs(tc - x) for x in (tt.min(), tt.max())] + [min(abs(tc - a), abs(tc - b)) for a, b in zip(tt[:-1], tt[1:]) if b - a > 0.05])
    return dep, sd, int(core.sum()), int(np.unique(s[near])[0]), edge

print("primary transits (epoch, sector, depth ppm, err ppm, core n, nearest gap or edge within 1 d, d)")
for n in range(-1, 200):
    tc = T0 + n * P
    r = local(tc, DUR)
    if r:
        print(f"  E{n:4d} BTJD {tc:.3f} S{r[3]}: {r[0]*1e6:7.0f} +- {r[1]*1e6:5.0f} (n {r[2]}) gap/edge {r[4]:.2f} d")
print("phase 0.81 of the primary")
for n in range(-1, 200):
    tc = T0 + (n + 0.8102576704609138) * P
    r = local(tc, DUR)
    if r:
        print(f"  E{n:4d}+0.81 BTJD {tc:.3f} S{r[3]}: {r[0]*1e6:7.0f} +- {r[1]*1e6:5.0f} (n {r[2]}) gap/edge {r[4]:.2f} d")
print("rank-2 signal events (P 25.2677, t0 1643.0609, duration 0.4167)")
for n in range(-2, 120):
    tc = T02 + n * P2
    r = local(tc, DUR2)
    if r:
        ph = ((tc - T0) / P) % 1
        print(f"  n{n:4d} BTJD {tc:.3f} S{r[3]}: {r[0]*1e6:7.0f} +- {r[1]*1e6:5.0f} (n {r[2]}) primary phase {ph:.3f} gap/edge {r[4]:.2f} d")
