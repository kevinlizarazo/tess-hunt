"""Rebuild vet-v3's fit light curve for 277774870-1 and compare the best chi2 of the flat-prior and density-prior
fits' samples, the grazing fraction, and the photo-eccentric bound. Read-only."""
import hashlib, json, sys
from pathlib import Path
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days, in_transit
from tess_hunt.lightcurve import LightCurve
from tess_hunt.transit import a_rs_from_density, light_curve

run = Path(sys.argv[1]) / "signals/277774870-1"
checks = json.loads((run / "checks.json").read_text())
path = lc_dir() / "277774870.npz"
print("lc sha256", hashlib.sha256(path.read_bytes()).hexdigest())
cs = load_criteria("criteria/search-v2.toml").values
cv = load_criteria("criteria/vet-v3.toml").values
lc = LightCurve.load(path)
good = good_timestamps(lc)
print("dropped", sorted(set(np.unique(lc.sector).tolist()) - set(np.unique(good.sector).tolist())))
flat = detrend(good, cs["detrend"], [])
parts = split(flat, cv["families"])
fl = parts[cv["families"]["fit"]]
eph = Ephemeris(**checks["ephemeris"])
near = np.abs(phase_days(fl.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, e = fl.time[near], fl.flux[near], fl.flux_err[near]
x = fl.exposure_days()[near]
print("cadences near transit", len(t), "in transit", int(in_transit(t, eph).sum()), "sectors", np.unique(fl.sector[near]).tolist())

def chi2(theta):
    t0, period, rp_rs, b, log_rho, q1, q2 = theta
    a_rs = a_rs_from_density(10.0**log_rho, period)
    u1, u2 = 2.0 * np.sqrt(q1) * q2, np.sqrt(q1) * (1.0 - 2.0 * q2)
    m = light_curve(t, x, t0, period, rp_rs, a_rs, b, u1, u2)
    return float(np.sum(((f - m) / e) ** 2))

chi_null = float(np.sum(((f - 1.0) / e) ** 2))
print("chi2 no transit", round(chi_null, 2), "n", len(t))
rng = np.random.default_rng(0)
tic_log_rho, tic_sd = checks["fit_prior"]["rho_prior"]
for name in ("fit_samples.npz", "fit_prior_samples.npz"):
    s = np.load(run / name)["samples"]
    idx = rng.choice(len(s), 3000, replace=False)
    c = np.array([chi2(s[i]) for i in idx])
    best = s[idx[np.argmin(c)]]
    print(name, "min chi2", round(c.min(), 2), "median chi2", round(np.median(c), 2),
          "best theta", np.round(best, 5).tolist())
    rp, b, lr = s[:, 2], s[:, 3], s[:, 4]
    graz = b > 1 - rp
    print("  grazing fraction (b > 1 - k)", round(graz.mean(), 4), "b>1", round((b > 1).mean(), 4))
    print("  Rp (Re) pct 16/50/84", np.round(np.percentile(rp * 1.51593 * 109.076, [16, 50, 84]), 2).tolist(),
          "P(Rp<22 Re)", round(float(np.mean(rp * 1.51593 * 109.076 < 22)), 4))
    print("  P(log_rho <= TIC + 2 sd)", round(float(np.mean(lr <= tic_log_rho + 2 * tic_sd)), 4),
          "P(log_rho <= TIC + 3 sd)", round(float(np.mean(lr <= tic_log_rho + 3 * tic_sd)), 4))
    # T14 per sample
    a = np.array([a_rs_from_density(10.0**l, p) for l, p in zip(lr, s[:, 1])])
    arg = np.clip(np.sqrt(np.clip((1 + rp) ** 2 - b**2, 0, None)) / np.sqrt(a**2 - b**2), 0, 1)
    t14 = s[:, 1] / np.pi * np.arcsin(arg) * 24
    print("  T14 h pct 16/50/84", np.round(np.percentile(t14, [16, 50, 84]), 3).tolist())
    # Flat-prior samples nearest the TIC density: what b and k they need
    near_tic = np.abs(lr - tic_log_rho) < 2 * tic_sd
    if near_tic.any():
        print("  samples within 2 sd of TIC density", int(near_tic.sum()), "b pct", np.round(np.percentile(b[near_tic], [16, 50, 84]), 3).tolist(),
              "grazing frac", round(float(graz[near_tic].mean()), 3))
# Expected T14 for a central transit on the TIC star, circular
a_tic = a_rs_from_density(10.0**tic_log_rho, eph.period)
print("a/R* at TIC density", round(a_tic, 2), "central T14 h (k=0.03)", round(eph.period / np.pi * np.arcsin(1.03 / a_tic) * 24, 3))
# Photo-eccentric: minimum e (omega = 90 deg) for the flat fit's density ratio
s = np.load(run / "fit_samples.npz")["samples"]
for q, label in ((50, "median"), (16, "p16")):
    lr = np.percentile(s[:, 4], q)
    g = (10 ** (lr - tic_log_rho)) ** (1 / 3)
    emin = (g**2 - 1) / (g**2 + 1)
    print(f"flat-fit log_rho {label} {lr:.3f}: rho ratio {10**(lr - tic_log_rho):.1f}, g {g:.2f}, e_min {emin:.3f}, periastron {a_tic*(1-emin):.2f} R*")
