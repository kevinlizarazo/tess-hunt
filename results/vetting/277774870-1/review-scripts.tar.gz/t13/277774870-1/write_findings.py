import json

V = "VET2_RUN=20261020T174317Z-vetting-run-61b5944-2d70"
RUN = 'run with: /tmp/t13/heavy.sh /bin/bash -lc "cd ~/code/tess-hunt && uv run python /tmp/t13/277774870-1/{s} $VET2_RUN"'

findings = [
    {
        "id": "F1",
        "lens": "planet",
        "rating": "hold",
        "claim": (
            "On the TIC star the transit lasts about a fifth of a central transit, so a planet there needs a grazing "
            "orbit whose size the data can't bound or an eccentricity of 0.7 to 0.9, and the light curve fits a "
            "central transit across a much denser star just as well; TRICERATOPS puts 83% on an eclipsing pair bound "
            "to the target."
        ),
        "evidence": (
            "Duration: TIC rho 0.333 solar (0.469 g/cm3) and R 1.516 (checks.json star) give a/R* 15.97 and a central "
            "T14 of 6.32 h for k 0.03. Observed T14: 1.05 h (0.94 to 1.16, 16th to 84th) from the flat-prior fit's "
            "samples, 0.0493 d (1.18 h) from LEO-Vetter's trapezoid (TRIAGE_RUN evidence/277774870-1.json trap_dur), "
            "box 1.00 h. LEO-Vetter's own transit fit lands at b 0.977 +- 0.045 and a/R* 25.4 +- 7.6 against "
            "15.98 +- 1.04 from the star (same file). "
            "Flat-prior fit (checks.json fit and density): log rho 1.560 (-0.781, +0.352), 36.3 g/cm3, 77 times the "
            "TIC's; density passes at 2.40 sigma on the side facing the TIC value (0016), yet only 0.05% of its 96000 "
            "samples lie within 3 TIC sd (0.098 dex) of the TIC density and none within 2. "
            "Density-prior fit (checks.json fit_prior, fit_prior_samples.npz): b 1.39 (-0.22, +0.28), Rp/R* 0.41, "
            "Rp 67.9 Earth radii (p16 32.4, p84 113.1); 95.8% of samples grazing (b > 1 - k); every sample within 2 "
            "sd of the TIC density grazes, b 1.20 to 1.65 (16th to 84th); 9.0% fall under the radius check's 22. "
            "Likelihood: on vet's fit light curve rebuilt from the run (592 cadences in S1, S27, S28, S67, S68; light "
            "curve sha256 18eae3af...c7d3 as VET2_RUN's provenance records; S102 to S104 dropped; nothing masked), "
            "the best chi2 of 3000 random samples is 587.34 for the flat-prior fit and 587.89 for the density-prior "
            "fit, against 831.06 with no transit. A delta chi2 of 0.55: the data don't separate a grazing transit of "
            "the TIC star from a central transit across a dense star. "
            "Eccentricity (0031's cause): the photo-eccentric factor (rho ratio)^(1/3) needs e >= 0.896 (omega 90 "
            "deg, periastron 1.67 R*) at the fit's median density and e >= 0.691 (periastron 4.93 R*) at its 16th "
            "percentile. "
            "TRICERATOPS (TRIC3A_RUN signals/277774870-1: mean FPP 0.933 sd 0.0097, mean NFPP 0.045, 10 runs, "
            "dropped_stars empty): the last run's probs.csv (FPP 0.9197 and NFPP 0.0521, as fpp[9] and nfpp[9]) gives "
            "SEB 0.726 (a 0.21 plus 0.11 Msun pair, radii 0.24 and 0.14 Rsun), SEBx2P 0.104, TP 0.069 (its fit b "
            "1.09, Rp 18.4 Earth radii), STP 0.029, PTP 0.011, NEB 0.045, and every EB-on-target scenario together "
            "0.005. "
            "What decides it: tess-point places the star in no upcoming sector (dossier), so no new TESS 2-min data. "
            "Ground-based transit photometry in two or more bands tells an M-dwarf pair diluted by a 6126 K star "
            "(deeper in the red) from a transit of the target, and higher SNR on the shape separates grazing from "
            "flat-bottomed; high-resolution (AO) imaging bounds a bound companion; precise RVs would bound a grazing "
            "body's mass. The density-prior ephemeris (period sd 2.4e-05 d, t0 sd 0.0034 d) carries to 9.5 min (1 "
            "sd, correlation ignored) on 2026-10-21 and 10.0 min on 2027-06-01, so transits can be scheduled. "
            "Numbers from /tmp/t13/277774870-1/chi2.py, " + RUN.format(s="chi2.py") + " (" + V + "); the ephemeris "
            "spread is sqrt(0.0034^2 + (n * 2.4e-05)^2) at epochs 235 and 252."
        ),
    },
    {
        "id": "F2",
        "lens": "planet",
        "rating": "note",
        "claim": (
            "Gaia DR3's radial velocities rule out an eclipsing binary on the target: a companion on a 12.82 d orbit "
            "around it is at most about 12 Jupiter masses, so the density-prior fit's 68 Earth-radius body can't be "
            "a star grazing the target."
        ),
        "evidence": (
            "Gaia archive ADQL: SELECT source_id, radial_velocity, radial_velocity_error, rv_nb_transits, "
            "rv_amplitude_robust, rv_chisq_pvalue, rv_renormalised_gof, non_single_star FROM gaiadr3.gaia_source "
            "WHERE source_id = 6384126735525555328. RV 4.97 +- 0.218 km/s over 20 transits, rv_amplitude_robust "
            "2.07 km/s, rv_chisq_pvalue 0.211, rv_renormalised_gof 0.398, non_single_star 0; no row in "
            "gaiadr3.nss_two_body_orbit, nss_acceleration_astro, vari_summary or vari_eclipsing_binary. "
            "DR3's error for a bright star, sqrt(pi/(2N) sigma^2 + 0.11^2), implies an epoch scatter of 0.671 km/s; "
            "if all of it were orbital, K <= 0.95 km/s, which is M2 sin i <= 12.1 Jupiter masses for M1 1.16 Msun "
            "and P 12.8195 d. K would be 37.5 km/s for a 0.6 Msun companion (the size of the density-prior fit's "
            "67.9 Earth radii), 7.8 km/s for 0.1 Msun and 2.4 km/s for 0.03 Msun (Kepler's law). "
            "TRICERATOPS agrees: EB, EBx2P, PEB and PEBx2P sum to 0.005 in the last run's probs.csv. "
            "What this leaves: a planet or brown dwarf under about 12 Jupiter masses on the target (grazing or "
            "eccentric, F1), or a pair off the target (SEB bound, BEB background), which the F star's RVs don't test."
        ),
    },
    {
        "id": "F3",
        "lens": "planet",
        "rating": "note",
        "claim": (
            "LEO-Vetter's ModShift finds no secondary at any phase, and unlike 370977908-1 its red-noise scaling "
            "decides nothing here; the search's other signal on the star is unrelated."
        ),
        "evidence": (
            "TRIAGE_RUN evidence/277774870-1.json leo_flux metrics: sig_pri 12.87; sig_sec 2.67 at phs_sec 0.0299 "
            "(0.38 d, 9.2 h after mid-transit), dep_sec 125 +- 47 ppm; sig_ter 2.46 at 0.0111; sig_pos 2.95 at 0.864; "
            "Fred 1.015; FA1 5.24; FA2 2.94. sig_sec / Fred = 2.63, and 2.67 unscaled, both far under FA1; "
            "sig_sec - sig_pos = -0.28 and sig_sec - sig_ter = 0.21, both under FA2: the strongest dip is weaker than "
            "the strongest positive excursion. Disposition PC, fp_failed and fa_failed empty. "
            "vet-v3 secondary at phase 0.5: -37 +- 53 ppm (-0.7 sigma, checks.json). Odd and even (PDCSAP) 835 +- 98 "
            "against 639 +- 79 ppm, 1.6 sigma; QLP 0.3 sigma. "
            "checks.json other_signals: rank 2 at 1.15087 d, SDE 8.1, 46 ppm, duration 0.125 d; 12.8194 / 1.1509 = "
            "11.14, no simple ratio, so no EB pair at a ratio the harmonics miss."
        ),
    },
    {
        "id": "F4",
        "lens": "on_star",
        "rating": "note",
        "claim": (
            "The 14.9 arcsec neighbour sits just inside the pixel rule's 15 arcsec and TRICERATOPS's NFPP of 0.045 "
            "can't clear it, but the per-sector pixel fits place the loss at the target and none lands near it."
        ),
        "evidence": (
            "neighbours.csv (centre Gaia DR3 6384126735525555328, J2016.0): two possible hosts, Gaia DR3 "
            "6384126701165816832 at 14.9\" (G 16.12, needs 14.4%) and 6384126735525555456 at 25.7\" (G 17.51, needs "
            "53%); Gaia DR3 parallaxes 1.193 and 0.912 mas against the target's 5.407, so both are background. "
            "TRICERATOPS weighed both (tdepth 0.1439 and 0.6057, hosts_tdepth_zero empty); in the last run NEB on "
            "TIC 277774871 (the 14.9\" star) is 0.0431 and NEBx2P 0.0068 of the NFPP 0.0521. The mean NFPP, 0.045, "
            "lies between the bars, and per 0032 that doesn't clear a nearby EB (TOI-1058.01's read 0.027). "
            "Pixels (pixels.json, SECOND2_RUN): the pass rests on S94 (3.0\", quality 0.82), not timing-suspect; S102 "
            "(9.5\") and S104 (6.3\") are. The pixel diagnosis's per-sector printout "
            "(results/benchmarks/pixel-check-diagnosis-2026-10-20-scripts.tar.gz, summary_second.txt, the 277774870-1 "
            "block): fits at E/N S104 (+6.1, -1.7), S102 (-6.9, +6.5), S95 (-0.9, +2.1), S94 (+0.6, -2.9), S68 "
            "(-2.9, +8.0) arcsec; quality-weighted mean (-0.6, +2.0), 2.1\" from the target, sky scatter 6.1\". The "
            "14.9\" star is at (+13.1, -6.7), 16.3\" from the mean fit. Box SNR at the target against the light "
            "curve's expectation: S94 3.7/3.8, S95 4.2/3.5, S102 4.1/4.5, S104 2.9/2.6, S68 1.9/3.9. "
            "Other on-star cases clean: VizieR I/350/gaiaedr3 within 20\" holds only the target and the 14.75\" star; "
            "no WDS (B/wds/wds) entry within 2'; RUWE 1.02, ipd_frac_multi_peak 0, ipd_gof_harmonic_amplitude 0.0046 "
            "(Gaia DR3); CROWDSAP 0.966 (S1) to 0.990 (S68); TIC contratio 0.0057. "
            "Ground-based photometry that resolves the 14.9\" star, as F1's would, closes this."
        ),
    },
    {
        "id": "F5",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "The evidence-only holdout fail comes from one partly covered S104 transit whose window sits on a "
            "baseline offset: 0031's partly covered transit, in a sector vet-v3 leaves out."
        ),
        "evidence": (
            "checks-with-suspect.json holdout: season 3 (S94 to S95) 'missed', depth 549 +- 109 ppm against a QLP "
            "reference of 1837 +- 297 ppm from 7 points (tension 4.08); season 4 (S102 to S104) holds n 3, depth "
            "1862 +- 453. "
            "/tmp/t13/277774870-1/transits.py: S102 runs 4140.950 to 4150.756 with a gap 4145.006 to 4146.747 that "
            "holds epoch 220 (4146.191); S103 runs 4166.631 to 4176.814 with a gap 4170.136 to 4172.619 that holds "
            "epoch 222 (4171.830); epoch 224 (4197.469, S104) has 30 cadences within two durations, 4 in transit, 2 "
            "in the core. /tmp/t13/277774870-1/edges.py: around epoch 224 the cadences are broken by dozens of short "
            "breaks, and the detrended flux sits below 1 in every 0.4 h bin from -3.6 to +3.6 h (-42 to -2839 ppm): "
            "an offset across the window, not the transit. "
            + RUN.format(s="transits.py") + "; the same for edges.py."
        ),
    },
    {
        "id": "F6",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "No transit or sector carries the signal: dropping any one of the 13 transits leaves it at 12 sigma or "
            "more, though one transit sits at S1's start and the deepest follows a data gap in S67."
        ),
        "evidence": (
            "/tmp/t13/277774870-1/transits.py on the checks' light curve (no S102 to S104), core the central half of "
            "the 1.0 h box: core depths 307 to 1130 ppm (errors 184 to 206), weighted 700 ppm, SNR 13.1 on white "
            "errors (signal_present gives 13.0); leaving one transit out gives 664 to 735 ppm and SNR 12.0 to 13.2. "
            "Epoch 0 (S1, 1800 s) sits 0.05 d after S1's first cadence with one core cadence; epoch 141 (S67), the "
            "deepest at 1130 +- 193 ppm, has data resume 2.9 h before mid-transit after a 5.3 h gap (3133.115 to "
            "3133.335, edges.py); without it SNR 12.0. "
            "vet-v3 sector depths agree (PDCSAP p 0.41; QLP p 0.06, S94 955 +- 200 against S95 504 +- 130); holdout "
            "predicted seasons 1 and 2 at 8.5 and 7.7 sigma (checks.json). "
            "The light-curve file keeps no quality flags, so momentum dumps were not checked by flag."
        ),
    },
    {
        "id": "F7",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "Nothing names the star as a planet host, binary or variable: the only catalogued row is ExoMiner's FFI "
            "row for this signal, and the three ADS hits are star catalogues."
        ),
        "evidence": (
            "literature.json (identical to LIT3_RUN's): ExoFOP read live, no TOIs, CTOIs, planets, imaging or files; "
            "arXiv, OpenAlex and Zenodo 0 hits on all four names. SIMBAD's page for TIC 277774870 (read live): type '*', "
            "3 references, no notes. "
            "Novelty (SNAP3): ExoMiner-v2 vetting_catalog_FFI 277774870-1-S56-69, period 12.81755 d, t0 3133.4594, "
            "score 0.573 (PC, second-list.csv); our epoch 141 predicts 3133.4559, 5 min off. No SPOC TCE "
            "(second-list.md). "
            "The ADS hits, each looked up on VizieR: 2018A&A...609A.116R (Gaia red clump calibration) lists the star "
            "only in its 'Low extinction TGAS HR diagram' table (J/A+A/609/A116/lowetgas), not as a clump giant: M_G "
            "3.55 from G 9.89 and parallax 5.407 mas, BP-RP 0.73, logg 4.15. 2019MNRAS.490.3158C (MDFC, "
            "II/361/mdfc-v10): G0, CalFlag 0, no WDS components, IRflag 1, which its ReadMe defines as a K-[22] or "
            "mid-IR excess; AllWISE W4 is 8.40 at quality B (qph AAAB) against K 8.65. 2014ASPC..485..223B (JSDC v2, "
            "II/346/jsdc_v2): G0, CalFlag 0. None names the star as a host, binary, variable or multiple member, or "
            "reports a period."
        ),
    },
]

out = {
    "signal": "277774870-1",
    "summary": (
        "Full brief on a second-list row with no failed check. The transit is about a fifth as long as a central "
        "transit of the 1.52 Rsun TIC star, so on that star it must graze or be very eccentric; the light curve fits "
        "that as well as a central transit across a dense star (delta chi2 0.55), and TRICERATOPS's FPP of 0.933 "
        "sits on an M-dwarf pair bound to the target (SEB 0.73, SEBx2P 0.10). Gaia DR3's RVs rule out an eclipsing "
        "binary on the target, the pixels place the loss at the target rather than the 14.9 arcsec neighbour, no "
        "transit or sector dominates, the evidence-only holdout fail is a baseline offset in one partial S104 "
        "transit, and nothing in the literature names the star."
    ),
    "findings": findings,
    "hits_flagged": [],
}

text = json.dumps(out, indent=2, ensure_ascii=False)
assert "—" not in text and "–" not in text
with open("/tmp/t13/277774870-1/findings.json", "w") as f:
    f.write(text + "\n")
print(len(findings), "findings written")
