"""Per-transit look at 277774870-1: core depth, nearest data gap or sector edge, and coverage in the timing-suspect
sectors. Core = central half of the signal's duration, at the signal's ephemeris, on the detrended light curve the
checks saw (and, for S102-104, the evidence-only one). Read-only."""
import json, sys
from pathlib import Path
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.checks.families import good_timestamps
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

run = Path(sys.argv[1]) / "signals/277774870-1"
checks = json.loads((run / "checks.json").read_text())
eph = Ephemeris(**checks["ephemeris"])
cs = load_criteria("criteria/search-v2.toml").values
lc = LightCurve.load(lc_dir() / "277774870.npz")
seen = detrend(good_timestamps(lc), cs["detrend"], [])
full = detrend(lc, cs["detrend"], [])

def table(flat, label):
    print("==", label)
    rows = []
    epoch = np.round((flat.time - eph.t0) / eph.period).astype(int)
    for n in np.unique(epoch):
        m = epoch == n
        mid = eph.t0 + n * eph.period
        dt = flat.time[m] - mid
        win = np.abs(dt) < 2 * eph.duration
        if not win.any():
            continue
        core = np.abs(dt) < 0.25 * eph.duration
        intr = np.abs(dt) < 0.5 * eph.duration
        sec = int(np.unique(flat.sector[m])[0])
        # Nearest gap edge: a jump over 0.1 d in this sector's cadences, or the sector's first or last cadence.
        ts = np.sort(flat.time[flat.sector == sec])
        jumps = np.where(np.diff(ts) > 0.1)[0]
        edges = np.concatenate([[ts[0]], ts[jumps], ts[jumps + 1], [ts[-1]]])
        near_edge = float(np.min(np.abs(edges - mid)))
        f, e = flat.flux[m][core], flat.flux_err[m][core]
        depth = 1 - np.mean(f) if core.any() else np.nan
        err = np.sqrt(np.sum(e**2)) / max(core.sum(), 1)
        rows.append((n, sec, int(win.sum()), int(intr.sum()), int(core.sum()), depth, err, near_edge))
        print(f"epoch {n:4d} S{sec:<4d} window {win.sum():3d} in-transit {intr.sum():3d} core {core.sum():3d} "
              f"depth {depth*1e6:8.0f} +- {err*1e6:5.0f} ppm  nearest gap/edge {near_edge:6.2f} d")
    return rows

rows = table(seen, "checks' light curve (no S102-104)")
r = np.array([(d, e) for _, _, _, _, c, d, e, _ in rows if c > 0])
w = 1 / r[:, 1] ** 2
mean = np.sum(w * r[:, 0]) / np.sum(w)
print(f"weighted core depth {mean*1e6:.0f} ppm, SNR {mean*np.sqrt(np.sum(w)):.1f} (white errors)")
for i in range(len(r)):
    k = np.ones(len(r), bool); k[i] = False
    mm = np.sum(w[k] * r[k, 0]) / np.sum(w[k])
    print(f"  without transit {i}: depth {mm*1e6:.0f} ppm, SNR {mm*np.sqrt(np.sum(w[k])):.1f}")
sus = full.select(np.isin(full.sector, [102, 103, 104]))
table(sus, "evidence-only light curve, S102-104 only")
for s in (102, 103, 104):
    t = sus.time[sus.sector == s]
    print(f"S{s}: {t.min():.3f} to {t.max():.3f}, gaps over 0.1 d:",
          [(round(a, 3), round(b, 3)) for a, b in zip(np.sort(t)[:-1][np.diff(np.sort(t)) > 0.1], np.sort(t)[1:][np.diff(np.sort(t)) > 0.1])])
    ep = np.arange(np.ceil((t.min() - eph.t0) / eph.period), np.floor((t.max() - eph.t0) / eph.period) + 1)
    print("   predicted epochs in span", ep.astype(int).tolist(), [round(eph.t0 + x * eph.period, 3) for x in ep])
