"""Cadences around epochs 141 (S67) and 224 (S104) of 277774870-1, raw and detrended. Read-only."""
import json, sys
from pathlib import Path
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve
run = Path(sys.argv[1]) / "signals/277774870-1"
eph = Ephemeris(**json.loads((run / "checks.json").read_text())["ephemeris"])
cs = load_criteria("criteria/search-v2.toml").values
lc = LightCurve.load(lc_dir() / "277774870.npz")
full = detrend(lc, cs["detrend"], [])
for n, s in ((141, 67), (224, 104)):
    mid = eph.t0 + n * eph.period
    m = (lc.sector == s) & (np.abs(lc.time - mid) < 0.6)
    t = lc.time[m]
    print(f"== epoch {n} S{s} mid {mid:.4f}; cadences within 0.6 d: {m.sum()}")
    d = np.diff(t)
    big = np.where(d > 2.5 * np.median(d))[0]
    print("   breaks (start, end, hours from mid):", [(round(t[i], 4), round(t[i + 1], 4), round((t[i] - mid) * 24, 2), round((t[i + 1] - mid) * 24, 2)) for i in big])
    mf = (full.sector == s) & (np.abs(full.time - mid) < 0.15)
    tb = (full.time[mf] - mid) * 24
    fb = (full.flux[mf] - 1) * 1e6
    bins = np.arange(-3.6, 3.61, 0.4)
    idx = np.digitize(tb, bins)
    print("   detrended, 0.4 h bins (hours from mid: n, mean ppm):", [(round(bins[i - 1] + 0.2, 1), int((idx == i).sum()), int(np.mean(fb[idx == i])) if (idx == i).any() else None) for i in range(1, len(bins))])
