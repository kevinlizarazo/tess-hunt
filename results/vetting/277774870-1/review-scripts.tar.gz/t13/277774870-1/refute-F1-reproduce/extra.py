"""Refuter 1 extras: abs-window density fractions, a second seed for the chi2 comparison, and a local optimisation
of both fits' best samples (prior fit penalised by the TIC density prior). Read-only."""
import json, sys
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days
from tess_hunt.lightcurve import LightCurve
from tess_hunt.transit import a_rs_from_density, light_curve

run = Path(sys.argv[1]) / "signals/277774870-1"
checks = json.loads((run / "checks.json").read_text())
cs = load_criteria("criteria/search-v2.toml").values
cv = load_criteria("criteria/vet-v3.toml").values
lc = LightCurve.load(lc_dir() / "277774870.npz")
good = good_timestamps(lc)
flat = detrend(good, cs["detrend"], [])
fl = split(flat, cv["families"])[cv["families"]["fit"]]
eph = Ephemeris(**checks["ephemeris"])
near = np.abs(phase_days(fl.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, e, x = fl.time[near], fl.flux[near], fl.flux_err[near], fl.exposure_days()[near]
print("n", len(t))
tic, sd = checks["fit_prior"]["rho_prior"]

def chi2(th):
    t0, p, k, b, lr, q1, q2 = th
    if not (0 < q1 < 1 and 0 < q2 < 1 and k > 0 and b >= 0):
        return 1e12
    a = a_rs_from_density(10.0**lr, p)
    if a <= 1 + k:
        return 1e12
    u1, u2 = 2 * np.sqrt(q1) * q2, np.sqrt(q1) * (1 - 2 * q2)
    m = light_curve(t, x, t0, p, k, a, b, u1, u2)
    return float(np.sum(((f - m) / e) ** 2))

flat_s = np.load(run / "fit_samples.npz")["samples"]
prior_s = np.load(run / "fit_prior_samples.npz")["samples"]
lr = flat_s[:, 4]
for n in (2, 3):
    print(f"flat fit |log_rho - TIC| < {n} sd:", int((np.abs(lr - tic) < n * sd).sum()), round(float(np.mean(np.abs(lr - tic) < n * sd)) * 100, 3), "%")
print("flat fit log_rho min", round(lr.min(), 3), "p16", round(np.percentile(lr, 16), 3))

for seed in (1,):
    rng = np.random.default_rng(seed)
    best = {}
    for name, s in (("flat", flat_s), ("prior", prior_s)):
        idx = rng.choice(len(s), 3000, replace=False)
        c = np.array([chi2(s[i]) for i in idx])
        best[name] = s[idx[np.argmin(c)]]
        print(f"seed {seed} {name} min chi2 {c.min():.2f}")
# Local optimisation from each best sample: flat fit free, prior fit with the Gaussian density penalty
r1 = minimize(chi2, best["flat"], method="Nelder-Mead", options={"maxiter": 20000, "xatol": 1e-7, "fatol": 1e-4})
pen = lambda th: chi2(th) + ((th[4] - tic) / sd) ** 2
r2 = minimize(pen, best["prior"], method="Nelder-Mead", options={"maxiter": 20000, "xatol": 1e-7, "fatol": 1e-4})
print("opt flat chi2", round(r1.fun, 2), "theta", np.round(r1.x, 4).tolist())
print("opt prior chi2", round(chi2(r2.x), 2), "penalty", round(((r2.x[4] - tic) / sd) ** 2, 2), "theta", np.round(r2.x, 4).tolist())
print("null chi2", round(float(np.sum(((f - 1) / e) ** 2)), 2))
