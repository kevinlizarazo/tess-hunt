from astroquery.vizier import Vizier
from astropy.coordinates import SkyCoord
import astropy.units as u
V=Vizier(columns=['**'], row_limit=10)
c=SkyCoord(146.851235*u.deg,-39.879963*u.deg)
for cat in ('J/MNRAS/506/150','J/MNRAS/478/4513','J/A+A/609/A116'):
    try: r=V.query_region(c, radius=5*u.arcsec, catalog=cat)
    except Exception as e: print(cat,'ERR',e); continue
    print('##', cat, [ (t.meta.get('name'), len(t)) for t in r])
    for t in r:
        for row in t:
            d={k: str(row[k]) for k in t.colnames if any(s in k.lower() for s in ('flag','sp','teff','logg','sobject','bin','name','gaia','source'))}
            print('  ', t.meta.get('name'), d)
