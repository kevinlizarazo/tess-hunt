from astroquery.vizier import Vizier
V=Vizier(columns=['**'], row_limit=10)
for n in ('22613','22614'):
    r=V.query_constraints(catalog='I/98A/nltt', NLTT=n)
    for t in r:
        for row in t: print(n, {k: str(row[k]) for k in t.colnames})
