import json, numpy as np
d=json.load(open('detail.json'))[0]
for s in d['per_sector']:
    if 'error' in s: print(s); continue
    f=s['fit']
    comp=[c for c in s['catalogue'] if c['tic']==44926982][0]
    tgt=s['catalogue'][0]
    ce=(comp['ra']-tgt['ra'])*np.cos(np.radians(tgt['dec']))*3600; cn=(comp['dec']-tgt['dec'])*3600
    nulls=[n for n in s['nulls'] if n.get('ok') and n['phase']>0]
    nb=np.array([n['box_snr'] for n in nulls]); nq=np.array([n['quality'] for n in nulls]); no=np.array([n['offset'] for n in nulls])
    print(f"S{s['sector']}: fit E {f['east']:6.1f} N {f['north']:6.1f} off {f['offset']:5.1f} Q {f['quality']:.2f} | comp E {ce:5.1f} N {cn:5.1f} sep {np.hypot(ce,cn):.1f} | fit-comp {np.hypot(f['east']-ce,f['north']-cn):5.1f} | transits_used {s['transits_used']} n_in {s['n_in']} | target box z {s['target_box']['snr']:.1f} exp {s['expected_snr']:.1f} depth_ratio {s['depth_ratio']:.2f} | nulls {len(nulls)} box z sd {nb.std(ddof=1):.2f} nulls>=Q {int((nq>=f['quality']).sum())} null offsets med {np.median(no):.1f}")
    print('   near_fit', [(n['tic'], round(n['sep_from_fit'],1), round(n['tmag'],2)) for n in s['near_fit']])
