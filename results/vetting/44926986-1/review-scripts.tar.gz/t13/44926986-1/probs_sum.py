# Sums the last TRICERATOPS run's scenario table by star and scenario.
import csv, collections, sys
rows = list(csv.DictReader(open(sys.argv[1])))
by = collections.defaultdict(float)
for r in rows:
    by[(r["ID"], r["scenario"])] += float(r["prob"])
print("TIC 44926982:", {s: p for (i, s), p in by.items() if i == "44926982"})
nf = sum(p for (i, s), p in by.items() if s in ("NTP", "NEB", "NEBx2P"))
on = sum(p for (i, s), p in by.items() if s in ("TP", "PTP", "DTP"))
print("NFPP %.5f  target TP+PTP+DTP %.4f  FPP %.5f" % (nf, on, 1 - on))
