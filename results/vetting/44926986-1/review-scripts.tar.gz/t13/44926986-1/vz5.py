from astroquery.vizier import Vizier
from astropy.coordinates import SkyCoord
import astropy.units as u
V=Vizier(columns=['**'], row_limit=10)
# NLTT positions are B1950/J2000 to ~arcmin precision; search wide around rNLTT's NLTT position
c=SkyCoord(146.80937*u.deg,-39.90002*u.deg)
r=V.query_region(c, radius=3*u.arcmin, catalog='I/98A')
for t in r:
    print('==', t.meta.get('name'), t.colnames)
    for row in t: print('  ', {k: str(row[k]) for k in t.colnames})
