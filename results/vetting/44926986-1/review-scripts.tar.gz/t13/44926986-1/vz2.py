from astroquery.vizier import Vizier
V=Vizier(columns=['**'], row_limit=-1)
r=V.get_catalogs('J/AJ/163/207')
for t in r:
    name=t.meta.get('name'); print('==', name, len(t), t.meta.get('description'))
    print('   cols', t.colnames[:12], '...')
    for row in t:
        s=' '.join(str(row[c]) for c in t.colnames)
        if '5431607545961330560' in s or '5431607545963652864' in s or '44926986' in s:
            print('   HIT:', {c: str(row[c]) for c in t.colnames})
