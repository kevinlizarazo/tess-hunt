import csv, numpy as np
from astropy.coordinates import SkyCoord
import astropy.units as u
g={int(r['source_id']):r for r in csv.DictReader(open('gaia_pair.csv'))}
A=g[5431607545961330560]; B=g[5431607545963652864]
a=SkyCoord(float(A['ra'])*u.deg,float(A['dec'])*u.deg); b=SkyCoord(float(B['ra'])*u.deg,float(B['dec'])*u.deg)
tic=SkyCoord(146.852182941572*u.deg,-39.8797286285282*u.deg)  # checks.json star ra/dec (TIC, J2000)
print('A-B sep at J2016 (both Gaia DR3): %.2f" PA %.1f deg' % (a.separation(b).arcsec, a.position_angle(b).deg))
print('TIC(J2000) target position to B (Gaia J2016): %.2f"' % tic.separation(b).arcsec)
print('TIC(J2000) target position to A (Gaia J2016): %.2f"' % tic.separation(a).arcsec)
for k in ('parallax','pmra','pmdec','radial_velocity'):
    print(k, A[k], B[k], A[k+'_error'] if k+'_error' in A else '', B[k+'_error'] if k+'_error' in B else '')
print('dist pc A %.1f B %.1f' % (1000/float(A['parallax']), 1000/float(B['parallax'])))
print('projected sep AU %.0f' % (a.separation(b).arcsec*1000/float(A['parallax'])))
