# Builds the 0034/0035 addendum from the old review, copying unchanged text exactly.
import json

old = json.load(open("/tmp/t13/out/44926986-1/review.json"))
by = {f["id"]: f for f in old["findings"]}


def sub(text, old_s, new_s):
    assert text.count(old_s) == 1, old_s
    return text.replace(old_s, new_s)


summary = sub(
    old["summary"],
    'and the neighbour table puts that companion at 12.5" because it measures from the target\'s J2000 position.',
    'and the first runs\' neighbour table put that companion at 12.5" because it measured from the target\'s J2000 '
    "position, which decision 0034 fixed. Updated 2026-10-21 for the 0034/0035 rerun.",
)

f1 = by["F1"]
F1 = {
    "id": "F1", "lens": f1["lens"], "rating": f1["rating"], "claim": f1["claim"], "evidence": f1["evidence"],
    "status": "unchanged",
    "why": "Diffed the first run's checks.json against VET2_RUN's (identical by cmp to drafts/m3-r2's): novelty's "
    "evidence and reason, ephemeris and catalogued are identical, so every number F1 quotes holds; LIT3_RUN's "
    "literature.json search.exofop still has no TOI, CTOI or planet rows; regrepped SNAP3's eumemic line 2969 and the "
    "2026-10-13 snapshot (2427 lines, no row); the first-run paths it cites still hold what it says.",
}

f2 = by["F2"]
ev2 = sub(
    f2["evidence"],
    "triceratops.json (TRIC_RUN signals/44926986-1/, identical to ~/.cache/tess-hunt/drafts/m3/44926986-1/triceratops.json by cmp)",
    "triceratops.json (TRIC2_RUN signals/44926986-1/, identical to ~/.cache/tess-hunt/drafts/m3-r2/44926986-1/triceratops.json by cmp)",
)
ev2 = sub(
    ev2,
    "probs_sum.py ~/.cache/tess-hunt/drafts/m3/44926986-1/probs.csv (last run): TIC 44926982 NTP 0.15486, NEB 2.8e-22, "
    "NEBx2P 3.2e-05; NFPP 0.15490, equal to that run's nfpp 0.15490;",
    "probs_sum.py ~/.cache/tess-hunt/drafts/m3-r2/44926986-1/probs.csv (last run): TIC 44926982 NTP 0.15487, NEB 2.8e-22, "
    "NEBx2P 3.2e-05; NFPP 0.15491, equal to that run's nfpp 0.15491;",
)
ev2 += (
    " Updated 2026-10-21 for the 0034/0035 rerun: triceratops.json and probs.csv are cited from the rerun, TRIC2_RUN "
    "20261020T181658Z-vetting-triceratops-61b5944-1bbf and drafts/m3-r2, in place of TRIC_RUN "
    "20261020T013408Z-vetting-triceratops-62882b5-e092 and drafts/m3; in the last run, the NTP on TIC 44926982 0.15486 "
    "to 0.15487 and its NFPP and nfpp 0.15490 to 0.15491; mean NFPP 0.167384 to 0.167390 and mean FPP 0.203988 to "
    "0.203988, the same at the precision quoted."
)
F2 = {
    "id": "F2", "lens": f2["lens"], "rating": f2["rating"], "claim": f2["claim"], "evidence": ev2,
    "status": "updated",
    "why": "Diffed TRIC2_RUN's triceratops.json and probs.csv (identical by cmp to drafts/m3-r2's) against the first "
    "run's: per-run nfpp to 3 decimals, mean, sd, fpp mean, blockers, missing_hosts, degenerate, field_population, "
    "ruwe, sectors, 600 s, 88 points, B's tdepth and required depth, R_p 4.67 and the star list's Tmags hold; reran "
    "probs_sum.py on the new probs.csv (NTP and NFPP move in the fifth decimal) and ephem.py, whose inputs match "
    "VET2_RUN's fit and fit_prior and TRIC2_RUN's ephemeris; gaia_pair.csv (sep.py: 9.86\", PA 234.1, 1103 au), the "
    "eumemic row and triage's pixel fits don't come from the rerun, and the fits match the dossier's centroid table. "
    "One kept number is off, not by the rerun: Tmag 9.4929 and 10.6073 give a flux ratio of 0.3583, not 0.359, in both "
    "runs; left as written.",
}

f3 = by["F3"]
F3 = {
    "id": "F3", "lens": f3["lens"], "rating": "note",
    "claim": "On the first runs (vetting 20261020T010149Z-vetting-run-62882b5-c3ee and its evidence-only twin "
    "20261020T011247Z-vetting-run-62882b5-d92b) this finding reported that the neighbour table measured separations "
    "from the target's J2000 TIC position to Gaia DR3 positions at J2016, so the bound companion TIC 44926982 read "
    "12.5\" for a true 9.86\"; decision 0034 fixed it, and the rerun's table measures from the target's own Gaia DR3 "
    "position at J2016.0.",
    "evidence": 'Original claim: "' + f3["claim"] + '" It was a note, with no refuters. Decision 0034 '
    "(docs/decisions/0034-neighbour-table-epochs.md) cites this finding and centres the cone on the target's own Gaia "
    "DR3 row. Rerun vetting 20261020T174317Z-vetting-run-61b5944-2d70 (signals/44926986-1/checks.json, identical by "
    "cmp to ~/.cache/tess-hunt/drafts/m3-r2/44926986-1/checks.json): neighbours pass, centre \"Gaia DR3 "
    "5431607545961330560, J2016.0\", reason \"6 of 28 neighbours could host the signal\" (was \"7 of 29\"). "
    "neighbours.csv: Gaia DR3 5431607545963652864 (TIC 44926982) sep_arcsec 9.8586 (was 12.5039), the same as A to B "
    "from both DR3 positions in /tmp/t13/44926986-1/gaia_pair.csv (sep.py: 9.86\" at PA 234.1 deg). The cone-edge "
    "case F3 warned of happened here: Gaia DR3 5431607644742487424 (possible, required depth 0.86, 59.04\" from the TIC "
    "position) sits 61.50\" from the target's DR3 position and leaves the 60\" cone, so the possible hosts go from 7 to "
    "6 and TRIC2_RUN's hosts_tdepth_zero from [5431607335504795136, 5431607644742487424] to [5431607335504795136]. The "
    "28 stars in both tables move by up to 2.74\" (Gaia DR3 5431607576022977792, 44.48\" to 41.74\"), and no star's "
    "possible flag flips. The dossier's possible-host table names its centre (Gaia DR3 5431607545961330560, J2016.0) "
    "and shows TIC 44926982 at 9.9\"; 0026's Ruling S reads 9.86\" (corrected in 0034); the Task 13 brief no longer "
    "gives 12.5\". The controls F3 left unchecked: 0034 item 3 keeps the control vet's mixed-epoch tables with 0034 as "
    "their note, and item 5 shows 0025, 0026 and 0032's 20.90\" and 23.53\" came from the network test, not this "
    "table, and hold within 0.05\". No check outcome changed.",
    "status": "resolved",
    "why": "Read 0034; diffed VET2_RUN's checks.json neighbours (centre, reason, possible_hosts) and neighbours.csv "
    "against the first run's; recomputed the companion's and the cone-edge star's separations from gaia_pair.csv's "
    "DR3 position of the target (9.86\", 61.50\"); compared the two runs' hosts_tdepth_zero; grepped 0026 and the "
    "brief for 12.5\".",
}

f4 = by["F4"]
F4 = {
    "id": "F4", "lens": f4["lens"], "rating": f4["rating"], "claim": f4["claim"], "evidence": f4["evidence"],
    "status": "unchanged",
    "why": "Diffed LIT3_RUN's literature.json (identical by cmp to drafts/m3-r2's) against the first run's: the same "
    "outcome and 6 hits, differing only in vetting_run and the resume's from_run markers; F4's VizieR evidence doesn't "
    "come from the runs.",
}

out = {
    "signal": old["signal"],
    "summary": summary,
    "findings": [F1, F2, F3, F4],
    "hits_flagged": old["hits_flagged"],
}
for k in ("F1", "F4"):
    f = {x["id"]: x for x in out["findings"]}[k]
    assert all(f[x] == by[k][x] for x in ("lens", "rating", "claim", "evidence"))
json.dump(out, open("/tmp/t13/44926986-1/addendum/findings.json", "w"), indent=2, ensure_ascii=False)
open("/tmp/t13/44926986-1/addendum/findings.json", "a").write("\n")
print("ok")
