"""Task 13 (0036): bring 44926986-1's review up to date with TRIC3B_RUN. Writes findings.json."""
import json

src = json.load(open("/tmp/t13/out-r2/44926986-1/review.json"))
f = {x["id"]: x for x in src["findings"]}
NEW = "20261021T194348Z-vetting-triceratops-cd4e7a2-7821"
OLD = "20261020T181658Z-vetting-triceratops-61b5944-1bbf"


def sub(text, edits):
    for old, new in edits:
        assert text.count(old) == 1, old
        text = text.replace(old, new)
    return text


def keep(fid, status, why, evidence=None):
    x = f[fid]
    return {"id": fid, "lens": x["lens"], "rating": x["rating"], "claim": x["claim"],
            "evidence": x["evidence"] if evidence is None else evidence, "status": status, "why": why}


f2 = sub(f["F2"]["evidence"], [
    ("triceratops.json (TRIC2_RUN signals/44926986-1/,", "triceratops.json (TRIC3B_RUN signals/44926986-1/,"),
    ("TIC 44926982 NTP 0.15487,", "TIC 44926982 NTP 0.15485,"),
    ("NFPP 0.15491, equal to that run's nfpp 0.15491; target TP+PTP+DTP 0.8065.",
     "NFPP 0.15489, equal to that run's nfpp 0.15489; target TP+PTP+DTP 0.8064."),
]) + (
    " Updated 2026-10-22 for the 0036 TRICERATOPS rerun: triceratops.json and probs.csv are cited from TRIC3B_RUN "
    f"{NEW} (identical by cmp to drafts/m3-r2) in place of TRIC2_RUN {OLD}; its dropped_stars lists three DUPLICATE "
    "rows, TIC 872495677, 872495726 and 872493659 (of 44926991, 44927039 and 44926970, 112\" to 190\" out), which "
    "TRIC2_RUN gave tdepth 0 and no probs.csv rows, and the 6 hosts, their TICs and B's tdepth are unchanged; in the "
    "last run, the NTP on TIC 44926982 0.15487 to 0.15485, its NFPP and nfpp 0.15491 to 0.15489, and target "
    "TP+PTP+DTP 0.8065 to 0.8064; mean NFPP 0.167390 to 0.167389 and mean FPP 0.203988 to 0.204016 (1.4e-4 "
    "relative), within 0036 item 5's run-to-run noise and the same at the precision quoted."
)

f3 = sub(f["F3"]["evidence"], [
    ("and TRIC2_RUN's hosts_tdepth_zero from [5431607335504795136, 5431607644742487424] to [5431607335504795136].",
     "and TRICERATOPS's hosts_tdepth_zero from [5431607335504795136, 5431607644742487424] (TRIC_RUN) to "
     "[5431607335504795136] (TRIC3B_RUN)."),
]) + (
    f" Updated 2026-10-22 for the 0036 TRICERATOPS rerun: hosts_tdepth_zero is cited from TRIC3B_RUN {NEW} in place "
    f"of TRIC2_RUN {OLD}; its value, [5431607335504795136], and the 6 hosts are the same in both."
)

out = {
    "signal": src["signal"],
    "summary": src["summary"] + " Updated 2026-10-22 for the 0036 TRICERATOPS rerun.",
    "findings": [
        keep("F1", "unchanged",
             "Cites no TRICERATOPS run or number; read VET_RUN's and VET2_RUN's signals/44926986-1/checks.json "
             "(novelty, ephemeris and catalogued the same in both: eumemic-allsky f1d17f0 44926986, 24.114628, ratio "
             "1.0; P 24.114544, t0 1556.3563, 0.125 d, 776 ppm; overlaps 30, 31, 60, 61, 90) and search.exofop in "
             "drafts/m3 and drafts/m3-r2 literature.json (no TOIs, CTOIs or planets in either)."),
        keep("F2", "updated",
             "Read TRIC3B_RUN's triceratops.json and probs.csv (cmp-identical to drafts/m3-r2), reran probs_sum.py, "
             "compare_tric.py (reproduces compare.txt), ephem.py and sep.py, and checked gaia_pair.csv and VET2_RUN "
             "checks.json's CROWDSAP (0.729 to 0.735): only the run citation and the last run's NTP, NFPP, nfpp and "
             "on-target share moved, inside 0036 item 5's noise, and every nfpp stays above 0.1 (min 0.146), so the "
             "kill rating holds; the dropped rows were never weighed here, so 'no bug or misread found' still holds; "
             "one kept number is off by rounding, not by the rerun: 10^(-0.4*(10.6073-9.4929)) is 0.358, where the "
             "evidence says 0.359.",
             evidence=f2),
        keep("F3", "updated",
             "Its one TRICERATOPS citation, TRIC2_RUN's hosts_tdepth_zero, moves to TRIC3B_RUN with the same value; "
             "read TRIC_RUN's and TRIC3B_RUN's triceratops.json (7 and 6 hosts) and VET_RUN's and VET2_RUN's "
             "checks.json and neighbours.csv (7 of 29 to 6 of 28, centre, 12.5039 to 9.8586, 59.04\" out of the cone "
             "at 61.50\" from gaia_pair.csv's A, largest move 2.74\" on 5431607576022977792, no possible flag flips), "
             "all as stated.",
             evidence=f3),
        keep("F4", "unchanged",
             "Rests on VizieR queries and cites no TRICERATOPS run or number; nothing it uses was rerun, and "
             "LIT3_RUN's literature.json is cmp-identical to drafts/m3-r2's."),
    ],
    "hits_flagged": src["hits_flagged"],
}
for a, b in (("F1", out["findings"][0]), ("F4", out["findings"][3])):
    assert b["claim"] == f[a]["claim"] and b["evidence"] == f[a]["evidence"]
json.dump(out, open("/tmp/t13/44926986-1/addendum-0036/findings.json", "w"), indent=2, ensure_ascii=False)
print(json.dumps(out, ensure_ascii=False))
