from astroquery.vizier import Vizier
from astropy.coordinates import SkyCoord
import astropy.units as u
c=SkyCoord(146.851235*u.deg,-39.879963*u.deg)
V=Vizier(columns=['**'], row_limit=50)
cats=V.find_catalogs('J/AJ/163/207')
for k,v in cats.items(): print(k, v.description)
r=V.query_region(c, radius=60*u.arcsec, catalog='J/AJ/163/207')
for t in r:
    print(t.meta.get('name'), t.meta.get('description')); t.pprint(max_width=400, max_lines=20)
r=V.query_constraints(catalog='J/AJ/163/207', TIC='44926986')
for t in r:
    print('BY TIC', t.meta.get('name')); t.pprint(max_width=400, max_lines=20)
