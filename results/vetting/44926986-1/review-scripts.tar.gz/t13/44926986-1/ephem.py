# Minutes between TRICERATOPS's fold (density-prior fit) and other ephemerides at the transits it used.
ref = (24.114782561889026, 1556.346474857804)
alts = {"search": (24.114544197506145, 1556.3563215855993),
        "flat fit": (24.114807974179474, 1556.3451657000792),
        "eumemic": (24.114628, 2458556.348 - 2457000)}
for name, (p, t) in alts.items():
    print(name, " ".join("E%d %+.1f min" % (e, ((t + e * p) - (ref[1] + e * ref[0])) * 1440) for e in (30, 31, 60, 61)))
