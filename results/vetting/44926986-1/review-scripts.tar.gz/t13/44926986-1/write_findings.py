import json

S = "/tmp/t13/44926986-1"
D = "~/.cache/tess-hunt/drafts/m3/44926986-1"
out = {
    "signal": "44926986-1",
    "summary": (
        "Short brief: novelty and TRICERATOPS killed this signal, and I tested whether either kill is wrong. Both stand: "
        "eumemic's public all-sky list (commit f1d17f0, 2026-10-16) holds this signal at the same period and epoch, and "
        "TRICERATOPS's NFPP stays above 0.1 in all ten runs, at every nearby ephemeris and in eumemic's own run, with no "
        "bug found. What TRICERATOPS can't exclude is a planet on the bound companion TIC 44926982 (9.86\" away, same "
        "parallax, proper motion and RV), not an eclipsing binary, and the neighbour table puts that companion at 12.5\" "
        "because it measures from the target's J2000 position."
    ),
    "findings": [
        {
            "id": "F1",
            "lens": "real_new",
            "rating": "kill",
            "claim": (
                "The novelty kill stands: eumemic's public all-sky candidate list holds this signal on this star, and "
                "the check matched it as decision 0013 says it should."
            ),
            "evidence": (
                f"checks.json (VET_RUN signals/44926986-1/checks.json, identical to {D}/checks.json by cmp), novelty: "
                "category known, one match, kind community, 'eumemic-allsky f1d17f0 44926986', period 24.114628, ratio 1.0. "
                "The row: grep 44926986 $SNAP3/raw/eumemic/results_public_candidates_allsky.csv gives line 2969: P_d "
                "24.114628, T0_BJD 2458556.348 (BTJD 1556.348), T14_h 2.91, depth_ppm 836, n_transits 6, tier 'likely "
                "nearby FP', search 'QLP re-search', NFPP 0.3023, cs_neighbour 44926982 at 9.9\". Ours (checks.json "
                "ephemeris): P 24.114544, t0 BTJD 1556.3563, 3.00 h, 776 ppm; checks.json catalogued shows the row's mask "
                "on all 5 of our transits with data (30, 31, 60, 61, 90). Same signal. When it appeared: $SNAP3/manifest.json "
                "reads eumemic at commit f1d17f073842 (raw/eumemic_exoplanets/head.json committer date 2026-10-16T16:16:02Z); "
                "the 2026-10-13T163454Z snapshot (commit da72261) has 2427 lines in the same file and no 44926986 row (grep -c . "
                "and grep 44926986 on ~/.cache/tess-hunt/catalogs/2026-10-13T163454Z/raw/eumemic/results_public_candidates_allsky.csv). "
                "No eumemic-tce row on the star in either snapshot (zcat results_public_all_signals_tce.csv.gz | awk -F, "
                "'$25==44926986'). Rule: src/tess_hunt/sources.py normalise_eumemic gives allsky rows kind 'community' (only "
                "eumemic-tce rows are 'tce'); 0013: a match of any kind but tce fails novelty; criteria/vet-v3.toml [novelty] "
                "inconclusive_kinds = ['tce']. Not a bug or misread: eumemic's own tier ('likely nearby FP') doesn't make the "
                "signal unknown; it is a public, dated record of this signal on this star. tess-hunt has no earlier public "
                "claim: curl -s -o /dev/null -w '%{http_code}' https://api.github.com/repos/kevinlizarazo/tess-hunt gives 404 "
                f"(not public). ExoFOP live: no TOI, CTOI or planet rows ({D}/literature.json search.exofop). 0031's causes "
                "don't apply to novelty."
            ),
        },
        {
            "id": "F2",
            "lens": "on_star",
            "rating": "kill",
            "claim": (
                "The TRICERATOPS kill stands: no bug or misread found, and NFPP > 0.1 holds in every run, at every nearby "
                "ephemeris and in an independent run, but the scenario it can't exclude is a planet on the bound companion "
                "TIC 44926982, not an eclipsing binary."
            ),
            "evidence": (
                f"triceratops.json (TRIC_RUN signals/44926986-1/, identical to {D}/triceratops.json by cmp): outcome fail; "
                "nfpp per run 0.165, 0.179, 0.160, 0.183, 0.205, 0.167, 0.167, 0.146, 0.147, 0.155 (mean 0.167, sd 0.018), fpp "
                "mean 0.204; blockers [], missing_hosts [], degenerate all false, field_population true, ruwe 0.848 (< 1.4); "
                "sectors 36, 62, 63 at 600 s, 88 binned points. "
                f"Which scenario: python3 {S}/probs_sum.py {D}/probs.csv (last run): TIC 44926982 NTP 0.15486, NEB 2.8e-22, "
                "NEBx2P 3.2e-05; NFPP 0.15490, equal to that run's nfpp 0.15490; target TP+PTP+DTP 0.8065. So NFPP is a planet "
                "on B (R_p 4.67 Earth radii in probs.csv), and TRICERATOPS puts about 0.81 on A. "
                f"B is bound: Gaia DR3 query saved as {S}/gaia_pair.csv: A 5431607545961330560 parallax 8.935 +- 0.011 mas, "
                "pm (-163.63, -52.65) mas/yr, RV 91.85 +- 0.19 km/s; B 5431607545963652864 parallax 8.919 +- 0.014, pm "
                f"(-165.81, -52.51), RV 92.19 +- 0.28. {S}/sep.py: 9.86\" at PA 234 deg, about 1100 au projected. Christian "
                "et al. 2022 Table C1 lists the pair (TIC-1 44926986, TIC-2 44926982). "
                "Depth bookkeeping is right: TRICERATOPS's tdepth on B 0.2188% against the neighbour table's required 0.2187% "
                "(triceratops.json hosts); Tmag 9.4929 vs 10.6073 gives a flux ratio of 0.359, matching CROWDSAP 0.729 to 0.735. "
                f"Ephemeris (0032's caveat): python3 {S}/ephem.py: at epochs 30, 31, 60 and 61 the search ephemeris sits +3.9 "
                "to -6.8 min from the density-prior fold, the flat fit within 0.8 min, eumemic's -4.5 to -11.4 min, against a "
                "3.6 h duration and 10 min bins. eumemic's own TRICERATOPS on its ephemeris and data gives NFPP 0.3023 and "
                "NFPP_g 0.3306 (SNAP3 row in F1). The fail doesn't move. "
                "0032's limit covers binaries 20\" to 25\" out; B is 9.86\" out, inside 15\", where 0032 says TRICERATOPS is "
                "what catches a blend the pixels miss. "
                "The pixels can't decide: triage's saved difference images refitted with /tmp/pixel-diag's sector_detail.py "
                f"and two_star.py (copied to {S}, run through /tmp/t13/heavy.sh; {S}/detail.json, {S}/two_star.json, summary "
                f"by {S}/summ.py). One transit per sector, expected 3x3 box SNR 1.1 to 1.9. Fits (east, north): S36 (-3.8, "
                "+1.9), S62 (-10.5, -7.4), S63 (+18.2, +11.7), S89 (-9.2, +6.4), S99 (-0.6, +10.9) arcsec; B sits at (-8.0, "
                "-5.8). Only S62 lands near B (3.0\"). S99, the timing-suspect sector triage's pass rests on, lands 1.0\" from "
                "TIC 872495558 (Tmag 19.89), which can't host the dip. Fixed two-PRF fit: target z 2.7, -0.2, 3.9, 0.1, 0.2; "
                "B z 0.2, 0.7, -8.9, 0.2, -0.0. No 0031 cause applies to TRICERATOPS. "
                "What would place the host: seeing-limited ground photometry that resolves the 9.9\" pair on a predicted "
                "transit (about 0.22% on B, about 780 ppm on A). 2-min data would not, since they come from the same pixels."
            ),
        },
        {
            "id": "F3",
            "lens": "on_star",
            "rating": "note",
            "claim": (
                "The neighbour table's separations mix epochs: it measures from the target's TIC position (J2000) to Gaia "
                "DR3 positions (J2016), so on this high-proper-motion star the companion reads 12.5\" when the pair is "
                "9.86\" apart."
            ),
            "evidence": (
                "src/tess_hunt/neighbours.py QUERY: DISTANCE(POINT('ICRS', ra, dec), POINT('ICRS', {ra}, {dec})) centred on "
                "the target's TIC ra 146.852183, dec -39.879729 (checks.json star; targets.parquet). "
                f"{S}/sep.py (repo venv python): TIC position to B's DR3 position 12.50\" (neighbours.csv sep_arcsec 12.5039); "
                "TIC position to A's own DR3 position 2.75\" (A moves 171.9 mas/yr); A to B, both DR3: 9.86\". This agrees "
                "with TRICERATOPS's J2000 star list (TIC 44926986 at 146.852183, -39.879729 and TIC 44926982 at 146.849306, "
                "-39.881337: 9.83\"), eumemic (9.9\"), the rNLTT (9.0\", PA 231) and Luyten's NLTT (9\", 231 deg). The 12.5\" "
                "is carried into the dossier, into decision 0026's Ruling S text and into the Task 13 brief. It changes no "
                "outcome here: required depths don't use separation (neighbours.required_depths), and Ruling S matched B at "
                "0.001\". But anything read off sep_arcsec (the dossier, the 15\" and 20\" to 25\" reasoning in 0032, a star "
                "near the 1' cone edge) is off by up to the target's motion since J2000. I did not check the controls' "
                "separations in 0025 and 0032, which come from the same table. Per the brief this goes to a decision record."
            ),
        },
        {
            "id": "F4",
            "lens": "real_new",
            "rating": "note",
            "claim": (
                "Three literature hits name the star as a member of a binary (Christian et al. 2022, Salim and Gould 2003, "
                "Luyten's NLTT); none names it as a planet host, eclipsing binary or variable, or reports a period."
            ),
            "evidence": (
                f"VizieR, scripts in {S}: vz2.py finds J/AJ/163/207/tablec1 ('Control sample', binaries without known "
                "planets) row 29: EDR3-1 5431607545961330560, EDR3-2 5431607545963652864, TIC-1 44926986, TIC-2 44926982, "
                "MajAxis 1039 au, e 0.49. vz3.py finds J/ApJ/582/1011/table2: NLTT 22614, BInd 1, BinN 22613, SepN 9.0, PAN "
                "231. vz5.py finds I/98A/remarks: 'L 462-147: Comp. to 146, 231d, 9\"'. Dismissed: GALAH DR3 (vz6.py, "
                "J/MNRAS/506/150: Flagsp 0) and GALAH DR2 (flag_cannon 0), survey catalogues; Ruiz-Dern et al. 2018, whose "
                "title doesn't explain a dwarf in a red-clump paper: it lists the star (Gaia DR1 5431607541661699840) only in "
                "its low-extinction TGAS calibration table 'lowetgas', a calibration sample, not a classification."
            ),
        },
    ],
    "hits_flagged": [
        "doi 10.3847/1538-3881/ac517f, arXiv 2202.00042",
        "doi 10.1086/344822, arXiv astro-ph/0206318",
        "1995yCat.1098....0L",
    ],
}

text = json.dumps(out, ensure_ascii=False)
assert "—" not in text and "–" not in text
with open(f"{S}/findings.json", "w") as fh:
    json.dump(out, fh, indent=1, ensure_ascii=False)
print("ok", [(f["id"], f["rating"]) for f in out["findings"]])
