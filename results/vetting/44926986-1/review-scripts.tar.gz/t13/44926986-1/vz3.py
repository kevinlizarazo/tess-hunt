from astroquery.vizier import Vizier
from astropy.coordinates import SkyCoord
import astropy.units as u
c=SkyCoord(146.852183*u.deg,-39.879729*u.deg, frame='icrs')
V=Vizier(columns=['**'], row_limit=20)
for cat in ['I/98A', 'J/ApJ/582/1011']:
    try:
        r=V.query_region(c, radius=40*u.arcsec, catalog=cat)
    except Exception as e:
        print(cat, 'ERR', e); continue
    print('##', cat, [t.meta.get('name') for t in r])
    for t in r:
        print('==', t.meta.get('name'), t.meta.get('description'))
        for row in t: print('  ', {k: str(row[k]) for k in t.colnames})
