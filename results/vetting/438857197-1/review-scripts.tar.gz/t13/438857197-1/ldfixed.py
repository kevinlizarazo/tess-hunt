"""Read-only: on the light curve vet-v3's fits saw for 438857197-1, hold limb darkening at LEO-Vetter's quadratic
coefficients for the star (u1 0.2346, u2 0.3086, triage evidence) and profile chi2 against log10 density, with
t0, Rp/R* and b free. Compares a central transit on a dense host with a grazing one on the TIC star."""
import json, os
import numpy as np
from scipy.optimize import minimize
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days
from tess_hunt.transit import a_rs_from_density, light_curve

run = os.environ["VET2_RUN"] + "/signals/438857197-1"
checks = json.load(open(run + "/checks.json"))
cs = load_criteria("criteria/search-v2.toml"); cv = load_criteria("criteria/vet-v3.toml")
e = checks["ephemeris"]; eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
lc = good_timestamps(LightCurve.load(lc_dir() / "438857197.npz"))
flat = detrend(lc, cs["detrend"], [])
fit_lc = split(flat, cv["families"])[cv["families"]["fit"]]
near = np.abs(phase_days(fit_lc.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, s = fit_lc.time[near], fit_lc.flux[near], fit_lc.flux_err[near]
x = fit_lc.exposure_days()[near]
P = checks["fit"]["period"]["median"]; T0 = checks["fit"]["t0"]["median"]
U1, U2 = 0.2346, 0.3086
def chi2(t0, k, b, lr):
    if not (0.001 < k < 1.0 and 0 <= b < 1 + k): return 1e12
    a = a_rs_from_density(10.0**lr, P)
    if b >= a: return 1e12
    return float(np.sum(((f - light_curve(t, x, t0, P, k, a, b, U1, U2))/s)**2))
opts = {"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4}
rows = []
for lr in [1.6, 1.4, 1.2, 1.0, 0.8, 0.6, 0.4, 0.2, 0.0, -0.245, -0.438]:
    best = None
    for k0, b0 in [(0.028, 0.1), (0.03, 0.5), (0.035, 0.8), (0.05, 0.95), (0.07, 1.03), (0.15, 1.1), (0.4, 1.35)]:
        r = minimize(lambda v: chi2(v[0], v[1], v[2], lr), [T0, k0, b0], method="Nelder-Mead", options=opts)
        if best is None or r.fun < best.fun: best = r
    rows.append((lr, best.fun, best.x[1], best.x[2]))
    print(f"fixed LD, log rho {lr:+.3f} (a/R* {a_rs_from_density(10.0**lr, P):5.2f}): chi2 {best.fun:.2f}  k {best.x[1]:.4f}  b {best.x[2]:.3f}")
m = min(r[1] for r in rows)
print("min over grid", round(m, 2))
