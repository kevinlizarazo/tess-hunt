"""What Gaia DR3's RVS scatter allows for a circular companion at P = 3.659 d on TIC 438857197.
Katz et al. 2023 (A&A 674, A5), eq. 1, bright stars: eps = sqrt((sqrt(pi/(2N)) * sigma_t)^2 + 0.113^2),
sigma_t the standard deviation (N-1) of the epoch RVs. Inverts it for sigma_t, then asks how often 10 epochs of a
sinusoid of semi-amplitude K at random phases have a standard deviation no larger, with NO measurement noise
(the most lenient case: any noise makes a large K less likely still)."""
import math
import numpy as np
eps, N = 0.4100736, 10            # gaia_dr3.csv: radial_velocity_error, rv_nb_transits
sig = math.sqrt(eps**2 - 0.113**2) / math.sqrt(math.pi / (2 * N))
print(f"epoch RV standard deviation implied: {sig:.3f} km/s")
G, P, MJ, Ms = 6.674e-11, 3.659157 * 86400, 1.898e27, 1.989e30
rng = np.random.default_rng(1)
ph = rng.uniform(0, 2 * np.pi, (200000, N))
s1 = np.sin(ph).std(axis=1, ddof=1)
for Mstar in (1.2, 1.35):
    kj = (2 * math.pi * G / P) ** (1 / 3) * MJ / (Mstar * Ms) ** (2 / 3) / 1000   # km/s per Jupiter mass
    print(f"M* {Mstar}: K per MJ {kj*1000:.0f} m/s")
    for m in (10, 13, 15, 20, 30, 80):
        K = kj * m
        p = np.mean(K * s1 <= sig)
        print(f"   {m:3d} MJ  K {K:5.2f} km/s  P(10-epoch std <= {sig:.2f} | no noise) = {p:.4f}")
    for q in (0.05, 0.01):
        print(f"   noise-free limit at {1-q:.0%}: {sig / np.quantile(s1, q) / kj:.1f} MJ")
