"""Read-only: how ExoMiner++'s FFI catalog scores TOIs of each TFOPWG disposition. Each ExoMiner FFI row is matched
to a TOI on the same TIC whose period agrees within 1%; per disposition, the share of rows scoring below 0.082 and
below 0.265 (the two scores on TIC 438857197), and the same for TOIs whose SPOC duration is under 0.35 of a central
transit's on their star (a short, likely grazing transit like this one's)."""
import os, numpy as np, pandas as pd
snap = os.environ["SNAP3"]
em = pd.read_csv(snap + "/raw/ExoMiner-v2/vetting_catalog_FFI.csv", comment="#", low_memory=False)
toi = pd.read_csv(snap + "/raw/TOI/toi.csv", low_memory=False)
toi = toi.rename(columns={"TIC ID": "tic", "Period (days)": "P", "TFOPWG Disposition": "disp", "Duration (hours)": "dur",
                          "Stellar Radius (R_Sun)": "R", "Stellar Mass (M_Sun)": "M"})
m = em.merge(toi[["tic", "TOI", "P", "disp", "dur", "R", "M"]], left_on="target_id", right_on="tic")
m = m[np.abs(m.tce_period / m.P - 1) < 0.01]
# Central-transit duration on the star, circular: T = P/pi * R*/a.
a_rs = (6.674e-11 * m.M * 1.989e30 * (m.P * 86400) ** 2 / (4 * np.pi**2)) ** (1 / 3) / (m.R * 6.957e8)
m["dur_ratio"] = m.dur / (m.P * 24 / np.pi / a_rs)
for label, sub in [("all", m), ("SPOC duration under 0.35 of central", m[m.dur_ratio < 0.35])]:
    print("==", label)
    for d, g in sub.groupby("disp"):
        if len(g) < 5: continue
        print(f"  {d}: n {len(g)}, median score {g.mean_score.median():.3f}, below 0.082 {np.mean(g.mean_score < 0.082):.2f}, below 0.265 {np.mean(g.mean_score < 0.265):.2f}")
r = m[m.target_id == 438857197]
print("rows on TIC 438857197 with a TOI:", len(r))
