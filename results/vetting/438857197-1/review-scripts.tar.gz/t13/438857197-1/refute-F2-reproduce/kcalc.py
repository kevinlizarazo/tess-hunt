import csv, os, math
# RV semi-amplitude the target would show for each on-target EB scenario in probs.csv run 10
G=6.674e-11; Msun=1.989e30; day=86400
D=os.path.expanduser('~/.cache/tess-hunt/drafts/m3-r2/438857197-1/')
for r in csv.DictReader(open(D+'probs.csv')):
    if r['scenario'] in ('EB','EBx2P','PEB','PEBx2P','DEB','DEBx2P'):
        M1=float(r['M_s'])*Msun; M2=float(r['M_EB'])*Msun; P=float(r['P_orb'])*day; i=math.radians(float(r['inc'])); e=float(r['ecc'])
        K=(2*math.pi*G/P)**(1/3)*M2*math.sin(i)/(M1+M2)**(2/3)/math.sqrt(1-e*e)
        print(r['scenario'], 'M_EB', round(float(r['M_EB']),3), 'P', round(float(r['P_orb']),3), 'K km/s', round(K/1e3,1), 'prob', round(float(r['prob']),4))
