import json, os, csv
D=os.path.expanduser('~/.cache/tess-hunt/drafts/m3-r2/438857197-1/')
t=json.load(open(D+'triceratops.json'))
e=t['evidence']
print('fpp_mean',e['fpp_mean'],'fpp_sd',e['fpp_sd'],'nfpp_mean',e['nfpp_mean'],'runs',e['runs'])
print('fpp list',e['fpp'])
print('nfpp list',e['nfpp'])
print('sectors',e['sectors'],'exposure_s',e['exposure_s'],'contrast',e['contrast'], t['contrast'])
print('dropped_stars',e['dropped_stars'])
print('left_out',e['left_out'])
print('ruwe',e['ruwe'])
rows=list(csv.DictReader(open(D+'probs.csv')))
p={}
for r in rows:
    p.setdefault(r['scenario'],0.0); p[r['scenario']]+=float(r['prob'])
tot=sum(float(r['prob']) for r in rows)
print('total prob',tot)
for k,v in p.items(): print(k, round(v,4))
planet=p['TP']+p['PTP']+p['DTP']
bound=p['SEB']+p['STP']+p['SEBx2P']
ontarget_eb=p['EB']+p['EBx2P']+p['PEB']+p['PEBx2P']+p['DEB']+p['DEBx2P']
bg=p['BTP']+p['BEB']+p['BEBx2P']
near=sum(v for k,v in p.items() if k.startswith('N'))
print('planet',planet,'bound',bound,'ontargetEB',ontarget_eb,'bg',bg,'nearby',near)
print('FPP from probs = 1 - planet =',1-planet)
# TRICERATOPS FPP = 1 - (TP+PTP+DTP); NFPP = sum of NTP,NEB,NEBx2P
print('NFPP from probs =',near)
rest=1-ontarget_eb
print('planet share without on-target EBs', planet/rest, 'FPP', 1-planet/rest, 'denominator',rest)
seb=[r for r in rows if r['scenario']=='SEB'][0]
print('SEB host R_s',seb['R_s'],'M_s',seb['M_s'],'b',seb['b'])
