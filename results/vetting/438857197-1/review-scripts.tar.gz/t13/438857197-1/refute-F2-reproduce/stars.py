import json, os
D=os.path.expanduser('~/.cache/tess-hunt/drafts/m3-r2/438857197-1/')
t=json.load(open(D+'triceratops.json'))
e=t['evidence']
print('stars keys', list(e['stars'][0].keys()))
for s in e['stars']:
    if str(s.get('ID')) in ('438808673','1048012133','438857197'):
        print(s)
print('hosts_tdepth_zero', e['hosts_tdepth_zero'])
print('hosts', e['hosts'][:3], '...')
print('groups', e['groups'])
print('ephemeris', e['ephemeris'])
print('degenerate', e['degenerate'])
