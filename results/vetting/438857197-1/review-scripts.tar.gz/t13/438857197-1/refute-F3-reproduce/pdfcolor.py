import sys
from pypdf import PdfReader
f = sys.argv[1]
page = PdfReader(f).pages[0]
state = {'rg': None}
def before(op, args, cm, tm):
    if op in (b'rg', b'sc', b'scn', b'g'):
        state['rg'] = (op.decode(), [float(a) for a in args if not hasattr(a, 'keys') and str(a).replace('.','',1).replace('-','',1).isdigit()])
def text(t, cm, tm, fd, fs):
    if any(k in t for k in ('Offset-rm', 'Offset-tot', 'GhostDiagnostic', 'DiffImageQuality', 'Depth-sig')):
        print(repr(t.strip()), state['rg'])
page.extract_text(visitor_operand_before=before, visitor_text=text)
