import csv, json, math
D='$TESS_HUNT_DATA/drafts/m3-r2/438857197-1/'
# SPOC S64 ticReferenceCentroid + msTicCentroidOffsets (dvr.xml lines 44-48, 816-819)
ra0,dec0=202.28847762662758,-48.12776641538574
pe,pn=8.435672,7.636111
c=math.cos(math.radians(dec0))
pra,pdec=ra0+pe/3600/c, dec0+pn/3600
print('SPOC S64 point PA %.1f sky %.2f'%(math.degrees(math.atan2(pe,pn))%360, math.hypot(pe,pn)))
print('to second-list S64 fit (E 2.2 N -8.0): %.2f'%math.hypot(pe-2.2,pn+8.0))
print('Gaia table (J2016) within 12 arcsec of SPOC point:')
for r in csv.DictReader(open(D+'neighbours.csv')):
    d=math.hypot((float(r['ra'])-pra)*c,float(r['dec'])-pdec)*3600
    if d<12: print('  ',r['source_id'],'%.2f'%d,'req %.3f'%float(r['required_depth']),r['possible'])
t=json.load(open(D+'triceratops.json'))['evidence']['stars']
print('TRICERATOPS star list (TIC) within 12 arcsec:')
for s in t:
    d=math.hypot((s['ra']-pra)*c,s['dec']-pdec)*3600
    if d<12: print('  ',s['ID'],'%.2f'%d,'Tmag',s['Tmag'],'tdepth',s['tdepth'])
