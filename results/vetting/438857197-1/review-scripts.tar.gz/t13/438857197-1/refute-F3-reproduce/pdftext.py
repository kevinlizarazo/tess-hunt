import sys
from pypdf import PdfReader
for f in sys.argv[1:]:
    t = PdfReader(f).pages[0].extract_text()
    print('==', f.split('/')[-1]); print(t)
