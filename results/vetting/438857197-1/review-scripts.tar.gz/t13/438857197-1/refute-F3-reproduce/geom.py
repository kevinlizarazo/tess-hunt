import csv, math
import numpy as np
from scipy.optimize import least_squares
D='$TESS_HUNT_DATA/drafts/m3-r2/438857197-1/neighbours.csv'
rows=list(csv.DictReader(open(D)))
ra=np.array([float(r['ra']) for r in rows]); dec=np.array([float(r['dec']) for r in rows]); sep=np.array([float(r['sep_arcsec']) for r in rows])
def angsep(ra1,dec1,ra2,dec2):
    r1,d1,r2,d2=map(np.radians,(ra1,dec1,ra2,dec2))
    return np.degrees(np.arccos(np.clip(np.sin(d1)*np.sin(d2)+np.cos(d1)*np.cos(d2)*np.cos(r1-r2),-1,1)))*3600
def res(p): return angsep(p[0],p[1],ra,dec)-sep
fit=least_squares(res,[202.288435,-48.12778],x_scale=[1e-4,1e-4],xtol=1e-15,ftol=1e-15,gtol=1e-15)
t_ra,t_dec=fit.x
print('target J2016 from trilateration: %.8f %.8f  max resid %.2e arcsec'%(t_ra,t_dec,abs(fit.fun).max()))
def EN(r,d,ra0=t_ra,dec0=t_dec):
    return ((r-ra0)*math.cos(math.radians(dec0))*3600,(d-dec0)*3600)
def pa(e,n): return math.degrees(math.atan2(e,n))%360
nb={}
for r in rows: nb[r['source_id']]=(float(r['ra']),float(r['dec']),float(r['sep_arcsec']),float(r['required_depth']))
names={'438857201':'6083427107255912960','438857186':'6083427038536431744','438857198':'6083427107255911936','438857190':'6083428516005182080','1048012266':'6083428584724663296','1048011908':'6083427107253979008'}
pos={}
for tic,sid in names.items():
    r,d,s,q=nb[sid]; e,n=EN(r,d); pos[tic]=(e,n)
    print('TIC %s Gaia %s sep %.2f PA %.1f E %.2f N %.2f req %.4f'%(tic,sid,s,pa(e,n),e,n,q))
fits={'S102':(-2.1,1.0),'S101':(-3.0,1.9),'S64':(2.2,-8.0),'S38':(3.5,-4.0),'S11':(-19.9,0.9)}
def adiff(a,b):
    x=abs(a-b)%360; return min(x,360-x)
for s,(e,n) in fits.items():
    print(s,'PA %.1f'%pa(e,n),' dPA to 186 %.1f  to 201 %.1f'%(adiff(pa(e,n),pa(*pos['438857186'])),adiff(pa(e,n),pa(*pos['438857201']))),
          ' dist to 186 %.1f 201 %.1f 198 %.1f'%tuple(math.hypot(e-pos[t][0],n-pos[t][1]) for t in ('438857186','438857201','438857198')))
