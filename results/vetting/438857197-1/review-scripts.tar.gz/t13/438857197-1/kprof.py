"""Read-only: profile chi2 in Rp/R* with the density held at the TIC value (and at +2 sigma), on the light curve
vet-v3's fits saw for 438857197-1; and count S11's cadences in the transit and its core at the signal's ephemeris."""
import json, os
import numpy as np
from scipy.optimize import minimize
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days, in_transit
from tess_hunt.transit import a_rs_from_density, light_curve

run = os.environ["VET2_RUN"] + "/signals/438857197-1"
checks = json.load(open(run + "/checks.json"))
cs = load_criteria("criteria/search-v2.toml"); cv = load_criteria("criteria/vet-v3.toml")
e = checks["ephemeris"]; eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
lc = good_timestamps(LightCurve.load(lc_dir() / "438857197.npz"))
flat = detrend(lc, cs["detrend"], [])
fit_lc = split(flat, cv["families"])[cv["families"]["fit"]]
near = np.abs(phase_days(fit_lc.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, s = fit_lc.time[near], fit_lc.flux[near], fit_lc.flux_err[near]
x = fit_lc.exposure_days()[near]
s11 = flat.sector == 11
print("S11 cadences in transit (1 duration):", int(in_transit(flat.time[s11], eph).sum()),
      " in core (0.5):", int(in_transit(flat.time[s11], eph, 0.5).sum()))
fe = checks["fit"]
def chi2(t0, p, k, b, lr, q1, q2):
    if not (0.001 < k < 1.0 and 0 <= b < 1+k and 0 < q1 < 1 and 0 < q2 < 1): return 1e12
    a = a_rs_from_density(10.0**lr, p)
    u1, u2 = 2*np.sqrt(q1)*q2, np.sqrt(q1)*(1-2*q2)
    return float(np.sum(((f - light_curve(t, x, t0, p, k, a, b, u1, u2))/s)**2))
opts = {"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4}
tic = -0.43810764210522046; sd = 0.0963604401338199
for lr, label in [(tic, "TIC"), (tic + 2*sd, "TIC+2sd")]:
    a = a_rs_from_density(10.0**lr, fe["period"]["median"])
    print(f"{label}: log rho {lr:.3f}, a/R* {a:.2f}")
    for k in [0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.10, 0.15, 0.3]:
        best = None
        for b0 in [1 - k + 0.02, 1.0, 1 + 0.3*k, 1 + 0.7*k]:
            for q in [(0.3, 0.3), (0.6, 0.6)]:
                r = minimize(lambda v: chi2(v[0], fe["period"]["median"], k, v[1], lr, v[2], v[3]),
                             [fe["t0"]["median"], b0, *q], method="Nelder-Mead", options=opts)
                if best is None or r.fun < best.fun: best = r
        rp = k * 1.66711 * 109.076
        print(f"  k {k:.2f} (Rp {rp:5.1f} Re): min chi2 {best.fun:.2f}  b {best.x[1]:.3f}")
