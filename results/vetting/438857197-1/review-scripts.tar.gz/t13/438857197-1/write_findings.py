"""Writes /tmp/t13/438857197-1/findings.json for the Task 13 review of 438857197-1."""
import json

D = "~/.cache/tess-hunt/drafts/m3-r2/438857197-1"
S = "/tmp/t13/438857197-1"
TRI = "$TRIAGE_RUN/evidence/438857197-1.json (leo_flux.evidence.metrics)"

findings = [
    {
        "id": "F1",
        "lens": "planet",
        "rating": "hold",
        "claim": (
            "On TIC 438857197 the 1.1 to 1.4 h transit can only be grazing, by a body of at least about 7 to 9 Earth "
            "radii that the light curve can't bound from above; the U-shaped 5.5 Earth-radius planet that shape, "
            "density and radius pass needs a host about 44 times denser than this star."
        ),
        "evidence": (
            "Duration: LEO-Vetter's metrics for this signal (" + TRI + ") give a central-transit duration on the TIC "
            "star of q 0.0502 x P = 4.40 h against the trapezoid's trap_qtran 0.01538 x P = 1.35 h (ratio 0.31; "
            + S + "/numbers.py). The flat fit puts the host at 16.2 g/cm3 against the TIC's 0.365 (" + D
            + "/checks.json, density evidence fit_rho_gcc and tic_rho_gcc; ratio 44); the density check passes at "
            "1.71 sigma only because it uses the fit's lower error, 0.96 dex (fit.log_rho minus). "
            "Profiles on the light curve the vet fit (lc sha256 7d9651a8... as in $VET2_RUN/provenance.json; PDCSAP "
            "S11, S38, S64; scripts " + S + "/lik.py and kprof.py run through /tmp/t13/heavy.sh, outputs lik.out and "
            "kprof.out): best fit with the density free chi2 1076.38 (k 0.028, b 0.44, log rho 1.26); best at the TIC "
            "density chi2 1076.57 (delta 0.19). With the density held at the TIC value, k 0.03 (5.5 Re) gives 1087.68 "
            "(delta 11.3), k 0.04 (7.3 Re) 1079.48 (delta 3.1), k 0.05 (9.1 Re) 1077.53 (delta 1.2), k 0.30 (54.6 Re) "
            "1076.62 (delta 0.24), each with b above 1 - k. At the TIC density plus 2 sd, k 0.03 still costs delta "
            "chi2 6.1. The flat fit's U shape rests on its free limb darkening: its best point has q1 0.670, q2 0.979 "
            "(u1 1.60, u2 -0.78). With limb darkening held at LEO-Vetter's coefficients for this star (transit_u1 "
            "0.2346, transit_u2 0.3086), central transits on a dense host (log rho 1.2 to 1.6) give chi2 1081.5 to "
            "1082.9 against 1076.6 at the TIC density (" + S + "/ldfixed.py, ldfixed.out): delta chi2 about 5 for the "
            "grazing solution. LEO-Vetter's own fit: transit_b 0.99999999 (its cap), transit_aRs 6.91 against aRs 6.37 "
            "from the star, trap_qin 0.352 +/- 0.047. SPOC's trapezoid fits are V-like too: S38 ingress 1.03 h of "
            "2.06 h, S64 0.46 h of 1.38 h (" + S + "/dv/*dvr.xml, trapezoidalFit). The density-prior fit M4 uses: "
            "b 1.33 (-0.26, +0.36), Rp 67.3 Re, 16th to 84th percentile 22.4 to 132.2 (checks.json fit_prior). "
            "Decision 0031's eccentricity cause can't rescue a small planet: matching 16.2 g/cm3 on this star needs "
            "e of at least 0.85, a periastron at 0.94 stellar radii (numbers.py). Gaia DR3 RVS (" + S
            + "/queries.sh, gaia_dr3.csv): radial_velocity 19.32 +/- 0.41 km/s over rv_nb_transits 10, "
            "rv_chisq_pvalue 0.79, rv_renormalised_gof -0.63, rv_amplitude_robust 3.46 km/s, so no RV variability. "
            "K is about 117 m/s per Jupiter mass at this period (108 at the FLAME mass 1.35) and 9.4 km/s for a "
            "0.08 Msun companion (numbers.py): a stellar companion grazing the target would have shown, a brown "
            "dwarf of up to about 20 Jupiter masses (K about 2.3 km/s) need not. TRICERATOPS's TP draw agrees: "
            "b 1.066, Rp 13.1 Re (probs.csv). So on this star it is a grazing giant planet or a brown dwarf; off it, "
            "see F2 and F3. Decides: precision RV for the mass (outside 0028's list, but it is what separates the "
            "two); 2-min data in S112 and S114 add transits but leave the grazing radius degeneracy."
        ),
    },
    {
        "id": "F2",
        "lens": "on_star",
        "rating": "hold",
        "claim": (
            "TRICERATOPS's FPP 0.743 is carried mostly by an eclipse or a planet on an unresolved bound companion "
            "(SEB, SEBx2P, STP), which nothing in the public data tests; Gaia's flat RVs remove only the on-target "
            "binary scenarios, and the FPP stays near 0.65 without them."
        ),
        "evidence": (
            D + "/triceratops.json (identical to $TRIC3A_RUN/signals/438857197-1/triceratops.json): fpp_mean 0.743 "
            "(sd 0.022), nfpp_mean 0.0168, 10 runs on S64 at 200 s, contrast [] (no curve). probs.csv is run 10: its "
            "scenarios sum to fpp[9] 0.7084 and nfpp[9] 0.0176. In it: planet on the target TP 0.246, PTP 0.041, "
            "DTP 0.004 (0.292); bound companion SEB 0.342 (host 0.40 Rsun, b 0.09), STP 0.111, SEBx2P 0.064 "
            "(0.517); binary on the target EB 0.033, EBx2P 0.092, PEB 0.014, PEBx2P 0.025, DEB and DEBx2P 0.002 "
            "(0.167); background 0.007; nearby 0.018. Gaia DR3 RVS (F1; " + S + "/gaia_dr3.csv) rules out the "
            "on-target binaries: each moves the F star by km/s. Without them the planet share is 0.292 / 0.833 = "
            "0.35, FPP about 0.65, still above fpp_pass 0.5 (criteria/vet-v3.toml). Nothing here tests the "
            "bound-companion scenarios: Gaia DR3 ruwe 0.925, ipd_frac_multi_peak 0, non_single_star 0 and no NSS "
            "orbit, no WDS pair within 2 arcmin (VizieR B/wds/wds), and no imaging on ExoFOP (literature.json "
            "search.exofop.imaging []). These limit bright companions, not an M dwarf 5 to 6 mag fainter. The "
            "DUPLICATE dropped under 0036 (TIC 1048012133, duplicate of TIC 438808673, about 128 arcsec out with "
            "tdepth 0 in the star list) changes nothing. Decides: high-resolution imaging, whose contrast curve "
            "TRICERATOPS takes (0026, --contrast), and multi-colour ground-based photometry (an eclipse on an "
            "M-dwarf companion diluted by the F star deepens toward red bands)."
        ),
    },
    {
        "id": "F3",
        "lens": "on_star",
        "rating": "hold",
        "claim": (
            "The pixel data can't place the dip on the target to better than the 11 to 14 arcsec at which two Gaia "
            "stars could host it: SPOC's own S64 difference image puts the centroid 11.4 arcsec northeast at 3.7 "
            "sigma, the second list's S64 fit puts it 8.3 arcsec south-southeast, and the sector fits scatter toward "
            "different neighbours."
        ),
        "evidence": (
            "$SECOND2_RUN/signals/438857197-1/pixels.json: pass on S101 3.6 arcsec (q 0.80), a timing-suspect "
            "sector; S102 2.3 (0.69), S38 5.4 (0.72), S64 8.3 (0.59), S11 19.9 (0.46). Without S101 the best vet-v3 "
            "sector, S38, still passes. Directions from the pixel diagnosis's refits (" + S
            + "/pixdiag/summary_second.txt, extracted from "
            "results/benchmarks/pixel-check-diagnosis-2026-10-20-scripts.tar.gz, lines 139 to 148): S38 E +3.5 "
            "N -4.0 and S64 E +2.2 N -8.0 lie 16 and 10 deg from the direction of TIC 438857186 (Gaia DR3 "
            "6083427038536431744, 13.7 arcsec at PA 155, needs a 15.3% eclipse); S101 E -3.0 N +1.9 and S102 E -2.1 "
            "N +1.0 lie 20 and 27 deg from TIC 438857201 (Gaia DR3 6083427107255912960, 11.2 arcsec at PA 323, "
            "needs 12.9%); S11 sits 5.9 arcsec from TIC 438857198 (25.0 arcsec, needs 37.7%). Sky scatter 9.3 "
            "arcsec; quality-weighted mean 3.2 arcsec from the target; no position repeats. SPOC's FFI DV for S64 ("
            + S + "/dv/hlsp_tess-spoc_tess_phot_0000000438857197-s0064-s0064_tess_v1_dvr.xml and dvs-01.pdf, "
            "fetched by queries.sh): msTicCentroidOffsets RA 8.44 +/- 2.97, Dec 7.64 +/- 3.13, sky 11.38 +/- 3.04 "
            "arcsec (TicOffset-rm 3.74 sigma, OotOffset-rm 12.39 arcsec at 4.04 sigma, flagged on the summary), "
            "image quality 0.85. For S38 it is 4.95 +/- 2.74 (1.80 sigma). SPOC's S64 position is about 17 arcsec "
            "from the second list's S64 fit, and no star there could make the dip: TIC 1048011908 (5.6 arcsec from "
            "it) would need over 100%, TIC 1048012266 (7.1 arcsec) 74% (TRICERATOPS 97%). The S64 centroid depends "
            "on the method: it neither confirms the target nor names a host. TRICERATOPS's NFPP 0.0168 sits between "
            "nfpp_pass 0.001 and nfpp_fail 0.1; in run 10 the NEB on TIC 438857186 is 0.0068 + 0.0013 (x2P) and on "
            "TIC 438857190 (25.1 arcsec, needs 13.9%) 0.0051 + 0.0014. SPOC's ghost diagnostic (core 3.98, halo "
            "0.85 in S38; 5.62, 1.48 in S64) puts the dip in the optimal aperture, which holds these neighbours. "
            "Decides: seeing-limited ground-based photometry of the target and TIC 438857201, 438857186 and "
            "438857190 across a predicted transit."
        ),
    },
    {
        "id": "F4",
        "lens": "planet",
        "rating": "note",
        "claim": (
            "The 0.082 recorded at promotion is ExoMiner++'s planet score (above 0.5 is a candidate), not a "
            "false-positive probability; both of the star's SPOC FFI TCEs score as false positives, a range where 77% "
            "of TFOPWG false positives and 6% of confirmed planets fall."
        ),
        "evidence": (
            "$SNAP3/raw/ExoMiner-v2/vetting_catalog_FFI.csv, header: Model ExoMiner++New, 5-fold cross-validation, "
            "mean_score the average of 5 models, model_label PC if score > 0.5, FP otherwise. Rows: "
            "438857197-1-S38 mean_score 0.265 (std 0.183), MES 7.20, FP; 438857197-1-S64 0.082 (std 0.030), "
            "MES 8.37, FP. $SECOND2_RUN/second-list.csv carries S64's, the latest sector run, by the list's rule. "
            "Matched to the snapshot's TOI table on TIC and period within 1% (" + S + "/exominer_weigh.py, "
            "exominer_weigh.out): scores below 0.082 for FP 77% (n 625), CP 6% (n 154), KP 32% (n 25), PC 20% "
            "(n 4752); among TOIs whose SPOC duration is under 0.35 of a central transit's, as this one's is "
            "(0.31, F1): FP 96% (n 48), CP 0% (n 5). The S64 TCE carries SPOC's centroid flag (F3), which ExoMiner++ "
            "can see, and scores lower than S38; that link is a guess I can't show. Decision 0033's table lists "
            "0.082 FP but its text doesn't weigh it; this is the only promoted row with an FP label (the others 0.573 "
            "to 0.811). The SPOC FFI TCEs from S38 (DV 2021-07-07) and S64 (DV 2023-10-09) never became TOIs. It "
            "decides nothing alone and points the same way as F1 to F3."
        ),
    },
    {
        "id": "F5",
        "lens": "planet",
        "rating": "note",
        "claim": (
            "No secondary eclipse at any phase: ModShift's secondary at phase 0.25 is no stronger than its tertiary "
            "or positive features, and unlike 370977908-1 the red-noise scaling is not what leaves it unflagged."
        ),
        "evidence": (
            TRI + ": sig_sec 2.868 at phs_sec 0.250 (dep_sec 152 +/- 53 ppm), sig_ter 2.535 at 0.874, sig_pos 2.517 "
            "at 0.807, sig_pri 15.45, Fred 0.926, FA1 5.001, FA2 2.531. With criteria/triage-v1.toml's MS4 0, MS5 -1, "
            "MS6 -1: sig_sec/Fred - FA1 = -1.90 (needs > 0; unscaled, 2.868 - 5.001 = -2.13); sig_sec - sig_ter - "
            "FA2 = -2.20 and sig_sec - sig_pos - FA2 = -2.18 (need > -1). Fred is below 1, so the scaling raises the "
            "secondary's significance. vet-v3 at phase 0.5: 54 +/- 56 ppm (0.96 sigma; " + D + "/checks.json), "
            "60 +/- 47 ppm (1.3 sigma) with S101 and S102 (checks-with-suspect.json). SPOC's weak secondary: S38 "
            "114 +/- 95 ppm at 2.565 d (MES 1.5), S64 394 +/- 138 ppm at -0.637 d (MES 2.5), so three methods find "
            "three phases. Odd and even: vet-v3 878 +/- 132 against 1150 +/- 110 ppm (1.6 sigma); LEO's trapezoid "
            "1062 +/- 75 against 943 +/- 79 (the other way); SPOC's odd/even significance 0.86 and 0.87. The "
            "search's rank-2 signal on the star, 12.7872 d (ratio 3.4946, SDE 11.0), sits below the production "
            "threshold SDE 20.24 (threshold.json highest_judged_pass_sde in $THRESHOLD_RUN) and is no binary pair. "
            "A low-mass grazing companion (F1's brown dwarf) would show no secondary at this precision, so this "
            "does not speak against it."
        ),
    },
    {
        "id": "F6",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "The holdout pass is sound: S11's few cadences hold the transit at the time the other two seasons "
            "predict, which is what decision 0035 needs a training season to do, and the refit's grid can't pass "
            "the check on its own."
        ),
        "evidence": (
            S + "/kprof.out: S11 holds 8 cadences inside the transit and 4 in its core at the signal's ephemeris, as "
            "0035 item 2 says; min_points 5 counts the whole transit. " + D + "/checks.json holdout: season 0 (S11), "
            "measured at the S38 plus S64 refit, shows 1059 +/- 200 ppm on 3 core cadences (5.3 sigma), and its "
            "status no_predicted_transit_in_data comes only from 3 < min_points. Seasons 1 (S38) and 2 (S64), each "
            "trained on S11 plus the other, show 1162 +/- 140 ppm at 8.29 sigma (tension 1.64) and 1106 +/- 158 ppm "
            "at 7.01 sigma (tension 0.06). 0035 item 2: with S11 the predictions sit 0.09 h and 0.07 h from the flat "
            "fit (core half-width 0.25 h); without it, 8.88 h and 6.86 h. The refit searches periods around the "
            "input ephemeris, which was fitted with the held-out season in (holdout.py refit_ephemeris), but the "
            "grid's reach at the held-out season is about 2.4 h or more for S38 and 4.6 h or more for S64 (" + S
            + "/numbers.py), 10 to 18 core half-widths, so S11's transit is what pins it. S38 and S64 show the dip "
            "on their own (sector_depth 1192 +/- 136 and 1007 +/- 136 ppm; SPOC single-sector TCEs at MES 7.2 and "
            "8.4). With S101 and S102 kept in (evidence only) each season trains on three and the check passes. No "
            "TTV or partly covered transit (0031) shows."
        ),
    },
    {
        "id": "F7",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "The dip is real and the same in every sector and both product families; nothing points to an "
            "artefact, one dominant sector or a QLP dilution mismatch."
        ),
        "evidence": (
            D + "/checks.json sector_depth: PDCSAP S38 1192 +/- 136 ppm, S64 1007 +/- 136 (p 0.34); "
            "checks-with-suspect.json: QLP S101 991 +/- 145, S102 996 +/- 176 (p 0.98); S11 1059 +/- 200 (holdout "
            "season 0). Every transit with in-transit data in plots/transits.png shows the dip. SPOC found it in S38 "
            "alone and S64 alone (DV bootstrap false-alarm 1.71e-12 and 5.69e-21, " + S + "/dv/). QLP depths match "
            "PDCSAP (CROWDSAP 0.901, 0.905, 0.892; TIC contratio 0.138), so QLP's dilution and SPOC's crowding "
            "correction agree. S64 holds 794 of the fit's 1057 cadences (lik.out), but S38 alone is 8.7 sigma. "
            "Red-noise beta 1.00 to 1.05 per sector. The evidence-only vet with S101 and S102 passes every check at "
            "15.2 sigma combined. The pixel pass's best sector is timing-suspect S101 (F3)."
        ),
    },
    {
        "id": "F8",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "Not known: no paper, catalog or ExoFOP entry names the star as a planet host, binary or variable, and "
            "the only rows at the period are the two ExoMiner FFI TCEs."
        ),
        "evidence": (
            D + "/checks.json novelty: inconclusive on ExoMiner vetting_catalog_FFI 438857197-1-S38 and -S64 only, "
            "nearby_rows 2 within 2.5 arcmin. Within 15 arcmin $SNAP3/known.parquet holds only those and TIC "
            "419944060 (657 arcsec, an EB at 0.91 and 1.82 d). " + D + "/literature.json ($LIT3_RUN): 0 hits from "
            "ADS, arXiv, OpenAlex and Zenodo for all four names; ExoFOP shows no TOI, CTOI, planet, imaging or file. "
            "A live ExoFOP re-read on 2026-10-21 returned HTTP 503. Public reads (" + S + "/queries.sh): SIMBAD gives "
            "TYC 8252-954-1 the type '*' only; Gaia DR3 has phot_variable_flag NOT_AVAILABLE and no vari_summary, "
            "vari_eclipsing_binary or NSS row for the target or the two near neighbours, and within 3 arcmin only a "
            "non-EB variable at 164.8 arcsec; VSX within 3 arcmin has only ASASSN-V J132920.71-480541.9 (ROT, "
            "1.325 d, 164.8 arcsec); WDS has nothing within 2 arcmin."
        ),
    },
]

out = {
    "signal": "438857197-1",
    "summary": (
        "I ran the full brief: the fits against the star, TRICERATOPS's scenarios, the pixel record beside SPOC's "
        "public FFI DV reports, ModShift, holdout, the ExoMiner score and novelty. The dip is real and not known, but "
        "on this F star it must be grazing (at least 7 to 9 Earth radii, no upper bound), and Gaia DR3's flat RVs "
        "leave a grazing giant planet or brown dwarf on the target. Otherwise it sits on another star: TRICERATOPS's "
        "FPP rests mostly on a bound companion, and the pixels, including SPOC's 3.7-sigma S64 centroid flag, can't "
        "separate the neighbours at 11 to 14 arcsec."
    ),
    "findings": findings,
    "hits_flagged": [],
}
text = json.dumps(out, indent=2)
assert "—" not in text and "–" not in text
with open("/tmp/t13/438857197-1/findings.json", "w") as f:
    f.write(text + "\n")
print(len(findings), {r: sum(x["rating"] == r for x in findings) for r in ("kill", "hold", "note")})
