# Small arithmetic used in findings F1 and F6 of the 438857197-1 review: python3 /tmp/t13/438857197-1/numbers.py
import math
b = 5 * 3.65916 * 0.0416667  # refit_resolutions * P * duration (holdout.py refit_ephemeris)
print("S38 held out: grid half width", b / (3067.5335 - 1600.0781), "d; reach at S38, 193 cycles:", 193 * b / (3067.5335 - 1600.0781) * 24, "h")
print("S64 held out: grid half width", b / (2360.0427 - 1600.0781), "d; reach at S64, 193 cycles:", 193 * b / (2360.0427 - 1600.0781) * 24, "h")
G, P, MJ, Ms = 6.674e-11, 3.659157 * 86400, 1.898e27, 1.989e30
for M in (1.2, 1.35):
    print("M*", M, "K per Jupiter mass (m/s)", round((2 * math.pi * G / P) ** (1 / 3) * MJ / (M * Ms) ** (2 / 3), 1),
          "K for 0.08 Msun (km/s)", round((2 * math.pi * G / P) ** (1 / 3) * 0.08 * Ms / ((M + 0.08) * Ms) ** (2 / 3) / 1000, 2))
g = (16.212160913431028 / 0.364663552) ** (1 / 3)  # checks.json density: fit_rho_gcc / tic_rho_gcc
e = (g * g - 1) / (g * g + 1)  # transit at periastron: duration factor sqrt((1-e)/(1+e)) = 1/g
print("duration factor needed", g, "minimum e", e, "periastron in R* at a/R* 6.37:", 6.37 * (1 - e))
print("LEO central duration h", 0.05015275882500022 * 3.659159805040612 * 24, "trapezoid h", 0.015382480003109267 * 3.659159805040612 * 24)
