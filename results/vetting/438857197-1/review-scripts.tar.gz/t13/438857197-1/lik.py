"""Read-only: rebuild the light curve vet-v3's fits saw for 438857197-1 and compare the best chi2 of the
flat-prior fit's samples with the density-prior fit's samples (prior term left out), then optimise each."""
import json, os, sys
import numpy as np
from scipy.optimize import minimize
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days, in_transit
from tess_hunt.transit import a_rs_from_density, light_curve

run = os.environ["VET2_RUN"] + "/signals/438857197-1"
checks = json.load(open(run + "/checks.json"))
cs = load_criteria("criteria/search-v2.toml"); cv = load_criteria("criteria/vet-v3.toml")
e = checks["ephemeris"]; eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
lc = good_timestamps(LightCurve.load(lc_dir() / "438857197.npz"))
flat = detrend(lc, cs["detrend"], [])
fit_lc = split(flat, cv["families"])[cv["families"]["fit"]]
near = np.abs(phase_days(fit_lc.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, s = fit_lc.time[near], fit_lc.flux[near], fit_lc.flux_err[near]
x = fit_lc.exposure_days()[near]; sec = fit_lc.sector[near]
print("cadences in fit window", len(t), {int(k): int((sec == k).sum()) for k in np.unique(sec)})

def model(th):
    t0, p, k, b, lr, q1, q2 = th
    a = a_rs_from_density(10.0**lr, p)
    u1, u2 = 2*np.sqrt(q1)*q2, np.sqrt(q1)*(1-2*q2)
    return light_curve(t, x, t0, p, k, a, b, u1, u2)

def chi2(th):
    t0, p, k, b, lr, q1, q2 = th
    if not (0.001 < k < 1.0 and 0 <= b < 1+k and -3 < lr < 2 and 0 < q1 < 1 and 0 < q2 < 1): return 1e12
    if b >= a_rs_from_density(10.0**lr, p): return 1e12
    return float(np.sum(((f - model(th))/s)**2))

null = float(np.sum(((f - 1.0)/s)**2))
print("chi2 no transit", round(null, 2))
rng = np.random.default_rng(0)
best = {}
for name in ("fit_samples", "fit_prior_samples"):
    S = np.load(run + f"/{name}.npz")["samples"]
    idx = rng.choice(len(S), 4000, replace=False)
    c = np.array([chi2(S[i]) for i in idx])
    i = idx[np.argmin(c)]
    best[name] = S[i]
    print(name, "min chi2 over 4000 draws", round(c.min(), 2), "median", round(float(np.median(c)), 2),
          "at", np.round(S[i], 5).tolist())
lr_tic = checks["fit_prior"]["log_rho"]  # summary only, for the print
tic_lr = -0.43810764210522046
def fixed(th5, lr):
    t0, p, k, b, q1, q2 = th5
    return chi2([t0, p, k, b, lr, q1, q2])
# Optimise: free density from the flat fit's best draw; density held at the TIC value from the prior fit's best.
r_free = minimize(chi2, best["fit_samples"], method="Nelder-Mead", options={"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4})
th = best["fit_prior_samples"]
r_tic = minimize(lambda v: fixed(v, tic_lr), np.delete(th, 4), method="Nelder-Mead", options={"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4})
print("optimised free density: chi2", round(r_free.fun, 2), np.round(r_free.x, 5).tolist())
print("optimised at TIC density (log rho -0.438): chi2", round(r_tic.fun, 2), np.round(r_tic.x, 5).tolist())
# Density held at TIC value, started from a small-planet near-grazing guess too.
for k0, b0 in [(0.03, 0.98), (0.06, 1.02), (0.12, 1.08), (0.37, 1.33)]:
    st = [checks["fit"]["t0"]["median"], checks["fit"]["period"]["median"], k0, b0, 0.4, 0.4]
    r = minimize(lambda v: fixed(v, tic_lr), st, method="Nelder-Mead", options={"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4})
    print(f"  TIC density from k={k0}, b={b0}: chi2", round(r.fun, 2), np.round(r.x, 5).tolist())
# Profile in log rho
for lr in [1.6, 1.2, 0.8, 0.4, 0.0, -0.2, -0.438]:
    r = min((minimize(lambda v: fixed(v, lr), st0, method="Nelder-Mead", options={"maxiter": 20000, "maxfev": 20000, "xatol": 1e-7, "fatol": 1e-4})
             for st0 in [np.delete(best["fit_samples"], 4), np.delete(th, 4),
                         [checks["fit"]["t0"]["median"], checks["fit"]["period"]["median"], 0.06, 1.0, 0.4, 0.4]]),
            key=lambda r: r.fun)
    print(f"profile log rho {lr:+.3f}: chi2 {r.fun:.2f}  k {r.x[2]:.4f} b {r.x[3]:.3f}")
