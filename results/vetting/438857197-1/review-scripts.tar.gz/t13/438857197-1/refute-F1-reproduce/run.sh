#!/bin/bash
cd ~/code/tess-hunt
. ~/.cache/tess-hunt/logs/m3-vars.sh; . ~/.cache/tess-hunt/logs/m3-rerun-vars.sh
export VET2_RUN
D=/tmp/t13/438857197-1/refute-F1-reproduce
for s in kprof lik ldfixed; do
  /tmp/t13/heavy.sh uv run python $D/$s.py > $D/$s.out 2> $D/$s.err; echo "$s exit $?" >> $D/status
done
