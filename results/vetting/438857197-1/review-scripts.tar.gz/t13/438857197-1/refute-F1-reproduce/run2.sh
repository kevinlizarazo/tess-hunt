#!/bin/bash
cd ~/code/tess-hunt
. ~/.cache/tess-hunt/logs/m3-vars.sh; . ~/.cache/tess-hunt/logs/m3-rerun-vars.sh
export VET2_RUN
D=/tmp/t13/438857197-1/refute-F1-reproduce
/tmp/t13/heavy.sh uv run python $D/de_check.py > $D/de_check.out 2> $D/de_check.err; echo "de_check2 exit $?" >> $D/status
