"""Independent check of kprof/ldfixed: global optimiser (differential evolution, then Nelder-Mead polish) on the same
light curve, instead of Nelder-Mead from a few starts."""
import json, os
import numpy as np
from scipy.optimize import differential_evolution, minimize
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days
from tess_hunt.transit import a_rs_from_density, light_curve

run = os.environ["VET2_RUN"] + "/signals/438857197-1"
checks = json.load(open(run + "/checks.json"))
cs = load_criteria("criteria/search-v2.toml"); cv = load_criteria("criteria/vet-v3.toml")
e = checks["ephemeris"]; eph = Ephemeris(e["period"], e["t0"], e["duration"], e["depth"])
lc = good_timestamps(LightCurve.load(lc_dir() / "438857197.npz"))
flat = detrend(lc, cs["detrend"], [])
fit_lc = split(flat, cv["families"])[cv["families"]["fit"]]
near = np.abs(phase_days(fit_lc.time, eph)) < cv["fit"]["window_half_width_durations"] * eph.duration
t, f, s = fit_lc.time[near], fit_lc.flux[near], fit_lc.flux_err[near]
x = fit_lc.exposure_days()[near]
P = checks["fit"]["period"]["median"]; T0 = checks["fit"]["t0"]["median"]
import time; T=time.time(); print("n", len(t), "P", P, "T0", T0)
def c2(t0, k, b, lr, u1, u2):
    if not np.isfinite(u1) or not (0.001 < k < 1.0): return 1e12
    a = a_rs_from_density(10.0**lr, P)
    if b >= a or b < 0 or b >= 1 + k: return 1e12
    return float(np.sum(((f - light_curve(t, x, t0, P, k, a, b, u1, u2)) / s) ** 2))
def q2u(q1, q2):
    if not (0 < q1 < 1 and 0 < q2 < 1): return np.nan, np.nan
    return 2*np.sqrt(q1)*q2, np.sqrt(q1)*(1-2*q2)
opts = {"maxiter": 20000, "maxfev": 20000, "xatol": 1e-8, "fatol": 1e-5}
def run_de(fun, bounds, seed=1):
    r = differential_evolution(fun, bounds, seed=seed, popsize=15, maxiter=250, tol=1e-8, polish=False)
    p = minimize(fun, r.x, method="Nelder-Mead", options=opts)
    return p if p.fun < r.fun else r
# Reference: everything free (t0, k, b, log rho, q1, q2)
ref = run_de(lambda v: c2(v[0], v[1], v[2], v[3], *q2u(v[4], v[5])),
             [(T0-0.006, T0+0.006), (0.01, 0.5), (0, 1.4), (-1.0, 2.0), (1e-4, 1-1e-4), (1e-4, 1-1e-4)])
print(round(time.time()-T),"s"); print("ALL FREE: chi2 %.2f" % ref.fun, np.round(ref.x, 5).tolist())
tic = -0.43810764210522046; sd = 0.0963604401338199
for lr, lab, ks in [(tic, "TIC", [0.03, 0.04, 0.05]), (tic + 2*sd, "TIC+2sd", [0.03, 0.04])]:
    for k in ks:
        r = run_de(lambda v: c2(v[0], k, v[1], lr, *q2u(v[2], v[3])),
                   [(T0-0.006, T0+0.006), (0, 1+k-1e-6), (1e-4, 1-1e-4), (1e-4, 1-1e-4)])
        print(f"{lab} k {k:.3f} (Rp {k*1.66711*109.076:.1f} Re): chi2 {r.fun:.2f} d {r.fun-ref.fun:.2f} b {r.x[1]:.3f} q {r.x[2]:.3f} {r.x[3]:.3f}")
# Fixed LD at LEO's u1,u2: dense host vs TIC density
U1, U2 = 0.2346, 0.3086
for lr in [1.4, 1.2, -0.438]:
    r = run_de(lambda v: c2(v[0], v[1], v[2], lr, U1, U2), [(T0-0.006, T0+0.006), (0.01, 0.6), (0, 1.6)])
    print(f"fixed LD log rho {lr:+.3f}: chi2 {r.fun:.2f} k {r.x[1]:.4f} b {r.x[2]:.3f}")
