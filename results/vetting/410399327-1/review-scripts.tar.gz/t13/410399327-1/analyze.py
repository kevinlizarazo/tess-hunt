"""Read-only review analysis for 410399327-1. Rebuilds the light curve vet-v3 saw and measures each epoch."""
import json, sys
import numpy as np
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria, lc_dir
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, in_transit, epoch_numbers, phase_days
from tess_hunt.checks.photometry import box_depth, with_red_noise
from tess_hunt.checks.families import good_timestamps

checks = json.load(open(sys.argv[1]))
crit_search = load_criteria("criteria/search-v2.toml")
crit_vet = load_criteria("criteria/vet-v3.toml")
lc_all = LightCurve.load(lc_dir() / "410399327.npz")
E = checks["ephemeris"]
eph = Ephemeris(E["period"], E["t0"], E["duration"], E["depth"])
masks = [Ephemeris(**m) for m in checks["masked"]]
core = crit_vet["depth"]["core_fraction"]

print("raw sectors and spans")
for s in np.unique(lc_all.sector):
    t = lc_all.time[lc_all.sector == s]
    gaps = np.where(np.diff(t) > 0.5)[0]
    segs = [(t[0], t[g]) for g in []]
    print(int(s), f"{t.min():.3f}-{t.max():.3f}", len(t), "gaps>0.5d at", [f"{t[g]:.2f}->{t[g+1]:.2f}" for g in gaps])

def epochs_report(lc_raw, flat, betas, label):
    noisy = with_red_noise(flat, betas)
    print(f"\n== {label}: per-epoch core depths at the search ephemeris")
    for ep in sorted(set(epoch_numbers(flat.time[in_transit(flat.time, eph, 4.0)], eph))):
        mid = eph.t0 + ep * eph.period
        m = np.abs(noisy.time - mid) < 0.5 * eph.duration * core
        sec = np.unique(noisy.sector[np.abs(noisy.time - mid) < 1])
        raw_near = np.abs(lc_raw.time - mid) < 0.5 * eph.duration * core
        d, e, n = box_depth(noisy.time[m], noisy.flux[m], noisy.flux_err[m], eph, core) if m.any() else (np.nan, np.nan, 0)
        # nearest data edges in the raw light curve (segment ends: gaps > 0.5 d or sector ends)
        print(f"epoch {ep} mid {mid:.3f} sectors {sec.tolist()} core n {n} (raw core cadences {raw_near.sum()}) depth {d*1e6:.0f} +- {e*1e6:.0f} ppm")
    return noisy

betas = checks["red_noise"]
good = good_timestamps(lc_all)
flat = detrend(good, crit_search["detrend"], masks)
noisy = epochs_report(good, flat, betas, "vet-v3 light curve (suspect sectors out, TOI-7925.01 masked)")
flat_all = detrend(lc_all, crit_search["detrend"], masks)
json_s = json.load(open(sys.argv[2]))
noisy_all = epochs_report(lc_all, flat_all, json_s["red_noise"], "evidence-only light curve (suspect sectors in)")

# Box scan: a 0.25 d box slid +-0.6 d around each epoch (TTV search), on the detrended curve WITHOUT the TOI mask
# but holding out the window from the trend, to see what the mask hides.
print("\n== box scan, 0.25 d box, detrended without the TOI-7925.01 mask (window held out of the trend)")
hold = np.zeros(len(lc_all.time), bool)
for ep in range(-1, 80):
    hold |= np.abs(lc_all.time - (eph.t0 + ep*eph.period)) < 0.75
flat_nomask = detrend(lc_all, crit_search["detrend"], [], hold_out=hold)
noisy_nomask = with_red_noise(flat_nomask, json_s["red_noise"])
toi = masks[0]
for ep in [0, 11, 41, 42, 62, 63, 70, 72]:
    mid = eph.t0 + ep * eph.period
    near = np.abs(noisy_nomask.time - mid) < 0.75
    t, f, e = noisy_nomask.time[near], noisy_nomask.flux[near], noisy_nomask.flux_err[near]
    if len(t) == 0:
        print(f"epoch {ep}: no data within 0.75 d"); continue
    tm = in_transit(t, toi, crit_search["detrend"]["known_mask_width"])
    best = None
    rows = []
    for off in np.arange(-0.6, 0.6001, 0.02):
        m = np.abs(t - (mid + off)) < 0.125
        if m.sum() < 5: rows.append((off, np.nan, np.nan, int(m.sum()))); continue
        w = 1/e[m]**2
        d = 1 - np.sum(w*f[m])/np.sum(w); de = 1/np.sqrt(np.sum(w))
        rows.append((off, d, de, int(m.sum())))
        if best is None or d/de > best[1]/best[2]: best = (off, d, de, int(m.sum()))
    tmin, tmax = t.min()-mid, t.max()-mid
    dt = np.diff(t); gi = np.where(dt > 3*np.median(dt))[0]
    gaps = [f"{(t[g]-mid)*24:+.1f}h..{(t[g+1]-mid)*24:+.1f}h" for g in gi]
    print(f"epoch {ep} mid {mid:.3f}: data {tmin*24:+.1f}h..{tmax*24:+.1f}h, gaps {gaps}, TOI-7925.01 mask covers {tm.sum()} of {len(t)} cadences "
          f"({(t[tm].min()-mid)*24:+.1f}h..{(t[tm].max()-mid)*24:+.1f}h)" if tm.any() else
          f"epoch {ep} mid {mid:.3f}: data {tmin*24:+.1f}h..{tmax*24:+.1f}h, gaps {gaps}, TOI mask covers 0")
    if best: print(f"   strongest box: offset {best[0]*24:+.1f} h, depth {best[1]*1e6:.0f} +- {best[2]*1e6:.0f} ppm ({best[1]/best[2]:.1f} sigma, n {best[3]})")
    sel = [r for r in rows if abs(r[0]) < 1e-9 or abs(abs(r[0])-0.1) < 1e-9 or abs(abs(r[0])-0.2)<1e-9 or abs(abs(r[0])-0.3)<1e-9]
    print("   at offsets (h): " + "; ".join(f"{r[0]*24:+.1f}: {r[1]*1e6:.0f}+-{r[2]*1e6:.0f} (n {r[3]})" for r in sel))
