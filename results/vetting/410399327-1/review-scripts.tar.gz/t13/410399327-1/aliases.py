"""Evidence only: per-transit core depths at the shorter periods the even epochs also allow (2P/3, 2P/5), on the
vet-v3 light curve, to see whether their extra transits are there."""
import json, sys
from dataclasses import replace
import numpy as np
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria, lc_dir
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, epoch_numbers, in_transit
from tess_hunt.checks.photometry import red_noise_beta, with_red_noise, box_depth
from tess_hunt.checks.families import good_timestamps

checks = json.load(open(sys.argv[1]))
cs, cv = load_criteria("criteria/search-v2.toml"), load_criteria("criteria/vet-v3.toml")
lc = good_timestamps(LightCurve.load(lc_dir() / "410399327.npz"))
E = checks["ephemeris"]; eph = Ephemeris(E["period"], E["t0"], E["duration"], E["depth"])
flat = detrend(lc, cs["detrend"], [Ephemeris(**m) for m in checks["masked"]])
for k in (3, 5):
    e = replace(eph, period=2 * eph.period / k)
    noisy = with_red_noise(flat, red_noise_beta(flat, e, 0.5 * e.duration, cv["red_noise"]))
    inside = in_transit(noisy.time, e, 0.5)
    eps = np.unique(epoch_numbers(noisy.time[inside], e))
    rows = []
    for n in eps:
        m = inside & (epoch_numbers(noisy.time, e) == n)
        d, err, c = box_depth(noisy.time[m], noisy.flux[m], noisy.flux_err[m], e, 0.5)
        old = n * 2 / k  # in units of the search period
        rows.append((int(n), old, d, err, c))
    extra = [r for r in rows if abs(r[1] - round(r[1])) > 1e-6 or round(r[1]) % 2 == 1]
    w = np.array([1 / r[3] ** 2 for r in extra]); dd = np.array([r[2] for r in extra])
    print(f"P = 2P/{k} = {e.period:.4f} d: {len(rows)} transits with core data; the {len(extra)} not on the even epochs: "
          f"weighted depth {np.sum(w*dd)/np.sum(w)*1e6:.0f} +- {1/np.sqrt(np.sum(w))*1e6:.0f} ppm")
    print("   " + "; ".join(f"{r[0]}: {r[2]*1e6:.0f}+-{r[3]*1e6:.0f}" for r in extra))
