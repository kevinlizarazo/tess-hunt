import json

S = "/tmp/t13/410399327-1"
RUN = (
    "/tmp/t13/heavy.sh bash -c 'cd ~/code/tess-hunt && uv run python /tmp/t13/410399327-1/{s}.py "
    "~/.cache/tess-hunt/drafts/m3/410399327-1/checks.json ~/.cache/tess-hunt/drafts/m3/410399327-1/checks-with-suspect.json'"
)
out = {
    "signal": "410399327-1",
    "summary": (
        "I rebuilt the light curve vet-v3 saw and measured every epoch to test the three kills (odd_even, sector_depth, holdout) "
        "against partial coverage, TTVs, low SNR, dilution and one-sector artefacts. All three stand at 34.94 d, and all three rest on one fact: "
        "both odd epochs with data (11 in S27, 41 in S66) are flat at full coverage, while every even epoch with usable data (0, 42, 62, and 72 in "
        "the timing-suspect S104) shows a 6-hour dip within 0.3 h of a linear ephemeris. The dips look like a 69.878-day signal, twice the search's "
        "period and past its 40-day cap, at which vet-v3's five light-curve checks pass; that is the one hold."
    ),
    "findings": [
        {
            "id": "F1",
            "lens": "planet",
            "rating": "kill",
            "claim": "The odd_even kill stands at 34.94 d: both odd transits with data are flat at full coverage, so it is not a partly covered transit, a TTV, low SNR or a dilution change.",
            "evidence": (
                "checks.json odd_even pdcsap: odd -117 +- 133 ppm (n 34) vs even 841 +- 101 (n 144), 5.7 sigma. Per epoch (" + S + "/scan.out, from "
                + RUN.format(s="scan") + "; plot " + S + "/epochs.png): epoch 11 (S27) core -156 +- 149 ppm on 18 of 18 core cadences, raw data -36 h to +36 h; "
                "epoch 41 (S66) 41 +- 298 on 16 of 54 core cadences because TOI-7925.01's mask cuts the rest (its transit falls 1.52 h after our mid, mask +-2.12 h), "
                "and 97 +- 164 on all 54 with the mask off and +-0.3 d held out of the trend. A 6-h box slid +-12 h around each odd epoch finds nothing above 2.3 sigma "
                "(epoch 11: +6.3 h, 198 +- 106 ppm, where TOI-7925.01's own transit falls at +4.31 h; epoch 41: +3.3 h, 266 +- 116), so no TTV-shifted transit hides nearby, "
                "and the even dips sit within 0.3 h of the linear ephemeris (epoch 0 +0.3 h, 42 0.0 h, 62 -0.3 h, 72 -0.3 h). Not low SNR: the expected depth is 0.75 to 0.84 ppt "
                "against errors of 0.15 to 0.16 ppt (holdout season 1 expected SNR 4.9). Not dilution: CROWDSAP S27 0.977, S66 0.974, S67 0.976 (checks.json sources); "
                "S66 and S67 are consecutive TESS-SPOC sectors with the same crowding, yet epoch 41 is flat and epoch 42, one period later, is 1106 +- 140 ppm. "
                "QLP's odd_even pass rests on its one odd transit, epoch 63, which is a sector-end ramp (F5). Empty odd epochs are what a period of twice 34.94 d gives, "
                "not a binary's alternating depths (F4)."
            ),
        },
        {
            "id": "F2",
            "lens": "real_new",
            "rating": "kill",
            "claim": "The sector_depth kill stands at 34.94 d: the chi-square comes from S27's empty odd epoch and S67's deep even one, not from the partly covered S66 transit or dilution.",
            "evidence": (
                "checks.json sector_depth pdcsap: S13 551 +- 146, S27 -156 +- 149 (n 18), S66 41 +- 298 (n 16), S67 1106 +- 140 ppm; chi2 40.7, dof 3, p 7.5e-09. "
                "Chi-square terms (" + S + "/twice.out, from " + RUN.format(s="twice") + "): S13 0.16, S27 18.93, S66 2.29, S67 19.33. "
                "Without the partly covered S66: chi2 38.25, dof 2, p 4.95e-09, still a fail. Without S27: p 9.1e-04, still a fail. Without S27 and S66: p 5.9e-03, a pass. "
                "So the fail needs S27, a fully covered epoch with no dip (F1). PDCSAP is crowding-corrected and CROWDSAP runs 0.974 to 0.991 over S13, S27, S66 and S67, "
                "so a dilution change of 2% cannot take 0.8 ppt to -0.16 ppt. QLP is compared only with itself and passes (p 0.72) on S93 and S94, S94 being the ramp of F5."
            ),
        },
        {
            "id": "F3",
            "lens": "real_new",
            "rating": "kill",
            "claim": "The holdout kill stands on season 1 (S27); season 0's miss is the refit ephemeris drifting 5.2 hours, not a missing transit.",
            "evidence": (
                "checks.json holdout season 1: predicted P 34.93872, t0 1666.7528, so epoch 11 at BTJD 2051.079 (the search's own epoch-11 time is 2051.080); "
                "depth -150 +- 153 ppm against an expected 753, tension 5.0, expected SNR 4.9, with S27 fully covered (F1). Season 0: the refit without S13 gives "
                "P 34.935329, t0 2051.2559, which puts epoch 0 at BTJD 1666.9673, 5.19 h after the search t0 (" + S + "/twice.out); with the refit's 0.1875 d duration "
                "the core window spans +4.1 h to +6.3 h, after the dip's egress. The dip is there: the best 6-h box sits +0.3 h from the search t0 at 936 +- 103 ppm (scan.out), "
                "and checks.json gives S13 551 +- 146 at the search ephemeris. The drift comes from extrapolating 42 cycles back from training dips at epochs 42 and 62 alone "
                "(the refit puts epoch 42 1.52 h late) and stays without S94 (+5.23 h), so it is not the S94 ramp. Not TTVs: the even dips sit within 0.3 h of a linear ephemeris. "
                "The fail therefore rests on season 1 alone, the same empty odd epoch as F1 and F2."
            ),
        },
        {
            "id": "F4",
            "lens": "planet",
            "rating": "hold",
            "claim": "The three kills show that 34.94 d is the wrong period, not that the dips are no planet: every usable dip falls on an even epoch, consistent with a 69.878-d transit that the search's 40-d cap could not find and that no check has vetted, and at that period vet-v3's five light-curve checks pass.",
            "evidence": (
                "Dips at epochs 0 (S13), 42 (S67), 62 (S93) and 72 (S104, timing-suspect; 0022 puts QLP's offsets under 36 min, small against a 6-h transit): best 6-h boxes "
                "within 0.3 h of the linear ephemeris at 936 +- 103, 1194 +- 98, 1063 +- 117 and 1002 +- 125 ppm (" + S + "/scan.out). Odd epochs 11 and 41 are flat (F1), odd epoch 63 "
                "is a ramp (F5), and epoch 70 has no core data (cut at a gap edge). Shorter periods the even epochs also allow fail: at 2P/3 (23.29 d) the one extra window reads "
                "139 +- 149 ppm, at 2P/5 (13.98 d) the eight extra windows read 19 +- 59 (" + S + "/aliases.out, from " + RUN.format(s="aliases") + "). "
                "vet-v3's own check functions at P = 69.877932 d on the light curve vet-v3 saw (" + S + "/twice.out): odd_even pass at 2.8 sigma (S13 551 +- 146 vs S67 1106 +- 140, "
                "close to the 3.0 line), secondary pass (+1.4 sigma, 111 +- 81 ppm over the odd epochs), sector_depth pass (p 0.006), holdout pass (2 seasons predicted, season 0 "
                "at 575 +- 148), signal_present 9.9 sigma; with the suspect sectors in, all pass, holdout on 3 seasons, 10.6 sigma. Density: the flat fit's log rho -0.227 (+0.167) "
                "rises by log10(2) at twice the period (rho scales with P at a fixed transit shape), to 0.074 (1.19 g/cm3) against the TIC's 0.340 +- 0.091: 1.40 sigma instead of 2.98. "
                "Radius roughly 2.5 Earth radii (2.09 x sqrt(841/599), even-epoch core depth over the combined one, checks.json). criteria/search-v2.toml [search] period_max_days = 40.0. "
                "Triage's two good-quality centroids are on sectors with even-epoch dips: S93 3.3\" (quality 0.75) and S104 3.2\" (0.69). Untested at 69.88 d: the shape, density "
                "and radius fits, ModShift (it ran at 34.94 d: 4.09 sigma at phase 0.591), TRICERATOPS (it did not judge this signal) and the neighbours (Gaia DR3 6434209314080910208 "
                "at 19.6\" needs a 52% eclipse). What would decide: the maintainer's call, with a decision record, on vetting these dips at 69.878 d, since the search cannot propose that period; "
                "then S114's transit at BTJD 4461.87 (epoch 80, even, predicted at both periods; the dossier's window is 4461.847 +- 47.6 min) with 2-min data for the shape."
            ),
        },
        {
            "id": "F5",
            "lens": "real_new",
            "rating": "note",
            "claim": "The one odd-epoch dip, epoch 63 in QLP S94, sits on a steep sector-end ramp, so QLP's odd_even and sector_depth passes at 34.94 d don't support that period.",
            "evidence": (
                "Raw S94 flux, normalized to the sector median (" + S + "/twice.out): -3848 ppm 2.25 to 2.0 d before the last cadence (BTJD 3868.503), -6528 ppm 1.0 to 0.75 d before, "
                "-15054 ppm in the last 6 h, steepening throughout. Epoch 63's mid (3867.906) is 14.3 h before the end, 2.3 h before the detrend's 0.5-d edge cut "
                "(criteria/search-v2.toml edge_cutoff_days), and its depth moves from 803 +- 189 ppm to 1616 +- 187 ppm depending only on how the trend is fitted (scan.out). "
                "Triage's S94 centroid (27.1\", quality 0.16) measures this ramp. Epoch 70 in S101 sits on a similar ramp before a gap at BTJD 4112.92. See " + S + "/epochs.png."
            ),
        },
        {
            "id": "F6",
            "lens": "real_new",
            "rating": "note",
            "claim": "ExoFOP's TOI-7925.01 note already names two of these dips, epochs 42 and 62, as possible unrelated transits, without a period.",
            "evidence": (
                "literature.json search.exofop.tois: TOI 7925.01 (2.607 d, PC, source qlp-s93-ffi, TOI date 2026-08-27) notes \"potential deeper unrelated transits near TBJD 3134 and 3833\"; "
                "our epochs 42 and 62 fall at BTJD 3134.188 and 3832.967. CTOIs on the star: none. No TOI, CTOI or paper gives these dips a period, so a 69.878-d signal would be new, "
                "but a CTOI should credit the note."
            ),
        },
        {
            "id": "F7",
            "lens": "on_star",
            "rating": "note",
            "claim": "The literature hit 2018A&A...609A.116R (a Gaia red clump calibration) doesn't make the star a giant: Gaia DR3 puts it on the main sequence.",
            "evidence": (
                "checks.json star: TIC radius 0.872 solar radii, Gaia DR3 FLAME radius 0.884, logg_flame 4.548, logg_gspphot 4.543, RUWE 1.03. The other four hits (2013AJ....146..134K, "
                "2017AJ....153...75K, 2020AJ....160...83S, 2014AJ....148...81M) are RAVE data releases and APASS photometry of RAVE stars; the star is a RAVE target "
                "(SIMBAD name RAVE J192459.5-660924). None names it as a planet host, a binary, a variable or a multiple."
            ),
        },
    ],
    "hits_flagged": [],
}
with open(f"{S}/findings.json", "w") as f:
    json.dump(out, f, indent=2)
s = open(f"{S}/findings.json").read()
print([(x["id"], x["rating"]) for x in out["findings"]], "em dash" if "—" in s else "no em dash")
