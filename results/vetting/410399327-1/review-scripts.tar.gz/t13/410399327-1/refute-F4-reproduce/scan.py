"""Per-epoch raw and detrended views, and a TTV box scan with the TOI-7925.01 mask off (window held out of the trend)."""
import json, sys
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria, lc_dir
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, in_transit
from tess_hunt.checks.photometry import with_red_noise

checks = json.load(open(sys.argv[1])); cs = json.load(open(sys.argv[2]))
crit_search = load_criteria("criteria/search-v2.toml")
lc = LightCurve.load(lc_dir() / "410399327.npz")
E = checks["ephemeris"]; eph = Ephemeris(E["period"], E["t0"], E["duration"], E["depth"])
toi = Ephemeris(**checks["masked"][0])
epochs = [0, 11, 41, 42, 62, 63, 70, 72]
hold = np.zeros(len(lc.time), bool)
for ep in range(-1, 80):
    hold |= np.abs(lc.time - (eph.t0 + ep*eph.period)) < 0.3
flat_nm = with_red_noise(detrend(lc, crit_search["detrend"], [], hold_out=hold), cs["red_noise"])
flat_m = with_red_noise(detrend(lc, crit_search["detrend"], [toi]), cs["red_noise"])

def box(t, f, e, c, hw):
    m = np.abs(t - c) < hw
    if m.sum() < 5: return np.nan, np.nan, int(m.sum())
    w = 1/e[m]**2
    return 1 - np.sum(w*f[m])/np.sum(w), 1/np.sqrt(np.sum(w)), int(m.sum())

fig, axes = plt.subplots(len(epochs), 2, figsize=(13, 2.3*len(epochs)))
for i, ep in enumerate(epochs):
    mid = eph.t0 + ep*eph.period
    r = np.abs(lc.time - mid) < 1.5
    s = np.unique(lc.sector[r])
    ax = axes[i, 0]
    if r.any():
        t = lc.time[r]; f = lc.flux[r] / np.nanmedian(lc.flux[r])
        ax.plot((t-mid)*24, (f-1)*1e6, ".", ms=1, color="0.6")
        b = np.floor((t-mid)*24).astype(int)
        for k in np.unique(b):
            ax.plot(k+0.5, (np.mean(f[b==k])-1)*1e6, "o", ms=3, color="C0")
        tm = in_transit(t, toi, 2.0)
        if tm.any(): ax.plot((t[tm]-mid)*24, (f[tm]-1)*1e6, ".", ms=2, color="C3")
    ax.axvspan(-3, 3, alpha=0.1); ax.set_xlim(-36, 36); ax.set_ylim(-4000, 4000)
    ax.set_title(f"raw normalized flux, epoch {ep}, S{s.tolist()}", fontsize=8)
    ax = axes[i, 1]
    n = np.abs(flat_nm.time - mid) < 1.5
    t, f, e = flat_nm.time[n], flat_nm.flux[n], flat_nm.flux_err[n]
    if n.any():
        ax.plot((t-mid)*24, (f-1)*1e6, ".", ms=1, color="0.6")
        b = np.floor((t-mid)*24).astype(int)
        for k in np.unique(b):
            ax.plot(k+0.5, (np.mean(f[b==k])-1)*1e6, "o", ms=3, color="C0")
    ax.axvspan(-3, 3, alpha=0.1); ax.set_xlim(-36, 36); ax.set_ylim(-3000, 3000)
    ax.set_title(f"detrended, TOI mask off, +-0.3 d held out of trend, epoch {ep}", fontsize=8)
    # TTV scan with a 0.25 d box (full duration) and the core box at 0.125 d
    rows = []
    for off in np.arange(-0.5, 0.5001, 0.0125):
        d, de, k = box(t, f, e, mid+off, 0.125) if n.any() else (np.nan, np.nan, 0)
        rows.append((off, d, de, k))
    good = [x for x in rows if np.isfinite(x[1]) and x[3] >= 20]
    best = max(good, key=lambda x: x[1]/x[2]) if good else None
    d0 = box(t, f, e, mid, 0.0625) if n.any() else (np.nan, np.nan, 0)
    dm = box(flat_m.time, flat_m.flux, flat_m.flux_err, mid, 0.0625)
    print(f"epoch {ep} S{s.tolist()} raw span {((lc.time[r].min()-mid)*24 if r.any() else np.nan):+.1f}h..{((lc.time[r].max()-mid)*24 if r.any() else np.nan):+.1f}h "
          f"| core depth, TOI mask on: {dm[0]*1e6:.0f}+-{dm[1]*1e6:.0f} (n {dm[2]}); TOI mask off: {d0[0]*1e6:.0f}+-{d0[1]*1e6:.0f} (n {d0[2]})"
          + (f" | best 6-h box within +-12 h: {best[0]*24:+.1f} h, {best[1]*1e6:.0f}+-{best[2]*1e6:.0f} ppm, {best[1]/best[2]:.1f} sigma, n {best[3]}" if best else ""))
fig.tight_layout(); fig.savefig("/tmp/t13/410399327-1/refute-F4-reproduce/epochs.png", dpi=90)
