"""Evidence only: vet-v3's light-curve checks at the search ephemeris and at twice its period, on the light curve vet-v3
saw (timing-suspect sectors out, TOI-7925.01 masked) and on the evidence-only one. Plus the holdout season-0 refit
prediction and the S94 end-of-sector ramp."""
import json, sys
from dataclasses import replace
import numpy as np
from tess_hunt.lightcurve import LightCurve
from tess_hunt.config import load_criteria, lc_dir
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.checks.photometry import red_noise_beta, with_red_noise, odd_even, secondary, sector_depths, signal_present, box_depth
from tess_hunt.checks.holdout import holdout, refit_ephemeris, season_labels
from tess_hunt.checks.families import good_timestamps, split, per_family

checks = json.load(open(sys.argv[1]))
cs, cv = load_criteria("criteria/search-v2.toml"), load_criteria("criteria/vet-v3.toml")
lc_all = LightCurve.load(lc_dir() / "410399327.npz")
E = checks["ephemeris"]; eph = Ephemeris(E["period"], E["t0"], E["duration"], E["depth"])
masks = [Ephemeris(**m) for m in checks["masked"]]
core = cv["depth"]["core_fraction"]; fam = cv["families"]

def run(lc, e, label):
    flat = detrend(lc, cs["detrend"], masks)
    betas = red_noise_beta(flat, e, core * e.duration, cv["red_noise"])
    noisy = with_red_noise(flat, betas)
    parts = split(noisy, fam)
    oe = per_family("odd_even", {n: odd_even(p, e, core, 3.0, 5) for n, p in parts.items()})
    sd = per_family("sector_depth", {n: sector_depths(p, e, core, 0.001, 5) for n, p in parts.items()})
    sec = secondary(noisy, e, 3.0, 5)
    ho = holdout(noisy, e, cv["holdout"], core, fam)
    sp = signal_present(noisy, e, core, 7.0, 5)
    print(f"\n== {label}: P {e.period:.6f} t0 {e.t0:.4f}")
    for r in (oe, sec, sd, ho, sp):
        print(f"  {r.check}: {r.outcome.value} - {r.reason}")
    for n, r in oe.evidence["families"].items():
        ev = r["evidence"]
        g = lambda k: float('nan') if ev.get(k) is None else ev[k]
        print(f"    odd_even {n}: odd {g('depth_odd')*1e6:.0f}+-{g('err_odd')*1e6:.0f} (n {ev['n_odd']}), even {g('depth_even')*1e6:.0f}+-{g('err_even')*1e6:.0f} (n {ev['n_even']}) [{r['outcome']}: {r['reason']}]")
    for n, r in sd.evidence["families"].items():
        rows = r["evidence"].get("sectors", [])
        print(f"    sector_depth {n}: " + "; ".join(f"S{x['sector']} {x['depth']*1e6:.0f}+-{x['err']*1e6:.0f} (n {x['n']})" for x in rows) + f" p {r['evidence'].get('p_value')}")
    for s in ho.evidence["seasons"]:
        print(f"    holdout season {s['season']}: {s['status']} pred P {s.get('predicted_period', float('nan')):.5f} t0 {s.get('predicted_t0', float('nan')):.4f} depth {(s.get('depth') or float('nan'))*1e6:.0f}+-{(s.get('err') or float('nan'))*1e6:.0f} exp_snr {s.get('expected_snr')} sigma {s.get('sigma')} tension {s.get('tension')} {s.get('reason','')}")
    print(f"    secondary: {sec.evidence['depth']*1e6:.0f}+-{sec.evidence['err']*1e6:.0f} ppm (n {sec.evidence['n']})")
    return noisy

good = good_timestamps(lc_all)
noisy = run(good, eph, "vet-v3 light curve, search ephemeris (reproduces checks.json)")
twice = replace(eph, period=2 * eph.period)
run(good, twice, "vet-v3 light curve, twice the period")
run(lc_all, twice, "evidence-only light curve (suspect sectors in), twice the period")

# Sector-depth chi2 contributions at the search ephemeris, PDCSAP
sd = checks["checks"][3]["evidence"]["families"]["pdcsap"]["evidence"]
d = np.array([r["depth"] for r in sd["sectors"]]); e = np.array([r["err"] for r in sd["sectors"]])
mean = np.sum(d / e**2) / np.sum(1 / e**2)
print("\nPDCSAP sector_depth chi2 terms:", {r["sector"]: round(((r["depth"] - mean) / r["err"]) ** 2, 2) for r in sd["sectors"]})
from scipy.stats import chi2
for drop in ([66], [27], [27, 66]):
    keep = [i for i, r in enumerate(sd["sectors"]) if r["sector"] not in drop]
    dd, ee = d[keep], e[keep]; m = np.sum(dd / ee**2) / np.sum(1 / ee**2); c = np.sum(((dd - m) / ee) ** 2)
    print(f"  without S{drop}: chi2 {c:.2f} dof {len(keep)-1} p {chi2.sf(c, len(keep)-1):.2e}")

# Holdout season 0: where the refit without S13 puts epoch 0
ho = checks["checks"][4]["evidence"]["seasons"][0]
P, T = ho["predicted_period"], ho["predicted_t0"]
n = round((eph.t0 - T) / P)
print(f"\nholdout season 0 refit: P {P:.6f} t0 {T:.4f}; epoch 0 predicted at {T + n*P:.4f} = {(T + n*P - eph.t0)*24:+.2f} h from the search t0 {eph.t0:.4f}")
for ep in (42, 62, 63):
    k = round((eph.t0 + ep*eph.period - T) / P)
    print(f"  epoch {ep}: refit {T + k*P:.4f}, search {eph.t0 + ep*eph.period:.4f}, diff {(T + k*P - eph.t0 - ep*eph.period)*24:+.2f} h")
labels = season_labels(noisy.time, cv["holdout"]["season_gap_days"])
train = noisy.select(labels != 0)
again = refit_ephemeris(train, eph, cv["holdout"])
print(f"  refit reproduced: P {again.period:.6f} t0 {again.t0:.4f} duration {again.duration}")
no94 = train.select(train.sector != 94)
r2 = refit_ephemeris(no94, eph, cv["holdout"])
n2 = round((eph.t0 - r2.t0) / r2.period)
print(f"  refit without S94: P {r2.period:.6f}; epoch 0 predicted at {r2.t0 + n2*r2.period:.4f} = {(r2.t0 + n2*r2.period - eph.t0)*24:+.2f} h from search t0")

# S94's end: raw normalized flux, median per 6 h over the sector's last 1.5 d
m = lc_all.sector == 94
t, f = lc_all.time[m], lc_all.flux[m] / np.median(lc_all.flux[m])
end = t.max()
print(f"\nS94 raw: ends {end:.3f}; epoch 63 mid {eph.t0 + 63*eph.period:.3f} is {(end - eph.t0 - 63*eph.period)*24:.1f} h before the end")
for a in np.arange(-2.0, 0.001, 0.25):
    s = (t >= end + a - 0.25) & (t < end + a)
    if s.any(): print(f"  {a-0.25:+.2f}..{a:+.2f} d from end: median {(np.median(f[s]) - 1)*1e6:+.0f} ppm (n {s.sum()})")
