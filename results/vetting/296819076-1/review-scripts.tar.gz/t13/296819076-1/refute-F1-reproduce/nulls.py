import json, sys, numpy as np
d = json.load(open(sys.argv[1]))[0]
for r in d["per_sector"]:
    if "error" in r or r["sector"] == 99: continue
    cat = r["catalogue"]
    t = cat[0]
    dec0 = t["dec"]
    nb = [c for c in cat if c["tic"] == 296819054][0]
    e = (nb["ra"] - t["ra"]) * np.cos(np.radians(dec0)) * 3600
    n = (nb["dec"] - t["dec"]) * 3600
    f = r["fit"]
    dreal = np.hypot(f["east"] - e, f["north"] - n)
    nul = [x for x in r["nulls"] if x.get("ok") and x["phase"] != 0.0]
    dn = [np.hypot(x["east"] - e, x["north"] - n) for x in nul]
    pas = [np.degrees(np.arctan2(x["east"], x["north"])) % 360 for x in nul]
    print(f"S{r['sector']}: target tic {t['tic']} T{t['tmag']:.2f}; 054 at E {e:.1f} N {n:.1f}; real fit dist {dreal:.1f}; nulls n={len(nul)} min dist {min(dn):.1f}; closer than real: {sum(x < dreal for x in dn)}")
    print("   null PAs:", sorted(round(p) for p in pas))
    print("   null offsets:", sorted(round(x['offset'],1) for x in nul))
