import json, numpy as np
d = json.load(open("two_star_multi.json"))
dep = 390.382e-6
for other in (296819054, 1132493523, 1132493525, 1132493581, 296819078):
    out = {}
    for r in d:
        if r["sector"] == 99: continue
        p = [x for x in r["pairs"] if x["other"] == other][0]
        ta = r["target_alone"]; fa = ta["amp"]/ta["depth"]
        sd_t = p["amp_t"]/p["snr_t"]
        out[r["sector"]] = (dep*p["flux_t"]/sd_t, dep*fa/sd_t, p["snr_t"])
    a = [v[0] for v in out.values()]; b = [v[1] for v in out.values()]; act = [v[2] for v in out.values()]
    print(other, "exp(2psf flux)", round(sum(a)/2,2), "rss", round(np.sqrt(sum(x*x for x in a)),2), "exp(alone flux)", round(sum(b)/2,2), "| actual", round(sum(act)/2,2))
# light-curve depth per dossier: check
