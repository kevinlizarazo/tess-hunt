import json, numpy as np
d = json.load(open("two_star_multi.json"))
T0, T1 = 10.31, 14.89
for depth in (390.382e-6, 562e-6):
    exp = []
    for r in d:
        if r["sector"] == 99: continue
        p = [x for x in r["pairs"] if x["other"] == 296819054][0]
        sd_t = p["amp_t"] / p["snr_t"]
        e = depth * p["flux_t"] / sd_t
        exp.append(e)
        f054 = p["flux_t"] * 10 ** (-0.4 * (T1 - T0))
        print(f"depth {depth*1e6:.0f}: S{r['sector']} expected target snr {e:.2f}; 054 implied eclipse {p['amp_o']/f054*100:.2f}% (amp_o {p['amp_o']:.1f}, flux_t {p['flux_t']:.0f})")
    print("  combined expected", sum(exp)/np.sqrt(len(exp)))
# target-alone comparison
for r in d:
    print(r["sector"], "target alone snr", round(r["target_alone"]["snr"],2))
