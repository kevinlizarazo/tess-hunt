import json, sys, numpy as np
d = json.load(open(sys.argv[1]))[0]
for r in d["per_sector"]:
    if "error" in r:
        print("S", r["sector"], "ERROR", r["error"]); continue
    f = r["fit"]
    pa = (np.degrees(np.arctan2(f["east"], f["north"]))) % 360
    nul = [n for n in r["nulls"] if n.get("ok")]
    rep = [n.get("reproduces_saved_image") for n in nul if n["phase"] == 0.0]
    print(f"S{r['sector']} cam{r['camera']} ccd{r['ccd']} off {f['offset']:.1f} q {f['quality']:.3f} E {f['east']:.1f} N {f['north']:.1f} PA {pa:.0f} dcol {f['dcol']:.2f} drow {f['drow']:.2f} expected_snr {r['expected_snr']:.2f} target_box_snr {r['target_box']['snr']:.2f} phase0_repro {rep} n_nulls {len(nul)-1}")
    for nb in r["near_fit"]:
        print("    near fit:", nb["tic"], round(nb["tmag"],2), "sep_fit", round(nb["sep_from_fit"],1), "sep_tgt", round(nb["sep_from_target"],1))
