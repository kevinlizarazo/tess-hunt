"""Fixed-position PRF fits of the target with two neighbours at once (two_star_multi.py's method), so the loss can
choose between TIC 296819078 (8" W), TIC 296819054 (22" W) and TIC 1132493581 (19" SW). SNRs against the same null
images. Usage: three_star.py OUT.json"""
import json, pickle, sys, warnings
import numpy as np
sys.path.insert(0, "/tmp/t13/296819076-1")
from sector_detail import null_images, prf_model
warnings.filterwarnings("ignore")
STAR = "$TESS_HUNT_DATA/tdi/20261015T155441Z-triage-7b12e25-3f57/296819076-1/tic296819076"
SETS = [(296819078, 296819054), (296819054, 1132493581), (296819078, 1132493581)]
def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)
def solve(img, basis):
    a = np.column_stack([b.ravel() for b in basis] + [np.ones(basis[0].size)])
    return np.linalg.lstsq(a, img.ravel(), rcond=None)[0]
out = []
for s in [102, 101, 65, 12]:
    with open(f"{STAR}/imageData_296819076.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    prf = prf_model(images, cat, pix)
    ids = np.asarray(cat["ticID"]).astype(int)
    nulls = [img["diffImage"] for ph, _, img in null_images(pix, planet)
             if ph != 0.0 and img and not np.isnan(np.sum(img["diffImage"]))]
    base = [unit_prf(prf, cat, cat["ticColPix"][0], cat["ticRowPix"][0])]
    for a, b in SETS:
        basis = base + [unit_prf(prf, cat, cat["ticColPix"][int(np.where(ids == t)[0][0])], cat["ticRowPix"][int(np.where(ids == t)[0][0])]) for t in (a, b)]
        real = solve(images["diffImage"], basis)[:3]
        sd = np.std([solve(n, basis)[:3] for n in nulls], axis=0, ddof=1)
        snr = real / sd
        out.append({"sector": s, "stars": [296819076, a, b], "amp": real.tolist(), "snr": snr.tolist()})
        print(f"S{s}: target {snr[0]:5.2f} | TIC {a} {snr[1]:5.2f} | TIC {b} {snr[2]:5.2f}  (nulls {len(nulls)})")
json.dump(out, open(sys.argv[1], "w"), indent=1)
