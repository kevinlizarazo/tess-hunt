"""Gaia DR3 rows for the 10 no-G stars of 296819076-1's neighbour table, read from the public archive (sync TAP)."""
import io, sys, urllib.parse, urllib.request
ids = "5877911685180852608,5877911685182321536,5877911650822550784,5877910929269366528,5877910929269935232,5877911650821138816,5877910894908286208,5877910929268065920,5877910929270028416,5877911685182376448"
q = f"""SELECT source_id, ra, dec, astrometric_params_solved, visibility_periods_used, parallax, parallax_error, pmra, pmdec,
 ruwe, phot_g_n_obs, phot_g_mean_mag, phot_bp_n_obs, phot_bp_mean_mag, phot_rp_n_obs, phot_rp_mean_mag,
 ipd_frac_multi_peak, ipd_frac_odd_win, ipd_gof_harmonic_amplitude, duplicated_source, matched_transits, astrometric_matched_transits, astrometric_excess_noise
 FROM gaiadr3.gaia_source WHERE source_id IN ({ids})"""
url = "https://gea.esac.esa.int/tap-server/tap/sync"
data = urllib.parse.urlencode({"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv", "QUERY": q}).encode()
print(urllib.request.urlopen(url, data, timeout=120).read().decode())
