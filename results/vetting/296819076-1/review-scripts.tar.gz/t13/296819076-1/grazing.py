"""How long a grazing eclipse on the target lasts when it is only 390 to 560 ppm deep: batman (tess_hunt.transit's
model, quadratic u1 0.45, u2 0.20, dark companion, the most favourable case), P 2.2797 d and a/R* 5.48 (the
density-prior fit), and at twice the period with a/R* scaled by (2)^(2/3). For each companion radius ratio k, the
impact parameter b that makes the eclipse this deep, and the time the flux stays below 1."""
import batman, numpy as np
from scipy.optimize import brentq
def model(k, b, P, a):
    p = batman.TransitParams(); p.t0, p.per, p.rp, p.a = 0.0, P, k, a
    p.inc = np.degrees(np.arccos(b / a)); p.ecc, p.w = 0.0, 90.0; p.u, p.limb_dark = [0.45, 0.20], "quadratic"
    t = np.linspace(-0.3, 0.3, 60001)
    f = batman.TransitModel(p, t).light_curve(p)
    return t, f
for P, a in ((2.27966, 5.48), (2 * 2.27966, 5.48 * 2 ** (2 / 3))):
    print(f"P {P:.4f} d, a/R* {a:.2f}")
    for depth in (390e-6, 560e-6):
        for k in (0.1, 0.2, 0.3, 0.5, 0.8, 1.0):
            g = lambda b: (1 - model(k, b, P, a)[1].min()) - depth
            lo, hi = 1 - k + 1e-6, 1 + k - 1e-6
            b = brentq(g, lo, hi, xtol=1e-7)
            t, f = model(k, b, P, a)
            dur = (t[f < 1].max() - t[f < 1].min()) * 24
            print(f"   depth {depth*1e6:.0f} ppm, k {k:.1f}: b {b:.4f}, eclipse lasts {dur:.2f} h")
