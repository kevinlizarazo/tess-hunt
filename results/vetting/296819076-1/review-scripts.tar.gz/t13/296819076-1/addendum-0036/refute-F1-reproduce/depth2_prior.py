import json, numpy as np
d = json.load(open("two_star_multi.json"))
det = {r["sector"]: r for r in json.load(open("detail.json"))[0]["per_sector"] if "error" not in r}
T0, T1 = 10.31, 14.89
sc = 10 ** (-0.4 * (T1 - T0))
rows = []
for r in d:
    if r["sector"] == 99: continue
    s = r["sector"]
    p = [x for x in r["pairs"] if x["other"] == 296819054][0]
    ta = r["target_alone"]
    ft_alone = ta["amp"] / ta["depth"]
    sd_t = p["amp_t"] / p["snr_t"]
    sd_o = p["amp_o"] / p["snr_o"]
    sd_alone = ta["amp"] / ta["snr"]
    box = det[s]["target_box"]["flux"]
    rows.append((s, ft_alone, sd_t, sd_alone, box, p))
    print(f"S{s}: flux_t(2psf) {p['flux_t']:.0f} ft_alone {ft_alone:.0f} box3x3 {box:.0f} | sd_t {sd_t:.2f} sd_alone {sd_alone:.2f}")
    for name, F in (("2psf", p["flux_t"]), ("alone", ft_alone), ("box", box)):
        print(f"    054 eclipse with {name} flux: {p['amp_o']/(F*sc)*100:.2f}%")
for depth in (390.382e-6,):
    for name, fi in (("alone flux / sd_t", lambda r: r[1] / r[2]), ("alone flux / sd_alone", lambda r: r[1] / r[3]), ("2psf flux / sd_t", lambda r: r[5]["flux_t"] / r[2])):
        e = [depth * fi(r) for r in rows]
        print(name, [round(x, 2) for x in e], "combined", round(sum(e) / 2, 2))
    e3 = [depth * fi(r) for r in rows if r[0] != 12 for fi in [lambda r: r[1]/r[2]]]
