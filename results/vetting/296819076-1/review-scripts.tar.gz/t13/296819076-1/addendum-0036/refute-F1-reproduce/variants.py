import json, numpy as np
d = [r for r in json.load(open("two_star_multi.json")) if r["sector"] != 99]
for dep_name, dep in (("390", 390.382e-6), ("562", 561.56e-6)):
    for fl in ("alone", "2psf"):
        for sdn in ("sd_t", "sd_alone"):
            e = []
            for r in d:
                p = [x for x in r["pairs"] if x["other"] == 296819054][0]
                ta = r["target_alone"]
                F = ta["amp"] / ta["depth"] if fl == "alone" else p["flux_t"]
                sd = p["amp_t"] / p["snr_t"] if sdn == "sd_t" else ta["amp"] / ta["snr"]
                e.append(dep * F / sd)
            e = np.array(e)
            print(dep_name, fl, sdn, "sum/2", round(e.sum()/2, 2), "rss", round(np.sqrt((e**2).sum()), 2), "no S12 sum/sqrt3", round(e[:3].sum()/np.sqrt(3), 2))
