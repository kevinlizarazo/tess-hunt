import json, math, sys
d = json.load(open(sys.argv[1]))[0]
for r in d["per_sector"]:
    if "error" in r:
        print("S", r["sector"], "ERROR", r["error"]); continue
    f = r["fit"]
    pa = math.degrees(math.atan2(f["east"], f["north"])) % 360
    # TIC 296819054 position relative to target
    cat = {c["tic"]: c for c in r["catalogue"]}
    t0 = r["catalogue"][0]
    n = cat.get(296819054)
    dec0 = t0["dec"]
    ne = (n["ra"] - t0["ra"]) * math.cos(math.radians(dec0)) * 3600
    nn = (n["dec"] - t0["dec"]) * 3600
    dist = math.hypot(f["east"] - ne, f["north"] - nn)
    p0 = [x for x in r["nulls"] if x["phase"] == 0.0][0]
    nulls = [x for x in r["nulls"] if x["phase"] != 0.0 and x["ok"]]
    nd = [math.hypot(x["east"] - ne, x["north"] - nn) for x in nulls]
    npa = sorted(round(math.degrees(math.atan2(x["east"], x["north"])) % 360) for x in nulls)
    print(f"S{r['sector']} cam{r['camera']} ccd{r['ccd']} fit E {f['east']:.1f} N {f['north']:.1f} off {f['offset']:.2f} q {f['quality']:.3f} PA {pa:.0f} dcol {f['dcol']:.2f} drow {f['drow']:.2f}")
    print(f"   n296819054 at ({ne:.1f},{nn:.1f}); fit-to-nbr {dist:.1f}; reproduces {p0.get('reproduces_saved_image')}; expected_snr {r['expected_snr']:.2f}")
    print(f"   nulls ok {len(nulls)}/{len([x for x in r['nulls'] if x['phase']!=0.0])}; closest null to nbr {min(nd):.1f}; any closer than real: {any(x < dist for x in nd)}; null PAs {npa}")
