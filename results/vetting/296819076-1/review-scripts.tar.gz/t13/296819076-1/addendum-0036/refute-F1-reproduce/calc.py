import json, numpy as np
d = json.load(open("two_star_multi.json"))
det = {r["sector"]: r for r in json.load(open("detail.json"))[0]["per_sector"] if "error" not in r}
print("target tmag", {s: round(det[s]["tmag"], 3) for s in det})
dep = 390.382e-6
T0, T1 = 10.31, 14.89
sc = 10 ** (-0.4 * (T1 - T0))
for other in (296819054, 1132493523, 1132493525):
    exp_alone, exp_2p, act_t, act_o = [], [], [], []
    for r in d:
        if r["sector"] == 99: continue
        p = [x for x in r["pairs"] if x["other"] == other][0]
        ta = r["target_alone"]; fa = ta["amp"] / ta["depth"]
        sd_t = p["amp_t"] / p["snr_t"]
        exp_alone.append(dep * fa / sd_t); exp_2p.append(dep * p["flux_t"] / sd_t)
        act_t.append(p["snr_t"]); act_o.append(p["snr_o"])
        if other == 296819054:
            print(f"S{r['sector']} 054 eclipse: 2psf-flux {p['amp_o']/(p['flux_t']*sc)*100:.2f}%  alone-flux {p['amp_o']/(fa*sc)*100:.2f}%  box {p['amp_o']/(det[r['sector']]['target_box']['flux']*sc)*100:.2f}%")
    print(other, "neighbour combined", round(sum(act_o)/2, 2), "target combined", round(sum(act_t)/2, 2),
          "expected if on target (alone flux)", round(sum(exp_alone)/2, 2), [round(x,2) for x in exp_alone],
          "(2psf flux)", round(sum(exp_2p)/2, 2))
