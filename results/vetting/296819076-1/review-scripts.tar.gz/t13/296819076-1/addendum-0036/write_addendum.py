"""Build the 0036 addendum of 296819076-1's review from review.json."""
import json
old = json.load(open("/tmp/t13/out/296819076-1/review.json"))
f = {x["id"]: x for x in old["findings"]}
T2 = "TRIC2_RUN 20261020T181658Z-vetting-triceratops-61b5944-1bbf"
T3 = "TRIC3B_RUN 20261021T194348Z-vetting-triceratops-cd4e7a2-7821"
U = " Updated 2026-10-22 for the 0036 TRICERATOPS rerun: "

def keep(i, status, why, claim=None, evidence=None, trailer=None):
    x = f[i]
    ev = (evidence if evidence is not None else x["evidence"]) + (U + trailer if trailer else "")
    return {"id": i, "lens": x["lens"], "rating": x["rating"], "claim": claim or x["claim"], "evidence": ev,
            "status": status, "why": why}

f3_ev = f["F3"]["evidence"]
for a, b in [
    ("nfpp_mean 0.05543 (sd 0.00065), fpp_mean 0.0707,", "nfpp_mean 0.05453 (sd 0.00058), fpp_mean 0.0698,"),
    ("carries 0.0364 (NEBx2P 0.0278, NEB 0.0085), 65% of that run's 0.0563;",
     "carries 0.0365 (NEBx2P 0.0279, NEB 0.0085), 66% of that run's 0.0554;"),
]:
    assert f3_ev.count(a) == 1, a
    f3_ev = f3_ev.replace(a, b)
f3_claim = f["F3"]["claim"]
assert f3_claim.count("mean NFPP of 0.0554 ") == 1
f3_claim = f3_claim.replace("mean NFPP of 0.0554 ", "mean NFPP of 0.0545 ")

findings = [
    keep("F1", "updated",
         "Read the new dossier.md row for Gaia DR3 5877911650854908160 (3.17%, not in dossier.diff), the new triceratops.json hosts (tdepth 0.0317279) and probs.csv (R_s 2.09038), and confirmed checks.json is byte-identical to VET2_RUN's; its TRICERATOPS depth and radius now come from TRIC3B_RUN with the same stated digits, so updated, and the kill rests on pixel fits the rerun does not touch, so the rating stands as it was.",
         trailer=f"the dossier's TRICERATOPS depth for Gaia DR3 5877911650854908160 (TIC 296819054) now comes from {T3} instead of {T2}: tdepth 0.031733 to 0.0317279 (triceratops.json hosts), 3.17% both times; its radius in probs.csv is 2.09038 both times. Nothing else in F1 reads TRICERATOPS."),
    keep("F2", "updated",
         "Reran gaia_nog.py and matched the ten no-G stars to the old and new triceratops.json star lists with nog_match.py, and confirmed checks.json (no_g) is byte-identical to VET2_RUN's; the star list it cites is now TRIC3B_RUN's and gives the same matches, so updated.",
         trailer=f"triceratops.json evidence.stars is now {T3}'s list, 6,036 stars to 5,977 after 0036 dropped 58 DUPLICATE rows and one ARTIFACT (was {T2}'s). Rematched against both lists (`uv run python -I /tmp/t13/296819076-1/gaia_nog.py > /tmp/t13/296819076-1/addendum-0036/gaia_nog.csv`, then `uv run python -I /tmp/t13/296819076-1/addendum-0036/nog_match.py /tmp/t13/296819076-1/addendum-0036/gaia_nog.csv /tmp/t13/296819076-1/pre-0036/triceratops.json ~/.cache/tess-hunt/drafts/m3-r2/296819076-1/triceratops.json`): the nine match the same TIC stars at 0.00 to 0.14\", T 19.73 to 20.85, tdepth 0, none of them a dropped row, and the tenth's nearest TIC star is still the target at 3.9\"."),
    keep("F3", "updated",
         "Read the new triceratops.json (nfpp and fpp means and sds, ephemeris, ruwe, contrast, missing_hosts, target tdepth 0.00039), the new probs.csv by star and scenario, criteria/vet-v3.toml and compare.txt; the NFPP, FPP and TIC 1132493581 digits changed, and 0.0545 still sits between 0.001 and 0.1 and above 0.027 and 0.0341, so updated with the note rating kept.",
         claim=f3_claim, evidence=f3_ev,
         trailer=f"triceratops.json and probs.csv are now {T3}'s (were {T2}'s); nfpp_mean 0.05543 (sd 0.00065) to 0.05453 (sd 0.00058); fpp_mean 0.0707 to 0.0698; in the last run TIC 1132493581 0.0364 to 0.0365, its NEBx2P 0.0278 to 0.0279, and 65% of 0.0563 to 66% of 0.0554. The fall is 0036's drop of the DUPLICATE rows, chiefly TIC 1132493585 (a copy of TIC 296819067; 0.00099 in the old last run), and lands where 0036 predicted (about 0.0545). TIC 296819054, 1132493523 and 1132493525 (0.0032, 0.0049, 0.00005, together 0.0082), the ephemeris, the 390 ppm input depth, RUWE, contrast and missing hosts are the same."),
    keep("F4", "updated",
         "Read the new probs.csv by scenario (EB, EBx2P, PEB, PEBx2P, DEB) and confirmed checks.json and checks-with-suspect.json are byte-identical to VET2_RUN's and VET2_SUSPECT_RUN's; it cites TRICERATOPS's probs.csv, now TRIC3B_RUN's with the same digits at the stated precision, so updated.",
         trailer=f"probs.csv's last run is now {T3}'s (was {T2}'s): EB 7.981e-14 to 7.991e-14, EBx2P 1.341e-7 to 1.343e-7, PEB 7.435e-15 to 7.445e-15, PEBx2P 1.108e-6 to 1.109e-6, DEB 2.021e-15 to 2.017e-15, the same at the precision given."),
    keep("F5", "unchanged",
         "Cites only checks-with-suspect.json, byte-identical to VET2_SUSPECT_RUN's (sector_depth qlp and holdout season 2 re-read: 549, 317, -52, 579 and 514 ppm, chi2 24.5 on 4 dof, p 6.2e-5, 13 +- 45 against 470 ppm), and decision records; no TRICERATOPS file or number, so unchanged."),
    keep("F6", "unchanged",
         "Cites literature.json (byte-identical to LIT3_RUN's), the neighbour table's 81.6% (neighbours.csv byte-identical to VET2_RUN's; dossier row not in dossier.diff) and Gaia, VizieR and light-curve commands the rerun does not touch; no TRICERATOPS file or number, so unchanged."),
]
for x in findings:
    if x["status"] == "unchanged":
        assert x["claim"] == f[x["id"]]["claim"] and x["evidence"] == f[x["id"]]["evidence"]
    if x["status"] == "updated" and x["id"] != "F3":
        assert x["claim"] == f[x["id"]]["claim"] and x["evidence"].startswith(f[x["id"]]["evidence"] + U)
    assert "—" not in x["evidence"] + x["claim"] + x["why"]
out = {"signal": old["signal"], "summary": old["summary"] + " Updated 2026-10-22 for the 0036 TRICERATOPS rerun.",
       "findings": findings, "hits_flagged": old["hits_flagged"]}
json.dump(out, open("/tmp/t13/296819076-1/addendum-0036/findings.json", "w"), indent=2, ensure_ascii=False)
print(json.dumps(out, ensure_ascii=False))
