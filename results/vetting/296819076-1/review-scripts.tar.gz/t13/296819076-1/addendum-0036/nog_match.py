"""Match the 10 no-G Gaia DR3 stars (moved to J2000 with their DR3 proper motion) to the old and new TRICERATOPS star lists."""
import csv, json, math, sys
gaia_csv, old_json, new_json = sys.argv[1:4]
rows = list(csv.DictReader(open(gaia_csv)))
def stars(p):
    e = json.load(open(p))["evidence"]
    return e["stars"], e.get("dropped_stars")
so, _ = stars(old_json); sn, dropped = stars(new_json)
dropped_ids = {d["ID"] for d in dropped or []}
t = sn[0]
def sep(ra1, de1, ra2, de2):
    d = math.radians
    c = math.sin(d(de1))*math.sin(d(de2)) + math.cos(d(de1))*math.cos(d(de2))*math.cos(d(ra1-ra2))
    return math.degrees(math.acos(min(1, c)))*3600
for r in rows:
    ra, de = float(r["ra"]), float(r["dec"])
    if r["pmra"]:
        ra -= float(r["pmra"])*16/3.6e6/math.cos(math.radians(de)); de -= float(r["pmdec"])*16/3.6e6
    out = [r["source_id"], f'{sep(ra, de, t["ra"], t["dec"]):.1f}"']
    for lab, sl in (("old", so), ("new", sn)):
        best = sorted(((sep(ra, de, s["ra"], s["dec"]), s) for s in sl), key=lambda x: x[0])[:2]
        out.append(lab + " " + "; ".join(f'TIC {s["ID"]} {d:.2f}" T {s["Tmag"]} tdepth {s["tdepth"]} {s.get("disposition")}{" DROPPED" if s["ID"] in dropped_ids else ""}' for d, s in best))
    print(" | ".join(out))
