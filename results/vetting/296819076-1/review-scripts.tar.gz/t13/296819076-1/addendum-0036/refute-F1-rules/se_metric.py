"""Diagnosis 'mean offset in standard errors' (summary.py formulas) for 296819076-1, by sector set."""
import json, sys
import numpy as np
d = json.load(open(sys.argv[1]))[0]
secs = {s["sector"]: s for s in d["per_sector"] if "error" not in s}
for keep in ([102, 101, 99, 65, 12], [102, 101, 65, 12], [102, 101, 65]):
    w = np.array([secs[k]["fit"]["quality"] for k in keep])
    e = np.array([secs[k]["fit"]["east"] for k in keep])
    n = np.array([secs[k]["fit"]["north"] for k in keep])
    me, mn = np.average(e, weights=w), np.average(n, weights=w)
    sc = np.sqrt(np.mean((e - me) ** 2 + (n - mn) ** 2))
    off = np.hypot(me, mn)
    print(f"sectors {keep}: mean offset {off:.1f}\" sky scatter {sc:.1f}\" -> {off / (sc / np.sqrt(len(keep))):.1f} standard errors")
