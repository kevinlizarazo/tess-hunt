"""Gaia DR3 variability tables for sources within 90" of 296819076's DR3 position (public archive, sync TAP)."""
import urllib.parse, urllib.request
def q(adql):
    data = urllib.parse.urlencode({"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv", "QUERY": adql}).encode()
    return urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync", data, timeout=180).read().decode()
cone = "1=CONTAINS(POINT('ICRS', g.ra, g.dec), CIRCLE('ICRS', 224.1597, -60.8914, 0.025))"
print(q(f"SELECT g.source_id, g.phot_g_mean_mag, g.phot_variable_flag, DISTANCE(POINT('ICRS', g.ra, g.dec), POINT('ICRS', 224.1597, -60.8914))*3600 AS sep FROM gaiadr3.gaia_source AS g WHERE {cone} AND g.phot_variable_flag='VARIABLE' ORDER BY sep"))
print(q(f"SELECT v.*, DISTANCE(POINT('ICRS', g.ra, g.dec), POINT('ICRS', 224.1597, -60.8914))*3600 AS sep FROM gaiadr3.gaia_source AS g JOIN gaiadr3.vari_classifier_result AS v USING (source_id) WHERE {cone}"))
print(q(f"SELECT e.source_id, e.frequency, 1/e.frequency AS period, e.global_ranking, DISTANCE(POINT('ICRS', g.ra, g.dec), POINT('ICRS', 224.1597, -60.8914))*3600 AS sep FROM gaiadr3.gaia_source AS g JOIN gaiadr3.vari_eclipsing_binary AS e USING (source_id) WHERE {cone}"))
