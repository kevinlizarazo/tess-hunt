"""two_star.py (pixel-diag) for several neighbours of 296819076-1: per sector, a fit of fixed-position PRFs for the
target and one neighbour (plus a constant) to the difference image and to the same null images, for each neighbour
in turn. Usage: two_star_multi.py OUT.json"""
import json, pickle, sys, warnings
import numpy as np
sys.path.insert(0, "/tmp/t13/296819076-1")
from sector_detail import null_images, prf_model
warnings.filterwarnings("ignore")
STAR = "$TESS_HUNT_DATA/tdi/20261015T155441Z-triage-7b12e25-3f57/296819076-1/tic296819076"
OTHERS = [296819054, 1132493523, 1132493581, 1132493525, 296819078]
def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)
def solve(img, basis):
    a = np.column_stack([b.ravel() for b in basis] + [np.ones(basis[0].size)])
    coef, *_ = np.linalg.lstsq(a, img.ravel(), rcond=None)
    return coef
out = []
for s in [102, 101, 99, 65, 12]:
    with open(f"{STAR}/imageData_296819076.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    prf = prf_model(images, cat, pix)
    ids = np.asarray(cat["ticID"]).astype(int)
    nulls = [img["diffImage"] for ph, _, img in null_images(pix, planet)
             if ph != 0.0 and img and not np.isnan(np.sum(img["diffImage"]))]
    p_t = unit_prf(prf, cat, cat["ticColPix"][0], cat["ticRowPix"][0])
    ft_alone = solve(images["meanOutTransit"], [p_t])[0]
    a_alone = solve(images["diffImage"], [p_t])[0]
    sd_alone = np.std([solve(n, [p_t])[0] for n in nulls], ddof=1)
    rec = {"sector": s, "n_nulls": len(nulls), "target_alone": {"amp": float(a_alone), "snr": float(a_alone / sd_alone),
           "depth": float(a_alone / ft_alone)}, "pairs": []}
    for other in OTHERS:
        if other not in ids:
            rec["pairs"].append({"other": other, "error": "not on cutout"}); continue
        j = int(np.where(ids == other)[0][0])
        p_o = unit_prf(prf, cat, cat["ticColPix"][j], cat["ticRowPix"][j])
        ft, fo, _ = solve(images["meanOutTransit"], [p_t, p_o])
        real = solve(images["diffImage"], [p_t, p_o])
        nn = np.array([solve(n, [p_t, p_o])[:2] for n in nulls])
        sd_t, sd_o = np.std(nn, axis=0, ddof=1)
        rec["pairs"].append({"other": other, "tmag": float(np.ma.filled(cat["ticMag"][j], np.nan)),
            "sep": float(np.ma.filled(cat["separation"][j], np.nan)),
            "flux_t": float(ft), "flux_o": float(fo), "amp_t": float(real[0]), "amp_o": float(real[1]),
            "snr_t": float(real[0] / sd_t), "snr_o": float(real[1] / sd_o),
            "depth_t": float(real[0] / ft), "depth_o": float(real[1] / fo) if fo > 0 else None})
    out.append(rec)
    print(f"S{s}: target alone SNR {rec['target_alone']['snr']:.2f} depth {rec['target_alone']['depth']*1e6:.0f} ppm (nulls {len(nulls)})")
    for p in rec["pairs"]:
        if "error" in p: print("   ", p); continue
        do = "nan" if p["depth_o"] is None else f"{p['depth_o']:.4f}"
        print(f"   + TIC {p['other']} T{p['tmag']:.2f} {p['sep']:.1f}\": target SNR {p['snr_t']:5.2f} depth {p['depth_t']*1e6:6.0f} ppm | other SNR {p['snr_o']:5.2f} depth {do} (flux t/o {p['flux_t']:.0f}/{p['flux_o']:.0f})")
json.dump(out, open(sys.argv[1], "w"), indent=1)
