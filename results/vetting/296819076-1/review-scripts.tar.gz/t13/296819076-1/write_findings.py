import json

D = "~/.cache/tess-hunt/drafts/m3-r2/296819076-1"
S = "/tmp/t13/296819076-1"

f1_claim = (
    "The transit's loss in the difference images sits 20 to 24\" west of the target, on TIC 296819054 (T 14.9) "
    "or one of two fainter stars beside it, not on TIC 296819076; triage's pixel pass rests on S102 alone, and "
    "S102's fit points west too."
)
f1_ev = (
    f"(1) Triage's record ({D}/checks.json, pixels.evidence.sectors): S102 13.0\" quality 0.534 (the one judged, "
    "timing-suspect), S101 20.1\" q 0.452, S65 24.5\" q 0.458, S12 24.6\" q 0.032, S99 87.9\" q 0.031. S65 and S101 "
    "fail the 15\" rule at nearly S102's quality. S100 has an image but no offset: its PRF fit raises "
    "ValueError('x must be strictly increasing') in the rebuild as well. "
    "(2) Directions, rebuilt from triage's saved pickles with the published diagnosis's own script (sha256 "
    "a52fdb505e9d5f49196c6e4cc03836cfd4b425c2495e918b2d4bb553ade49ce6, byte-identical to sector_detail.py in "
    "results/benchmarks/pixel-check-diagnosis-2026-10-20-scripts.tar.gz): "
    f"`/tmp/t13/heavy.sh uv run python {S}/sector_detail.py {S}/detail.json {S}/jobs.json`; every refit reproduces "
    "its saved image (phase-0 check true). Fit east/north of the target in arcsec: S102 (-11.6, +6.0) PA 297; S101 "
    "(-19.5, +4.6) PA 283; S65 (-23.7, +6.0) PA 284; S12 (-24.4, +3.1) PA 277; that is 9.1, 2.4, 3.0 and 4.8\" from "
    "TIC 296819054 at (-20.7, +6.7). The four come from four camera/CCD pairs (S12 cam2 ccd1, S65 cam2 ccd3, S101 "
    "cam3 ccd1, S102 cam2 ccd4) with detector offsets of opposite sign (dcol -1.11 px in S12, +1.16 px in S65), so "
    "the position is fixed on the sky, not on the detector. None of the 64 null-image fits (16 transit-free phases "
    "per sector) lands as close to TIC 296819054 as the real fit in its sector, and their directions scatter all "
    "round. S99's fit (q 0.03) sits 87\" north on an image whose target fit is -0.93 sigma: no transit there. "
    "(3) Fixed-position PRF fits, two_star.py's method "
    f"(`/tmp/t13/heavy.sh uv run python {S}/two_star_multi.py {S}/two_star_multi.json`), SNR against the same "
    "nulls: target + TIC 296819054 gives the neighbour 2.94 (S102), 6.30 (S101), 2.94 (S65), 3.53 (S12), combined "
    "7.9, and the target 1.25, 0.73, 0.23, -1.13, combined 0.5, where a dip on the target would have given it 4.3 "
    "(a 3.7 sigma shortfall). TIC 1132493523 (T 17.13, 20.3\") or TIC 1132493525 (T 17.62, 23.0\") in its place give "
    "the same (combined 7.9 and 8.3, target 0.0 and 0.8): the fits can't tell the three apart. Three PRFs at once "
    f"(`/tmp/t13/heavy.sh uv run python {S}/three_star.py {S}/three_star.json`) keep the loss on TIC 296819054 "
    "against TIC 296819078 (8\" west) and TIC 1132493581 (19\" south-west): 6.65 and 3.41 in S65, 3.58 and 4.68 in "
    "S101, 1.08 and 3.18 in S102, with the other stars between -0.70 and 1.03; S12 is ambiguous. A single PRF at "
    "the target shows 3.6, 3.4 and 2.6 sigma in S102, S101 and S65: the western loss leaking into the target's "
    "21\" PRF. "
    "(4) Depth: the S65, S101 and S102 amplitudes put a 3.3 to 4.5% eclipse on TIC 296819054 (its flux scaled from "
    "T 14.89 against the target's 10.31, since the two-PRF fit to the crowded mean image gives it a negative flux), "
    "against the 2.73% the neighbour table needs at 390 ppm (3.9% at the 562 ppm PDCSAP depth) and TRICERATOPS's "
    f"tdepth of 3.17% ({D}/dossier.md, Gaia DR3 5877911650854908160). It is G 15.64, BP-RP 1.47, parallax 0.50 mas, "
    f"RUWE 1.04 (`uv run python -I {S}/gaia_w.py`), a distant star TRICERATOPS sizes at 2.09 solar radii: a "
    "few-percent eclipse there is an ordinary binary. "
    "(5) The project's own standard: decision 0033 item 5 says a fit that repeats its sky position across sectors "
    "and cameras, with nothing at the target in a fixed-position fit, marks a real off-target source; 0032 says the "
    "pixel check is what catches binaries 20 to 25\" out (TOI-1058.01 at 21.5\", TOI-1175.01 at 25.1\"), and it would "
    "have caught this one from S65 or S101. Caveat: the images hold the transit weakly, the 3x3 box at the target "
    "expecting z 1.15 to 1.31 in S65, S101 and S102 and 3.59 in S12 (detail.json expected_snr), so each sector alone "
    "is 2 to 4 sigma; the case rests on the four agreeing and the nulls not. Confirmation: seeing-limited "
    "ground-based photometry that resolves the target from TIC 296819054 (22\" west) on a predicted transit."
)

f2_claim = (
    "Nine of the ten Gaia DR3 stars without a G magnitude are TIC stars of T 19.73 to 20.85, which would need "
    "eclipses of 230% or more; the tenth, 4.3\" south-east of the target, has no photometry anywhere and looks "
    "spurious, but nothing public rules it out."
)
f2_ev = (
    f"{D}/checks.json neighbours.evidence.no_g lists 10 stars at 4.3, 13.5, 31.2, 35.6, 40.0, 41.2, 44.3, 49.6, 50.4 "
    f"and 51.0\". Gaia DR3 (`uv run python -I {S}/gaia_nog.py`, public archive): all have phot_g_n_obs 0; six have "
    f"RP 19.31 to 19.91. Matched to TRICERATOPS's TIC star list ({D}/triceratops.json evidence.stars), each moved to "
    "J2000 with its DR3 proper motion where it has one: nine sit within 0.14\" of a TIC star with Tmag 19.73 to "
    "20.85 (TIC 1132493625, T 20.31, for the 13.5\" one), all given tdepth 0. A host needs T at most 18.83 for a "
    "total eclipse at 390 ppm (10.3055 + 2.5 log10(1/0.000390)), 18.43 at 562 ppm; T 19.73 needs 2.30 (230%). The "
    "tenth, Gaia DR3 5877911685180852608 at 4.3\" (PA 120): a two-parameter solution, 4 visibility periods, 11 "
    "matched transits, no G, BP or RP, ipd_frac_multi_peak 13; no TIC star within 3.9\" of it (the nearest is the "
    "target); VVV DR2 and DR4 (VizieR II/348/vvv2 and II/376/vvv4; `curl "
    "\"https://vizier.cds.unistra.fr/viz-bin/asu-tsv?-source=II/348/vvv2&-c=224.16166+-60.89201&-c.rs=6&-out.add=_r&-sort=_r\"`) "
    "list nothing within 2.3\" of it, though they list a J 17.59 star at that distance; the target (2MASS J 9.55) "
    "saturates there, so a faint companion could hide. It is 0.2 pixel from the target, inside any pixel rule, and "
    "the pixel fits point the other way (F1). High-resolution imaging would settle it. Removing it would not change "
    "TRICERATOPS's outcome (F3)."
)

f3_claim = (
    "TRICERATOPS's blocker is not what stops it passing: its mean NFPP of 0.0554 sits between the bars and above "
    "both nearby-binary controls', and it puts most of that on a star the pixels don't favour while weighing the "
    "western stars at 0.008."
)
f3_ev = (
    f"{D}/triceratops.json: nfpp_mean 0.05543 (sd 0.00065), fpp_mean 0.0707, 10 runs of 1,000,000; "
    "criteria/vet-v3.toml nfpp_pass 0.001 and nfpp_fail 0.1, so without the no-G blocker it is still inconclusive. "
    "Decision 0032's nearby-binary controls read 0.027 (TOI-1058.01) and 0.0341 (TOI-1175.01). The last run's "
    f"{D}/probs.csv: TIC 1132493581 (T 13.45, 18.7\" south-west) carries 0.0364 (NEBx2P 0.0278, NEB 0.0085), 65% of "
    "that run's 0.0563; TIC 296819054 0.0032, TIC 1132493523 0.0049 and TIC 1132493525 0.00005, 0.0082 together. "
    "TRICERATOPS reads no pixel positions, so F1 is outside what it tests. It ran on the signals file's 390 ppm while "
    "the PDCSAP fold it fits is 562 ppm deep (checks.json sector_depth pdcsap mean_depth 0.000562), a ratio of 1.44 "
    "(0026's limitation on crowded stars), so every neighbour tdepth it gave is that much too shallow. Its ephemeris "
    "is the density-prior fit's (P 2.280317, t0 1601.0154), which folds S11 and S12 well; 0032 warns NFPP can move "
    "with it. RUWE 1.02, no contrast curve, no possible host left unweighed."
)

f4_claim = (
    "An eclipsing binary on the target can't make this event: a grazing eclipse 390 to 560 ppm deep lasts 0.7 to "
    "1.1 h, the event lasts about 3 h, and nothing else points to a binary on the star; the binary case left is "
    "F1's blend."
)
f4_ev = (
    f"`uv run python {S}/grazing.py` (batman, quadratic u1 0.45 u2 0.20, dark companion, a/R* 5.48 from the "
    "density-prior fit): for companion radius ratios 0.1 to 1.0 the eclipse lasts 0.71 to 0.92 h at P 2.2797 d and "
    "0.88 to 1.10 h at twice the period (a/R* 8.70); a luminous companion makes it shallower still. The fits put the "
    f"duration near 3 h ({D}/checks.json window_duration 0.1246 d, density-prior fit; the box was 2.0 h); shape: "
    "grazing in 4% of samples, b 0.54. probs.csv (last run): EB 8.0e-14, EBx2P 1.3e-7, PEB 7.4e-15, PEBx2P 1.1e-6, "
    "DEB 2.0e-15. Odd and even: 521 +- 120 and 602 +- 120 ppm (0.5 sigma, PDCSAP), QLP 0.4 sigma. Phase 0.5: "
    "117 +- 51 ppm (2.3 sigma, under the 3 sigma bar); a planet's occultation is at most 8.7 ppm here "
    "(results/benchmarks/vet-v3-control-diagnosis-2026-10-17.md, the shortlist table), but with S99 to S102 in it "
    f"falls to 34 +- 29 ppm ({D}/checks-with-suspect.json), so it does not grow with four times the data. ModShift: "
    "95 ppm at phase 0.443, 2.76 sigma, Fred 0.975. The search's other signal on the star, 33.308 d at ratio 14.61, "
    "is no harmonic. Density agrees at 0.4 sigma. If on the target, Rp 2.99 Earth radii at 2.28 d and about 1200 "
    "times Earth's insolation (L = 1.3137^2 x (5450/5772)^4 = 1.37 solar; a = 5.48 x 1.3137 solar radii = "
    "0.0335 AU) puts it in the hot-Neptune desert (Mazeh et al. 2016), where planets are rare, so the "
    "false-positive prior is higher than for a typical sub-Neptune."
)

f5_claim = (
    "With S99 to S102 kept in (evidence only), the QLP depths disagree, mostly because S100 shows no dip, and "
    "holdout misses the 2026 season; neither counts, and the holdout miss is the refit period's imprecision, not a "
    "missing transit."
)
f5_ev = (
    f"{D}/checks-with-suspect.json sector_depth qlp: S65 549 +- 177, S99 317 +- 107, S100 -52 +- 105, S101 579 +- "
    "99, S102 514 +- 90 ppm; chi2 24.5 on 4 dof, p 6.2e-5. Holdout season 2 (BTJD 4046.6 to 4150.6), trained on "
    "seasons 0 and 1: predicted period 2.279710 and t0 1601.0220 against the search's 2.279660 and 1601.0147; depth "
    "13 +- 45 ppm against 470 expected (SNR 10.5), status missed. Over about 1095 cycles to BTJD 4098 that moves the "
    "window by 0.0073 + 0.0000493 x 1095 = 0.061 d (1.5 h), past the core's +-0.5 h: the kind of miss decision 0031 "
    "warns about. At the search ephemeris S101 and S102 show the dip at 5.8 and 5.7 sigma, and their pixel images "
    "hold loss (F1). S100's no-dip is 4 sigma off S101 and S102; QLP's timing errors (single transits up to 35 min, "
    "0022) shave a 2 h transit's core but would not erase every transit in a sector. A blend 1 pixel from the "
    "target whose share of each sector's QLP aperture changes would also do it; QLP publishes no aperture and S100 "
    "has no usable difference image, so neither can be checked. vet-v3's own run (S11, S12, S65): sector depths "
    "agree (p 0.40), signal_present 7.3 sigma against a 7.0 bar, holdout untestable."
)

f6_claim = (
    "Nothing public names a planet, a binary or a variable on the target or the western stars, and no single "
    "transit or flagged cadence drives the S11 to S12 signal."
)
f6_ev = (
    f"{D}/literature.json: 0 hits from ADS, arXiv and OpenAlex for TIC 296819076, Gaia DR3 5877911685214643072, "
    "TYC 9020-187-1 and 2MASS J14563840-6053286; ExoFOP no TOI, CTOI or planet; novelty 0 rows within 2.5' among "
    f"951,362. Gaia DR3 (`uv run python -I {S}/gaia_vari.py`): within 90\" four sources are flagged VARIABLE, none "
    "of them the target or the western stars (phot_variable_flag NOT_AVAILABLE and non_single_star 0 for the target "
    "and TIC 296819054, 1132493523, 1132493525 in gaia_w.py): 5877910929300382208 (G 14.93, 37.7\", LPV) and "
    "5877911753900458752 (G 19.53, 60.0\", eclipsing, P 2.8353 d, 1.244 times this period, no harmonic, needing an "
    "81.6% eclipse by the neighbour table), two more beyond 75\". VSX within 3' (VizieR B/vsx/vsx): "
    "GDS_J1456408-605401 at 37.9\" (VAR) and the same Gaia binary. TESS EB catalogue (J/ApJS/258/16/tess-ebs, 3') "
    "and WDS (B/wds/wds, 2'): none. The name searches covered the target only; VSX and the TESS EB catalogue hold "
    "nothing for TIC 296819054 either, so no catalogue settles F1. Per transit "
    f"(`/tmp/t13/heavy.sh uv run python {S}/per_transit.py`, S11 and S12 PDCSAP, 1-day "
    "running median, quality 0): 15 transits with core cadences give 47 to 1105 ppm at +-320 to 452 ppm each, mean "
    "569 ppm; reaction-wheel desaturation flags fall within 1.5 durations of epochs 7 and 16 only."
)

out = {
    "signal": "296819076-1",
    "summary": (
        "I ran the three lenses and rebuilt triage's pixel check from its saved difference images, with null images "
        "and fixed-position fits. In S12, S65, S101 and S102 the in-transit loss sits 13 to 25\" west of the target, "
        "at TIC 296819054 (T 14.9) and two fainter stars beside it, and the target carries almost none of it; "
        "triage's pass rests on S102 alone, whose fit points west too, so I rate the dip off-target (kill). Nothing "
        "else argues against a planet: nine of the ten no-G Gaia stars are too faint to host it (one at 4.3\" has "
        "no photometry and can't be ruled out), an eclipsing binary on the target can't last 3 h at this depth, and "
        "the literature search found nothing."
    ),
    "findings": [
        {"id": "F1", "lens": "on_star", "rating": "kill", "claim": f1_claim, "evidence": f1_ev},
        {"id": "F2", "lens": "on_star", "rating": "note", "claim": f2_claim, "evidence": f2_ev},
        {"id": "F3", "lens": "on_star", "rating": "note", "claim": f3_claim, "evidence": f3_ev},
        {"id": "F4", "lens": "planet", "rating": "note", "claim": f4_claim, "evidence": f4_ev},
        {"id": "F5", "lens": "real_new", "rating": "note", "claim": f5_claim, "evidence": f5_ev},
        {"id": "F6", "lens": "real_new", "rating": "note", "claim": f6_claim, "evidence": f6_ev},
    ],
    "hits_flagged": [],
}
text = json.dumps(out, indent=2, ensure_ascii=False)
assert "—" not in text and "–" not in text
open(f"{S}/findings.json", "w").write(text + "\n")
print("ok", len(text))
