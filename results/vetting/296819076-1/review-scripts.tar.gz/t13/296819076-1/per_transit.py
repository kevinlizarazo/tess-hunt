"""Per-transit core depths of 296819076-1 in the TESS-SPOC S11 and S12 PDCSAP light curves, with quality flags
near each transit. Detrending: a 1-day running median with the transits (1.5 durations either side) left out."""
import numpy as np
from astropy.io import fits
P, T0, DUR = 2.279660292222581, 1601.014734127526, 0.0833333333333333
for s in (11, 12):
    f = f"$TESS_HUNT_DATA/lc_fits/hlsp_tess-spoc_tess_phot_0000000296819076-s00{s}_tess_v1_lc.fits"
    d = fits.getdata(f, 1)
    t, fl, q = d["TIME"], d["PDCSAP_FLUX"], d["QUALITY"]
    ok = np.isfinite(t) & np.isfinite(fl)
    phase = ((t - T0 + 0.5 * P) % P) - 0.5 * P
    oot = ok & (np.abs(phase) > 1.5 * DUR) & (q == 0)
    trend = np.array([np.nanmedian(fl[oot & (np.abs(t - ti) < 0.5)]) if ok[i] else np.nan for i, ti in enumerate(t)])
    rel = fl / trend - 1
    good = ok & (q == 0)
    sd = np.nanstd(rel[oot]) 
    print(f"S{s}: out-of-transit scatter {sd*1e6:.0f} ppm per {np.nanmedian(np.diff(t))*1440:.0f}-min cadence; flagged cadences {np.sum(q != 0)}")
    n0, n1 = int(np.ceil((np.nanmin(t) - T0) / P)), int(np.floor((np.nanmax(t) - T0) / P))
    for n in range(n0, n1 + 1):
        tc = T0 + n * P
        core = good & (np.abs(t - tc) < 0.25 * DUR)
        win = ok & (np.abs(t - tc) < DUR)
        flags = sorted(set(int(x) for x in q[(np.abs(t - tc) < 1.5 * DUR) & (q != 0)]))
        if core.sum() == 0:
            print(f"   epoch {n}: no core cadence; flags within 1.5 dur {flags}")
            continue
        dep = -np.mean(rel[core]); err = sd / np.sqrt(core.sum())
        print(f"   epoch {n}: core depth {dep*1e6:6.0f} +- {err*1e6:4.0f} ppm (n {core.sum()}), in-window {win.sum()}, flags within 1.5 dur {flags}")
