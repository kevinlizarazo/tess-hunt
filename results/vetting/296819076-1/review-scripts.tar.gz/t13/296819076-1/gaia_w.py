"""Gaia DR3 flags for the target and its western neighbours (public archive, sync TAP)."""
import urllib.parse, urllib.request, urllib.error
ids = "5877911685214643072,5877911650854908160,5877911650821133824,5877911650821138560,5877911650854902272"
q = f"""SELECT source_id, phot_g_mean_mag, bp_rp, parallax, parallax_error, ruwe, non_single_star, phot_variable_flag, ipd_frac_multi_peak, logg_gspphot, teff_gspphot FROM gaiadr3.gaia_source WHERE source_id IN ({ids})"""
data = urllib.parse.urlencode({"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv", "QUERY": q}).encode()
try:
    print(urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync", data, timeout=180).read().decode())
except urllib.error.HTTPError as e:
    print(e.read().decode()[:1500])
