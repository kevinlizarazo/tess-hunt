import json, numpy as np
t = json.load(open("/tmp/t13/296819076-1/two_star_multi.json"))
for depth in (390e-6, 562e-6):
    et, ot, eo, oo = [], [], [], []
    for r in t:
        if r["sector"] == 99: continue
        p = [q for q in r["pairs"] if q.get("other") == 296819054][0]
        sd_t = p["amp_t"] / p["snr_t"]; sd_o = p["amp_o"] / p["snr_o"]
        # a dip on the target scales the target light: the same two-PRF fit to depth x mean image
        exp_t = depth * p["flux_t"] / sd_t; exp_o = depth * p["flux_o"] / sd_o
        ta = r["target_alone"]; sd_a = ta["amp"] / ta["snr"]; exp_a = depth * (ta["amp"] / ta["depth"]) / sd_a
        print(r["sector"], "depth", depth, "pair: target obs %.2f exp %.2f | nbr obs %.2f exp %.2f | alone obs %.2f exp %.2f" % (p["snr_t"], exp_t, p["snr_o"], exp_o, ta["snr"], exp_a))
        et.append(exp_t); ot.append(p["snr_t"]); eo.append(exp_o); oo.append(p["snr_o"])
    et, ot = np.array(et), np.array(ot)
    print("combined target obs %.2f exp %.2f" % (ot.sum()/np.sqrt(len(ot)), np.sqrt((et**2).sum())))
