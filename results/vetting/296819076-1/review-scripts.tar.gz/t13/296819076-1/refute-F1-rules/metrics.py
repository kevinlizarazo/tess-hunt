import json, numpy as np
d = json.load(open("/tmp/t13/296819076-1/detail.json"))[0]
PIX = 21.0
secs = [s for s in d["per_sector"] if "error" not in s]
def summ(sel):
    ss = [s for s in secs if s["sector"] in sel]
    w = np.array([s["fit"]["quality"] for s in ss]); e = np.array([s["fit"]["east"] for s in ss]); n = np.array([s["fit"]["north"] for s in ss])
    me, mn = np.average(e, weights=w), np.average(n, weights=w)
    sky = np.sqrt(np.mean((e-me)**2 + (n-mn)**2))
    dc = np.array([s["fit"]["dcol"] for s in ss])*PIX; dr = np.array([s["fit"]["drow"] for s in ss])*PIX
    det = np.sqrt(np.mean((dc-dc.mean())**2 + (dr-dr.mean())**2))
    off = np.hypot(me, mn)
    print(sel, "mean E %.1f N %.1f off %.1f sky %.1f det %.1f mean/stderr %.1f" % (me, mn, off, sky, det, off/(sky/np.sqrt(len(ss)))))
summ([102,101,99,65,12]); summ([102,101,65,12]); summ([102,101,65])
t = json.load(open("/tmp/t13/296819076-1/two_star_multi.json"))
for r in t:
    p = [q for q in r["pairs"] if q.get("other")==296819054][0]
    print(r["sector"], "alone", round(r["target_alone"]["snr"],2), "pair t", round(p["snr_t"],2), "o", round(p["snr_o"],2), "flux_t", round(p["flux_t"]), "flux_o", round(p["flux_o"]))
