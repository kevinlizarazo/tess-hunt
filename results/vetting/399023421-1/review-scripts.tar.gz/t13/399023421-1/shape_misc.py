"""Trapezoid shape per family, robustness drops, the rank-2 signal, and RAVEN in S64. Read-only.
Usage: shape_misc.py CHECKS.json LC.npz"""
import json, sys, tomllib
import numpy as np
from scipy.optimize import least_squares
from tess_hunt.checks.photometry import box_depth
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, in_transit, phase_days
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1])); lc = LightCurve.load(sys.argv[2])
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
flat = detrend(lc, crit["detrend"], [])
ok = np.isfinite(flat.flux) & np.isfinite(flat.flux_err)
t, f, e, sec = flat.time[ok], flat.flux[ok], flat.flux_err[ok], flat.sector[ok]
pdc = np.isin(sec, [11, 37, 38, 64]); qlp = np.isin(sec, [99, 100, 101, 102])
e0 = checks["ephemeris"]; box = Ephemeris(e0["period"], e0["t0"], e0["duration"])
fp = checks["fit"]; fit = Ephemeris(fp["period"]["median"], fp["t0"]["median"], 0.1403)

def trap(x, dep, t14, fin, dt):
    # x in days from mid; fin = ingress fraction of t14
    a = np.abs(x - dt); tin = fin * t14
    y = np.zeros_like(x)
    full = a <= t14 / 2 - tin
    ramp = (a > t14 / 2 - tin) & (a < t14 / 2)
    y[full] = dep
    y[ramp] = dep * (t14 / 2 - a[ramp]) / tin
    return 1 - y

def fit_trap(mask, eph, label):
    x = phase_days(t[mask], eph); y = f[mask]; s = e[mask]
    w = np.abs(x) < 0.4
    x, y, s = x[w], y[w], s[w]
    best = None
    for fin0 in (0.05, 0.15, 0.3, 0.45):
        r = least_squares(lambda p: (trap(x, *p) - y) / s, [4e-4, 0.14, fin0, 0.0],
                          bounds=([0, 0.04, 0.01, -0.05], [3e-3, 0.3, 0.5, 0.05]))
        if best is None or r.cost < best.cost: best = r
    J = best.jac; cov = np.linalg.pinv(J.T @ J) * (2 * best.cost / max(len(x) - 4, 1))
    err = np.sqrt(np.diag(cov))
    p = best.x
    print(f"{label}: depth {p[0]*1e6:.0f}+-{err[0]*1e6:.0f} ppm, T14 {p[1]*24:.2f}+-{err[1]*24:.2f} h, ingress fraction {p[2]:.3f}+-{err[2]:.3f}, shift {p[3]*24*60:+.1f}+-{err[3]*24*60:.1f} min, chi2/dof {2*best.cost/(len(x)-4):.3f}")
    # profile: chi2 at fixed ingress fractions
    prof = []
    for fin in (0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.4):
        r = least_squares(lambda q: (trap(x, q[0], q[1], fin, q[2]) - y) / s, [p[0], p[1], p[3]],
                          bounds=([0, 0.04, -0.05], [3e-3, 0.3, 0.05]))
        prof.append((fin, round(2 * r.cost - 2 * best.cost, 2)))
    print("   delta chi2 at fixed ingress fraction:", prof)

fit_trap(pdc, fit, "PDCSAP (S11, S37, S38, S64), flat-fit ephemeris")
fit_trap(pdc, box, "PDCSAP, box ephemeris")
fit_trap(qlp, box, "QLP (S99-S102, timing-suspect), box ephemeris")
fit_trap(pdc | qlp, box, "all eight sectors, box ephemeris (triage's light curve family mix)")

def comb(mask, eph, label):
    d, s, n = box_depth(t[mask], f[mask], e[mask], eph, 0.5)
    print(f"{label}: {d*1e6:.1f} +- {s*1e6:.1f} ppm (n {n}, {d/s:.2f} sigma)")
ep = np.round((t - box.t0) / box.period).astype(int)
comb(pdc, box, "PDCSAP all (check: 388.2)")
comb(pdc & (ep != 0), box, "without epoch 0 (S11 planet-search-exclude span)")
comb(pdc & (ep != 187), box, "without epoch 187 (background 1.32x)")
comb(pdc & ~np.isin(ep, [0, 182, 187, 192]), box, "without epochs 0, 182, 187, 192")
comb(pdc & (sec == 64), box, "S64 only")

o = checks["other_signals"][0]
r2 = Ephemeris(o["period"], o["t0"], o["duration"])
mask_ours = in_transit(t, box, 1.5) | in_transit(t, fit, 1.5)
print("\nrank-2 signal", r2)
for fam, m in (("pdcsap", pdc), ("qlp", qlp)):
    comb(m & ~mask_ours, r2, f"rank 2 at its ephemeris, {fam}, ours masked")
er = np.round((t - r2.t0) / r2.period).astype(int)
for n in np.unique(er[in_transit(t, r2, 0.5)]):
    m = (er == n)
    d, s, k = box_depth(t[m], f[m], e[m], r2, 0.5)
    print(f"   rank-2 epoch {n:3d} S{int(sec[m][0])} t {r2.t0 + n*r2.period:9.3f} depth {d*1e6:6.0f} +- {s*1e6:4.0f} (n {k})")

rv = [r for r in checks["catalogued"]["rows"] if r["source"] == "RAVEN"][0]
raven = Ephemeris(rv["period"], rv["t0"], rv["duration"])
comb(pdc & (sec == 64) & ~mask_ours, raven, "\nRAVEN ephemeris in S64 only (outside RAVEN's sectors 1-55), ours masked")
comb(pdc & np.isin(sec, [11, 37, 38]) & ~mask_ours, raven, "RAVEN ephemeris in S11/S37/S38 (RAVEN's own data), ours masked")
