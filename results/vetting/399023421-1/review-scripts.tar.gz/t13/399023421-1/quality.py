"""Quality flags, gaps and background around each transit in the four PDCSAP files fetch read. Read-only."""
import glob
import numpy as np
from astropy.io import fits

P, T0, DUR = 3.9268536916387626, 1600.8815043352288, 0.14029006054330334  # flat fit; window_duration
BITS = {1: "attitude tweak", 2: "safe mode", 4: "coarse point", 8: "earth point", 16: "argabrightening",
        32: "desat (momentum dump)", 128: "manual exclude", 1024: "impulsive outlier", 2048: "stray light",
        4096: "scattered light", 8192: "planet search exclude", 16384: "bad calibration", 32768: "insufficient targets"}
for path in sorted(glob.glob("/tmp/t13/399023421-1/fits/*.fits")):
    with fits.open(path) as h:
        d = h[1].data
        sec = h[0].header["SECTOR"]
        t = d["TIME"]; q = d["QUALITY"]; pdc = d["PDCSAP_FLUX"]; bkg = d["SAP_BKG"]
    good = np.isfinite(t) & np.isfinite(pdc) & (q == 0)
    tg = t[good]
    gaps = np.where(np.diff(tg) > 0.5)[0]
    edges = [tg[0]] + [x for i in gaps for x in (tg[i], tg[i + 1])] + [tg[-1]]
    print(f"== S{sec}: good data {tg[0]:.3f} to {tg[-1]:.3f}; gaps > 0.5 d: {[(round(tg[i],3), round(tg[i+1],3)) for i in gaps]}")
    allflags = np.unique(q[q > 0])
    tot = {}
    for b in BITS:
        n = int(np.sum((q & b) > 0))
        if n: tot[BITS[b]] = n
    print("   flagged cadences in sector by kind:", tot)
    n0 = int(np.ceil((tg[0] - T0) / P)); n1 = int(np.floor((tg[-1] - T0) / P))
    bmed = np.nanmedian(bkg[good])
    for n in range(n0, n1 + 1):
        tc = T0 + n * P
        win = np.abs(t - tc) < 1.5 * DUR
        intr = np.abs(t - tc) < 0.5 * DUR
        ng = int(np.sum(good & intr))
        flags = {}
        for b in BITS:
            k = int(np.sum(win & ((q & b) > 0)))
            if k: flags[BITS[b]] = k
        dedge = min(abs(tc - e) for e in edges)
        bk = np.nanmedian(bkg[good & intr]) / bmed if ng else float("nan")
        desat_t = t[win & ((q & 32) > 0)]
        print(f"   epoch {n:4d} t {tc:9.3f} good in-transit {ng:3d} | nearest gap/edge {dedge:5.2f} d | bkg in-transit/median {bk:5.2f} | flags within 1.5 dur: {flags} {('desat at ' + str(np.round((desat_t - tc) * 24, 2)) + ' h') if len(desat_t) else ''}")
