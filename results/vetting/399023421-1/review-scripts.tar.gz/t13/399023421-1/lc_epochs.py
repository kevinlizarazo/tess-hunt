"""Per-epoch core depths of 399023421-1 in the light curve vet-v3 saw, and the RAVEN 9.82 d row's epochs.

Read-only. Usage: lc_epochs.py CHECKS.json LC.npz [--suspect]
"""
import json
import sys
import tomllib

import numpy as np

from tess_hunt.checks.photometry import box_depth
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, in_transit, phase_days
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1]))
lc = LightCurve.load(sys.argv[2])
suspect = "--suspect" in sys.argv
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
drop = [] if suspect else checks["dropped_suspect"]
seen = lc.select(~np.isin(lc.sector, drop))
flat = detrend(seen, crit["detrend"], [Ephemeris(**m) for m in checks["masked"]])
t, f, e, sec = flat.time, flat.flux, flat.flux_err, flat.sector
ok = np.isfinite(f) & np.isfinite(e)
t, f, e, sec = t[ok], f[ok], e[ok], sec[ok]
pdc = np.isin(sec, [11, 37, 38, 64])

e0 = checks["ephemeris"]
box = Ephemeris(e0["period"], e0["t0"], e0["duration"])
fp = checks["fit"]
fit = Ephemeris(fp["period"]["median"], fp["t0"]["median"], checks["window_duration"]["days"])
rv = [r for r in checks["catalogued"]["rows"] if r["source"] == "RAVEN"][0]
raven = Ephemeris(rv["period"], rv["t0"], rv["duration"])
print("box", box, "\nfit", fit, "\nraven", raven)

def combined(mask, eph, label):
    d, s, n = box_depth(t[mask], f[mask], e[mask], eph, 0.5)
    print(f"{label}: depth {d*1e6:7.1f} +- {s*1e6:5.1f} ppm, n {n}, snr {d/s:5.2f}")
    return d, s, n

print("\n== combined, PDCSAP family (vet-v3's light curve)")
combined(pdc, box, "all transits, box ephemeris")
combined(pdc, fit, "all transits, flat-fit ephemeris")

ep = np.round((t - box.t0) / box.period).astype(int)
overlap = np.isin(ep, [182, 187, 192])
combined(pdc & ~overlap, box, "without epochs 182, 187, 192")
combined(pdc & overlap, box, "epochs 182, 187, 192 only")
for s in (11, 37, 38, 64):
    combined(pdc & (sec == s), box, f"S{s}")
    combined(pdc & (sec == s) & ~overlap, box, f"S{s} without 182/187/192")

print("\n== per epoch (box ephemeris, core = central half of 0.125 d)")
rows = []
for n in np.unique(ep[pdc & in_transit(t, box, 0.5)]):
    m = pdc & (ep == n)
    d, s, k = box_depth(t[m], f[m], e[m], box, 0.5)
    tc = box.t0 + n * box.period
    # where the RAVEN transit nearest this one sits, in our phase
    kr = np.round((tc - raven.t0) / raven.period)
    dt = (raven.t0 + kr * raven.period) - tc
    rows.append((int(n), int(sec[m][0]), d, s, k, dt))
    print(f"epoch {n:4d} S{int(sec[m][0]):<3d} t {tc:9.3f} depth {d*1e6:7.0f} +- {s*1e6:4.0f} (n {k:3d}, z {d/s:5.2f}) nearest RAVEN mid {dt*24:+7.2f} h")
ds = np.array([r[2] for r in rows]); ss = np.array([r[3] for r in rows])
w = 1 / ss**2
mean = np.sum(w * ds) / np.sum(w)
chi2 = np.sum(((ds - mean) / ss) ** 2)
from scipy.stats import chi2 as c2
print(f"per-epoch chi2 about the mean {mean*1e6:.0f} ppm: {chi2:.1f} on {len(ds)-1} dof, p = {c2.sf(chi2, len(ds)-1):.3g}")
for n, s_, d, s, k, dt in rows:
    if n in (182, 187, 192):
        print(f"  epoch {n}: {(d-mean)/s:+.2f} sigma from the mean")

print("\n== RAVEN row's epochs (its own ephemeris, its duration 0.164 d; core = central half)")
our = in_transit(t, fit, 1.0) | in_transit(t, box, 1.0)
er = np.round((t - raven.t0) / raven.period).astype(int)
fam = pdc if not suspect else np.ones(len(t), bool)
alone = []
for n in np.unique(er[fam & in_transit(t, raven, 0.5)]):
    m = fam & (er == n)
    tc = raven.t0 + n * raven.period
    ph = ((tc - box.t0) / box.period) % 1
    hit_ours = abs(phase_days(np.array([tc]), box)[0]) < 0.5 * (box.duration + raven.duration)
    d, s, k = box_depth(t[m], f[m], e[m], raven, 0.5)
    m2 = m & ~our
    d2, s2, k2 = box_depth(t[m2], f[m2], e[m2], raven, 0.5)
    print(f"RAVEN epoch {n:4d} S{int(sec[m][0]):<3d} t {tc:9.3f} our phase {ph:5.3f} overlaps ours {hit_ours!s:5s} depth {d*1e6:6.0f} +- {s*1e6:4.0f} (n {k:3d}) | ours masked: {d2*1e6:6.0f} +- {s2*1e6:4.0f} (n {k2})")
    if not hit_ours:
        alone.append(n)
m = fam & np.isin(er, alone) & ~our
combined(m, raven, "RAVEN epochs that miss ours, our transits masked")
m = fam & ~our
combined(m, raven, "every RAVEN epoch, our transits masked")

print("\n== our phase 0.5 and 0.435 (box ephemeris, our duration)")
for ph in (0.5, 0.435):
    sh = Ephemeris(box.period, box.t0 + ph * box.period, box.duration)
    combined(pdc, sh, f"phase {ph}")
    sh2 = Ephemeris(box.period, box.t0 + ph * box.period, box.duration)
    for s in (11, 37, 38, 64):
        combined(pdc & (sec == s), sh2, f"  phase {ph} S{s}")
