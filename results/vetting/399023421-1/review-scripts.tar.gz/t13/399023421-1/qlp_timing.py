"""Where the QLP S99-S102 transits sit against the density-prior fit's ephemeris (the one the windows use). Read-only."""
import json, sys, tomllib
import numpy as np
from scipy.optimize import least_squares
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, phase_days
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1])); lc = LightCurve.load(sys.argv[2])
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
flat = detrend(lc, crit["detrend"], [])
ok = np.isfinite(flat.flux) & np.isfinite(flat.flux_err)
t, f, e, sec = flat.time[ok], flat.flux[ok], flat.flux_err[ok], flat.sector[ok]
pe = checks["fit_prior"]["ephemeris"]
P, T0 = pe["period"]["median"], pe["t0"]["median"]
sdP, sdT = pe["period"]["sd"], pe["t0"]["sd"]
eph = Ephemeris(P, T0, checks["window_duration"]["days"])
fp = checks["fit_prior"]
# fixed shape from the prior fit: box of the window duration, depth free, shift free (a box is enough for a mid-time)
def model(x, dep, dt, dur):
    return 1 - dep * (np.abs(x - dt) < dur / 2)
for label, secs in (("S11", [11]), ("S37-38", [37, 38]), ("S64", [64]), ("QLP S99-S102", [99, 100, 101, 102]),
                    ("S99", [99]), ("S100", [100]), ("S101", [101]), ("S102", [102])):
    m = np.isin(sec, secs)
    x = phase_days(t[m], eph); y = f[m]; s = e[m]; w = np.abs(x) < 0.35
    x, y, s = x[w], y[w], s[w]
    best = None
    for dt0 in np.linspace(-0.08, 0.08, 33):
        r = least_squares(lambda p: (model(x, p[0], p[1], eph.duration) - y) / s, [4e-4, dt0], bounds=([0, -0.12], [3e-3, 0.12]))
        if best is None or r.cost < best.cost: best = r
    # chi2 scan for the shift error
    grid = np.linspace(-0.12, 0.12, 241); chi = []
    for g in grid:
        r = least_squares(lambda p: (model(x, p[0], g, eph.duration) - y) / s, [best.x[0]], bounds=([0], [3e-3]))
        chi.append(2 * r.cost)
    chi = np.array(chi); inside = grid[chi <= chi.min() + 1]
    n_mid = np.round(np.median((t[m] - T0) / P))
    pred_sd = np.sqrt(sdT**2 + (n_mid * sdP) ** 2) * 1440
    print(f"{label:13s} epochs ~{n_mid:.0f}: shift {best.x[1]*1440:+6.1f} min (1-sigma range {inside.min()*1440:+.0f} to {inside.max()*1440:+.0f}), depth {best.x[0]*1e6:.0f} ppm; prediction sd at that epoch {pred_sd:.0f} min")
