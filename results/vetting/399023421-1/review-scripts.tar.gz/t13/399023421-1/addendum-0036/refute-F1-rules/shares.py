import csv, collections, sys
rows=list(csv.DictReader(open(sys.argv[1])))
tot=collections.Counter(); byid=collections.defaultdict(float)
for r in rows:
    p=float(r['prob']); tot[r['scenario']]+=p
    if r['scenario'] in ('NTP','NEB','NEBx2P'): byid[r['ID']]+=p
print('by scenario', {k:round(v,5) for k,v in tot.items()})
print('NFPP last run', round(sum(byid.values()),5))
for k,v in sorted(byid.items(), key=lambda kv:-kv[1]):
    if v>1e-5: print(k, round(v,5))
