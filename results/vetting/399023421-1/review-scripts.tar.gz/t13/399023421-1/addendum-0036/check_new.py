"""Task 13 addendum (0036): the numbers the 399023421-1 review cites, from old and new TRICERATOPS files."""
import json, sys
import pandas as pd
from pathlib import Path

for label, d in (("old", Path("/tmp/t13/399023421-1/pre-0036")),
                 ("new", Path.home() / ".cache/tess-hunt/drafts/m3-r2/399023421-1")):
    rec = json.loads((d / "triceratops.json").read_text())
    ev = rec["evidence"]
    print(f"===== {label}: {d}")
    print("outcome", rec["outcome"], "| reason", rec["reason"])
    for k in ("fpp_mean", "fpp_sd", "nfpp_mean", "nfpp_sd", "blockers", "missing_hosts", "contrast", "dropped_stars"):
        print(k, ev.get(k, "<absent>"))
    print("runs fpp", ev.get("fpp"), "\nruns nfpp", ev.get("nfpp"))
    stars = pd.DataFrame(ev["stars"])
    print("stars", len(stars), "cols", list(stars.columns))
    for tic in ("399023421", "399023424", "993417194", "993417193", "993417201", "399023414", "399023429", "399023447", "399023443", "399023427"):
        s = stars[stars["ID"].astype(str) == tic]
        print("star", tic, s.to_dict("records"))
    hosts = pd.DataFrame(ev["hosts"])
    for tic in ("993417193", "993417201", "399023424", "399023414", "399023429", "399023447", "399023443", "399023399"):
        h = hosts[hosts["tic"].astype(str) == tic]
        print("host", tic, h.to_dict("records"))
    p = pd.read_csv(d / "probs.csv")
    print("probs cols", list(p.columns), "rows", len(p))
    near = p[p["scenario"].isin(["NTP", "NEB", "NEBx2P"])]
    print("NTP+NEB+NEBx2P", near["prob"].sum())
    print("by ID (near):", near.groupby("ID")["prob"].sum().sort_values(ascending=False).head(12).to_dict())
    print("by scenario:", p.groupby("scenario")["prob"].sum().to_dict())
    for tic in (399023424, 993417194, 993417193, 993417201):
        print("NEB rows", tic, p[(p["ID"] == tic) & (p["scenario"].isin(["NEB", "NEBx2P", "NTP"]))].to_dict("records"))
    print("ID 993417194 rows:", (p["ID"] == 993417194).sum())
    six = [399023424, 993417194, 993417193, 993417201, 399023414, 399023447]
    print("near without 3 close + dup:", near[~near["ID"].isin(six[:4])]["prob"].sum(),
          "without six:", near[~near["ID"].isin(six)]["prob"].sum())
