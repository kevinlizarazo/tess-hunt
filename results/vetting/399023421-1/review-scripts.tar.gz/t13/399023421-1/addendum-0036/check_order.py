"""Task 13 addendum (0036): which stars' probs.csv draws changed, by star-list position; dispositions in the new list."""
import json
from collections import Counter
from pathlib import Path
import pandas as pd

old_d, new_d = Path("/tmp/t13/399023421-1/pre-0036"), Path.home() / ".cache/tess-hunt/drafts/m3-r2/399023421-1"
so = [s["ID"] for s in json.loads((old_d / "triceratops.json").read_text())["evidence"]["stars"]]
sn = json.loads((new_d / "triceratops.json").read_text())["evidence"]["stars"]
print("dup index in old list:", so.index("993417194"), "399023424 at", so.index("399023424"))
print("dispositions in new list:", Counter(s.get("disposition") for s in sn))
po, pn = pd.read_csv(old_d / "probs.csv"), pd.read_csv(new_d / "probs.csv")
cols = ["M_s", "R_s", "P_orb", "inc", "b", "ecc", "w", "R_p", "M_EB", "R_EB"]
m = po.merge(pn, on=["ID", "scenario"], suffixes=("_o", "_n"))
m["same_draw"] = (m[[c + "_o" for c in cols]].values == m[[c + "_n" for c in cols]].values).all(axis=1)
m["pos"] = m["ID"].astype(str).map(lambda i: so.index(i) if i in so else -1)
near = m[m["scenario"].isin(["NTP", "NEB", "NEBx2P"])]
print(near.groupby("ID").agg(pos=("pos", "first"), same=("same_draw", "all")).sort_values("pos").to_string())
print("non-N scenarios same draw:", m[~m["scenario"].str.startswith("N")][["ID", "scenario", "same_draw"]].to_string())
