"""Task 13 addendum (0036): bring the 399023421-1 review up to date with the TRICERATOPS rerun."""
import copy
import json
from pathlib import Path

review = json.loads(Path("/tmp/t13/out/399023421-1/review.json").read_text())
NEW_RUN = "20261021T194348Z-vetting-triceratops-cd4e7a2-7821"
TAG = "Updated 2026-10-22 for the 0036 TRICERATOPS rerun: "


def swap(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


f = {x["id"]: x for x in copy.deepcopy(review["findings"])}
out = []

# F1: NFPP, FPP and per-star shares changed.
x = f["F1"]
claim = swap(x["claim"], "NFPP of 0.0191", "NFPP of 0.0161")
ev = swap(x["evidence"], "nfpp_mean 0.0191 (sd 0.00039), fpp_mean 0.0617", "nfpp_mean 0.0161 (sd 0.00029), fpp_mean 0.0589")
ev = swap(ev, "NTP+NEB+NEBx2P 0.0186, of it TIC 399023424 0.00336 plus its TIC duplicate 993417194 0.00275 (F3), 399023414 0.00313, 399023447 0.00306,",
          "NTP+NEB+NEBx2P 0.0158, of it TIC 399023424 0.00337, 399023414 0.00295, 399023447 0.00318,")
ev += (" " + TAG + f"triceratops.json and probs.csv are now TRIC3B_RUN's ({NEW_RUN}, sha256 equal; the old files are in "
       "/tmp/t13/399023421-1/pre-0036/), and its dropped_stars lists TIC 993417194, DUPLICATE of 399023424. nfpp_mean "
       "0.0191 -> 0.0161, its sd 0.00039 -> 0.00029, fpp_mean 0.0617 -> 0.0589; last run's NTP+NEB+NEBx2P 0.0186 -> "
       "0.0158; shares 399023424 0.00336 -> 0.00337, 993417194 0.00275 -> none (no rows), 399023414 0.00313 -> 0.00295, "
       "399023447 0.00306 -> 0.00318. The two far stars' shares move by Monte Carlo noise: every star after the dropped "
       "row in the star list gets new draws, while 993417193, 993417201 and 399023424, listed before it, keep theirs "
       "exactly (/tmp/t13/399023421-1/addendum-0036/check_order.py). Unchanged: the outcome, blockers, missing_hosts, "
       "the hosts' TICs and tdepths, 993417193's and 993417201's shares at the precision quoted, and 399023424's NEB "
       "R_EB 0.219 and R_s 0.921.")
out.append(dict(id="F1", lens=x["lens"], rating=x["rating"], claim=claim, evidence=ev, status="updated",
                why="Read the new triceratops.json and probs.csv (sha256 equal to TRIC3B_RUN's), neighbours.csv (equal "
                    "to VET2_RUN's) and criteria/vet-v3.toml: NFPP, FPP and shares changed, hosts and R_EB did not, "
                    "and 0.0161 still sits between 0.001 and 0.1, so the hold stands."))

x = f["F2"]
out.append(dict(id="F2", lens=x["lens"], rating=x["rating"], claim=x["claim"], evidence=x["evidence"], status="unchanged",
                why="Cites checks.json (sha256 equal to VET2_RUN's), triage's pickles and the /tmp/t13 fit files, no "
                    "TRICERATOPS file or number; the far hosts' TICs are the same in the new triceratops.json hosts."))

# F3: the defect 0036 fixed.
x = f["F3"]
claim = ("On the pre-0036 TRICERATOPS run (TRIC2_RUN 20261020T181658Z-vetting-triceratops-61b5944-1bbf), TRICERATOPS "
         "weighed TIC 399023424 twice through its TIC duplicate 993417194, which added about 0.003 to the NFPP; "
         "decision 0036 fixed it, and the rerun no longer weighs the duplicate.")
ev = ('Original claim: "' + x["claim"] + '" Decision 0036 (docs/decisions/0036-triceratops-tic-duplicates.md) names '
      "this finding and drops the TIC's DUPLICATE and ARTIFACT rows before TRICERATOPS uses the star list. On "
      f"TRIC3B_RUN {NEW_RUN} (~/.cache/tess-hunt/drafts/m3-r2/399023421-1/triceratops.json and probs.csv, sha256 "
      "equal to the run's): dropped_stars [{ID 993417194, disposition DUPLICATE, duplicate_id 399023424}]; stars 844 "
      "-> 843, with 399023424 kept (disposition SPLIT, tdepth 0.0405); probs.csv rows with ID 993417194 3 -> 0. Last "
      "run's NTP+NEB+NEBx2P 0.0186 -> 0.0158 (this finding's renormalised estimate was 0.0159); mean NFPP 0.0191 -> "
      "0.0161 (0036 predicted about 0.0163; per-run sd 0.00029); outcome inconclusive before and after "
      "(/tmp/t13/399023421-1/addendum-0036/compare.txt).")
out.append(dict(id="F3", lens=x["lens"], rating="note", claim=claim, evidence=ev, status="resolved",
                why="Read the new triceratops.json (dropped_stars, stars) and probs.csv against the pre-0036 copies, "
                    "and 0036: the duplicate is dropped and carries no scenario, so what F3 reported is fixed."))

x = f["F4"]
out.append(dict(id="F4", lens=x["lens"], rating=x["rating"], claim=x["claim"], evidence=x["evidence"], status="unchanged",
                why="Cites the snapshot, RAVEN's Zenodo files and the light-curve scripts' outputs, no TRICERATOPS file "
                    "or number; none of its inputs was rerun."))

x = f["F5"]
ev = x["evidence"] + (" " + TAG + f"probs.csv is now TRIC3B_RUN's last run ({NEW_RUN}); EB 1.683e-9 -> 1.688e-9, EBx2P "
                      "6.952e-5 -> 6.971e-5, PEB 4.933e-6 -> 4.946e-6, the same at the precision quoted.")
out.append(dict(id="F5", lens=x["lens"], rating=x["rating"], claim=x["claim"], evidence=ev, status="updated",
                why="Summed the new probs.csv by scenario (EB, EBx2P, PEB hold as quoted) and checks.json is VET2_RUN's; "
                    "updated only because the probs.csv it cites is now the new run's."))

x = f["F6"]
ev = x["evidence"] + (" " + TAG + f"probs.csv is now TRIC3B_RUN's last run ({NEW_RUN}); its NEB rows for TIC 399023424 "
                      "(R_EB/R_s 0.219/0.921 -> 0.219/0.921) and 993417193 (0.507/1.062 -> 0.507/1.062) carry the same "
                      "draws, so nothing quoted changed.")
out.append(dict(id="F6", lens=x["lens"], rating=x["rating"], claim=x["claim"], evidence=ev, status="updated",
                why="The new probs.csv NEB rows for 399023424 and 993417193 have identical R_EB and R_s "
                    "(check_new.py); the rest cites checks.json (VET2_RUN's) and triage; updated because probs.csv is "
                    "now the new run's."))

for fid, why in (
    ("F7", "Cites checks.json (sha256 equal to VET2_RUN's) and shape_misc.txt, no TRICERATOPS file or number."),
    ("F8", "Cites the SPOC files, quality.txt, shape_misc.txt, lc_epochs.txt and checks.json (VET2_RUN's), no "
           "TRICERATOPS file or number."),
    ("F9", "Cites checks-with-suspect.json (sha256 equal to VET2_SUSPECT_RUN's), shape_misc.txt and qlp_timing.txt, "
           "no TRICERATOPS file or number."),
):
    x = f[fid]
    out.append(dict(id=fid, lens=x["lens"], rating=x["rating"], claim=x["claim"], evidence=x["evidence"],
                    status="unchanged", why=why))

x = f["F10"]
ev = swap(x["evidence"], "TRICERATOPS's FPP of 0.0617", "TRICERATOPS's FPP of 0.0589")
ev += (" " + TAG + f"mean FPP 0.0617 -> 0.0589 (~/.cache/tess-hunt/drafts/m3-r2/399023421-1/triceratops.json, now "
       f"TRIC3B_RUN {NEW_RUN}); last run's STP 0.0356 -> 0.0357 and SEB 0.00237 -> 0.00238 (probs.csv), the same at "
       "the precision quoted; TIC 399023443's tdepth 0.255 is unchanged; the FPP stays under fpp_pass 0.5.")
out.append(dict(id="F10", lens=x["lens"], rating=x["rating"], claim=x["claim"], evidence=ev, status="updated",
                why="Mean FPP changed in the new triceratops.json; STP and SEB (new probs.csv) and 399023443's tdepth "
                    "(new hosts) hold as quoted; the rest is Gaia, VizieR and checks.json."))

summary = swap(review["summary"],
               "(NFPP 0.0191), which seeing-limited ground-based photometry would decide; TRICERATOPS also counts one of "
               "them twice through a TIC duplicate.",
               "(NFPP 0.0161), which seeing-limited ground-based photometry would decide; TRICERATOPS had counted one of "
               "them twice through a TIC duplicate, which decision 0036 fixed. Updated 2026-10-22 for the 0036 "
               "TRICERATOPS rerun.")
result = dict(signal=review["signal"], summary=summary, findings=out, hits_flagged=review["hits_flagged"])
Path("/tmp/t13/399023421-1/addendum-0036/findings.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
for g in out:
    if g["status"] == "unchanged":
        assert (g["claim"], g["evidence"]) == (f[g["id"]]["claim"], f[g["id"]]["evidence"])
assert "—" not in json.dumps(result, ensure_ascii=False)
print(json.dumps(result, ensure_ascii=False))
