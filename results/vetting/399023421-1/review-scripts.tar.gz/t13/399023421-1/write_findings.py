import json

D = "~/.cache/tess-hunt/drafts/m3-r2/399023421-1"
S = "/tmp/t13/399023421-1"
findings = [
    {
        "id": "F1", "lens": "on_star", "rating": "hold",
        "claim": "Three Gaia stars 5.2\" to 6.8\" from the target could make the dip with 4% to 17% eclipses, TESS pixels can't tell them from the target, and TRICERATOPS's NFPP of 0.0191 sits between its pass and fail bars, so the public data can't say the dip is on the target.",
        "evidence": (
            f"{D}/triceratops.json: outcome inconclusive, nfpp_mean 0.0191 (sd 0.00039), fpp_mean 0.0617, blockers [], missing_hosts []; "
            "criteria/vet-v3.toml nfpp_pass 0.001, nfpp_fail 0.1. "
            f"{D}/probs.csv (last run) summed by ID: NTP+NEB+NEBx2P 0.0186, of it TIC 399023424 0.00336 plus its TIC duplicate 993417194 0.00275 (F3), "
            "399023414 0.00313, 399023447 0.00306, 993417193 0.00131, 993417201 0.00112. "
            f"{D}/neighbours.csv: Gaia DR3 6080509415699611008 at 5.21\" needs 0.168 (TIC 993417193, TRICERATOPS tdepth 0.164), "
            "6080509415706208640 at 6.65\" needs 0.0956 (TIC 993417201, tdepth 0.190), 6080509415699614464 at 6.77\" needs 0.0404 (TIC 399023424, tdepth 0.0405). "
            "Gaia DR3 gaia_source for 6080509415699614464 (astroquery.gaia by source_id, 2026-10-21): ruwe 1.596, ipd_frac_multi_peak 31, "
            "astrometric_excess_noise_sig 19.9, signs of its own unresolved companion. "
            f"Fixed-position fits (target, one neighbour, a constant) to triage's saved difference images: {S}/two_star.py on {S}/jobs_two.json and {S}/pairs.json "
            f"(the method of results/benchmarks/pixel-check-diagnosis-2026-10-20.md), output {S}/two_star.json and two_star.txt. With TIC 399023424 the target's z is "
            "-0.1, 0.3, -1.1, 2.4, 2.0 and the neighbour's 0.6, 1.1, 1.9, -2.0, -2.1 in S64, S99, S100, S101, S102; with 993417193 and 993417201 the two amplitudes "
            "trade sign the same way. At a third of a pixel the fit can't place the loss between them. Shape doesn't separate them either (F6): TRICERATOPS's NEB fit "
            "on TIC 399023424 has R_EB 0.22 on R_s 0.92 (probs.csv), an ingress near a fifth of the transit, which the 9-sigma fold can't exclude. "
            "Nothing in vet-v3 lets cleared neighbours lower the NFPP. What would decide it: seeing-limited ground-based photometry on a predicted transit "
            "(the dossier's windows, sd about 30 min, or a refit with the QLP times, F9) that resolves stars 5\" from the target and shows whether any of the three "
            "dims by 4% to 17%, and whether TIC 399023414, 399023429 and 399023447 (23.7\" to 39.6\", 1.8% to 3.6% by TRICERATOPS's tdepth) dim. "
            "2-min TESS data use the same 21\" pixels and would not decide it."
        ),
    },
    {
        "id": "F2", "lens": "on_star", "rating": "note",
        "claim": "Triage's pixel pass rests on S99, a timing-suspect QLP sector, and S64, the one pixel sector vet-v3 keeps, would read 16.1\" by itself; the refitted images show a weak transit in S64 and fits that scatter around the target with no repeated off-target position, and fixed-position fits put the loss on the target rather than on the possible hosts 23.7\" to 39.6\" out in four of five sectors.",
        "evidence": (
            f"{D}/checks.json pixels: S102 8.75\" q 0.598, S101 7.59\" q 0.480, S100 21.37\" q 0.468, S99 7.93\" q 0.660, S64 16.06\" q 0.497; "
            "the rule judges the best-quality sector, S99. The difference images come from TESScut cutouts (src/tess_hunt/pixels.py:22), not from QLP's light "
            "curves, whose timestamps 0022 flags, and S99's image holds the transit where the ephemeris puts it (below). "
            "Refits of triage's pickles (~/.cache/tess-hunt/tdi/20261015T155441Z-triage-7b12e25-3f57/399023421-1/tic399023421/): "
            f"{S}/sector_detail.py (copied from /tmp/t13/44926986-1, the diagnosis's method) on {S}/jobs.json, output {S}/detail.json, summarised by {S}/summ.py "
            f"into {S}/summ.txt. Every refit reproduces the recorded offset and the saved image. Fit east, north in arcsec: S64 (2.9, 15.8), S99 (-1.0, 7.9), "
            "S100 (-20.8, -5.1), S101 (2.1, -7.3), S102 (7.0, -5.2), on cameras 2, 4, 3, 2 and 1; quality-weighted mean (-1.4, 1.5), 2.0\" from the target, "
            "sky scatter 12.8\", 0.35 standard errors from the target. Target 3x3 box over the sd of 16 null images per sector (box_snr / null sd): "
            "S64 0.33/0.17 = 1.9 against 0.58/0.17 = 3.4 expected from the depth, S99 6.9 (6.0 expected), S100 3.6 (4.6), S101 3.5 (4.7), S102 2.4 (2.2); "
            "in S64 1 of 16 nulls reaches the transit fit's quality. "
            f"Fixed-position fits ({S}/two_star.txt), target z / neighbour z in S64, S99, S100, S101, S102: TIC 399023414 (23.9\") 1.4/-0.5, 4.2/-0.3, 0.1/4.4, "
            "2.4/-0.6, 1.4/-0.7; TIC 399023429 (23.7\") 0.9/2.3, 3.6/1.5, 0.5/1.4, 2.6/-1.5, 1.0/0.6; TIC 399023447 (39.6\") 2.0/1.0, 4.4/1.6, 1.1/1.3, "
            "2.8/-1.7, 1.3/0.2; TIC 399023399 (33.5\") 1.9/-0.3, 4.5/-1.0, 0.7/3.4, 2.8/-0.6, 1.4/0.3. S100 alone favours 399023414 (its free fit lands 5.7\" "
            "from that star); a source there would show in every sector. 399023429 is the least excluded of the far hosts: positive in 4 of 5 sectors, summed "
            "(Stouffer) 1.9 against the target's 3.9."
        ),
    },
    {
        "id": "F3", "lens": "on_star", "rating": "note",
        "claim": "TRICERATOPS weighs TIC 399023424 twice, because TIC 993417194 is its catalogued duplicate and TRICERATOPS 1.1.0 never drops the TIC's duplicates; here that adds about 0.003 to the NFPP, and it can do so on any star, so it is a defect in the check's input for a decision record.",
        "evidence": (
            f"{D}/triceratops.json stars: TIC 399023424 and TIC 993417194 share ra 198.313645637733, dec -51.9460735503653, Tmag 15.6838 and tdepth 0.0405. "
            "MAST TIC (astroquery Catalogs.query_criteria(catalog='TIC', ID=[399023424, 993417194]), 2026-10-21): 993417194 disposition DUPLICATE, "
            "duplicate_id 399023424; 399023424 disposition SPLIT; both GAIA (DR2) 6080509415699614464. "
            ".venv/lib/python3.12/site-packages/triceratops/triceratops.py:135 selects 'disposition' and 'duplicate_id'; grep -n 'disposition\\|duplicate' "
            "over the package finds no other line, so neither is used. "
            f"{D}/probs.csv, last run: rows with ID 993417194 sum to 0.00275 of an NFPP of 0.0186; without them, renormalised, 0.0159. The outcome stays "
            "inconclusive. The bias runs toward inconclusive or fail, never a false pass, but a real planet near the 0.1 fail bar could be failed by a duplicate's "
            "share. Design 4.8: a finding that shows a check is wrong goes to a decision record."
        ),
    },
    {
        "id": "F4", "lens": "real_new", "rating": "note",
        "claim": "The RAVEN row on this star (9.825 d, 395 ppm) is most likely this signal at a 5:2 alias, not a second body: the three transits it shares with ours carry no extra depth and neither carry nor make our signal, its other epochs show about half its depth, and RAVEN publishes no row at our period, so our period is not catalogued but the star's dip is, and a CTOI should cite RAVEN.",
        "evidence": (
            "Snapshot row ($SNAP3/known.parquet; raw RAVEN/nsfp09_table.csv line 12790): candidate 5, bls_per 9.824768, bls_t0 2345.0358, bls_tdur 3.93 h, "
            "bls_depth 394.7 ppm, bls_sde 10.65, bls_mes 1.23, prob_NSFP_mean 0.9975. 9.824768 / 3.926854 (flat fit) = 2.502, and RAVEN's t0 sits at our phase "
            "0.506, so in S37 and S38 its epochs alternate between our transits (182, 187, 192) and our phase 0.5. The paper (Lafarga et al. 2026, MNRAS, "
            "arXiv:2603.22597, Zenodo 19661443) searches TESS-SPOC FFIs of S1 to S55, keeps the five highest BLS peaks per star as candidates 1 to 5, and skips "
            f"only peaks at twice or half a stronger one's period, so a 2.5x alias can survive as peak 5. The star is in neither vet_table.csv nor val_table.csv "
            f"(downloaded to {S}/zenodo/; that nsfp09_table.csv has the snapshot's sha256 7b4fb0b02a85...), and nsfp09 holds no other row for it. "
            f"{S}/lc_epochs.py (output lc_epochs.txt), on vet-v3's light curve (PDCSAP S11, S37, S38, S64, the checks' detrending, box ephemeris, core half): "
            "all 388.2 +- 42.9 ppm (9.06 sigma, equal to checks.json signal_present); without epochs 182, 187, 192 390.1 +- 46.1 (8.47 sigma); those three "
            "alone 375.9 +- 116.7; per-epoch depths about their mean chi2 15.0 on 22 dof (p 0.86), epoch 182 -0.87, 187 +1.47, 192 -0.86 sigma; S64, which no "
            "RAVEN epoch meets, 420.6 +- 73.9. RAVEN's own ephemeris with our transits masked: 179.9 +- 72.6 ppm over its other epochs (S11 241, 133; S37 170; "
            f"S38 253; S64 215, 181, -298 ppm); against 116 shifts of its t0 ({S}/lc_null.py, lc_null.txt) z 3.06, but RAVEN's ephemeris was chosen on S11, "
            f"S37 and S38, and S64 alone, outside RAVEN's data, gives 148.3 +- 114.0 (1.3 sigma; {S}/shape_misc.txt), 2.2 sigma short of 395 ppm. A BLS of "
            "the residual light curve (our transits masked, lc_null.txt) finds nothing near 9.82 d (SDE 1.74; top peak SDE 4.78 at 13.63 d). Novelty's "
            "harmonics (1, 0.5, 2, 1/3, 3) leave out 2.5, so neither novelty nor the 'passed' bar's ExoFOP period match can see such a row."
        ),
    },
    {
        "id": "F5", "lens": "planet", "rating": "note",
        "claim": "Nothing points to an eclipsing binary on the target: the depth and U shape rule out a stellar eclipse there, odd and even transits agree, phase 0.5 holds no significant dip, and LEO-Vetter's ModShift secondary at phase 0.435 is not in vet-v3's light curve.",
        "evidence": (
            f"{D}/checks.json: odd_even 0.66 sigma (even 358 +- 63, odd 415 +- 59 ppm); secondary 57 +- 32 ppm, 1.81 sigma; shape grazing probability 0.0016, "
            f"rp_rs 0.0182, b 0.53; density tension 0.26 sigma, so no eccentricity is needed. {S}/lc_null.txt: our phase 0.5 74.1 +- 44.8 ppm against nulls at "
            "other phases mean -8.5, sd 47.4, z 1.74. The diagnosis's occultation bound for this signal is 3.8 ppm (albedo 0.5) or 6.6 ppm (albedo 1.0) "
            "(results/benchmarks/vet-v3-control-diagnosis-2026-10-17.md line 167), so a real 57 ppm dip would not be the planet's occultation, but it is not "
            "significant. ModShift ($TRIAGE_RUN/evidence/399023421-1.json): sig_sec 3.25 at phase 0.435, 82 ppm, sig_ter 1.84, sig_pos 2.24, Fred 1.09, "
            f"LEO-Vetter fp_failed [], on triage's eight-sector light curve. {S}/lc_epochs.txt, PDCSAP at phase 0.435: 45.1 +- 43.6 ppm (1.0 sigma); S11 199 "
            f"+- 112, S37 -140 +- 97, S38 90 +- 80, S64 46 +- 74. {D}/probs.csv: EB 1.7e-9, EBx2P 7.0e-5, PEB 4.9e-6. The binary scenarios left are blends (F1)."
        ),
    },
    {
        "id": "F6", "lens": "planet", "rating": "note",
        "claim": "The transit's shape is weakly pinned: LEO-Vetter's fit on triage's light curve reads b 0.93, and trapezoids on the PDCSAP fold give ingress fractions from 0.09 to 0.35 depending on the ephemeris, so shape alone can't exclude a diluted eclipsing binary with a radius ratio near 0.2, which keeps F1 open.",
        "evidence": (
            "$TRIAGE_RUN/evidence/399023421-1.json leo_flux metrics: transit_b 0.928 +- 0.044, transit_aRs 4.22 +- 1.15 (aRs 7.30 from the star), trap_qin 0.15, "
            f"on 39 transits of which 21 are timing-suspect QLP. {D}/checks.json fit (flat prior, PDCSAP only): b 0.53 (-0.35, +0.29), grazing probability 0.0016, "
            f"log rho -0.20 against the TIC's -0.32. {S}/shape_misc.py (output shape_misc.txt), least-squares trapezoids: PDCSAP at the flat-fit ephemeris "
            "ingress fraction 0.353 +- 0.077 (chi2 16.4 worse at 0.02), at the box ephemeris 0.092 +- 0.061 (chi2 0.4 better at 0.02, 2.5 worse at 0.3); QLP "
            "0.180 +- 0.077; all eight sectors 0.322 +- 0.059. A trapezoid's ramp also takes up limb darkening, so these don't overturn the physical fit; they "
            f"show the ingress is not measured well at 9 sigma. TRICERATOPS's NEB fits ({D}/probs.csv) imply ingress fractions of about 0.19 (TIC 399023424, "
            "R_EB/R_s 0.219/0.921) to 0.33 (993417193, 0.507/1.062)."
        ),
    },
    {
        "id": "F7", "lens": "planet", "rating": "note",
        "claim": "The search's second signal on the star (26.07 d, 508 ppm, 8 h) comes from two 8-hour dips in QLP S99 and S101 alone, is absent from the PDCSAP data at that period, and is no eclipsing-binary partner of this signal.",
        "evidence": (
            f"{D}/checks.json other_signals: rank 2, P 26.07397, t0 1616.524, depth 508 ppm, duration 0.333 d, SDE 13.5, ratio 6.64. {S}/shape_misc.txt with "
            "our transits masked: PDCSAP 28.5 +- 114.2 ppm (0.25 sigma), QLP 843.4 +- 93.6 (9.0 sigma); epochs S11 162 +- 138, S64 24 +- 119, S99 868 +- 130 "
            "(BTJD 4067.48), S101 817 +- 135 (BTJD 4119.63). S64's 24 +- 119 rules out an 850 ppm dip every 26.07 d. Ratio 6.64 is no harmonic, and the depth "
            "and duration (8 h against our 3.4 h) differ from ours, so it is not the other eclipse of a binary at our period. Whether the two QLP dips are "
            "systematics in the timing-suspect sectors or single events on some star was not tested. It decides nothing for 399023421-1."
        ),
    },
    {
        "id": "F8", "lens": "real_new", "rating": "note",
        "claim": "No artefact makes the signal: no momentum dump falls near a transit, dropping the two transits on raised background moves the depth by at most 15 ppm, no sector dominates, and the per-transit depths agree.",
        "evidence": (
            f"{S}/quality.py on the four TESS-SPOC files from MAST ({S}/fits/, sha256 equal to checks.json sources), output quality.txt: no desat (bit 32) flag "
            "within 1.5 durations of any transit with data; nearest gap or edge to any such transit 0.68 d. Epoch 0 (BTJD 1600.88): every S11 cadence before "
            "1601.37 carries QUALITY 8192, SPOC's planet-search-exclude bit, while SAP_BKG falls from 3063 to 2183 e/s; fetch keeps that bit "
            "(src/tess_hunt/fetch.py:51, lightkurve's default bitmask), 158 such cadences in the slim S11. Epoch 187: in-transit background 1.32 times the S38 "
            f"median, 1.33 d after its first good cadence. {S}/shape_misc.txt: all 388.2 +- 42.9 ppm; without epoch 0 386.2 +- 43.7; without 187 373.7 +- "
            "43.9; without 0, 182, 187 and 192 387.9 +- 47.1 (8.2 sigma). Inverse-variance weights from sector_depth's errors (100, 97, 80, 74 ppm): S11 18%, "
            f"S37 19%, S38 29%, S64 34%. Per-epoch chi2 15.0 on 22 dof ({S}/lc_epochs.txt). Holdout: seasons 1 and 2 predicted at 5.25 and 5.69 sigma, "
            f"tensions 0.35 and 0.91, season 0 underpowered ({D}/checks.json)."
        ),
    },
    {
        "id": "F9", "lens": "real_new", "rating": "note",
        "claim": "The timing-suspect QLP sectors S99 to S102 show the transit at a consistent, diluted depth, but about 30 to 50 minutes later than the density-prior ephemeris predicts there, so the S112 to S114 windows may run early by about one of their standard deviations.",
        "evidence": (
            f"{D}/checks-with-suspect.json: signal_present 11.5 sigma; qlp sector depths 307 +- 95, 345 +- 107, 297 +- 82, 400 +- 95 ppm (p 0.85); qlp odd and "
            "even 1.1 sigma; QLP weighted mean 333 +- 47 against PDCSAP 388 +- 43, ratio 0.86, as expected from CROWDSAP 0.89 to 0.92 and QLP depths that keep "
            f"the crowding (0023). Timing: {S}/shape_misc.txt, a trapezoid on the QLP fold at the box ephemeris, shift -28.6 +- 4.7 min; the box ephemeris "
            "(P 3.926959, t0 1600.8528) runs 62 min after the density-prior one (P 3.9268447, t0 1600.8824) at epoch 636, so the QLP transits sit about 34 min "
            f"after the windows' ephemeris. {S}/qlp_timing.py (a box model on the prior ephemeris, rough errors), output qlp_timing.txt: QLP combined +50 min, "
            "per sector +29, +65, +7, +43; S11 +22, S37-38 +7, S64 -14; the prediction's sd at epoch 636 is 39 min. 0022 puts reliable QLP minus SPOC median "
            "offsets under 10 min (single transits up to +35 min), so most of the shift is likely the ephemeris. The dossier's S112 windows have sd 30 min and "
            "3-sigma half-widths of 91 min; a follow-up plan should refit with these times or widen the window late."
        ),
    },
    {
        "id": "F10", "lens": "on_star", "rating": "note",
        "claim": "The target shows no visual double or bound companion in the public data, none of the stars within 7\" moves with it, and the only catalogued variable among the possible hosts is a rotational variable 43\" out.",
        "evidence": (
            "Gaia DR3 gaia_source (astroquery.gaia, 2026-10-21) for 6080509411401414016: ruwe 0.949, ipd_frac_multi_peak 0, ipd_gof_harmonic_amplitude 0.005, "
            "non_single_star 0, duplicated_source false, parallax 3.596 +- 0.016 mas, pm (1.19, -28.01) mas/yr, astrometric_excess_noise 0.077 mas "
            "(significance 8.1, common at G 10.8; RUWE is the indicator vet-v3 uses). The stars at 5.2\", 6.6\" and 6.8\": pm (-5.99, -1.11), (-27.11, -5.93), "
            "(-5.65, 0.96) mas/yr, parallaxes 0.21, 1.13, 0.44 mas: background stars, none bound. Vizier B/wds/wds within 60\": none; literature.json's SIMBAD "
            "names hold no WDS name. Vizier B/vsx/vsx within 60\": Gaia DR3 6080509518785429248 at 42.8\", type ROT, G 17.31 to 17.37, Gaia DR3 classifier "
            "SOLAR_LIKE (I/358/vclassre); it is the possible host at 43.2\" needing 9.63% (TIC 399023443, TRICERATOPS tdepth 0.255). $SNAP3/known.parquet "
            "within 5': only the RAVEN row. CROWDSAP 0.902, 0.890, 0.923, 0.909 (checks.json sources), TIC contratio 0.085. Gaia can miss companions inside "
            "about 1\"; TRICERATOPS's FPP of 0.0617 (STP 0.036, SEB 0.0024) carries that without a contrast curve and passes its own bar."
        ),
    },
]
out = {
    "signal": "399023421-1",
    "summary": (
        "Full brief. I re-measured the transits epoch by epoch, tested the RAVEN row's epochs, refitted triage's difference images with free and "
        "fixed-position PRF fits, read TRICERATOPS's scenarios and star list, and checked Gaia DR3, the TIC, WDS, VSX and the quality flags. Nothing kills it: "
        "the dip is consistent across 23 PDCSAP transits and the four QLP sectors, the RAVEN row on the star looks like this signal at a 5:2 alias, and the "
        "pixels favour the target over the possible hosts 23\" and farther. It holds on blending: three Gaia stars 5.2\" to 6.8\" out that TESS pixels can't "
        "separate (NFPP 0.0191), which seeing-limited ground-based photometry would decide; TRICERATOPS also counts one of them twice through a TIC duplicate."
    ),
    "findings": findings,
    "hits_flagged": [],
}
s = json.dumps(out, indent=1, ensure_ascii=False)
assert "—" not in s and "–" not in s
with open("/tmp/t13/399023421-1/findings.json", "w") as fh:
    fh.write(s + "\n")
print(len(findings), "findings written")
