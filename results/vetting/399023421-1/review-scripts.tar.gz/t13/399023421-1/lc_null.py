"""Null calibration for the RAVEN-epoch depth, and a BLS of the residual light curve (our transits masked).

Read-only. Usage: lc_null.py CHECKS.json LC.npz [--suspect]
"""
import json
import sys
import tomllib

import numpy as np
from astropy.timeseries import BoxLeastSquares

from tess_hunt.checks.photometry import box_depth
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, in_transit
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1]))
lc = LightCurve.load(sys.argv[2])
suspect = "--suspect" in sys.argv
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
drop = [] if suspect else checks["dropped_suspect"]
seen = lc.select(~np.isin(lc.sector, drop))
flat = detrend(seen, crit["detrend"], [])
ok = np.isfinite(flat.flux) & np.isfinite(flat.flux_err)
t, f, e, sec = flat.time[ok], flat.flux[ok], flat.flux_err[ok], flat.sector[ok]

e0 = checks["ephemeris"]
box = Ephemeris(e0["period"], e0["t0"], e0["duration"])
fp = checks["fit"]
fit = Ephemeris(fp["period"]["median"], fp["t0"]["median"], checks["window_duration"]["days"])
rv = [r for r in checks["catalogued"]["rows"] if r["source"] == "RAVEN"][0]
raven = Ephemeris(rv["period"], rv["t0"], rv["duration"])
ours = in_transit(t, box, 1.5) | in_transit(t, fit, 1.5)
keep = ~ours
print(f"cadences {len(t)}, our transits masked (1.5 durations, both ephemerides): {ours.sum()}")
print(f"baseline: 1 - weighted mean flux out of our transits = {(1-np.average(f[keep], weights=1/e[keep]**2))*1e6:.1f} ppm")

# Null: shift RAVEN's t0 across its period in steps of its duration, our transits masked.
real = box_depth(t[keep], f[keep], e[keep], raven, 0.5)
shifts = np.arange(raven.duration, raven.period - raven.duration, raven.duration / 2)
nulls = []
for s in shifts:
    eph = Ephemeris(raven.period, raven.t0 + s, raven.duration)
    d, err, n = box_depth(t[keep], f[keep], e[keep], eph, 0.5)
    if n >= 20:
        nulls.append(d)
nulls = np.array(nulls)
print(f"RAVEN epochs, our transits masked: {real[0]*1e6:.1f} +- {real[1]*1e6:.1f} ppm (n {real[2]})")
print(f"nulls ({len(nulls)} shifts of t0 by half-durations): mean {nulls.mean()*1e6:.1f} ppm, sd {nulls.std(ddof=1)*1e6:.1f} ppm,"
      f" fraction >= real {np.mean(nulls >= real[0]):.3f}; z vs nulls {(real[0]-nulls.mean())/nulls.std(ddof=1):.2f}")

# Same null for our own signal's phase 0.5
nulls2 = []
for s in np.arange(2 * box.duration, box.period - 2 * box.duration, box.duration / 2):
    eph = Ephemeris(box.period, box.t0 + s, box.duration)
    d, err, n = box_depth(t[keep], f[keep], e[keep], eph, 0.5)
    nulls2.append(d)
nulls2 = np.array(nulls2)
p5 = box_depth(t[keep], f[keep], e[keep], Ephemeris(box.period, box.t0 + 0.5 * box.period, box.duration), 0.5)
print(f"our phase 0.5: {p5[0]*1e6:.1f} +- {p5[1]*1e6:.1f}; nulls at other phases mean {nulls2.mean()*1e6:.1f} sd {nulls2.std(ddof=1)*1e6:.1f}; z {(p5[0]-nulls2.mean())/nulls2.std(ddof=1):.2f}")

# BLS on the residual light curve
bls = BoxLeastSquares(t[keep], f[keep], e[keep])
periods = np.exp(np.linspace(np.log(1.0), np.log(40.0), 200000))
durs = [0.08, 0.12, 0.16, 0.25, 0.33]
res = bls.power(periods, durs, objective="snr")
p = res.power
sde = (p - np.mean(p)) / np.std(p)
order = np.argsort(sde)[::-1]
print("\nBLS (objective snr) on the residual, our transits masked: top peaks")
shown = []
for i in order:
    if any(abs(periods[i] - q) / q < 0.01 for q in shown):
        continue
    shown.append(periods[i])
    print(f"  P {periods[i]:9.4f} d  SDE {sde[i]:5.2f}  depth {res.depth[i]*1e6:6.0f} ppm  dur {res.duration[i]:.2f}  t0 {res.transit_time[i]:.3f}")
    if len(shown) >= 8:
        break
near = np.abs(periods - raven.period) / raven.period < 0.002
j = np.where(near)[0][np.argmax(sde[near])]
print(f"best near RAVEN's period: P {periods[j]:.4f} SDE {sde[j]:.2f} depth {res.depth[j]*1e6:.0f} ppm t0 {res.transit_time[j]:.3f}")
st = bls.compute_stats(raven.period, 0.16, raven.t0)
print("at RAVEN's exact ephemeris: depth", st["depth"][0] * 1e6, "+-", st["depth"][1] * 1e6, "ppm; per-transit count", len(st["transit_times"]))
