"""Per-event look at the primary (phase 0) and LEO-Vetter's ModShift secondary (phase 0.487) for 370977908-1,
on the light curve the checks saw (PDCSAP 11, 38, 65, rebuilt as the plots rebuild it) and on all five sectors."""

import json
import sys
from pathlib import Path

import numpy as np

from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

RUN = Path(sys.argv[1])
checks = json.loads((RUN / "signals/370977908-1/checks.json").read_text())
crit = load_criteria("criteria/search-v2.toml")
lc = LightCurve.load(Path.home() / ".cache/tess-hunt/lc/370977908.npz")
e = checks["ephemeris"]
P, t0, dur = e["period"], e["t0"], e["duration"]


def flat_of(drop):
    seen = lc.select(~np.isin(lc.sector, drop))
    return detrend(seen, crit["detrend"], [Ephemeris(**m) for m in checks["masked"]])


def events(flat, phase, half=None):
    half = dur / 2 if half is None else half
    rows = []
    n0 = int(np.floor((flat.time.min() - t0) / P)) - 1
    n1 = int(np.ceil((flat.time.max() - t0) / P)) + 1
    for n in range(n0, n1 + 1):
        tc = t0 + (n + phase) * P
        dt = flat.time - tc
        inn = np.abs(dt) < half
        out = (np.abs(dt) > 1.5 * dur) & (np.abs(dt) < 1.5 * dur + 0.5)
        if inn.sum() < 10 or out.sum() < 10:
            continue
        f = flat.flux
        d = np.median(f[out]) - np.mean(f[inn])
        err = np.std(f[out]) / np.sqrt(inn.sum())
        rows.append((n, round(tc, 3), int(flat.sector[inn][0]), int(inn.sum()), d * 1e6, err * 1e6))
    return rows


def combined(rows):
    d = np.array([r[4] for r in rows])
    w = 1 / np.array([r[5] for r in rows]) ** 2
    m = np.sum(d * w) / np.sum(w)
    return m, 1 / np.sqrt(np.sum(w))


for label, drop in (("pdcsap 11 38 65 (the checks' light curve)", checks["dropped_suspect"]), ("all five sectors", [])):
    flat = flat_of(drop)
    print(f"== {label}: {len(flat.time)} cadences")
    for name, ph in (("primary phase 0", 0.0), ("ModShift secondary phase 0.487", 0.4867030999962607), ("phase 0.5", 0.5)):
        rows = events(flat, ph)
        print(f"-- {name}")
        for r in rows:
            print("   epoch %d  t %.3f  S%d  n %d  depth %.0f +- %.0f ppm" % r)
        m, s = combined(rows)
        print(f"   combined {m:.0f} +- {s:.0f} ppm ({m / s:.1f} sigma, white noise)")
    # How unusual is the secondary's depth among all phases, by the same box (per-event white errors)?
    grid = np.arange(0.02, 0.98, 0.002)
    sig = []
    for ph in grid:
        rows = events(flat, ph)
        if len(rows) < 3:
            sig.append(np.nan)
            continue
        m, s = combined(rows)
        sig.append(m / s)
    sig = np.array(sig)
    order = np.argsort(-np.nan_to_num(sig, nan=-99))
    print("-- strongest box dips away from the primary (phase, sigma):",
          [(round(grid[i], 3), round(sig[i], 1)) for i in order[:8]])
    print("-- strongest box rises (phase, sigma):",
          [(round(grid[i], 3), round(sig[i], 1)) for i in np.argsort(np.nan_to_num(sig, nan=99))[:5]])
    print(f"-- box sigma over phases 0.02-0.98: sd {np.nanstd(sig):.2f}, n {np.isfinite(sig).sum()}")
