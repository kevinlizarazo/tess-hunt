"""Which stars carry TRICERATOPS's NFPP (probs.csv, the last of the ten runs), where each sits, and how far each is
from SPOC DV's multi-sector difference-image centroid (tce_ditco_*, offset from the TIC position, from the snapshot's
s0001-s0039 and s0001-s0065 tcestats files) and from the pixel check's quality-weighted mean fit (E -3.2", N -1.6",
sky scatter 9.3" over 5 sectors, /tmp/pixel-diag/summary_second.txt). Also the TIC star at the no-G Gaia source."""
import csv, json, math
from collections import defaultdict
D = "$TESS_HUNT_DATA/drafts/m3-r2/370977908-1/"
d = json.load(open(D + "triceratops.json"))
ev = d["evidence"]
stars = {s["ID"]: s for s in ev["stars"]}
t = stars["370977908"]
def en(s):
    return (s["ra"] - t["ra"]) * math.cos(math.radians(t["dec"])) * 3600, (s["dec"] - t["dec"]) * 3600
print("NFPP runs:", [round(x, 4) for x in ev["nfpp"]], "mean", round(ev["nfpp_mean"], 4), "sd", round(ev["nfpp_sd"], 4))
share = defaultdict(float)
for r in csv.DictReader(open(D + "probs.csv")):
    if r["scenario"] in ("NTP", "NEB", "NEBx2P"):
        share[r["ID"]] += float(r["prob"])
spoc = {"s1-s65": (0.7870498, 2.52612, 2.225992, 4.955749), "s1-s39": (-1.28984, 2.640273, -9.182559, 7.396021)}
print("TIC | Tmag | sep | E, N | tdepth | NTP+NEB+NEBx2P share | sigma from SPOC s1-s65, s1-s39 | from pixel mean fit")
for k, v in sorted(share.items(), key=lambda x: -x[1]):
    if v < 1e-4:
        continue
    s = stars[k]; e, n = en(s)
    sig = [round(math.hypot((e - a) / ea, (n - b) / eb), 1) for a, ea, b, eb in spoc.values()]
    print(k, s["Tmag"], round(math.hypot(e, n), 1), (round(e, 1), round(n, 1)), round(s["tdepth"], 4), round(v, 4), sig,
          round(math.hypot(e + 3.2, n + 1.6) / (9.3 / math.sqrt(5)), 1))
print("sum", round(sum(share.values()), 4))
g = (226.45635172901473, -51.47146587285448)
best = min(ev["stars"], key=lambda s: math.hypot((s["ra"] - g[0]) * math.cos(math.radians(g[1])), s["dec"] - g[1]))
dist = math.hypot((best["ra"] - g[0]) * math.cos(math.radians(g[1])), best["dec"] - g[1]) * 3600
need = ev["ephemeris"]["depth"] * 10 ** (0.4 * (best["Tmag"] - t["Tmag"]))
print(f"no-G Gaia DR3 5900597942960134272 -> TIC {best['ID']} at {dist:.2f}\", Tmag {best['Tmag']}, tdepth {best['tdepth']}, required depth {need:.2f}")
