"""Fixed-position PRF fits (target, one neighbour, constant) to 370977908-1's difference images at the transit
(phase 0) and at LEO-Vetter's ModShift secondary (phase 0.487), each against null images for the noise. Same
method as the pixel diagnosis's two_star.py, reusing its helpers read-only. Images: SECOND2_RUN's tdi pickles.

Usage: pix2.py STAR_DIR NEIGHBOUR_TIC [NEIGHBOUR_TIC ...]
"""
import pickle
import sys
import warnings

import numpy as np

sys.path.insert(0, "/tmp/pixel-diag")
from sector_detail import box_stats, index_of, null_images, prf_model  # noqa: E402
from transitDiffImage import tessDiffImage  # noqa: E402

warnings.filterwarnings("ignore")
PH2 = 0.4867030999962607
star_dir, others = sys.argv[1], [int(x) for x in sys.argv[2:]]


def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)


def solve(img, basis):
    a = np.column_stack([b.ravel() for b in basis] + [np.ones(basis[0].size)])
    coef, *_ = np.linalg.lstsq(a, img.ravel(), rcond=None)
    return coef


def image_at(pix, planet, phase):
    obj = tessDiffImage.tessDiffImage.__new__(tessDiffImage.tessDiffImage)
    obj.allowedBadCadences = 0
    obj.allowedInTransitLossFraction = 0.8
    p = dict(planet)
    p["epoch"] = planet["epoch"] + phase * planet["period"]
    q = dict(pix)
    q["quality"] = pix["quality"].copy()
    in_idx, _, _, images = obj.find_transits(q, p, allowedBadCadences=0)
    return in_idx, images


for s in (103, 102, 65, 38, 11):
    with open(f"{star_dir}/imageData_370977908.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    ids = np.asarray(cat["ticID"]).astype(int)
    prf = prf_model(images, cat, pix)
    p_t = unit_prf(prf, cat, cat["ticColPix"][0], cat["ticRowPix"][0])
    r0, c0 = index_of(cat, pix, cat["ticColPix"][0], cat["ticRowPix"][0])
    nulls_img = [img for ph, _, img in null_images(pix, planet)
                 if ph != 0.0 and img and not np.isnan(np.sum(img["diffImage"]))]
    in2, sec = image_at(pix, planet, PH2)
    sec_ok = bool(sec) and not np.isnan(np.sum(sec["diffImage"]))
    print(f"== S{s} cam {pix['camera']} ccd {pix['ccd']}: epoch {planet['epoch']:.4f} period {planet['period']:.5f} "
          f"dur {planet['durationHours']:.2f} h; nulls {len(nulls_img)}; secondary-phase image "
          f"{'ok, in-cadences ' + str(len(in2)) if sec_ok else 'none'}")
    nb = np.array([box_stats(img, r0, c0)["diff"] for img in nulls_img])
    for label, img in (("transit", images), ("phase 0.487", sec if sec_ok else None)):
        if img is None:
            continue
        b = box_stats(img, r0, c0)
        print(f"   {label}: 3x3 box at target diff {b['diff']:.1f} e/s, z vs nulls {b['diff'] / np.std(nb, ddof=1):.1f}, "
              f"box depth {b['depth'] * 1e6:.0f} ppm")
    for other in others:
        if other not in ids:
            print(f"   TIC {other} not on the cutout")
            continue
        j = int(np.where(ids == other)[0][0])
        p_o = unit_prf(prf, cat, cat["ticColPix"][j], cat["ticRowPix"][j])
        ft, fo, _ = solve(images["meanOutTransit"], [p_t, p_o])
        nl = np.array([solve(img["diffImage"], [p_t, p_o])[:2] for img in nulls_img])
        sd = np.std(nl, axis=0, ddof=1)
        line = [f"   TIC {other} T{float(np.ma.filled(cat['ticMag'][j], np.nan)):.2f} "
                f"{float(np.ma.filled(cat['separation'][j], np.nan)):.1f}\" (flux t/o {ft:.0f}/{fo:.0f}):"]
        for label, img in (("transit", images), ("phase 0.487", sec if sec_ok else None)):
            if img is None:
                continue
            a = solve(img["diffImage"], [p_t, p_o])
            line.append(f"{label} z target {a[0] / sd[0]:.1f}, z neighbour {a[1] / sd[1]:.1f} "
                        f"(depth t {a[0] / ft * 1e6:.0f} ppm, n {a[1] / fo if fo > 0 else np.nan:.3f})")
        print(" ".join(line[:1]) + "\n      " + "\n      ".join(line[1:]))
