"""Where the phase-0.487 events sit in their sectors, and how often a single 4.5 h box dip that deep turns up
anywhere in the same sector (primary transits left out). Same light curve rebuild as secondary.py."""

import json
import sys
from pathlib import Path

import numpy as np

from tess_hunt.config import load_criteria
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

RUN = Path(sys.argv[1])
checks = json.loads((RUN / "signals/370977908-1/checks.json").read_text())
crit = load_criteria("criteria/search-v2.toml")
lc = LightCurve.load(Path.home() / ".cache/tess-hunt/lc/370977908.npz")
e = checks["ephemeris"]
P, t0, dur = e["period"], e["t0"], e["duration"]
PH2 = checks["modshift"]["phs_sec"]
flat = detrend(lc, crit["detrend"], [Ephemeris(**m) for m in checks["masked"]])
print("detrend cfg", dict(crit["detrend"]))


def box(time, flux, tc):
    dt = time - tc
    inn = np.abs(dt) < dur / 2
    out = (np.abs(dt) > 1.5 * dur) & (np.abs(dt) < 1.5 * dur + 0.5)
    if inn.sum() < 10 or out.sum() < 10:
        return np.nan, np.nan
    return (np.median(flux[out]) - np.mean(flux[inn])) * 1e6, np.std(flux[out]) / np.sqrt(inn.sum()) * 1e6


for s in np.unique(flat.sector):
    m = flat.sector == s
    t, f = flat.time[m], flat.flux[m]
    gaps = np.where(np.diff(t) > 0.1)[0]
    print(f"\n== S{s}: {t.min():.3f} to {t.max():.3f}, gaps >0.1 d:",
          [(round(t[i], 3), round(t[i + 1], 3)) for i in gaps])
    # Primary and secondary events in this sector, with distance to the nearest data edge.
    edges = np.concatenate([[t.min()], t[gaps], t[gaps + 1], [t.max()]])
    for name, ph in (("primary", 0.0), ("secondary", PH2)):
        n0, n1 = int(np.floor((t.min() - t0) / P)) - 1, int(np.ceil((t.max() - t0) / P)) + 1
        for n in range(n0, n1 + 1):
            tc = t0 + (n + ph) * P
            if t.min() - 0.3 < tc < t.max() + 0.3:
                d, err = box(t, f, tc)
                print(f"   {name} epoch {n} at {tc:.3f}: box {d:.0f} +- {err:.0f} ppm; nearest edge {np.min(np.abs(edges - tc)):.2f} d")
    # Sliding single-event boxes, every 0.02 d, away from primary transits.
    grid = np.arange(t.min() + 0.4, t.max() - 0.4, 0.02)
    phase = ((grid - t0) / P) % 1
    away = (phase > 0.03) & (phase < 0.97)
    vals = np.array([box(t, f, g) for g in grid[away]])
    ok = np.isfinite(vals[:, 0])
    d, err = vals[ok, 0], vals[ok, 1]
    for thr in (200, 300, 355):
        # Count independent events: boxes more than one duration apart.
        hits = grid[away][ok][d >= thr]
        indep = 0 if len(hits) == 0 else 1 + int(np.sum(np.diff(hits) > dur))
        print(f"   single 4.5 h boxes >= {thr} ppm away from primaries: {indep} independent events in "
              f"{(t.max() - t.min()):.1f} d (box depth sd {np.std(d):.0f} ppm, median white err {np.median(err):.0f})")
    top = np.argsort(-d)[:6]
    print("   deepest boxes away from primaries (t, ppm, phase):",
          [(round(grid[away][ok][i], 2), round(d[i]), round(phase[away][ok][i], 3)) for i in top])
