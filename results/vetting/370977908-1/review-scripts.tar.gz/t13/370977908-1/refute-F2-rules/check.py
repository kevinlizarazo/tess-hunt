"""Rule checks for F2: blockers, outcome without the blocker, the no-G star's TRICERATOPS match, NFPP by star,
duplicates' originals, controls' largest known-planet NFPP."""
import csv, json, math, os, sys
sys.path.insert(0, "src")
from collections import defaultdict
import tomllib
D = os.path.expanduser("~/.cache/tess-hunt/drafts/m3-r2/370977908-1/")
ev = json.load(open(D + "triceratops.json"))["evidence"]
print("blockers", ev["blockers"]); print("missing_hosts", ev["missing_hosts"], "hosts", len(ev["hosts"]),
      "max match", round(max(h["distance_arcsec"] for h in ev["hosts"]), 2), "ruwe", round(ev["ruwe"], 3),
      "field_population", ev["field_population"], "raised", ev["raised"], "degenerate", set(ev["degenerate"]))
cfg = tomllib.load(open("criteria/vet-v3.toml", "rb"))["triceratops"]
from tess_hunt import tricera
r = tricera.outcome(ev["fpp"], ev["nfpp"], cfg, [], False)
print("outcome without blockers:", r.outcome if hasattr(r, "outcome") else r, getattr(r, "reason", ""))
print("nfpp min", round(min(ev["nfpp"]), 4), "max", round(max(ev["nfpp"]), 4), "mean", round(ev["nfpp_mean"], 4))
st = {s["ID"]: s for s in ev["stars"]}; t = ev["stars"][0]; cd = math.cos(math.radians(t["dec"]))
s = st["1150965440"]; print("no-G match TIC 1150965440", s)
share = defaultdict(float)
for row in csv.DictReader(open(D + "probs.csv")):
    if row["scenario"] in ("NTP", "NEB", "NEBx2P"): share[row["ID"]] += float(row["prob"])
for k, v in sorted(share.items(), key=lambda x: -x[1])[:8]:
    s = st[k]; print(k, round(v, 4), round(math.hypot((s["ra"]-t["ra"])*cd*3600, (s["dec"]-t["dec"])*3600), 1), s["tdepth"])
for d in ev["dropped_stars"]:
    o = st[d["duplicate_id"]]; print("dup of", d["duplicate_id"], "tdepth", o["tdepth"])
c = list(csv.DictReader(open("results/benchmarks/20261020T082333Z-benchmark-controls-16418d2-f45a/controls.csv")))
k = [x for x in c if x["kind"] == "control"]
m = max(k, key=lambda x: float(x["nfpp_mean"])); print("largest known-planet NFPP", m["name"], m["nfpp_mean"])
print("max control possible_hosts", max(int(x["possible_hosts"]) for x in k))
