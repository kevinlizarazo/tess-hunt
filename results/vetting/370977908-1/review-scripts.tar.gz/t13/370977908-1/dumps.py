"""Momentum-dump cadences (quality bit 32) in each sector's FFI pixel time series, and the S11 light-curve cadences
nearest the two S11 transit mid-times."""
import pickle, sys
import numpy as np
d = sys.argv[1]
for s in (11, 38, 65):
    with open(f"{d}/imageData_370977908.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, *_ = pickle.load(fh)
    t, q = np.asarray(pix["time"]), np.asarray(pix["quality"]).astype(int)
    dt = t[(q & 32) != 0]
    print(f"S{s} dumps:", np.round(dt, 3).tolist(), "spacing", np.round(np.diff(dt), 3).tolist())
lc = np.load(sys.argv[2], allow_pickle=True)
print(lc.files)
t = lc["time"]; sec = lc["sector"]
for tc in (1603.0924, 1620.1838):
    m = (sec == 11) & (np.abs(t - tc) < 0.12)
    gaps = np.diff(t[m])
    print(f"S11 2-min cadences within 0.12 d of {tc}: {m.sum()}; largest gap {gaps.max() * 1440:.0f} min at {t[m][np.argmax(gaps)]:.4f}")
