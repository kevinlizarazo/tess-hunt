#!/bin/bash
. ~/.cache/tess-hunt/logs/m3-vars.sh; . ~/.cache/tess-hunt/logs/m3-rerun-vars.sh
cd ~/code/tess-hunt
O=/tmp/t13/370977908-1/refute-F1-reproduce
D=/tmp/t13/370977908-1
/tmp/t13/heavy.sh uv run python $D/secondary.py $VET2_RUN > $O/secondary.out 2>&1; echo "secondary exit $?" >> $O/status
/tmp/t13/heavy.sh uv run python $D/events.py $VET2_RUN > $O/events.out 2>&1; echo "events exit $?" >> $O/status
/tmp/t13/heavy.sh .venv/bin/python $D/pix2.py $SECOND2_RUN/tdi/370977908-1/tic370977908 370977918 370977897 370977937 370977930 > $O/pix2.out 2>&1; echo "pix2 exit $?" >> $O/status
/tmp/t13/heavy.sh .venv/bin/python $D/flags.py $SECOND2_RUN/tdi/370977908-1/tic370977908 > $O/flags.out 2>&1; echo "flags exit $?" >> $O/status
