"""Quality flags in the FFI pixel time series (transit-diffImage pickles) around each primary and phase-0.487 event."""
import pickle
import sys

import numpy as np

star_dir = sys.argv[1]
P, T0, PH2, HALF = 17.09144213349047, 1603.0924114376926, 0.4867030999962607, 0.1875 / 2
for s in (11, 38, 65, 102, 103):
    with open(f"{star_dir}/imageData_370977908.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, *_ = pickle.load(fh)
    t, q = np.asarray(pix["time"]), np.asarray(pix["quality"]).astype(int)
    print(f"== S{s}: {len(t)} cadences {t.min():.3f}-{t.max():.3f}; flagged {np.sum(q != 0)}")
    for name, ph in (("primary", 0.0), ("ph0.487", PH2)):
        for n in range(int((t.min() - T0) / P) - 1, int((t.max() - T0) / P) + 2):
            tc = T0 + (n + ph) * P
            if not (t.min() - 0.5 < tc < t.max() + 0.5):
                continue
            w = np.abs(t - tc) < HALF + 0.25
            inn = np.abs(t - tc) < HALF
            flags = sorted(set(q[w][q[w] != 0].tolist()))
            dumps = t[w & ((q & 32) != 0)]
            print(f"   {name} epoch {n} at {tc:.3f}: in-window cadences {inn.sum()}, flagged in window+-0.25d "
                  f"{np.sum(q[w] != 0)} (flags {flags}); momentum dumps at {np.round(dumps, 3).tolist()}")
