import json, math, csv
from collections import defaultdict
D="$TESS_HUNT_DATA/drafts/m3-r2/370977908-1/"
d=json.load(open(D+"triceratops.json")); ev=d["evidence"]
stars=ev["stars"]
t=stars[0]; print("target row", t)
print("n stars", len(stars))
# no-G star at J2016 and moved to J2000
ra,dec,pmra,pmdec=226.45635172901473,-51.47146587285448,1.1372565413668543,-3.847636904814198
ra00=ra-pmra*16/(3.6e6*math.cos(math.radians(dec))); dec00=dec-pmdec*16/3.6e6
def sep(a,b,c,e):
    return math.hypot((a-c)*math.cos(math.radians(b)),(b-e))*3600
for lab,(r,de) in {"J2016":(ra,dec),"J2000":(ra00,dec00)}.items():
    ss=sorted(stars[1:], key=lambda s: sep(r,de,s["ra"],s["dec"]))[:3]
    for s in ss: print(lab, s["ID"], round(sep(r,de,s["ra"],s["dec"]),3), s["Tmag"], s["tdepth"], s.get("disposition"))
best=sorted(stars[1:], key=lambda s: sep(ra,dec,s["ra"],s["dec"]))[0]
depth=ev["ephemeris"]["depth"]
print("target Tmag", t["Tmag"], "depth", depth)
print("required depth", depth*10**(0.4*(best["Tmag"]-t["Tmag"])))
print("sep from target", sep(t["ra"],t["dec"],best["ra"],best["dec"]))
