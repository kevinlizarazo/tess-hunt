import json, math, csv
from collections import defaultdict
D="$TESS_HUNT_DATA/drafts/m3-r2/370977908-1/"
d=json.load(open(D+"triceratops.json")); ev=d["evidence"]
stars={s["ID"]:s for s in ev["stars"]}; t=ev["stars"][0]
def en(s): return ((s["ra"]-t["ra"])*math.cos(math.radians(t["dec"]))*3600,(s["dec"]-t["dec"])*3600)
# dropped duplicates
for r in ev["dropped_stars"]:
    s=stars.get(r["duplicate_id"]); 
    print("dup", r["ID"], "->", r["duplicate_id"], round(math.hypot(*en(s)),1) if s else None, s["tdepth"] if s else None, r["ID"] in stars)
rows=list(csv.DictReader(open(D+"probs.csv")))
print(rows[0].keys(), len(rows))
print(set(r["scenario"] for r in rows))
tot=defaultdict(float); share=defaultdict(float)
for r in rows:
    tot[r["scenario"]]+=float(r["prob"])
    if r["scenario"] in ("NTP","NEB","NEBx2P"): share[r["ID"]]+=float(r["prob"])
print({k:round(v,4) for k,v in tot.items()})
print("NFPP from probs", sum(share.values()))
print("1150965440 in probs:", [ (r["scenario"],r["prob"]) for r in rows if r["ID"]=="1150965440"])
for k,v in sorted(share.items(), key=lambda x:-x[1])[:12]:
    s=stars[k]; e,n=en(s)
    print(k, s["Tmag"], round(math.hypot(e,n),1), round(e,1), round(n,1), round(s["tdepth"],4), round(v,4))
