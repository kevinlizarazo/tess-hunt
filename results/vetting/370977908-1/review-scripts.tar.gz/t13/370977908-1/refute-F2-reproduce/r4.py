import json, tomllib
from tess_hunt import tricera
D="$TESS_HUNT_DATA/drafts/m3-r2/370977908-1/"
ev=json.load(open(D+"triceratops.json"))["evidence"]
cfg=tomllib.load(open("criteria/vet-v3.toml","rb"))["triceratops"]
for b in (ev["blockers"], []):
    r=tricera.outcome(ev["fpp"], ev["nfpp"], cfg, b, False)
    print(r.outcome, "|", r.reason)
import statistics as st
print(min(ev["nfpp"]), max(ev["nfpp"]), st.mean(ev["nfpp"]), st.stdev(ev["nfpp"]), st.mean(ev["fpp"]))
print("all runs > 0.1:", all(x>0.1 for x in ev["nfpp"]))
