import json, math
D="$TESS_HUNT_DATA/drafts/m3-r2/370977908-1/"
ev=json.load(open(D+"triceratops.json"))["evidence"]
stars={s["ID"]:s for s in ev["stars"]}; t=ev["stars"][0]
ids=["370977937","370977823","370977918","370977898","370977969","370977953","370977928"]
# from tcestats (printed above)
spoc={"s1-s65":(0.78705,2.52612,2.225992,4.955749),"s1-s39":(-1.28984,2.640273,-9.182559,7.396021)}
se=9.3/math.sqrt(5)
for i in ids:
    s=stars[i]; e=(s["ra"]-t["ra"])*math.cos(math.radians(t["dec"]))*3600; n=(s["dec"]-t["dec"])*3600
    out=[i, round(e,1), round(n,1)]
    for k,(a,ea,b,eb) in spoc.items():
        out.append((k, round(math.hypot((e-a)/ea,(n-b)/eb),2)))
    out.append(("pix", round(math.hypot(e+3.2,n+1.6)/se,2)))
    print(out)
