import json

V = ". ~/.cache/tess-hunt/logs/m3-vars.sh; . ~/.cache/tess-hunt/logs/m3-rerun-vars.sh; cd ~/code/tess-hunt; "
findings = [
    {
        "id": "F1",
        "lens": "planet",
        "rating": "hold",
        "claim": "A dip at phase 0.487, about as deep as the transit, sits in every orbit with data at that phase (one PDCSAP event, two QLP S103 events) and at the target's pixels; vet-v3's secondary check only looks at phase 0.5, LEO-Vetter's ModShift leaves it unflagged only on its red-noise test, and if it is real it is an eclipsing binary's second eclipse, not this planet.",
        "evidence": (
            "(1) Triage's LEO-Vetter, $TRIAGE_RUN/evidence/370977908-1.json (leo_flux.evidence.metrics, all five sectors, 9 transits): "
            "sig_sec 5.12 at phs_sec 0.4867, dep_sec 267 +- 52 ppm against the primary's dep 342 +- 29 ppm; Fred 1.623, FA1 5.009, FA2 2.544. "
            "LEO's rule (.venv/lib/python3.12/site-packages/leo_vetter/thresholds.py:173-189) flags a secondary when MS4 = sig_sec/Fred - FA1 > 0 and MS5 or MS6 > -1: "
            "MS4 = 3.15 - 5.01 = -1.85 fails; MS5 = 5.12 - 2.81 - 2.54 = -0.24 and MS6 = 5.12 - 2.60 - 2.54 = -0.03 both pass. Only the red-noise scaling keeps it unflagged. "
            "albedo 260 +- 73, so it can't be the planet's own occultation (0031's first cause). "
            "(2) vet-v3's secondary (src/tess_hunt/checks/photometry.py:127-129) measures phase 0.5 over one duration; phase 0.487 is 0.227 d (5.4 h) earlier, outside its 0.094 d half-window, hence its -0.1 sigma pass. "
            "(3) Per event, on the light curve rebuilt as the plots rebuild it, a 4.5 h box against a local baseline (" + V +
            "/tmp/t13/heavy.sh uv run python /tmp/t13/370977908-1/secondary.py $VET2_RUN): phase 0.487 has data in three orbits: "
            "S65 epoch 86 (BTJD 3081.275, PDCSAP) 360 +- 53 ppm; S103 epoch 149 (4158.036, QLP) 215 +- 56; S103 epoch 150 (4175.127, QLP) 355 +- 64. "
            "S11's, S38's and S102's fall in data gaps. Combined 308 +- 33 ppm (white errors) against the primary's 271 +- 20 over its nine transits; phase 0.5 gives 55 +- 33. "
            "4158.036 - 3081.275 = 1076.761 d = 63.000 periods, so the dips keep the signal's period. A phase scan of all five sectors (every 0.002, 3 or more events) puts the strongest dip away from the transit at 0.488 (8.9 sigma white); "
            "the next, unrelated, at 0.858 (5.4); the scan's sd is 1.86. With each sector's empirical single-box scatter (same setup, /tmp/t13/370977908-1/events.py: S65 96 ppm, S103 131 ppm) the three events combine to 321 +- 67 ppm, 4.8 sigma. "
            "Implied e cos w about (pi/2)(0.4867 - 0.5) = -0.021. "
            "(4) Pixels (" + V + "/tmp/t13/heavy.sh .venv/bin/python /tmp/t13/370977908-1/pix2.py $SECOND2_RUN/tdi/370977908-1/tic370977908 370977918 370977897 370977937 370977930; "
            "output in /tmp/t13/370977908-1/pix2.txt): difference images at phase 0.487, 3x3 box at the target against each sector's null images: S65 z 3.6 (320 ppm), S103 z 3.5 (232 ppm, both events); "
            "the transit's own images give z 2.4 and 6.0 in the same sectors. S11's and S38's phase-0.487 windows sit in gaps (5 and 16 cadences). "
            "No quality flag or momentum dump within 0.25 d of the three events (/tmp/t13/370977908-1/flags.py, same tdi directory). "
            "QLP's S99-S104 timing error (medians under 10 min, single transits up to 35 min; decision 0022) is far below the 5.4 h offset from phase 0.5. "
            "Against: SPOC DV s0001-s0065 ($SNAP3/raw/SPOC-TCE/tess2018206190142-s0001-s0065_dvr-tcestats.csv) gives its weak-secondary maximum at MES 2.57, -3.33 d (phase 0.805), wst_depth 78.9 ppm; "
            "its 2-min data hold only the S65 event at 0.487. S65 also holds a second single dip of the same size away from 0.487 (3078.84, 343 ppm, phase 0.344; events.py). "
            "QLP S102 and S103 are redder than PDCSAP (red-noise beta 1.84 and 1.60 against 1.04 to 1.31; checks-with-suspect.json red_noise). "
            "If real, the eclipses are nearly equal, so a host must reach the required depth at both: TIC 370977897 (8.5\", needs 79%) and TIC 370977892 (13.6\", 84% to 97%) cannot; TIC 370977918 (11.3\", 19%) can (neighbours.csv). "
            "What decides it: ground-based photometry at predicted phase-0.487 times (signal t0 1603.0924, P 17.091442, t0 + (n + 0.4867) P) on the target and the neighbours within 1'. "
            "A QLP redelivery of S102 and S103, or an independent FFI extraction, would test the two S103 events. No TESS sector is scheduled (checks.json upcoming_sectors empty)."
        ),
    },
    {
        "id": "F2",
        "lens": "on_star",
        "rating": "hold",
        "claim": "TRICERATOPS's only blocker is immaterial, so its inconclusive is a would-be fail (mean NFPP 0.126, all ten runs above 0.1); the NFPP is spread over seven stars 11\" to 55\" out, each 4.0 sigma or more from SPOC's difference-image centroid, and the public data can't settle which of the two is right.",
        "evidence": (
            "triceratops.json (TRIC3A_RUN, copied in the draft): inconclusive on one blocker, the neighbour table's no-G star. That star is Gaia DR3 5900597942960134272, 52.4\" out (neighbours.csv: no G, no BP-RP). "
            "TRICERATOPS's own star list holds it as TIC 1150965440, 0.05\" away, Tmag 20.12, tdepth 0; at that magnitude it would need a 775% eclipse "
            "(python3 /tmp/t13/370977908-1/nfpp_hosts.py). It is already in the NFPP, at zero, and can't host. "
            "Without the blocker tricera.outcome gives fail: runs 0.119 to 0.132, mean 0.1261 (sd 0.0040) against nfpp_fail 0.1 (criteria/vet-v3.toml); mean FPP 0.288. "
            "The 10 DUPLICATE rows dropped under 0036 (dropped_stars) copy stars 101\" to 193\" out whose tdepth is 0, so the fix doesn't move the NFPP. "
            "Who carries it (probs.csv, the last run, NTP+NEB+NEBx2P = 0.1256; nfpp_hosts.py): TIC 370977937 (24.7\", T 14.92, 0.037), 370977823 (54.7\", T 12.11, 0.031), "
            "370977918 (11.2\", T 16.05, 0.025), 370977898 (55.2\", 0.019), 370977969 (50.9\", 0.011), 370977953 (34.4\", 0.003), 370977928 (33.0\", 0.0004). No star dominates; the largest share sits in 0032's 20\" to 25\" band. "
            "Against those hosts: SPOC DV's multi-sector difference-image centroid offset from the TIC position, s0001-s0065 tce_ditco_mra +0.79 +- 2.53\", tce_ditco_mdec +2.23 +- 4.96\" "
            "(s0001-s0039: -1.29 +- 2.64, -9.18 +- 7.40; $SNAP3/raw/SPOC-TCE tcestats files), puts each from 4.0 sigma (370977918; 4.5 in s0001-s0039) to 22 sigma from the source; "
            "the pixel check's quality-weighted mean fit (E -3.2\", N -1.6\", /tmp/pixel-diag/summary_second.txt) puts them 3.3 to 13 standard errors away. "
            "For the fail: 0.126 is above every known planet in the controls (largest 0.0081, TOI-451.03) and both 20\" to 25\" binary controls (0.027, 0.034), "
            "results/benchmarks/20261020T082333Z-benchmark-controls-16418d2-f45a/controls.csv. Those small control planets sit on Tmag 5 to 7 stars where few neighbours can host; here 46 Gaia stars within 1' can (checks.json neighbours possible_hosts), so the comparison is not like for like. "
            "CROWDSAP is 0.927 to 0.937 (checks.json sources): other stars do share the aperture. "
            "Decision 0032 says an NFPP fail is not a reliable kill for a 20\" to 25\" binary, which the pixel check catches instead, and that NFPP can move with the ephemeris; it says nothing that clears a fail. "
            "What decides it: seeing-limited ground-based photometry of the stars within 1' at the transit and phase-0.487 times (F1), TIC 370977918 first (a 19% eclipse would be needed; inside the pixel rule's 15\", the TOI-1399.01 case)."
        ),
    },
    {
        "id": "F3",
        "lens": "on_star",
        "rating": "note",
        "claim": "Triage's pixel pass can't place the source to better than about 10\" to 15\": S38's image holds the transit at its expected strength but too weakly to locate it, the five sector fits point every way, and the 15\" rule says nothing about the possible hosts at 8.5\" and 11.3\".",
        "evidence": (
            "$SECOND2_RUN/signals/370977908-1/pixels.json: pass on S38, 9.32\", quality 0.76 (S38 is a SPOC sector, not timing-suspect). "
            "The pixel diagnosis's rebuild of the same images from the first second-list run (identical offsets; /tmp/pixel-diag/summary_second.txt lines 83-98): "
            "S38's 3x3-box loss at the target is z 1.1 against 1.0 expected (0 of 16 nulls reach its quality). "
            "Unlike TOI-396.01's pass (z -1.2 against 1.8 expected) the image holds what an on-target transit would give, but at z 1 it can't place it. "
            "Fits (E, N): S103 (-8.0, -6.1), S102 (-1.2, -3.1), S65 (+2.6, +5.7), S38 (-4.5, -8.2), S11 (-3.3, +14.1); sky scatter 9.3\" against detector scatter 9.6\", the diagnosis's 'too little transit' mode; quality-weighted mean 3.6\" from the target. "
            "S103 holds the transit best (box z 6.0 against 4.2 expected), but the box spans 63\". "
            "Fixed target-plus-neighbour fits (pix2.txt, command in F1) are degenerate for the 8.4\" and 11.4\" stars: their fitted out-of-transit flux comes out negative (TIC 370977918: -446 e/s in S65, -55 in S38; TIC 370977897: -6412 in S102), so the pixels can't split those stars from the target. "
            "For the 24.8\" and 26.0\" stars, S65's phase-0.487 loss goes to the target (z 2.9 and 3.7), not to them (0.0 and -0.4). F2 covers TIC 370977918."
        ),
    },
    {
        "id": "F4",
        "lens": "real_new",
        "rating": "note",
        "claim": "Both S11 transits sit on momentum dumps, but the signal holds in S38 and S65 without them; it is a low-SNR signal that one held-out season supports.",
        "evidence": (
            "Quality bit 32 in S11's FFI pixel series at BTJD 1603.078 and 1620.203, 0.014 and 0.019 d from mid-transit; S11 dumps come every 3.125 d (" + V +
            "/tmp/t13/heavy.sh .venv/bin/python /tmp/t13/370977908-1/dumps.py $SECOND2_RUN/tdi/370977908-1/tic370977908 ~/.cache/tess-hunt/lc/370977908.npz). "
            "The 2-min light curve has a 16-minute hole at each (1603.068, 1620.194). S38's and S65's four transits have no dump within 1.2 d, except S65 epoch 87 (a dump 0.42 d after, 0.21 d before the orbit gap; events.py). "
            "checks.json: sector_depth S11 354 +- 78, S38 293 +- 59, S65 320 +- 73 ppm (p 0.82); holdout predicts S38 at 5.36 sigma (tension 0.09) and is inconclusive only because S11 and S65 are underpowered (expected SNR 3.8 and 3.9 against 4.0). "
            "signal_present 8.0 sigma against 7.0; SPOC's MES 7.32 (s0001-s0065) and 7.66 (s0001-s0039), just over 7.1. "
            "QLP S102 and S103 give 427 ppm against PDCSAP's 316 (1.2 sigma; checks-with-suspect.json); QLP publishes no CROWDSAP."
        ),
    },
    {
        "id": "F5",
        "lens": "real_new",
        "rating": "note",
        "claim": "No paper, catalogue or ExoFOP entry names the star as a planet host, binary or variable, but the signal is not undetected: two SPOC TCEs and ExoMiner (PC, 0.782) have it, and a claim must credit them.",
        "evidence": (
            "checks.json novelty: two SPOC DV TCEs (s0001-s0039 updated 2021-08-31, s0001-s0065 updated 2023-08-05) and four ExoMiner rows; $SECOND2_RUN/second-list.csv: ExoMiner-v2 2-min score 0.782, PC; never a TOI. "
            "literature.json search.exofop: no TOI, CTOI, comments, files or imaging. SIMBAD (sim-script query 'HD 133325'): otypes NIR,*; G2/3V; its 12 bibcodes are the 12 ADS hits. "
            "No WDS, VSX or Gaia DR3 eclipsing-binary row within 90\" (VizieR asu-tsv on B/wds/wds, B/vsx/vsx, I/358/veb at 226.452627 -51.457178). "
            "All 12 hits are catalogues. Two of them test binarity and clear it: Kervella et al. 2019 (doi 10.1051/0004-6361/201834371; VizieR J/A+A/623/A72: PMa S/N 0.68, BinG2 0) "
            "and its EDR3 update (J/A+A/657/A7: S/N 0.70 and 1.04, no flag), and Brandt 2021 HGCA EDR3 (doi 10.3847/1538-4365/abf93c; J/ApJS/254/42: chi2 0.057, no acceleration). "
            "Gaia DR3 (TAP on gaiadr3.gaia_source): RUWE 0.888, ipd_frac_multi_peak 0, non_single_star 0. None flagged."
        ),
    },
    {
        "id": "F6",
        "lens": "planet",
        "rating": "note",
        "claim": "The transit's own shape and density fit a planet on this star, odd and even disagree mildly only in LEO-Vetter's fits with QLP in, and the search's second signal is noise, not an eclipsing-binary partner.",
        "evidence": (
            "checks.json: density 0.5 sigma from the TIC's; grazing in 2% of samples, b 0.47 (flat) and 0.66 (prior); Rp 2.64 and 2.71 Earth radii; odd and even 0.76 sigma in PDCSAP (odd 286, even 347 ppm) and 0.2 sigma in QLP (checks-with-suspect.json). "
            "Triage's LEO-Vetter on all nine transits leans the other way: odd 389 +- 39 against even 282 +- 44 ppm (1.8 sigma), trapezoid 499 +- 38 against 356 +- 38 (2.7 sigma), b 0.91 +- 0.07. "
            "Rank 2 (22.1987 d, ratio 1.30, SDE 9.4; checks.json other_signals) is not at a novelty harmonic: its t0 1613.755 sits 0.12 d after S11's orbit gap ends (1613.637) and its S65 event (66 periods, 3078.87) is the 343 ppm single dip at 3078.84 (events.py), "
            "not one of F1's phase-0.487 events."
        ),
    },
]
out = {
    "signal": "370977908-1",
    "summary": (
        "Full brief on 370977908-1, a 279 ppm, 17.09 d SPOC TCE on a Tmag 9.0 F star, promoted from the second list. "
        "The main finding is a dip at phase 0.487, as deep as the transit, in all three orbits with data there and at the target's pixels: vet-v3's phase-0.5 check can't see it, LEO-Vetter misses flagging it only on red noise, and if real it makes this an eclipsing binary. "
        "TRICERATOPS's no-G blocker is immaterial (the star is TIC 1150965440, T 20.1), so NFPP 0.126 is a would-be fail, yet every star carrying it sits 4 or more sigma from SPOC's difference-image centroid; ground-based photometry at the transit and phase-0.487 times decides both."
    ),
    "findings": findings,
    "hits_flagged": [],
}
text = json.dumps(out, indent=2, ensure_ascii=False)
assert "—" not in text and "–" not in text
open("/tmp/t13/370977908-1/findings.json", "w").write(text + "\n")
print(len(text))
