import json, sys
H = '$TESS_HUNT_DATA/drafts/'
for lab in ('m3', 'm3-r2'):
    d = H + lab + '/103312990-1/'
    for fn in ('checks.json', 'checks-with-suspect.json'):
        c = json.load(open(d + fn))
        print('=====', lab, fn)
        ch = {x['check']: x for x in c['checks']}
        print(' outcomes', {k: v['outcome'] for k, v in ch.items()})
        ho = ch.get('holdout')
        if ho:
            print(' holdout', ho['outcome'], '|', ho['reason'])
            for s in ho['evidence'].get('seasons', []):
                print('   ', {k: (round(v, 3) if isinstance(v, float) else v) for k, v in s.items() if k not in ('cadences',)})
        sd = ch.get('sector_depth')
        if sd:
            print(' sector_depth', sd['outcome'], json.dumps(sd['evidence'])[:900])
        sec = ch.get('secondary')
        if sec: print(' secondary', sec['outcome'], json.dumps(sec['evidence'])[:400])
        oe = ch.get('odd_even')
        if oe: print(' odd_even', oe['outcome'], json.dumps(oe['evidence'])[:700])
        de = ch.get('density')
        if de: print(' density', de['outcome'], json.dumps(de['evidence'])[:400])
        if fn == 'checks.json':
            fp = c['fit_prior']
            print(' fit_prior rp', json.dumps(fp['rp_rearth']), 'b', json.dumps(fp['b'])[:200])
            print(' fit b', json.dumps(c['fit']['b'])[:200], 'log_rho', json.dumps(c['fit']['log_rho'])[:200])
            print(' star rad', c['star']['rad'], 'rho', c['star']['rho'], c['star']['e_rho'], 'ruwe', c['star']['ruwe'], 'logg', c['star']['logg'], c['star']['logg_flame'])
            print(' other', c['other_signals'])
            print(' red_noise', json.dumps(c['red_noise'])[:600])
            print(' ephemeris', c['ephemeris'])
            print(' neighbours', c['neighbours']['outcome'], c['neighbours']['reason'], c['neighbours']['evidence'].get('centre'))
            print(' pixels', c['pixels']['outcome'], c['pixels']['reason'])
            print(' upcoming', c['upcoming_sectors'], 'dropped', c['dropped_suspect'])
            print(' sources', {k: (v.get('crowdsap'), v.get('n_good'), v.get('timing_suspect'), v.get('author') or v.get('pipeline')) for k, v in c['sources'].items()})
