import json, csv, statistics, sys
H = '$TESS_HUNT_DATA/'
files = {
  'm3(e092?)': H+'drafts/m3/103312990-1/',
  'old 1bbf': '/tmp/t13/103312990-1/pre-0036/',
  'new 7821': H+'drafts/m3-r2/103312990-1/',
}
for lab, d in files.items():
    t = json.load(open(d+'triceratops.json'))
    e = t['evidence']
    print('==', lab, t['outcome'], '|', t['reason'], '| vetting_run', t.get('vetting_run'))
    print(' nfpp_mean %.7f sd %.6f (%.2g) runs %d; fpp_mean %.7f sd %.7f' % (e['nfpp_mean'], e['nfpp_sd'], e['nfpp_sd'], e['runs'], e['fpp_mean'], e['fpp_sd']))
    print(' nfpp last run %.6f; stdev recomputed %.6f' % (e['nfpp'][-1], statistics.stdev(e['nfpp'])))
    print(' ephemeris_from', t['ephemeris_from'], 'dropped', e.get('dropped_stars'), 'stars', len(e['stars']), 'blockers', e['blockers'])
    hosts = e['hosts']
    print(' hosts', len(hosts))
    for h in sorted(hosts, key=lambda h: h['sep_arcsec']):
        print('   TIC %s  sep %.2f  req %.4f  tdepth %.4f  sid %s' % (h.get('tic'), h['sep_arcsec'], h['required_depth'], h['tdepth'], h['source_id']))
    z = set(e['hosts_tdepth_zero'])
    zs = sorted(h['sep_arcsec'] for h in hosts if h['source_id'] in z)
    print(' zero-depth', len(z), 'seps %.2f to %.2f' % (zs[0], zs[-1]))
    nz = [h for h in hosts if h['source_id'] not in z]
    print(' max sep with nonzero depth %.2f' % max(h['sep_arcsec'] for h in nz))
    rows = list(csv.DictReader(open(d+'probs.csv')))
    tot = sum(float(r['prob']) for r in rows)
    print(' probs.csv sum %.6f' % tot)
    def g(i, s):
        return [float(r['prob']) for r in rows if r['ID']==i and r['scenario']==s]
    tgt='103312990'
    for s in ('TP','PTP','STP','SEB','DTP','EB'):
        print('  ', s, g(tgt,s))
    print('   NTP 103312997', g('103312997','NTP'), ' NEB 864915227', g('864915227','NEB'))
    # largest N* terms
    nt = sorted(((float(r['prob']), r['ID'], r['scenario']) for r in rows if r['scenario'].startswith('N')), reverse=True)[:5]
    print('   top N terms', [(f'{p:.5f}', i, s) for p,i,s in nt])
