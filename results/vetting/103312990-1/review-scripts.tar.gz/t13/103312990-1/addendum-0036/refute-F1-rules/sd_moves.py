import json,sys,os
R=os.path.expanduser("~/.cache/tess-hunt/runs")
runs=sys.argv[1:]
def load(r):
    out={}
    d=os.path.join(R,r,"signals")
    for s in sorted(os.listdir(d)):
        p=os.path.join(d,s,"triceratops.json")
        if not os.path.exists(p): continue
        e=json.load(open(p))["evidence"]
        out[s]=(e.get("nfpp_mean"),e.get("nfpp_sd"),e.get("fpp_mean"),e.get("fpp_sd"))
    return out
a,b=load(runs[0]),load(runs[1])
for s in a:
    if s not in b: continue
    x,y=a[s],b[s]
    def rel(i):
        if x[i] in (None,0) or y[i] is None: return None
        return (y[i]-x[i])/x[i]
    print(s, "nfpp_mean %s->%s rel %s | nfpp_sd %s->%s rel %s | fpp_sd rel %s"%(x[0],y[0],rel(0),x[1],y[1],rel(1),rel(3)))
