import json
D='$TESS_HUNT_DATA/drafts/'
for lab in ('m3','m3-r2'):
    c=json.load(open(D+lab+'/103312990-1/checks.json'))
    fp=c['fit_prior']
    print(lab,'fit_prior rp_rearth',fp.get('rp_rearth'),'depth',fp.get('depth'))
    print(lab,'star',{k:c['star'].get(k) for k in ('rad','mass','ruwe','rho','e_rho','dr3_from','Tmag','teff')})
t=json.load(open(D+'m3-r2/103312990-1/triceratops.json'))
print(t['outcome'],t['reason'],t.get('run_id') or t.get('run'))
print(t['evidence'].get('contrast'), [k for k in t['evidence'] if 'contrast' in k or 'valid' in k])
