import json
c=json.load(open('$TESS_HUNT_DATA/drafts/m3-r2/103312990-1/checks.json'))
print(sorted(c.keys()))
print('fit_prior keys', sorted(c['fit_prior'].keys()))
for k in ('depth','depth_ppm','rp_rs'):
    for f in ('fit','fit_prior'):
        if k in c[f]: print(f,k,c[f][k])
if 'depth' in c: print('depth', c['depth'])
print('ephemeris', c.get('ephemeris'))
