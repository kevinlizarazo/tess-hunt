"""Calibrate which_star2's target-versus-neighbour test on the known planets, the controls and this signal.
For each sector and each catalogued star 8" to 25" from the target: dchi2 = chi2(PRF at the star) - chi2(PRF at the
target), each a free amplitude plus a constant, with each pixel's noise from the sector's null images; z = (dchi2 -
mean under H0) / sd under H0, H0 being each null image plus the target-PRF signal at the fitted amplitude. Per sector
the lowest z over those stars is kept (the star the image most prefers to the target)."""
import json, pickle, sys, warnings
import numpy as np
sys.path.insert(0, "/tmp/t13/103312990-1/addendum-0036/refute-F1-reproduce")
from sector_detail import null_images, prf_model
warnings.filterwarnings("ignore")

def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)

def chi2(img, sig, p, ok):
    a = np.column_stack([p[ok], np.ones(ok.sum())]) / sig[ok][:, None]
    b = img[ok] / sig[ok]
    coef, *_ = np.linalg.lstsq(a, b, rcond=None)
    r = b - a @ coef
    return float(r @ r), coef

def sector(path):
    with open(path, "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    prf = prf_model(images, cat, pix)
    sep = np.asarray(np.ma.filled(cat["separation"], np.nan), dtype=float)
    ids = np.asarray(cat["ticID"]).astype(int)
    pt = unit_prf(prf, cat, cat["ticColPix"][0], cat["ticRowPix"][0])
    nulls = np.array([img["diffImage"] for ph, _, img in null_images(pix, planet)
                      if ph != 0.0 and img and not np.isnan(np.sum(img["diffImage"]))])
    if len(nulls) < 6:
        return {"error": f"{len(nulls)} nulls"}
    nn = nulls - np.median(nulls, axis=(1, 2), keepdims=True)
    sig = 1.4826 * np.median(np.abs(nn - np.median(nn, axis=0)), axis=0)
    d = images["diffImage"]
    ok = np.isfinite(sig) & (sig > 0) & np.isfinite(d)
    c0, k0 = chi2(d, sig, pt, ok)
    h0imgs = [n + k0[0] * pt for n in nulls]
    h0t = [chi2(h, sig, pt, ok)[0] for h in h0imgs]
    stars = []
    for i in np.where((sep >= 8) & (sep <= 25))[0]:
        pk = unit_prf(prf, cat, cat["ticColPix"][i], cat["ticRowPix"][i])
        ck, kk = chi2(d, sig, pk, ok)
        h0 = np.array([chi2(h, sig, pk, ok)[0] for h in h0imgs]) - np.array(h0t)
        sd = np.std(h0, ddof=1)
        z = (ck - c0 - h0.mean()) / sd if sd > 0 else np.nan
        stars.append({"tic": int(ids[i]), "sep": float(sep[i]), "dchi2": ck - c0, "h0_mean": float(h0.mean()),
                      "h0_sd": float(sd), "z": float(z), "amp": float(kk[0])})
    zs = [s["z"] for s in stars if np.isfinite(s["z"])]
    best = min(stars, key=lambda s: s["z"] if np.isfinite(s["z"]) else 1e9) if zs else None
    return {"sector": int(pix["sector"]), "cam": f"{pix['camera']}.{pix['ccd']}", "target_amp": float(k0[0]),
            "n_stars": len(stars), "min_z": float(min(zs)) if zs else None, "best": best, "stars": stars}

jobs = json.load(open("/tmp/pixel-diag/jobs.json")) + json.load(open("/tmp/t13/103312990-1/addendum-0036/refute-F1-reproduce/jobs.json"))
out = []
for job in jobs:
    recs = []
    for s in job["sectors"]:
        path = f"{job['star_dir']}/imageData_{job['planet_id']}_sector{s}.pickle"
        try:
            r = sector(path)
        except Exception as exc:
            r = {"error": repr(exc)}
        r.setdefault("sector", s)
        recs.append(r)
    out.append({"group": job["group"], "label": job["label"], "per_sector": recs})
    zs = [f'S{r["sector"]}:{r["min_z"]:+.1f}' if r.get("min_z") is not None else f'S{r["sector"]}:-' for r in recs]
    print(job["group"], job["label"], " ".join(zs), flush=True)
    json.dump(out, open("/tmp/t13/103312990-1/addendum-0036/refute-F1-reproduce/which_star_cal.json", "w"), indent=1, default=float)
