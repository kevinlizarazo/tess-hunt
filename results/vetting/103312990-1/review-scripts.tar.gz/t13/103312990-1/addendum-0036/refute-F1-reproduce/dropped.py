import json, math
O='/tmp/t13/103312990-1/pre-0036/triceratops.json'
N='$TESS_HUNT_DATA/drafts/m3-r2/103312990-1/triceratops.json'
o=json.load(open(O))['evidence']['stars']; n=json.load(open(N))['evidence']['stars']
print('old stars', len(o), 'new', len(n))
tgt=[s for s in o if str(s['ID'])=='103312990'][0]
print('target row', tgt)
ra0,dec0=tgt['ra'],tgt['dec']
for i in ('103312957','864915594','103313054'):
    for lab,L in (('old',o),('new',n)):
        r=[s for s in L if str(s['ID'])==i]
        for s in r:
            e=(s['ra']-ra0)*math.cos(math.radians(dec0))*3600; nn=(s['dec']-dec0)*3600
            print(lab, i, 'sep %.1f' % math.hypot(e,nn), {k:s[k] for k in s if k not in ('ra','dec')})
        if not r: print(lab, i, 'absent')
