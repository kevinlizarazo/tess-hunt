import csv, math, json
D='$TESS_HUNT_DATA/drafts/m3-r2/103312990-1/'
ra0,dec0=156.82891262569836,-47.52064833343752
rows=list(csv.DictReader(open(D+'neighbours.csv')))
poss=[r for r in rows if r['possible']=='True']
print('rows',len(rows),'possible',len(poss))
for r in sorted(poss,key=lambda r: float(r['sep_arcsec'])):
    ra,dec=float(r['ra']),float(r['dec'])
    e=(ra-ra0)*math.cos(math.radians(dec0))*3600; n=(dec-dec0)*3600
    print(r['source_id'], 'table %.2f recomputed %.2f T %.2f need %.4f' % (float(r['sep_arcsec']), math.hypot(e,n), float(r['tmag']), float(r['required_depth'])))
# map TRICERATOPS hosts source_id to tic
t=json.load(open(D+'triceratops.json'))
m={str(h['source_id']):h['tic'] for h in t['evidence']['hosts']}
print('hosts in table', sum(1 for r in poss if r['source_id'] in m), 'of', len(m))
for r in sorted(poss,key=lambda r: float(r['sep_arcsec']))[:6]:
    print(r['source_id'], m.get(r['source_id']))
# checks.json neighbour evidence centre
c=json.load(open(D+'checks.json'))
print(type(c), list(c.keys())[:20] if isinstance(c,dict) else len(c))
