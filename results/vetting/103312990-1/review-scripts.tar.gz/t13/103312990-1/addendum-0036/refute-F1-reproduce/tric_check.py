import json, csv, statistics
R='$TESS_HUNT_DATA/runs/20261021T194348Z-vetting-triceratops-cd4e7a2-7821/signals/103312990-1/'
O='/tmp/t13/103312990-1/pre-0036/'
for lab,d in (('new',R),('old 1bbf',O)):
    t=json.load(open(d+'triceratops.json')); e=t['evidence']
    print('==',lab,t['outcome'],t.get('vetting_run'))
    print(' nfpp list', ['%.5f'%x for x in e['nfpp']])
    print(' mean %.7f (stat.mean %.7f) sd %.6f (stdev %.6f pstdev %.6f) runs %d' % (e['nfpp_mean'], statistics.mean(e['nfpp']), e['nfpp_sd'], statistics.stdev(e['nfpp']), statistics.pstdev(e['nfpp']), e['runs']))
    print(' ephemeris_from', t['ephemeris_from'], 'blockers', e['blockers'])
    print(' dropped', e.get('dropped_stars'))
    print(' hosts[0] keys', list(e['hosts'][0].keys()))
    print(' stars[0] keys', list(e['stars'][0].keys()) if e['stars'] else None)
    z=set(e['hosts_tdepth_zero'])
    for h in sorted(e['hosts'], key=lambda h: h['sep_arcsec']):
        print('   %s sep %.2f req %.4f tdepth %.4f %s' % (h.get('tic'), h['sep_arcsec'], h['required_depth'], h['tdepth'], 'ZERO' if h['source_id'] in z else ''))
    zs=sorted(h['sep_arcsec'] for h in e['hosts'] if h['source_id'] in z)
    print(' zero', len(z), zs)
    rows=list(csv.DictReader(open(d+'probs.csv')))
    def g(i,s): return [r['prob'] for r in rows if r['ID']==i and r['scenario']==s]
    print(' NTP 103312997', g('103312997','NTP'), 'NEB 864915227', g('864915227','NEB'))
    nt=sorted(((float(r['prob']),r['ID'],r['scenario']) for r in rows if r['scenario'] in ('NTP','NEB','NEBx2P')), reverse=True)[:5]
    print(' top N', nt)
