import json
d = json.load(open("which_star_cal.json"))
sat = {"TOI-144.01", "TOI-2011.02", "TOI-396.01", "TOI-396.03"}
for grp in ("known", "control"):
    n = hit = planets = 0; multi = []; unsat_n = unsat_hit = 0
    for j in d:
        if j["group"] != grp: continue
        zs = [r["min_z"] for r in j["per_sector"] if r.get("min_z") is not None]
        if not zs: continue
        planets += 1; n += len(zs); k = sum(z <= -3 for z in zs); hit += k
        if j["label"] not in sat: unsat_n += len(zs); unsat_hit += k
        if k >= 2: multi.append(j["label"])
        print(" ", grp, j["label"], [round(z, 2) for z in zs], "hits", k)
    print(grp, "planets", planets, "sectors", n, "z<=-3", hit, "2+:", len(multi), multi, "| unsaturated only:", unsat_hit, "of", unsat_n)
