"""Mean pixel-fit offset in standard errors (pixel diagnosis's statistic) for every job in a detail.json, plus
the camera of each sector and the fit directions."""
import json, sys
import numpy as np
for path in sys.argv[1:]:
    for job in json.load(open(path)):
        secs=[s for s in job["per_sector"] if "error" not in s]
        if len(secs)<2: continue
        q=np.array([s["fit"]["quality"] for s in secs]); e=np.array([s["fit"]["east"] for s in secs]); n=np.array([s["fit"]["north"] for s in secs])
        me,mn=np.average(e,weights=q),np.average(n,weights=q)
        sky=np.sqrt(np.mean((e-me)**2+(n-mn)**2))
        se=np.hypot(me,mn)/(sky/np.sqrt(len(secs)))
        pas=(np.degrees(np.arctan2(e,n))%360).round().astype(int)
        cams=[f'{s["camera"]}.{s["ccd"]}' for s in secs]
        print(f'{job["group"]:9s} {job["label"]:16s} Tmag {secs[0]["tmag"]:5.2f} n {len(secs)} mean {np.hypot(me,mn):5.1f}" sky {sky:5.1f}" stderr {se:5.2f}  PA {list(pas)} cams {cams}')
