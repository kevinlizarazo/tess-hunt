import json
H='$TESS_HUNT_DATA/'
for lab,f in [('drafts/m3',H+'drafts/m3/103312990-1/checks.json'),('VET2 2d70 (= drafts/m3-r2)',H+'runs/20261020T174317Z-vetting-run-61b5944-2d70/signals/103312990-1/checks.json')]:
    c=json.load(open(f))
    print('==',lab, 'top keys', list(c.keys()))
    print(' fit_prior keys', list(c['fit_prior'].keys()))
    for k in ('rp_rearth','depth_ppm','depth','rp_rs','b','log_rho'):
        if k in c['fit_prior']: print('  fit_prior',k, c['fit_prior'][k])
    for k in ('rp_rearth','depth_ppm','depth','rp_rs'):
        if k in c['fit']: print('  fit',k, c['fit'][k])
    print(' star', {k:c['star'].get(k) for k in ('rad','e_rad','mass','rho','Tmag','teff','ruwe','GAIAmag','d','plx','logg')})
    print(' ephemeris', c.get('ephemeris'))
