import csv, sys
for lab, f in [('e092 (drafts/m3)', '$TESS_HUNT_DATA/drafts/m3/103312990-1/probs.csv'),
               ('7821 (TRIC3B, drafts/m3-r2)', '$TESS_HUNT_DATA/runs/20261021T194348Z-vetting-triceratops-cd4e7a2-7821/signals/103312990-1/probs.csv')]:
    rows = list(csv.DictReader(open(f)))
    print('==', lab, 'columns', list(rows[0].keys()), 'nrows', len(rows))
    tgt = [r for r in rows if r['ID'] == '103312990']
    for r in tgt:
        print('  ', r['ID'], r['scenario'], repr(r['prob']))
    by = {}
    for r in rows: by[r['scenario']] = by.get(r['scenario'], 0) + float(r['prob'])
    print('  sums', {k: f'{v:.5g}' for k, v in sorted(by.items(), key=lambda x: -x[1])})
