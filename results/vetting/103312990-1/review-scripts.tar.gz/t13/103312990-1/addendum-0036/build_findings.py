import json
src = json.load(open('/tmp/t13/out-r2/103312990-1/review.json'))
F = {f['id']: f for f in src['findings']}

def sub(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

out = []
def add(fid, status, why, claim=None, evidence=None, rating=None):
    f = F[fid]
    out.append({
        'id': fid, 'lens': f['lens'], 'rating': rating or f['rating'],
        'claim': claim if claim is not None else f['claim'],
        'evidence': evidence if evidence is not None else f['evidence'],
        'status': status, 'why': why,
    })

e1 = sub(F['F1']['evidence'], 'mean NFPP 0.0198 (sd 0.00022) over 10 runs', 'mean NFPP 0.0198 (sd 0.00023) over 10 runs')
e1 += (' Updated 2026-10-22 for the 0036 TRICERATOPS rerun: the triceratops.json and probs.csv cited (same drafts/m3-r2 paths) '
       'are now TRICERATOPS run 20261021T194348Z-vetting-triceratops-cd4e7a2-7821\'s, not 20261020T181658Z-vetting-triceratops-61b5944-1bbf\'s; '
       'NFPP sd 0.00022 to 0.00023 (0.000224 to 0.000225) and mean 0.0198004 to 0.0198006, within 0036 item 5\'s run-to-run noise; '
       'dropped_stars lists TIC 103312957 (ARTIFACT) and TIC 864915594 (a DUPLICATE of TIC 103313054), 118" and 139" out (0036 item 3) and neither a host; '
       'the 21 hosts, their tdepths and the seven zero-depth hosts are unchanged, and the last run\'s NTP on TIC 103312997 (0.004828 to 0.004829) '
       'and NEB on TIC 864915227 (0.002753 both) read the same at the digits given.')
add('F1', 'updated',
    'Read drafts/m3-r2 triceratops.json and probs.csv (sha256 equal to TRIC3B_RUN\'s) against /tmp/t13/103312990-1/pre-0036/ (1bbf) with tric_nums.py: only the NFPP sd\'s second digit and the run behind the cited paths changed; mean NFPP, the five hosts\' tdepths, the 21 hosts, the seven zero-depth hosts at 49.65" to 59.83" and the two probs.csv terms hold, and the pixel, neighbour and vet-v3.toml numbers come from files 0036 did not touch (checks.json sha256 is the new run\'s input).',
    evidence=e1)

e2 = sub(F['F2']['evidence'], '($TESS_HUNT_DATA/drafts/m3/103312990-1/probs.csv, last run)', '($TESS_HUNT_DATA/drafts/m3-r2/103312990-1/probs.csv, last run)')
e2 += (' Updated 2026-10-22 for the 0036 TRICERATOPS rerun: the probs.csv cited for STP, PTP and SEB moves from drafts/m3 '
       '(the first TRICERATOPS run, 20261020T013408Z-vetting-triceratops-62882b5-e092) to drafts/m3-r2 (20261021T194348Z-vetting-triceratops-cd4e7a2-7821); '
       'the last run\'s STP 0.03554 to 0.03554, PTP 0.17615 to 0.17616, SEB 7.148e-5 to 7.149e-5, the same at the digits given.')
add('F2', 'updated',
    'Its one TRICERATOPS citation was drafts/m3\'s probs.csv (sha256 equal to e092\'s), with digits 1bbf shares, so it moves to the new run\'s probs.csv, where STP, PTP and SEB read the same at the digits given (tric_nums.py); the drafts/m3 checks.json citation is a vetting file 0036 did not touch, its fit_prior Rp and depth equal m3-r2 checks.json\'s (vet_nums.py), and it stays.',
    evidence=e2)

add('F3', 'unchanged',
    'Cites no TRICERATOPS file or number; vet_nums.py shows its holdout seasons (5.79 sigma, tension 0.33; 3.32; untestable S90), S99 at 3.38 sigma (4.28, 0.69), S90 at 3.50, sector depths, dropped_suspect and upcoming sectors equal in drafts/m3-r2 checks.json and checks-with-suspect.json, and per_transit.py and LEO-Vetter read files 0036 did not touch.')
add('F4', 'unchanged',
    'Cites no TRICERATOPS file or number; vet_nums.py shows the secondary (1.004e-4, 3.95e-5, 2.54 sigma, 116 cadences; 78 +- 34 ppm, 2.33 sigma with S99) and ModShift (0.121, 118 ppm, 3.01 sigma; 2.58 at 0.379; 2.43 at 0.424; Fred 1.09) equal in drafts/m3-r2 checks.json and checks-with-suspect.json.')
add('F5', 'unchanged',
    'Cites no TRICERATOPS file or number; vet_nums.py shows fit b, the odd and even depths, the density tension and other_signals equal in drafts/m3-r2 checks.json.')
add('F6', 'unchanged',
    'Cites no TRICERATOPS file or number, and its two TRICERATOPS statements hold in the new triceratops.json (TIC 103313020 in hosts_tdepth_zero, outcome inconclusive on RUWE 6.21); the neighbours outcome (21 of 55, centre Gaia DR3 5365550158677776896, J2016.0) is from drafts/m3-r2 checks.json, which 0036 did not touch.')
add('F7', 'unchanged',
    'Cites no TRICERATOPS file or number; drafts/m3-r2 literature.json holds the same 7 hits as the file it cites, and 0036 reran only TRICERATOPS.')
add('F8', 'unchanged',
    'Cites no TRICERATOPS file or number; vet_nums.py shows red_noise (S9 and S10 beta 1.0, 2 cadences per bin, need 3), n_good and the sector depths equal in drafts/m3-r2 checks.json, and per_transit.py reads a light curve 0036 did not touch.')

obj = {
    'signal': src['signal'],
    'summary': src['summary'] + ' Updated 2026-10-22 for the 0036 TRICERATOPS rerun.',
    'findings': out,
    'hits_flagged': src['hits_flagged'],
}
# unchanged findings keep claim and evidence byte for byte
for f in out:
    if f['status'] == 'unchanged':
        assert f['claim'] == F[f['id']]['claim'] and f['evidence'] == F[f['id']]['evidence']
    assert f['claim'] == F[f['id']]['claim']
    assert '—' not in f['evidence'] + f['why']
json.dump(obj, open('/tmp/t13/103312990-1/addendum-0036/findings.json', 'w'), indent=2, ensure_ascii=False)
print(json.dumps(obj, ensure_ascii=False))
