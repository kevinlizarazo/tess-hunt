import urllib.request, urllib.parse, sys
def asu(src, extra):
    url="https://vizier.cds.unistra.fr/viz-bin/asu-tsv?"+urllib.parse.urlencode({"-source":src,"-out.all":"","-out.max":"50",**extra})
    try:
        return urllib.request.urlopen(url,timeout=120).read().decode(errors="replace")
    except Exception as e:
        return f"ERR {e}"
pos={"-c":"156.82891 -47.52065","-c.rs":"5"}
for src in ["J/AJ/153/257","J/AJ/155/149","J/A+A/609/A116","B/wds/wds","J/MNRAS/506/2269","J/MNRAS/490/3158"]:
    out=asu(src,pos)
    lines=[l for l in out.splitlines() if l and not l.startswith('#')]
    print("=====",src,len(lines))
    print("\n".join(lines[:30]))
