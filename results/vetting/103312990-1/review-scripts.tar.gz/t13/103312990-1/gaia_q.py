import sys, urllib.parse, urllib.request, json
def q(adql):
    data=urllib.parse.urlencode({"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":adql}).encode()
    r=urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync",data=data,timeout=120)
    return r.read().decode()
SID=5365550158677776896
print(q(f"""SELECT source_id, ra, dec, ref_epoch, parallax, parallax_error, pmra, pmdec, ruwe, astrometric_excess_noise, astrometric_excess_noise_sig,
ipd_frac_multi_peak, ipd_gof_harmonic_amplitude, ipd_frac_odd_win, duplicated_source, non_single_star, visibility_periods_used,
phot_g_mean_mag, phot_bp_mean_mag, phot_rp_mean_mag, bp_rp, phot_bp_rp_excess_factor, radial_velocity, radial_velocity_error, rv_nb_transits, rv_chisq_pvalue, rv_renormalised_gof, rv_amplitude_robust, rv_expected_sig_to_noise,
phot_variable_flag, teff_gspphot, logg_gspphot, distance_gspphot, classprob_dsc_combmod_star, has_xp_continuous
FROM gaiadr3.gaia_source WHERE source_id={SID}"""))
for t in ["nss_two_body_orbit","nss_acceleration_astro","nss_non_linear_spectro","nss_vim_fl"]:
    try:
        print(t, q(f"SELECT * FROM gaiadr3.{t} WHERE source_id={SID}"))
    except Exception as e:
        print(t,"ERR",e)
for t in ["vari_summary","vari_eclipsing_binary","vari_classifier_result"]:
    try:
        print(t, q(f"SELECT * FROM gaiadr3.{t} WHERE source_id={SID}"))
    except Exception as e:
        print(t,"ERR",e)
