import urllib.parse, urllib.request
def q(adql):
    data=urllib.parse.urlencode({"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":adql}).encode()
    return urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync",data=data,timeout=300).read().decode()
print(q("SELECT source_id, ref_epoch, ra, dec, parallax, parallax_error, pmra, pmra_error, pmdec, pmdec_error, astrometric_excess_noise, astrometric_excess_noise_sig, visibility_periods_used, radial_velocity, radial_velocity_error, rv_nb_transits, phot_g_mean_mag FROM gaiadr2.gaia_source WHERE source_id=5365550158677776896"))
print(q("SELECT source_id, tycho2_id, ref_epoch, parallax, parallax_error, pmra, pmra_error, pmdec, pmdec_error, astrometric_excess_noise, astrometric_excess_noise_sig, phot_g_mean_mag FROM gaiadr1.tgas_source WHERE source_id=5365550154375279232"))
print(q("SELECT source_id, pmra, pmra_error, pmdec, pmdec_error, parallax, parallax_error, ruwe, ipd_frac_multi_peak, ipd_gof_harmonic_amplitude, ipd_gof_harmonic_phase, astrometric_params_solved, astrometric_gof_al, astrometric_chi2_al, astrometric_n_good_obs_al, phot_bp_n_blended_transits, phot_rp_n_blended_transits, phot_bp_n_obs, phot_rp_n_obs, scan_direction_strength_k1 FROM gaiadr3.gaia_source WHERE source_id=5365550158677776896"))
