import urllib.parse, urllib.request
def q(adql):
    data=urllib.parse.urlencode({"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":adql}).encode()
    return urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync",data=data,timeout=300).read().decode()
print(q("""SELECT source_id, ra, dec, phot_g_mean_mag, bp_rp, parallax, parallax_error, pmra, pmdec, ruwe, radial_velocity, radial_velocity_error,
 DISTANCE(POINT(156.82891262569836,-47.52064833343752), POINT(ra,dec))*3600 AS sep_arcsec
FROM gaiadr3.gaia_source
WHERE 1=CONTAINS(POINT(ra,dec), CIRCLE(156.82891262569836,-47.52064833343752, 6.0))
AND parallax BETWEEN 6.4 AND 9.4 AND ABS(pmra+47.85)<12 AND ABS(pmdec+56.53)<12 AND phot_g_mean_mag<13
ORDER BY sep_arcsec"""))
