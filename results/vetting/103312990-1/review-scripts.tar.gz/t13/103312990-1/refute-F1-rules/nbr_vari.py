"""Gaia DR3 variability and NSS rows for the 20 possible hosts in neighbours.csv (keyless Gaia TAP)."""
import csv, urllib.parse, urllib.request
def q(adql):
    data=urllib.parse.urlencode({"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":adql}).encode()
    return urllib.request.urlopen("https://gea.esac.esa.int/tap-server/tap/sync",data=data,timeout=180).read().decode()
rows=list(csv.DictReader(open('$TESS_HUNT_DATA/drafts/m3/103312990-1/neighbours.csv')))
ids=[r['source_id'] for r in rows if r['possible']=='True']
print(len(ids),"possible hosts")
L=",".join(ids)
print(q(f"SELECT source_id, phot_variable_flag, non_single_star, ruwe, phot_g_n_obs FROM gaiadr3.gaia_source WHERE source_id IN ({L})"))
for t in ["vari_summary","vari_eclipsing_binary","vari_classifier_result","nss_two_body_orbit"]:
    print("==",t); print(q(f"SELECT * FROM gaiadr3.{t} WHERE source_id IN ({L})")[:3000])
