"""Which single catalogued star best explains each difference image: one PRF held at each candidate's catalogue
position, free amplitude plus a constant, chi-square with the image's own sigma. The same fit on the null images
(no transit) gives the noise of the chi-square difference. Read-only, on the triage run's saved pickles."""
import json, pickle, sys, warnings
import numpy as np
sys.path.insert(0, "/tmp/t13/103312990-1")
from sector_detail import null_images, prf_model
warnings.filterwarnings("ignore")
STAR_DIR = "$TESS_HUNT_DATA/tdi/20261015T155441Z-triage-7b12e25-3f57/103312990-1/tic103312990"
CANDS = [103312990, 103312987, 864915227, 864916052, 103312995, 103312997, 103313005, 103313002, 103312980]

def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)

def chi2_one(img, sig, p):
    ok = np.isfinite(img) & np.isfinite(sig) & (sig > 0)
    a = np.column_stack([p[ok], np.ones(ok.sum())]) / sig[ok][:, None]
    b = img[ok] / sig[ok]
    coef, *_ = np.linalg.lstsq(a, b, rcond=None)
    r = b - a @ coef
    return float(r @ r), float(coef[0])

out = {}
for s in [99, 90, 36, 10, 9]:
    with open(f"{STAR_DIR}/imageData_103312990.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    ids = np.asarray(cat["ticID"]).astype(int)
    prf = prf_model(images, cat, pix)
    prfs = {}
    for t in CANDS:
        if t in ids:
            j = int(np.where(ids == t)[0][0])
            prfs[t] = unit_prf(prf, cat, cat["ticColPix"][j], cat["ticRowPix"][j])
    sig = images["diffImageSigma"]
    real = {t: chi2_one(images["diffImage"], sig, p) for t, p in prfs.items()}
    nulls = []
    for phase, _, img in null_images(pix, planet):
        if phase == 0.0 or not img or np.isnan(np.sum(img["diffImage"])):
            continue
        nulls.append({t: chi2_one(img["diffImage"], img["diffImageSigma"], p)[0] for t, p in prfs.items()})
    out[s] = {"real": {str(t): v for t, v in real.items()},
              "nulls": [{str(t): v for t, v in n.items()} for n in nulls]}
    base = real[103312990][0]
    print(f"S{s} cam {pix['camera']}.{pix['ccd']}: chi2(target) {base:.1f}, amp {real[103312990][1]:.1f}")
    for t in prfs:
        if t == 103312990: continue
        d = real[t][0] - base
        nd = np.array([n[t] - n[103312990] for n in nulls])
        print(f"   TIC {t}: dchi2 (star - target) {d:+7.2f}  amp {real[t][1]:8.1f} | nulls dchi2 median {np.median(nd):+6.2f} sd {np.std(nd, ddof=1):5.2f} (n {len(nd)})")
json.dump(out, open("/tmp/t13/103312990-1/which_star.json", "w"), indent=1)
