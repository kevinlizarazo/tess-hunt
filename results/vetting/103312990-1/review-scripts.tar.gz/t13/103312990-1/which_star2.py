"""Target or neighbour: per sector, one PRF held at the target or at a neighbour (free amplitude plus a constant)
fitted to the difference image, with each pixel's noise taken from the sector's null images. dchi2 = chi2(neighbour)
- chi2(target): negative favours the neighbour. Calibrated by simulation: each null image plus the fitted signal
placed at the target (H0) or at the neighbour (H1). Read-only, on the triage run's saved pickles."""
import pickle, sys, warnings
import numpy as np
sys.path.insert(0, "/tmp/t13/103312990-1")
from sector_detail import null_images, prf_model
warnings.filterwarnings("ignore")
STAR_DIR = "$TESS_HUNT_DATA/tdi/20261015T155441Z-triage-7b12e25-3f57/103312990-1/tic103312990"
TGT = 103312990
NB = [864915227, 103312987, 103312995, 103312997, 864916052]

def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)

def fit(img, sig, p, ok):
    a = np.column_stack([p[ok], np.ones(ok.sum())]) / sig[ok][:, None]
    b = img[ok] / sig[ok]
    coef, *_ = np.linalg.lstsq(a, b, rcond=None)
    r = b - a @ coef
    return float(r @ r), coef

tot = {k: {"real": 0.0, "h0": [], "h1": []} for k in NB}
for s in [99, 90, 36, 10, 9]:
    with open(f"{STAR_DIR}/imageData_103312990.1_sector{s}.pickle", "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    ids = np.asarray(cat["ticID"]).astype(int)
    prf = prf_model(images, cat, pix)
    P = {}
    for t in [TGT] + NB:
        j = int(np.where(ids == t)[0][0])
        P[t] = unit_prf(prf, cat, cat["ticColPix"][j], cat["ticRowPix"][j])
    nulls = [img["diffImage"] for ph, _, img in null_images(pix, planet)
             if ph != 0.0 and img and not np.isnan(np.sum(img["diffImage"]))]
    nulls = np.array(nulls)
    # robust per-pixel noise from the nulls, each null's median removed (the fit's constant takes a sky offset)
    nn = nulls - np.median(nulls, axis=(1, 2), keepdims=True)
    sig = 1.4826 * np.median(np.abs(nn - np.median(nn, axis=0)), axis=0)
    ok = np.isfinite(sig) & (sig > 0) & np.isfinite(images["diffImage"])
    d = images["diffImage"]
    c0, k0 = fit(d, sig, P[TGT], ok)
    print(f"S{s} cam {pix['camera']}.{pix['ccd']} nulls {len(nulls)}: target amp {k0[0]:.1f} (z {k0[0] / np.sqrt(1 / np.sum(P[TGT][ok] ** 2 / sig[ok] ** 2)):.1f})")
    for k in NB:
        ck, kk = fit(d, sig, P[k], ok)
        real = ck - c0
        h0 = [fit(n + k0[0] * P[TGT], sig, P[k], ok)[0] - fit(n + k0[0] * P[TGT], sig, P[TGT], ok)[0] for n in nulls]
        h1 = [fit(n + kk[0] * P[k], sig, P[k], ok)[0] - fit(n + kk[0] * P[k], sig, P[TGT], ok)[0] for n in nulls]
        print(f"   TIC {k}: dchi2 {real:+7.2f} (amp {kk[0]:6.1f}) | if target: {np.mean(h0):+7.2f} sd {np.std(h0, ddof=1):5.2f} | if this star: {np.mean(h1):+7.2f} sd {np.std(h1, ddof=1):5.2f}")
        if s != 99:
            tot[k]["real"] += real; tot[k]["h0"].append(np.array(h0)); tot[k]["h1"].append(np.array(h1))
print("Sum over S9, S10, S36, S90 (S99 left out as timing-suspect):")
for k in NB:
    h0 = np.sum(tot[k]["h0"], axis=0); h1 = np.sum(tot[k]["h1"], axis=0)
    print(f"   TIC {k}: dchi2 {tot[k]['real']:+7.2f} | if target {h0.mean():+7.2f} sd {h0.std(ddof=1):5.2f} | if this star {h1.mean():+7.2f} sd {h1.std(ddof=1):5.2f}")
