import warnings; warnings.filterwarnings("ignore")
from astroquery.vizier import Vizier
import astropy.units as u
from astropy.coordinates import SkyCoord
c=SkyCoord(156.82891262569836,-47.52064833343752,unit="deg")
v=Vizier(columns=["**"],row_limit=50)
for src,rad in [("J/AJ/153/257",10),("J/AJ/155/149",10),("J/A+A/609/A116",10),("B/wds/wds",60),("J/MNRAS/506/2269",10),("J/MNRAS/490/3158",10),("B/gcvs",30),("J/A+A/664/A4",10)]:
    try:
        res=v.query_region(c,radius=rad*u.arcsec,catalog=src)
    except Exception as e:
        print("=====",src,"ERR",e); continue
    print("=====",src,len(res))
    for t in res:
        print("--",t.meta.get("name"),len(t))
        t.pprint(max_lines=20,max_width=400)
