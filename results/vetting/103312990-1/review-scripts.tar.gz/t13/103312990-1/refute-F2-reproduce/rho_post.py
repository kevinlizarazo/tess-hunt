"""Flat-prior fit (vet's fit_samples.npz, columns as fit.NAMES): how much of the posterior allows a denser host."""
import numpy as np
s=np.load("$TESS_HUNT_DATA/runs/20261020T010149Z-vetting-run-62882b5-c3ee/signals/103312990-1/fit_samples.npz")["samples"]
names=("t0","period","rp_rs","b","log_rho","q1","q2")
lr=s[:,4]; b=s[:,3]
print("log_rho (g/cc) percentiles 2.5,16,50,84,97.5,99.85:", np.round(np.percentile(lr,[2.5,16,50,84,97.5,99.85]),3))
for label,rho_sun in [("TIC target 0.593",0.593),("K5V 0.70 Msun 0.68 Rsun",0.70/0.68**3),("M0V 0.57/0.58",0.57/0.58**3),("M3V 0.35/0.36",0.35/0.36**3),("M5V 0.16/0.20",0.16/0.20**3)]:
    x=np.log10(rho_sun*1.408)
    print(f"{label:26s} log10 rho {x:5.2f} g/cc: posterior fraction above {np.mean(lr>x):.4f}")
print("b percentiles 16,50,84:", np.round(np.percentile(b,[16,50,84]),3))
