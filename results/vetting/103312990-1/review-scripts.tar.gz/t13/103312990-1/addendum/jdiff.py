import json, sys
def walk(a, b, path=""):
    if type(a) != type(b):
        print(f"{path}: TYPE {type(a).__name__} -> {type(b).__name__}: {str(a)[:200]} -> {str(b)[:200]}"); return
    if isinstance(a, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a: print(f"{path}.{k}: ADDED {json.dumps(b[k])[:400]}")
            elif k not in b: print(f"{path}.{k}: REMOVED {json.dumps(a[k])[:400]}")
            else: walk(a[k], b[k], f"{path}.{k}")
    elif isinstance(a, list):
        if len(a) != len(b): print(f"{path}: LEN {len(a)} -> {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)): walk(x, y, f"{path}[{i}]")
        if len(b) > len(a):
            for i in range(len(a), len(b)): print(f"{path}[{i}]: ADDED {json.dumps(b[i])[:400]}")
    else:
        if a != b: print(f"{path}: {a} -> {b}")
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
walk(a, b)
