"""Build the 0034/0035 addendum for 103312990-1's Task 13 review from the old review.json."""
import json

OLD = "/tmp/t13/out/103312990-1/review.json"
OUT = "/tmp/t13/103312990-1/addendum/findings.json"
TAG = "Updated 2026-10-21 for the 0034/0035 rerun: "
old = json.load(open(OLD))
by = {f["id"]: f for f in old["findings"]}


def keep(fid, why):
    f = by[fid]
    return {k: f[k] for k in ("id", "lens", "rating", "claim", "evidence")} | {"status": "unchanged", "why": why}


def sub(text, old_s, new_s, count=1):
    assert text.count(old_s) == count, (old_s, text.count(old_s))
    return text.replace(old_s, new_s)


f1 = by["F1"]
c1 = sub(f1["claim"], '15" to 57" from the target', '15" to 60" from the target')
e1 = sub(f1["evidence"], "$TESS_HUNT_DATA/drafts/m3/103312990-1/",
         "$TESS_HUNT_DATA/drafts/m3-r2/103312990-1/", 4)
e1 = sub(e1, "and 15 more about 35\" to 57\" out needing 6.4% to 98.1% (dossier's neighbour table)",
         "and 16 more 34.6\" to 59.8\" out needing 6.4% to 98.1% (dossier's neighbour table)")
e1 = sub(e1, "The six hosts it gave zero depth sit 50.1\" to 56.5\" out",
         "The seven hosts it gave zero depth sit 49.7\" to 59.8\" out")
e1 += (" " + TAG + "decision 0034 adds Gaia DR3 5365550055598557056 (TIC 103313020) as a possible host at 59.83\" "
       "needing 21.5% (TRICERATOPS depth 0), so the claim's outer bound 57\" to 60\"; the hosts past the fifth, "
       "15 at about 35\" to 57\" to 16 at 34.6\" to 59.8\" (the table now measures from the target's DR3 "
       "position, as sep_dr3.py did); TRICERATOPS's zero-depth hosts, six at 50.1\" to 56.5\" (the old table's "
       "TIC-epoch separations) to seven at 49.7\" to 59.8\", the new star among them; mean NFPP 0.0197995 to "
       "0.0198004 (sd 0.000224 both) and the probs.csv terms quoted read the same at the digits given; the cited run "
       "files move from drafts/m3 to drafts/m3-r2.")

f6 = by["F6"]
c6 = ("On the first runs (vetting 20261020T010149Z-vetting-run-62882b5-c3ee) this finding reported that "
      "neighbours.csv's separations ran from the target's J2000 TIC position, off by up to 1.2\" for a target moving "
      "74 mas/yr, so the 15.37\" possible host read 14.5\" and the centroid plot drew it inside the 15\" line, with no "
      "outcome changed; decision 0034 fixed it, and the rerun's table and plot measure from the target's Gaia DR3 "
      "position at J2016.0.")
e6 = ("Original claim: \"" + f6["claim"] + "\" Decision 0034 (docs/decisions/0034-neighbour-table-epochs.md) "
      "centres the cone on the target's own Gaia DR3 row, so every separation runs from DR3 at J2016.0. Rerun vetting "
      "20261020T174317Z-vetting-run-61b5944-2d70 ($TESS_HUNT_DATA/drafts/m3-r2/103312990-1/checks.json "
      "neighbours): centre \"Gaia DR3 5365550158677776896, J2016.0\"; the five nearest possible hosts read 9.41\", "
      "15.37\", 18.63\", 20.38\" and 32.36\" (neighbours.csv sep_arcsec), within 0.01\" of the DR3 values F6 gave "
      "(9.41\", 15.37\", 18.63\", 20.38\", 32.37\") where the first table read 8.23\", 14.47\", 19.29\", 20.07\" and "
      "31.98\"; plots/centroids.png draws Gaia "
      "DR3 5365550193037516288 (TIC 864915227) at 15.4\", above the 15\" line. No outcome changed: neighbours passes "
      "at 21 of 55 (was 20 of 54), Gaia DR3 5365550055598557056 (TIC 103313020) entering at 59.83\" needing 21.5%, "
      "which TRICERATOPS gives zero depth; TRICERATOPS stays inconclusive on RUWE 6.21.")

R2 = "drafts/m3-r2/103312990-1"
findings = [
    {"id": "F1", "lens": f1["lens"], "rating": f1["rating"], "claim": c1, "evidence": e1, "status": "updated",
     "why": f"Read {R2}'s checks.json (pixels, neighbours), neighbours.csv, triceratops.json (hosts, hosts_tdepth_zero, "
            "nfpp, runs, ephemeris_from), probs.csv and dossier.md, diffed each against drafts/m3 (addendum/jdiff.py, "
            "addendum/read_new.py) and reran sep_dr3.py on the new table (addendum/sep_dr3_r2.py): the pixel offsets, "
            "the five nearest hosts' separations, magnitudes, required depths and tdepths, NFPP 0.0198 (sd 0.00022, "
            "10 runs, fit_prior ephemeris) and the NTP and NEB terms read as written, while the host list and the "
            "zero-depth list each gained the 59.83\" star."},
    keep("F2", f"Read {R2}'s checks.json (fit_prior Rp 2.204, 1.968 to 2.525; star rad 1.19019, ruwe 6.2079; ephemeris "
               "depth 3.64e-4) and probs.csv (STP 0.03554, PTP 0.17614, SEB 7.148e-5), the same at the quoted digits; "
               "sha256 shows the rerun vetting run's fit_samples.npz byte-identical to the first run's, so rho_post.py's "
               "5.4% and 0.01% stand; the Gaia, SIMBAD and ExoFOP numbers come from outside the runs."),
    keep("F3", f"Read holdout, sector_depth, upcoming_sectors and dropped_suspect in {R2}'s checks.json and "
               "checks-with-suspect.json (byte-identical to the two rerun vetting runs' files): every season status, "
               "sigma, expected SNR, tension and depth reads as written; 0035 only adds training_seasons_with_transits "
               "(2 for every season in the vet, 3 in the evidence-only vet), which makes no season untestable; the "
               "light curve per_transit.py reads and triage's LEO-Vetter evidence predate the rerun."),
    keep("F4", f"Read secondary in {R2}'s checks.json (1.004e-4 +- 3.95e-5, 2.54 sigma, 116 cadences) and "
               "checks-with-suspect.json (78 +- 34 ppm, 2.33 sigma) and checks.json modshift (3.01 sigma at 0.121, "
               "118 ppm; 2.58 at 0.379; 2.43 at 0.424; Fred 1.09): unchanged by the rerun; triage and decision 0031 "
               "were not rerun."),
    keep("F5", f"Read fit (b 0.532, -0.371 +0.333; grazing 0.0017), odd_even, density and other_signals in {R2}'s "
               "checks.json, field for field the same as the first run's (addendum/jdiff.py shows only holdout's new "
               "counts and the neighbour table changed); fit_samples.npz is byte-identical, so rho_post.py's numbers "
               "stand; LEO-Vetter's are triage's, not rerun."),
    {"id": "F6", "lens": f6["lens"], "rating": "note", "claim": c6, "evidence": e6, "status": "resolved",
     "why": f"Read {R2}'s checks.json neighbours (centre, sep_arcsec), neighbours.csv and plots/centroids.png: the table "
            "now measures from the target's DR3 position at J2016.0 and matches F6's DR3 separations (addendum/"
            "sep_dr3_r2.py), and the plot draws the 15.37\" star above the 15\" line, so 0034 fixed what it reported."},
    keep("F7", f"Diffed {R2}'s literature.json against the first run's (addendum/jdiff.py): the same 7 hits with the same "
               "ids and found_by, ExoFOP status ok with no TOIs, CTOIs, planets or imaging; only from_run markers were "
               "added; the Gaia, SIMBAD and VizieR reads are outside the runs."),
    keep("F8", f"Read sources (n_good), red_noise and sector_depth in {R2}'s checks.json, unchanged from the first run's "
               "(S9 and S10 beta 1.0 at 2 cadences per bin, need 3); per_transit.py reads the cached light curve "
               "(written 2026-10-13) at the density-prior ephemeris, both unchanged by the rerun."),
]
assert [f["id"] for f in findings] == [f["id"] for f in old["findings"]]
summary = old["summary"] + " Updated 2026-10-21 for the 0034/0035 rerun."
out = {"signal": old["signal"], "summary": summary, "findings": findings, "hits_flagged": old["hits_flagged"]}
with open(OUT, "w") as fh:
    json.dump(out, fh, indent=2)
    fh.write("\n")
for f in findings:
    if f["status"] == "unchanged":
        assert all(f[k] == by[f["id"]][k] for k in ("lens", "rating", "claim", "evidence"))
print("wrote", OUT, [(f["id"], f["rating"], f["status"]) for f in findings])
