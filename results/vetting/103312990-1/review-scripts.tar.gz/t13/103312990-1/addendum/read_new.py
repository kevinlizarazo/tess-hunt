"""Print every number the review's findings cite, from the rerun's draft files (drafts/m3-r2/103312990-1)."""
import csv, json, sys
D = sys.argv[1]
c = json.load(open(f"{D}/checks.json"))
s = json.load(open(f"{D}/checks-with-suspect.json"))
t = json.load(open(f"{D}/triceratops.json"))
print("top keys", list(c))
for ch in c["checks"]:
    print("CHECK", ch["check"], ch["outcome"], "|", ch["reason"])
for k in ("neighbours", "pixels", "triceratops", "literature"):
    if k in c: print("TOP", k, c[k].get("outcome"), "|", c[k].get("reason"))
px = c["pixels"]["evidence"]
print("PIXELS", [(x["sector"], round(x["offset_arcsec"],2), round(x["quality"],3)) for x in px["sectors"]], px["offset_qual_arcsec"])
print("SOURCES", json.dumps(c.get("sources"))[:1500])
byname = {ch["check"]: ch for ch in c["checks"]}
sbyname = {ch["check"]: ch for ch in s["checks"]}
for name in ("holdout", "secondary", "sector_depth", "odd_even", "density", "shape"):
    print("EV", name, json.dumps(byname[name]["evidence"])[:2500])
    print("SEV", name, json.dumps(sbyname[name]["evidence"])[:2500])
print("SUSPECT holdout", sbyname["holdout"]["outcome"], sbyname["holdout"]["reason"])
for k in ("fit", "fit_prior", "red_noise", "other_signals", "upcoming_sectors", "star", "ephemeris"):
    print("K", k, json.dumps(c.get(k))[:1500])
print("NEIGH centre", c["neighbours"]["evidence"].get("centre"))
ph = c["neighbours"]["evidence"]["possible_hosts"]
print("NEIGH possible", len(ph), "table", len(c["neighbours"]["evidence"]["table"]))
for h in ph:
    print("  ", h["source_id"], round(h["sep_arcsec"], 2), round(h["required_depth"], 4), round(h.get("tmag", float("nan")), 2))
ev = t["evidence"]
print("TRIC", t.get("outcome"), "|", t.get("reason"))
for k in ("nfpp_mean", "nfpp_sd", "fpp_mean", "fpp_sd", "ephemeris_from", "ruwe", "contrast", "sectors"):
    print("TRIC", k, ev.get(k))
print("TRIC n runs", len(ev["nfpp"]), "last nfpp", ev["nfpp"][-1])
for h in ev["hosts"]:
    print("  H", h["tic"], h["source_id"], round(h["sep_arcsec"], 2), round(h["required_depth"], 4), round(h["tdepth"], 4), round(h["distance_arcsec"], 4))
zero = set(ev["hosts_tdepth_zero"])
zs = sorted(h["sep_arcsec"] for h in ev["hosts"] if h["source_id"] in zero)
print("TRIC zero", len(zero), [round(x, 2) for x in zs])
rows = list(csv.DictReader(open(f"{D}/probs.csv")))
nf = [r for r in rows if r["scenario"] in ("NTP", "NEB", "NEBx2P")]
print("PROBS nfpp sum", sum(float(r["prob"]) for r in nf))
for r in sorted(nf, key=lambda r: -float(r["prob"]))[:4]:
    print("  NF", r["ID"], r["scenario"], r["prob"])
for r in rows:
    if r["ID"] == "103312990": print("  T", r["scenario"], r["prob"])
L = json.load(open(f"{D}/literature.json"))
print("LIT keys", list(L))
print("LIT", json.dumps(L.get("outcome")), json.dumps(L.get("reason")))
