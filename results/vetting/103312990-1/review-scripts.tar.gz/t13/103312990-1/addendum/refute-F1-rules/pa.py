import json, csv, math, sys
D = sys.argv[1]
c = json.load(open(D + "/checks.json"))
nb = c["neighbours"] if "neighbours" in c else None
print("centre:", (nb or {}).get("evidence", {}).get("centre"))
star = c.get("star", {})
print("star keys:", sorted(star)[:40])
print("ruwe", star.get("ruwe"), "dr3", star.get("dr3_source_id"))
