import json, sys
D = sys.argv[1]
c = json.load(open(D + "/checks.json"))
def find(o, key, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == key: yield path + "/" + k, v
            yield from find(v, key, path + "/" + k)
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from find(v, key, path + f"[{i}]")
for p, v in find(c, "pixels"):
    s = json.dumps(v)
    print(p, s[:3000])
t = json.load(open(D + "/triceratops.json"))
print("TRIC keys", sorted(t))
for k in ("outcome","reason","blockers","nfpp","fpp","ephemeris_from","hosts_tdepth_zero","ruwe"):
    if k in t: print(k, json.dumps(t[k])[:1500])
