import json, sys
D = sys.argv[1]
t = json.load(open(D + "/triceratops.json"))
e = t["evidence"]
print("evidence keys", sorted(e))
for k in ("nfpp_mean","nfpp_sd","fpp_mean","fpp_sd","blockers","hosts_missing","hosts_tdepth_zero","runs"):
    if k in e: print(k, json.dumps(e[k])[:1200])
for h in e.get("hosts", []):
    print({k: h.get(k) for k in ("source_id","sep_arcsec","required_depth","tic","tdepth","distance_arcsec")})
