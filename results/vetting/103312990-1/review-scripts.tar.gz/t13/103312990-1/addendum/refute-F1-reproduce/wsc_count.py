"""Counts from which_star_cal.json: z <= -3 rates on the known planets and controls, and the candidate's best stars."""
import json
d = json.load(open("which_star_cal.json"))
for grp in ("known", "control"):
    n = hit = 0; planets = 0; multi = []
    for j in d:
        if j["group"] != grp: continue
        zs = [r["min_z"] for r in j["per_sector"] if r.get("min_z") is not None]
        if not zs: continue
        planets += 1; n += len(zs); k = sum(z <= -3 for z in zs); hit += k
        if k >= 2: multi.append(j["label"])
        near = [round(z, 3) for z in zs if -3.1 < z < -2.9]
        if near: print("  near -3:", j["label"], near)
    print(grp, "planets", planets, "sectors", n, "z<=-3", hit, "planets with 2+:", len(multi), multi)
for j in d:
    if j["label"] in ("103312990-1", "TOI-1058.01"):
        for r in j["per_sector"]:
            b = r.get("best") or {}
            print(j["label"], "S%s" % r["sector"], r.get("cam"), "min_z %.2f" % r["min_z"] if r.get("min_z") is not None else r.get("error"),
                  "best TIC", b.get("tic"), "sep %.1f" % b.get("sep", float("nan")),
                  "| all:", [(s["tic"], round(s["sep"], 1), round(s["z"], 2)) for s in r.get("stars", [])])
