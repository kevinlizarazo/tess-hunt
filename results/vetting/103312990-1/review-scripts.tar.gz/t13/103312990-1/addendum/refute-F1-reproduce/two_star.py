"""Which star dims: a fit of fixed-position PRFs (the target, a named neighbour and a constant) to each sector's
difference image, with the same fit on null images (no transit) for the noise.

Not the pixel check: the check fits one PRF anywhere. This holds the two catalogued positions fixed and asks how
much of the in-transit loss each star carries. Depths use each star's out-of-transit flux from the same two-PRF fit
to the mean out-of-transit image.

Usage: two_star.py OUT.json JOBS.json PAIRS.json, PAIRS mapping a job label to the neighbour's TIC.
"""
import json
import pickle
import sys
import warnings

import numpy as np

sys.path.insert(0, "/tmp/t13/103312990-1/addendum/refute-F1-reproduce")
from sector_detail import null_images, prf_model  # noqa: E402

warnings.filterwarnings("ignore")


def unit_prf(prf, cat, col, row):
    return prf.evaluate(col - float(cat["dCol"]) + 0.5, row - float(cat["dRow"]) + 0.5)


def solve(images_2d, basis):
    a = np.column_stack([b.ravel() for b in basis] + [np.ones(basis[0].size)])
    coef, *_ = np.linalg.lstsq(a, images_2d.ravel(), rcond=None)
    return coef


def main():
    out_path, jobs_path, pairs_path = sys.argv[1:4]
    pairs = json.load(open(pairs_path))
    results = []
    for job in json.load(open(jobs_path)):
        if job["label"] not in pairs:
            continue
        other = int(pairs[job["label"]])
        recs = []
        for s in job["sectors"]:
            path = f"{job['star_dir']}/imageData_{job['planet_id']}_sector{s}.pickle"
            with open(path, "rb") as fh:
                images, cat, pix, _, _, _, planet = pickle.load(fh)
            ids = np.asarray(cat["ticID"]).astype(int)
            if other not in ids:
                recs.append({"sector": s, "error": f"TIC {other} not on the cutout"})
                continue
            j = int(np.where(ids == other)[0][0])
            prf = prf_model(images, cat, pix)
            p_t = unit_prf(prf, cat, cat["ticColPix"][0], cat["ticRowPix"][0])
            p_o = unit_prf(prf, cat, cat["ticColPix"][j], cat["ticRowPix"][j])
            flux_t, flux_o, _ = solve(images["meanOutTransit"], [p_t, p_o])
            real = solve(images["diffImage"], [p_t, p_o])
            nulls = []
            for phase, _, img in null_images(pix, planet):
                if phase == 0.0 or not img or np.isnan(np.sum(img["diffImage"])):
                    continue
                nulls.append(solve(img["diffImage"], [p_t, p_o])[:2])
            nulls = np.array(nulls)
            sd_t, sd_o = (np.std(nulls, axis=0, ddof=1) if len(nulls) > 2 else (np.nan, np.nan))
            recs.append({
                "sector": int(s), "other_tic": other, "other_tmag": float(np.ma.filled(cat["ticMag"][j], np.nan)),
                "other_sep": float(np.ma.filled(cat["separation"][j], np.nan)),
                "flux_target": float(flux_t), "flux_other": float(flux_o),
                "amp_target": float(real[0]), "amp_other": float(real[1]),
                "snr_target": float(real[0] / sd_t), "snr_other": float(real[1] / sd_o),
                "depth_target": float(real[0] / flux_t), "depth_other": float(real[1] / flux_o) if flux_o > 0 else None,
                "n_nulls": int(len(nulls)),
                "null_sd_target": float(sd_t), "null_sd_other": float(sd_o),
            })
        results.append({"label": job["label"], "group": job["group"], "depth": job["depth"], "per_sector": recs})
    json.dump(results, open(out_path, "w"), indent=1)
    for r in results:
        print(f'== {r["label"]} ({r["group"]}) light-curve depth {r["depth"]}')
        for s in r["per_sector"]:
            if "error" in s:
                print("  ", s)
                continue
            dep_o = s["depth_other"]
            print(f'   S{s["sector"]:<4d} other TIC {s["other_tic"]} T{s["other_tmag"]:.2f} at {s["other_sep"]:.1f}": '
                  f'target SNR {s["snr_target"]:6.1f} depth {s["depth_target"] * 1e6:8.0f} ppm | '
                  f'other SNR {s["snr_other"]:6.1f} depth {"nan" if dep_o is None else f"{dep_o:.4f}"} '
                  f'(flux t/o {s["flux_target"]:.0f}/{s["flux_other"]:.0f}, nulls {s["n_nulls"]})')


if __name__ == "__main__":
    main()
