"""TRICERATOPS numbers F1 cites, from the rerun draft triceratops.json and probs.csv."""
import csv, json, statistics
D="$TESS_HUNT_DATA/drafts/m3-r2/103312990-1"
t=json.load(open(D+"/triceratops.json"))
ev=t["evidence"]
print("outcome", t["outcome"], "|", t["reason"], "| ephemeris_from", t["ephemeris_from"])
print("runs", ev["runs"], "len nfpp", len(ev["nfpp"]), "draws", ev["draws"], "sectors", ev["sectors"], "exposure", ev["exposure_s"])
print("nfpp_mean %.7f sd %.6f ; recomputed mean %.7f stdev(n-1) %.6f pstdev %.6f" % (ev["nfpp_mean"], ev["nfpp_sd"], statistics.mean(ev["nfpp"]), statistics.stdev(ev["nfpp"]), statistics.pstdev(ev["nfpp"])))
print("last-run nfpp", ev["nfpp"][-1])
for h in ev["hosts"][:5]:
    print("host TIC", h["tic"], "sep %.2f need %.2f%% tdepth %.2f%% dist %.2f" % (h["sep_arcsec"], 100*h["required_depth"], 100*h["tdepth"], h["distance_arcsec"]))
zero=set(ev["hosts_tdepth_zero"])
zs=[(round(h["sep_arcsec"],2), h["tic"], h["tdepth"]) for h in ev["hosts"] if h["source_id"] in zero]
print("zero-depth hosts", len(zero), sorted(zs))
print("nonzero tdepth hosts beyond 49:", [(round(h["sep_arcsec"],1),h["tic"]) for h in ev["hosts"] if h["sep_arcsec"]>49 and h["source_id"] not in zero])
print("n hosts", len(ev["hosts"]), "missing", ev["missing_hosts"])
rows=list(csv.DictReader(open(D+"/probs.csv")))
print("probs cols", list(rows[0].keys()))
nf=[r for r in rows if r["scenario"] in ("NTP","NEB","NEBx2P")]
print("NFPP sum from probs.csv (NTP+NEB+NEBx2P) %.6f" % sum(float(r["prob"]) for r in nf))
for r in sorted(nf, key=lambda r: -float(r["prob"]))[:5]:
    print("  ", r["ID"], r["scenario"], "%.5f" % float(r["prob"]))
