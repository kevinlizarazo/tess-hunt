"""Separations of every possible host in the rerun table from the target DR3 J2016 position: flat (as sep_dr3.py) and great-circle."""
import csv, math
ra0,dec0=156.82891262569836,-47.52064833343752
rows=list(csv.DictReader(open("$TESS_HUNT_DATA/drafts/m3-r2/103312990-1/neighbours.csv")))
def gc(r1,d1,r2,d2):
    r1,d1,r2,d2=map(math.radians,(r1,d1,r2,d2))
    s=math.sin((d2-d1)/2)**2+math.cos(d1)*math.cos(d2)*math.sin((r2-r1)/2)**2
    return math.degrees(2*math.asin(math.sqrt(s)))*3600
n=0
for r in rows:
    if r["possible"]!="True": continue
    n+=1
    ra,dec=float(r["ra"]),float(r["dec"])
    e=(ra-ra0)*math.cos(math.radians(dec0))*3600; nn=(dec-dec0)*3600
    tab=float(r["sep_arcsec"]); T=float(r["tmag"]); need=100*float(r["required_depth"])
    print(n, r["source_id"], "table %.3f flat %.3f gc %.3f T %.2f need %.2f%%" % (tab, math.hypot(e,nn), gc(ra0,dec0,ra,dec), T, need))
print("possible", n, "of", len(rows))
