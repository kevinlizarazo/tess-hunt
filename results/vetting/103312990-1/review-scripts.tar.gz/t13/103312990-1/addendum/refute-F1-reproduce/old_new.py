"""Compare drafts/m3 against drafts/m3-r2 for the numbers F1 says moved or held."""
import csv, json
for tag in ("m3","m3-r2"):
    D="$TESS_HUNT_DATA/drafts/%s/103312990-1" % tag
    ev=json.load(open(D+"/triceratops.json"))["evidence"]
    rows=list(csv.DictReader(open(D+"/neighbours.csv")))
    poss=[r for r in rows if r["possible"]=="True"]
    print(tag, "nfpp_mean %.7f sd %.6f runs %d" % (ev["nfpp_mean"], ev["nfpp_sd"], ev["runs"]), "hosts", len(ev["hosts"]), "zero", len(ev["hosts_tdepth_zero"]))
    print("  possible", len(poss), "seps", [round(float(r["sep_arcsec"]),2) for r in poss])
    print("  has 5365550055598557056:", any(r["source_id"]=="5365550055598557056" for r in rows), [ (r["sep_arcsec"], r["possible"]) for r in rows if r["source_id"]=="5365550055598557056"])
    z=set(ev["hosts_tdepth_zero"])
    print("  zero seps", sorted(round(h["sep_arcsec"],2) for h in ev["hosts"] if h["source_id"] in z))
    pr=list(csv.DictReader(open(D+"/probs.csv")))
    for r in pr:
        if (r["ID"],r["scenario"]) in (("103312997","NTP"),("864915227","NEB")): print("  ", r["ID"], r["scenario"], r["prob"])
