"""Per-transit look at the light curve: coverage, gaps near each transit, local depth on a linear baseline."""
import numpy as np
z=np.load("$TESS_HUNT_DATA/lc/103312990.npz")
t,f,e,s=z["time"],z["flux"],z["flux_err"],z["sector"]
P,T0,D=7.523158501215208,1545.9487439220118,0.1466011494226792
print("sectors and spans:")
for sec in np.unique(s):
    m=s==sec; tt=t[m]; dt=np.diff(tt); cad=np.median(dt)
    gaps=[(tt[i],tt[i+1]) for i in np.where(dt>5*cad)[0]]
    print(f" S{sec}: {tt.min():.3f}-{tt.max():.3f}, cadence {cad*86400:.0f}s, n {m.sum()}, gaps>5cad: "+", ".join(f"{a:.2f}-{b:.2f}" for a,b in gaps))
n0=int(np.floor((t.min()-T0)/P)); n1=int(np.ceil((t.max()-T0)/P))
rows=[]
for n in range(n0,n1+1):
    tc=T0+n*P
    near=np.abs(t-tc)<3*D
    if near.sum()==0: continue
    sec=int(np.bincount(s[near]).argmax())
    ms=s==sec
    cad=np.median(np.diff(t[ms]))
    intr=np.abs(t-tc)<D/2
    core=np.abs(t-tc)<D/4
    oot=(np.abs(t-tc)>0.75*D)&(np.abs(t-tc)<3*D)
    expected_in=D/cad
    # nearest data gap edge or sector edge to the transit
    tt=t[ms]; dt=np.diff(tt)
    edges=[tt.min(),tt.max()]+[x for i in np.where(dt>5*cad)[0] for x in (tt[i],tt[i+1])]
    dist=min(abs(x-tc) for x in edges)
    dep=np.nan; err=np.nan
    if core.sum()>=2 and oot.sum()>=6:
        A=np.vstack([np.ones(oot.sum()),t[oot]-tc]).T
        c,*_=np.linalg.lstsq(A,f[oot],rcond=None)
        base=c[0]+c[1]*(t[core]-tc)
        resid=f[oot]-(A@c)
        sd=np.std(resid,ddof=2)
        dep=np.mean(base-f[core]); err=sd/np.sqrt(core.sum())
    rows.append((n,sec,tc,intr.sum(),expected_in,dist,dep,err))
print("epoch sector mid  in-transit(n/expected)  nearest-edge(d)  core depth ppm (err)  snr")
for n,sec,tc,ni,ne,dist,dep,err in rows:
    print(f"{n:4d} S{sec:<3d} {tc:10.3f}  {ni:4d}/{ne:5.1f}  {dist:6.2f}  {dep*1e6:8.0f} ({err*1e6:5.0f})  {dep/err if err==err else float('nan'):5.2f}")
