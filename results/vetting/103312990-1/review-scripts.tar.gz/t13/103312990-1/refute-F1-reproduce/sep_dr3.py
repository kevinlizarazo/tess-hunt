"""Neighbour separations from the target's own Gaia DR3 position (J2016, gaia_q.py) to each DR3 neighbour (J2016)."""
import csv, math
ra0,dec0=156.82891262569836,-47.52064833343752
rows=list(csv.DictReader(open('$TESS_HUNT_DATA/drafts/m3/103312990-1/neighbours.csv')))
for r in rows:
    if r['possible']!='True': continue
    ra,dec=float(r['ra']),float(r['dec'])
    e=(ra-ra0)*math.cos(math.radians(dec0))*3600; n=(dec-dec0)*3600
    print(r['source_id'], f"table {float(r['sep_arcsec']):.2f}  DR3-DR3 {math.hypot(e,n):.2f}  E {e:+.1f} N {n:+.1f} PA {math.degrees(math.atan2(e,n))%360:.0f}  T {float(r['tmag']):.2f} need {float(r['required_depth']):.4f}")
