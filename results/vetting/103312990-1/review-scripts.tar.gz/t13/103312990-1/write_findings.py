import json
D = "$TESS_HUNT_DATA/drafts/m3/103312990-1"
S = "/tmp/t13/103312990-1"
RUN = "MSYS_NO_PATHCONV=1 wsl.exe -d Ubuntu-26.04 --cd /tmp/t13/103312990-1 -- bash -l -s, then P=~/code/tess-hunt/.venv/bin/python"
findings = [
 {"id": "F1", "lens": "on_star", "rating": "hold",
  "claim": "A nearby eclipsing binary 15\" to 57\" from the target can't be excluded: the pixel check passes near its 15\" limit with its fits leaning east toward possible hosts, and TRICERATOPS's NFPP of 0.0198 sits between its bars, near the two real nearby-binary controls, so only ground-based photometry that resolves the neighbours decides.",
  "evidence": (
   f"Pixel check ({D}/checks.json, pixels): offsets S9 14.4\", S10 20.7\", S36 13.1\" (quality 0.72, the sector triage judged; TESS-SPOC 600 s, not timing-suspect), S90 9.8\", S99 23.8\" (timing-suspect). "
   f"Refit of triage's saved difference images ($TESS_HUNT_DATA/tdi/20261015T155441Z-triage-7b12e25-3f57/103312990-1/) with the pixel diagnosis's scripts, copied to {S} ({RUN}; /tmp/t13/heavy.sh $P sector_detail.py detail.json jobs.json; $P summary.py detail.json candidate): "
   "fits east, north of the target S99 +22.9\", +6.6\"; S90 +9.8, +1.1; S36 +12.3, -4.7; S10 +16.7, +12.2; S9 -12.1, +7.8 (position angles 74, 84, 111, 54, 303 deg); quality-weighted mean +10.4, +3.8 (11.1\"), sky scatter 13.3\" against detector scatter 15.5\", so the sky-versus-detector test can't separate a source from noise. "
   "Mean offset in standard errors ($P stderr_cmp.py /tmp/pixel-diag/detail.json detail.json): 1.87, above every unsaturated known planet (1.42 at most; saturated TOI-144.01 4.02), below 295140687-1 (2.97, 'off-target source supported, weakly') and the three controls (7.83 to 26.61). "
   "No null image reaches any sector's quality (0 of 16 each; null median quality 0.12 to 0.30), so the images hold a real loss; box z at the target 3.9, 3.5, 3.9, 0.4, 2.6 against 5.1, 4.4, 3.3, 0.9, 2.6 expected for a transit on the target (S99, S90, S36, S10, S9): S10's image holds almost no transit, so its 20.7\" says nothing. "
   "Fixed two-PRF fits (/tmp/t13/heavy.sh $P two_star.py two_star.json jobs_pairs.json pairs.json; two_star.txt) with TIC 864915227, 103312987, 103312995, 103312997 or 864916052 as the neighbour: no neighbour reaches z 3 (1.7 at most), the target -0.2 to 2.8; the diagnosis's rate for a neighbour at z 3 or more above the target is 1 of 75 unsaturated known-planet sectors and 10 of 15 control sectors. "
   "A single-PRF target-versus-star comparison calibrated on null images (/tmp/t13/heavy.sh $P which_star_cal.py; which_star_cal.txt) prefers TIC 864915227 to the target at z -3.1 in S90 (camera 2.1) and S99 (camera 3.2), but gives z -3 or lower in 18 of 75 known-planet sectors (4 of 15 planets in two or more) and in only 1 of 5 sectors of TOI-1058.01's real 20.9\" binary, so it decides nothing. "
   f"Possible hosts, separations from the target's own DR3 position ($P sep_dr3.py), TESS mag, eclipse needed, TRICERATOPS tdepth ({D}/triceratops.json hosts): TIC 103312987 9.41\" (T 17.70, 65.0%, 68.6%), TIC 864915227 15.37\" (16.06, 14.4%, 16.1%), TIC 864916052 18.63\" (17.90, 77.9%, 82.5%), TIC 103312995 20.38\" (16.63, 24.3%, 29.7%), TIC 103312997 32.37\" (13.02, 0.87%, 1.53%), and 15 more about 35\" to 57\" out needing 6.4% to 98.1% (dossier's neighbour table); the one host inside 15\" needs a 65% eclipse. "
   f"TRICERATOPS ({D}/triceratops.json): mean NFPP 0.0198 (sd 0.00022) over 10 runs, between nfpp_pass 0.001 and nfpp_fail 0.1 (criteria/vet-v3.toml), so inconclusive even without the RUWE blocker; decision 0032's real binaries at 20.9\" and 23.5\" read 0.027 and 0.0341. Largest NFPP terms ({D}/probs.csv, last run): NTP on TIC 103312997 0.0048, NEB on TIC 864915227 0.0028. The six hosts it gave zero depth sit 50.1\" to 56.5\" out, beyond every pixel fit (23.8\" at most). Its NFPP comes from one ephemeris (density-prior fit) and can move with it (0032). "
   "Deciding evidence: ground-based seeing-limited photometry at a predicted transit (dossier windows in S110 to S113), which resolves every possible host (all 9.4\" or more out). 2-min data would not decide it: same pixels (0028).")},
 {"id": "F2", "lens": "on_star", "rating": "hold",
  "claim": "Gaia DR3 sees an unresolved companion (RUWE 6.21) that no public data identify, so whether the dip is on HD 297321 or on the companion, and how much the companion dilutes the depth and the radius, stays open until high-resolution imaging finds or bounds it.",
  "evidence": (
   f"Gaia archive TAP ({RUN}; $P -I gaia_q.py): source 5365550158677776896, RUWE 6.208, astrometric_excess_noise 0.73 mas at significance 891, ipd_frac_multi_peak 0 and ipd_gof_harmonic_amplitude 0.0073 (no resolved second peak), non_single_star 0 with no rows in nss_two_body_orbit, nss_acceleration_astro, nss_non_linear_spectro or nss_vim_fl; RVS over 29 transits rv_chisq_pvalue 0.077, rv_renormalised_gof 0.79, rv_amplitude_robust 3.93 km/s (not RV-variable by DR3's criteria); no vari_* rows. "
   "$P -I gaia_dr12.py: RV DR2 33.61 +- 0.44 and DR3 33.51 +- 0.24 km/s; proper motion TGAS (-48.46 +- 1.18, -55.83 +- 0.69), DR2 (-47.89 +- 0.10, -56.68 +- 0.12), DR3 (-47.85 +- 0.07, -56.53 +- 0.07) mas/yr, the same within about 1 sigma, so no long-term acceleration; DR2 excess noise 0.30 mas (sig 40); parallax DR2 7.753 +- 0.070, DR3 7.922 +- 0.069. "
   "SIMBAD (sim-id HD 297321): type PM*, no WDS name; ExoFOP live (target.php?id=103312990&json): no stellar companions, imaging or spectroscopy. "
   "So the companion is faint, very close or on a near face-on orbit, and Gaia can't say which. "
   f"Depth and radius if the dip is on the target: with the companion's TESS flux fraction f the true depth is the measured one over (1 - f) and Rp grows by 1/sqrt(1 - f), 5% at f = 0.1; the TIC radius 1.19 (M_G 4.54 = 10.047 + 5 log10(0.007922) + 5, read as one star) shrinks for a bright companion, which partly cancels. Rp now: 2.20 (1.97 to 2.53) Earth radii, density-prior fit ({D}/checks.json fit_prior). "
   f"Host: on the companion the eclipse is the measured depth over f (3.6% at f = 0.01); TRICERATOPS's STP 0.0355, PTP 0.176 and SEB 7.1e-5 ({D}/probs.csv, last run) use priors that don't know a companion is there (decision 0026's blocker). "
   "The shape limits a dense host: in the flat-prior fit (/tmp/t13/heavy.sh $P -I rho_post.py, on the vetting run's fit_samples.npz) 5.4% of the density posterior lies above an M0V's (0.57 Msun, 0.58 Rsun) and 0.01% above an M3V's (0.35, 0.36), circular orbits, so an M-dwarf host needs an eccentric orbit while a G or K companion host stays open. "
   "Deciding evidence: high-resolution imaging (speckle or AO) for a companion and its contrast, which TRICERATOPS can then take as a contrast curve (0026); Gaia DR4's epoch astrometry and RVs, when released, for its orbit.")},
 {"id": "F3", "lens": "real_new", "rating": "hold",
  "claim": "The dip is in every season at a steady depth, but vet-v3's held-out check can test only S9-10, so it stays inconclusive until a QLP redelivery of S99 or the S110 to S113 light curves give it a second testable season.",
  "evidence": (
   f"{D}/checks.json holdout: season 0 (S9-10) predicted, 5.79 sigma, tension 0.33; season 1 (S36) underpowered, expected SNR 3.32 under min_expected_snr 4.0; season 2 (S90, QLP) untestable, no QLP training cadences (decision 0023). "
   f"{D}/checks-with-suspect.json (evidence only): with S99 the QLP family has training cadences, S99 is predicted at 3.38 sigma (expected SNR 4.28, tension 0.69) and holdout passes on two seasons; S90 stays underpowered (3.50). "
   "Sector depths (both files): S9 343 +- 97, S36 322 +- 94, S90 333 +- 94, S99 309 +- 111 ppm. "
   f"Per transit ({RUN}; /tmp/t13/heavy.sh $P -I per_transit.py on $TESS_HUNT_DATA/lc/103312990.npz, local linear baseline, density-prior ephemeris, core half): all 15 measured transits positive, 14 between 234 and 612 ppm, none above 5.1 sigma; LEO-Vetter (triage evidence 103312990-1.json) MES 10.0 over 14 transits, max SES 4.45. "
   "Nothing failed, so 0031's causes (TTVs, a partly covered transit) don't arise; vet-v3 leaves S99 out for QLP's S99 to S104 timing (0022). "
   "Deciding evidence: a QLP redelivery of S99 with corrected timestamps, or new TESS sectors (tess-point gives S110 to S113).")},
 {"id": "F4", "lens": "planet", "rating": "note",
  "claim": "A 2.5-sigma dip at phase 0.5 (100 +- 40 ppm) is under the 3-sigma line, but if real it would be 28% of the primary, far past any occultation of a 2.2 Earth-radius planet, so it would mean an eclipsing binary; it looks like noise now and is worth watching in S110 to S113.",
  "evidence": (
   f"{D}/checks.json secondary: depth 1.004e-4, err 3.95e-5, 2.54 sigma, 116 cadences; {D}/checks-with-suspect.json: 78 +- 34 ppm, 2.33 sigma. Decision 0031 bounds the shortlist's own occultations at 15.2 ppm (albedo 1.0). "
   "LEO-Vetter's ModShift (triage evidence 103312990-1.json): strongest secondary at phase 0.121, 118 ppm, 3.01 sigma, under FA1 5.01 (implied albedo 55 +- 25); tertiary 2.58 sigma at phase 0.379 and the strongest positive feature 2.43 sigma at 0.424, Fred 1.09, so features this size sit at several phases.")},
 {"id": "F5", "lens": "planet", "rating": "note",
  "claim": "At 7 sigma the transit's shape and odd and even depths can't tell a diluted eclipsing binary at 7.52 or 15.05 days from a planet, so they add nothing against F1 and F2; nothing on the target itself looks like a binary.",
  "evidence": (
   f"Flat-prior fit ({D}/checks.json fit; rho_post.py): b 0.53, 16th to 84th percentile 0.16 to 0.87, grazing probability 0.0017; LEO-Vetter's fit (triage evidence) b 0.86 +- 0.20, trapezoid ingress fraction 0.15 +- 0.07. "
   "Odd and even (checks.json): pdcsap 478 +- 117 vs 321 +- 67 ppm (1.17 sigma), qlp 384 +- 131 vs 278 +- 137 (0.56), odd deeper in both; the inverse-variance mean of the two differences is 140 +- 110 ppm, so eclipses differing by under about 330 ppm (3 sigma) pass. LEO-Vetter over all 14 transits: odd 388 +- 58, even 395 +- 55 ppm. "
   "Density: flat-prior log rho 0.053 (+0.39, -0.65) against the TIC's -0.078 +- 0.094 (0.2 sigma). The search's other signal on the star, 33.213 d (ratio 4.41, SDE 9.6; checks.json other_signals), sits at no binary or novelty harmonic (1, 1/2, 2, 1/3, 3).")},
 {"id": "F6", "lens": "on_star", "rating": "note",
  "claim": "neighbours.csv's separations run from the target's J2000 TIC position, and the target moves 74 mas/yr, so each is off by up to 1.2\"; from the target's DR3 position the 14.5\" possible host is 15.37\" out, just past the pixel rule, and no outcome changes.",
  "evidence": (
   f"Target DR3 (gaia_q.py): ra 156.828913, dec -47.520648 (J2016), pm -47.85, -56.53 mas/yr; TIC ({D}/checks.json star): 156.829228, -47.520396, 1.19\" apart. $P sep_dr3.py: table to DR3 8.23 to 9.41\", 14.47 to 15.37\", 19.29 to 18.63\", 20.07 to 20.38\", 31.98 to 32.37\". "
   f"Required depths don't use the separation, and TRICERATOPS matched each host at J2000 within 0.0007\" to 0.09\" ({D}/triceratops.json hosts distance_arcsec). The dossier's centroid plot draws the 15.37\" star at 14.5\", inside the 15\" line.")},
 {"id": "F7", "lens": "real_new", "rating": "note",
  "claim": "Two literature hits list HD 297321 in a Gaia comoving pair, whose partner is degrees away and plays no part in the light curve; no hit or ExoFOP row names it a planet host, binary or variable or reports a signal near 7.52 d.",
  "evidence": (
   f"{D}/literature.json (7 hits, ADS by SIMBAD id). Oh et al. 2017 (2017AJ....153..257O) catalogue comoving TGAS pairs out to 10 pc (arXiv 1612.02440 abstract), and Bochanski et al. 2018 (2018AJ....155..149B) fit MIST isochrones to that catalogue's stars (arXiv 1801.00537 abstract); SIMBAD's TAP mesFe_H gives Bochanski's [Fe/H] 0.08 for this star. Flagged as membership of a multiple system. "
   f"Gaia DR3 ({RUN}; $P -I gaia_comove_2deg.py): no other star within 2 deg with parallax 6.4 to 9.4 mas and proper motion within 10 mas/yr of the target's; $P -I gaia_comove.py (6 deg, within 12 mas/yr, G under 13) finds two, 4.1 deg and 5.9 deg away. "
   "Ruiz-Dern et al. 2018 (2018A&A...609A.116R) calibrate the red clump and selected low-reddening red giants (arXiv 1710.05803 abstract), yet this star is a dwarf (M_G 4.54 from the DR3 parallax, TIC logg 4.29, FLAME logg 4.28, and the transit density in F5); its catalogue row couldn't be read because VizieR answered 'The database is not currently reachable' on 2026-10-20, so how it entered that list is unconfirmed. Dismissed. "
   "The other four are star catalogues (HDE charts, spectral type K0; JSDC v2; mid-infrared diameters; Cape astrographic zone). "
   "ExoFOP live (target.php?id=103312990&json, 2026-10-20): no TOIs, CTOIs, planet parameters, imaging, spectroscopy or stellar companions; SIMBAD lists no WDS or variable name.")},
 {"id": "F8", "lens": "real_new", "rating": "note",
  "claim": "No artefact explains the dip: no transit sits near a gap or sector edge except S36's epoch 101, 0.20 d before the sector ends and the one transit without a dip, only S90's epoch 296 lost more than one in-transit cadence (7 of 63), and no sector dominates the fold.",
  "evidence": (
   f"/tmp/t13/heavy.sh $P -I per_transit.py ({RUN}): in-transit cadences present as expected in 13 of 15 transits (epoch 296 56 of 63, epoch 101 20 of 21; the vet's light curve keeps only good-quality cadences, n_good in checks.json sources); nearest gap or sector edge 0.97 d or more for every transit but epoch 101 (0.20 d, 53 +- 127 ppm) and epoch 3 (S9's end, 1 of 7 cadences, unmeasured). "
   "Sector depths 343, 322, 333 and 309 ppm (F3); the largest single transit is epoch 295 (S90), 612 +- 120 ppm. "
   f"Red-noise beta is 1.0 for S9 and S10 by default (2 cadences per bin, need 3; {D}/checks.json red_noise), so their errors were not tested for red noise.")},
]
out = {
 "signal": "103312990-1",
 "summary": ("Tested all three lenses on 103312990-1 (HD 297321; 2.2 Earth radii at 7.52 d, 7.1 sigma), refitting triage's difference images and reading Gaia, SIMBAD and ExoFOP. "
             "Nothing kills it: the dip is in every sector at a steady depth, shows no binary signature on the target, and is not known. "
             "It is held on three counts: a nearby binary within 1' that the pixels and TRICERATOPS can't exclude (ground-based photometry decides), Gaia's unresolved companion at RUWE 6.21 (high-resolution imaging decides), and a held-out check with one testable season (a QLP S99 redelivery or S110 to S113 decide)."),
 "findings": findings,
 "hits_flagged": ["doi 10.3847/1538-3881/aa6ffd, arXiv 1612.02440", "doi 10.3847/1538-3881/aaaebe, arXiv 1801.00537"],
}
txt = json.dumps(out, indent=1, ensure_ascii=False)
assert "—" not in txt and "–" not in txt
open("/tmp/t13/103312990-1/findings.json", "w").write(txt + "\n")
print(len(findings), "findings written")
