import numpy as np
z=np.load("$TESS_HUNT_DATA/lc/103312990.npz", allow_pickle=False)
for k in z.files:
    a=z[k]; print(k, a.dtype, a.shape, a[:3] if a.ndim==1 else '')
