import warnings; warnings.filterwarnings("ignore")
from astroquery.vizier import Vizier
v=Vizier(columns=["**"],row_limit=2)
for src in ["J/AJ/153/257","J/AJ/155/149","J/A+A/609/A116","J/MNRAS/506/2269"]:
    try:
        cats=v.get_catalogs(src)
    except Exception as e:
        print(src,"ERR",e); continue
    for t in cats:
        print("==",t.meta.get("name"),t.colnames)
        t.pprint(max_width=300)
