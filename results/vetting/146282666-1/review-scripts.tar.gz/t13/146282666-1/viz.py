import warnings
warnings.filterwarnings("ignore")
from astroquery.vizier import Vizier
from astroquery.simbad import Simbad
import astropy.units as u
from astropy.coordinates import SkyCoord
c = SkyCoord(35.98821, -34.10994, unit="deg")
s = Simbad(); s.add_votable_fields("sp", "otype", "otypes", "ids")
try:
    r = s.query_object("HD 14989")
    print(r.colnames); print(r)
except Exception as ex:
    print("simbad", ex)
v = Vizier(columns=["**"], row_limit=50)
for cat in ["J/MNRAS/512/L60", "III/283", "II/361", "J/A+A/609/A116", "III/80", "III/133", "B/wds/wds", "B/vsx/vsx", "J/ApJS/258/16", "I/358/vclassre", "J/A+AS/37/367", "II/215"]:
    try:
        res = v.query_region(c, radius=30 * u.arcsec, catalog=cat)
        if len(res) == 0:
            print(f"== {cat}: nothing within 30\"")
        for tab in res:
            print(f"== {cat} -> {tab.meta.get('name', '')} ({len(tab)} rows)")
            for row in tab:
                print("   " + "; ".join(f"{k}={row[k]}" for k in tab.colnames)[:1500])
    except Exception as ex:
        print(f"== {cat}: error {ex!r}"[:300])
