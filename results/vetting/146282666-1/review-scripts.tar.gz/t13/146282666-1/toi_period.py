"""Linear ephemeris through the six dips' best 7.7-h box times from lc_toi.txt (n = 0, 25, 97, 98, 99, 100)."""
import numpy as np
n = np.array([0, 25, 97, 98, 99, 100])
t = np.array([1398.356, 2120.658, 4201.240, 4230.150, 4259.040, 4287.943])
A = np.vstack([np.ones_like(n), n]).T.astype(float)
(c, p), *_ = np.linalg.lstsq(A, t, rcond=None)
print(f"T0 {c:.4f}  P {p:.5f}  722.26198/25 = {722.2619756368/25:.5f}")
print("residuals (h):", " ".join(f"{(t[i]-c-p*n[i])*24:+.1f}" for i in range(len(n))))
print(f"P / ours = {p/9.995091231532186:.4f}")
for k in (101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111):
    print(f"  n={k}: {c+p*k:.2f}", end="")
print()
