import numpy as np
from astropy.coordinates import AltAz, EarthLocation, SkyCoord, get_sun
from astropy.time import Time
import astropy.units as u

P, sP, T0, sT0 = 9.995026, 2.5e-5, 1389.3286, 0.0061  # density-prior fit, BTJD
dur = 0.1875  # search box, days
star = SkyCoord("02h23m57.15s", "-34d06m33.8s")
sites = {
    "CTIO/LaSilla": EarthLocation(lat=-30.169 * u.deg, lon=-70.806 * u.deg, height=2207 * u.m),
    "SAAO": EarthLocation(lat=-32.38 * u.deg, lon=20.81 * u.deg, height=1798 * u.m),
    "SidingSpring": EarthLocation(lat=-31.273 * u.deg, lon=149.064 * u.deg, height=1165 * u.m),
}
now = Time("2027-06-01T00:00:00", scale="utc")
end = Time("2027-12-31T00:00:00", scale="utc")
n0 = int(np.ceil((now.jd - 2457000 - T0) / P))
n1 = int((end.jd - 2457000 - T0) / P)
for n in range(n0, n1 + 1):
    mid_btjd = T0 + n * P
    sd_min = np.hypot(sT0, n * sP) * 1440
    mid = Time(mid_btjd + 2457000, format="jd", scale="tdb").utc
    t = mid + np.linspace(-dur / 2 - 1 / 24, dur / 2 + 1 / 24, 61) * u.day
    row = [f"E{n} {mid.iso[:16]} UT (sd {sd_min:.0f} min)"]
    for name, loc in sites.items():
        frame = AltAz(obstime=t, location=loc)
        ok = (star.transform_to(frame).alt > 30 * u.deg) & (get_sun(t).transform_to(frame).alt < -12 * u.deg)
        # in-transit part only
        intr = np.abs((t - mid).to_value(u.day)) <= dur / 2
        row.append(f"{name} {ok.mean():.0%} (in-transit {ok[intr].mean():.0%})")
    print("; ".join(row))
