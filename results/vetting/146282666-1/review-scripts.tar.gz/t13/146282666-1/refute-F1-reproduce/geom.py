import json, sys, numpy as np
d=json.load(open(sys.argv[1]))[0]
for s in d['per_sector']:
    cat={c['tic']:c for c in s['catalogue']}
    t=s['catalogue'][0]
    def en(c): return ((c['ra']-t['ra'])*np.cos(np.radians(t['dec']))*3600, (c['dec']-t['dec'])*3600)
    a,b=cat.get(146282669),cat.get(632015732)
    n=cat.get(632015734)
    out=f"S{s['sector']} target tic {t['tic']}"
    if a and b:
        ea,eb=en(a),en(b); out+=f" pair sep {np.hypot(ea[0]-eb[0],ea[1]-eb[1]):.2f}"
    if n:
        en_=en(n); out+=f" nb E,N {en_[0]:.2f},{en_[1]:.2f} sep {np.hypot(*en_):.2f}"
    print(out)
P=np.array([(s['fit']['east'],s['fit']['north'],s['fit']['quality']) for s in d['per_sector']])
m=np.average(P[:,:2],axis=0,weights=P[:,2])
s106=[s for s in d['per_sector'] if s['sector']==106][0]
t=s106['catalogue'][0]; n=[c for c in s106['catalogue'] if c['tic']==632015734][0]
ne=((n['ra']-t['ra'])*np.cos(np.radians(t['dec']))*3600,(n['dec']-t['dec'])*3600)
print('mean',m,'to target',np.hypot(*m),'to neighbour',np.hypot(m[0]-ne[0],m[1]-ne[1]))
f=s106['fit']; print('S106 fit to neighbour', np.hypot(f['east']-ne[0], f['north']-ne[1]))
for s in d['per_sector']:
    f=s['fit']; print(s['sector'], round(f['east'],2), round(f['north'],2), round(f['offset'],2), round(f['quality'],3))
