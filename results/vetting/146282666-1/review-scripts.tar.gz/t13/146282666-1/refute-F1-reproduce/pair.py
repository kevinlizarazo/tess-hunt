import json, numpy as np
e=json.load(open('$TESS_HUNT_DATA/drafts/m3-r2/146282666-1/triceratops.json'))['evidence']
st={s['ID']:s for s in e['stars']}
a,b=st['146282669'],st['632015732']
print('TRICERATOPS stars pair sep', np.hypot((a['ra']-b['ra'])*np.cos(np.radians(a['dec'])), a['dec']-b['dec'])*3600)
h={x['tic']:x for x in e['hosts']}
a,b=h['146282669'],h['632015732']
print('hosts ra_2000 pair sep', np.hypot((a['ra_2000']-b['ra_2000'])*np.cos(np.radians(a['dec_2000'])), a['dec_2000']-b['dec_2000'])*3600)
print('NEB alone share', 0.00047421578437190266/0.00152924)
