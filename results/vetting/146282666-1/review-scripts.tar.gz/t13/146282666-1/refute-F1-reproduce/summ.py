import json, numpy as np
d=json.load(open('/tmp/t13/146282666-1/refute-F1-reproduce/detail.json'))[0]
neigh={632015734:'6.0" T15.36',146282663:'69" T11.59',146282669:'32.5" T15.61',632015732:'33.2" T15.82',632016189:'31.4" T17.98',146283232:'92" T12.98'}
pts=[]
for s in d['per_sector']:
    if 'error' in s: print(s); continue
    f=s['fit']
    tgt=s['catalogue'][0]
    nulls=[n for n in s['nulls'] if n.get('ok') and n['phase']>0]
    nb=np.array([n['box_snr'] for n in nulls]); nq=np.array([n['quality'] for n in nulls]); no=np.array([n['offset'] for n in nulls])
    rep=[n.get('reproduces_saved_image') for n in s['nulls'] if n['phase']==0.0]
    print(f"S{s['sector']} cam{s['camera']} ccd{s['ccd']}: fit E {f['east']:6.1f} N {f['north']:6.1f} off {f['offset']:5.1f} Q {f['quality']:.3f} | transits_used {s['transits_used']} n_in {s['n_in']} | target box z {s['target_box']['snr']:.2f} exp {s['expected_snr']:.2f} depth_ratio {s['depth_ratio']:.2f} | nulls {len(nulls)} box-z mean {nb.mean():.2f} sd {nb.std(ddof=1):.2f} z/nullsd {s['target_box']['snr']/nb.std(ddof=1):.2f} nulls>=Q {int((nq>=f['quality']).sum())} null offsets med {np.median(no):.1f} | reproduces {rep} | peak {s['saturation']['peak_e_s']:.0f} colhalfmax {s['saturation']['column_half_max_px']}")
    print('   near_fit', [(n['tic'], round(n['sep_from_fit'],1), round(n['sep_from_target'],1), round(n['tmag'],2), round(n['needed_depth'],4)) for n in s['near_fit']])
    pts.append((f['east'],f['north'],f['quality']))
    for c in s['catalogue']:
        if c['tic'] in neigh:
            ce=(c['ra']-tgt['ra'])*np.cos(np.radians(tgt['dec']))*3600; cn=(c['dec']-tgt['dec'])*3600
            if s['sector']==106: print(f"      neighbour TIC {c['tic']} {neigh[c['tic']]}: E {ce:6.1f} N {cn:6.1f}")
P=np.array(pts); w=P[:,2]
m=np.average(P[:,:2],axis=0,weights=w)
sc=np.sqrt(np.average(np.sum((P[:,:2]-m)**2,axis=1),weights=w))
print('quality-weighted mean fit E/N', m.round(1), 'offset', np.hypot(*m).round(1), 'sky scatter', sc.round(1), 'mean in std errors', (np.hypot(*m)/(sc/np.sqrt(len(P)))).round(2))
