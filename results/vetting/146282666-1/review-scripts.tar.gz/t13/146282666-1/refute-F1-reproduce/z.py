import json
for r in json.load(open('/tmp/t13/146282666-1/refute-F1-reproduce/two_star.json')):
    print(r['label'], 'other z', [round(s['snr_other'],2) for s in r['per_sector']], 'target z', [round(s['snr_target'],2) for s in r['per_sector']], 'flux_other', [round(s['flux_other']) for s in r['per_sector']])
d=json.load(open('/tmp/t13/146282666-1/refute-F1-reproduce/detail.json'))[0]
print('box z / null sd', [round(s['target_box']['snr']/__import__('numpy').std([n['box_snr'] for n in s['nulls'] if n.get('ok') and n['phase']>0], ddof=1),2) for s in d['per_sector']])
# expected flux of a T 15.36 star relative to the target's fitted flux
for r in json.load(open('/tmp/t13/146282666-1/refute-F1-reproduce/two_star.json'))[:1]:
    print('T15.36 flux from target fit', [round(s['flux_target']*10**(-0.4*(s['other_tmag']-9.1259))) for s in r['per_sector']], 'from 15000*10^(-0.4(T-10))', round(15000*10**(-0.4*(15.3646-10))))
