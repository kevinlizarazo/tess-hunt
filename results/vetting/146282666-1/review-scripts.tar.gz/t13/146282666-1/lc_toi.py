"""Read-only: TOI-4298.01's dips and the other single dips on TIC 146282666, against our transits.

The light curve is detrended as vet-v3 does it (search-v2's biweight) but with nothing masked and every window below
held out of the trend (kept, the trend interpolated across it), so no dip is eaten by the trend. Prints 1-hour bins
around each event and the depth in a sliding 0.3-d box, and draws them.

Usage (repo root): lc_toi.py CHECKS.json LC.npz OUT.png
"""
import json
import sys
import tomllib

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from tess_hunt.checks.photometry import box_depth
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1]))
lc = LightCurve.load(sys.argv[2])
out_png = sys.argv[3]
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
e0 = checks["ephemeris"]
box = Ephemeris(e0["period"], e0["t0"], e0["duration"])
ours = [box.t0 + n * box.period for n in checks["catalogued"]["transits"]]
events = {
    "TOI S3": 1398.396, "TOI S30": 2120.658, "S104 dip": 4201.30, "S105 (28.9 d guess)": 4230.15,
    "S106 dip A": 4236.91, "S106 dip B": 4259.04, "TOI S107 (722 d)": 4287.443,
}
hold = np.zeros(len(lc.time), bool)
for tc in list(events.values()) + ours:
    hold |= np.abs(lc.time - tc) < 0.45
flat = detrend(lc, crit["detrend"], [], hold_out=hold)
ok = np.isfinite(flat.flux) & np.isfinite(flat.flux_err)
t, f, e = flat.time[ok], flat.flux[ok], flat.flux_err[ok]


def binned(tc, half=1.0, width=1 / 24):
    edges = np.arange(tc - half, tc + half + 1e-9, width)
    out = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (t >= lo) & (t < hi)
        if m.sum() < 5:
            out.append((0.5 * (lo + hi), np.nan, np.nan))
            continue
        w = 1 / e[m] ** 2
        out.append((0.5 * (lo + hi), (1 - np.sum(w * f[m]) / np.sum(w)) * 1e6, 1e6 / np.sqrt(np.sum(w))))
    return np.array(out)


def scan(tc, dur, half=0.8, step=0.02):
    best = None
    for c in np.arange(tc - half, tc + half + 1e-9, step):
        d, s, n = box_depth(t, f, e, Ephemeris(1e4, c, dur), 1.0)
        if n >= 0.6 * dur * 720 and (best is None or d / s > best[1] / best[2]):
            best = (c, d, s, n)
    return best


targets = dict(events)
targets["our 290"] = box.t0 + 290 * box.period
fig, axes = plt.subplots(len(targets), 1, figsize=(9, 2.2 * len(targets)), sharey=True)
for ax, (label, tc) in zip(axes, targets.items()):
    b = binned(tc)
    if np.all(np.isnan(b[:, 1])):
        print(f"{label} {tc:.3f}: no data")
        continue
    for dur in (0.1875, 0.3214):
        best = scan(tc, dur)
        if best:
            c, d, s, n = best
            print(f"{label} {tc:.3f}: best {dur*24:.1f}-h box at {c:.3f} ({(c-tc)*24:+.1f} h): {d*1e6:5.0f} +- {s*1e6:3.0f} ppm (z {d/s:4.1f}, n {n})")
    near = [o for o in ours if abs(o - tc) < 1.0]
    print("   our transits within 1 d: " + ", ".join(f"{o:.3f} ({(o-tc)*24:+.1f} h)" for o in near))
    print("   1-h bins (ppm below 1), -12 h to +12 h: " + " ".join("nan" if np.isnan(x) else f"{x:.0f}" for x in b[12:36, 1]))
    ax.errorbar((b[:, 0] - tc) * 24, b[:, 1], b[:, 2], fmt="o", ms=3)
    for o in near:
        ax.axvspan((o - tc) * 24 - box.duration * 12, (o - tc) * 24 + box.duration * 12, color="C1", alpha=0.2)
    ax.axhline(0, color="k", lw=0.5)
    ax.set_title(f"{label}, t {tc:.3f} (our transits shaded)", fontsize=9)
    ax.invert_yaxis()
axes[-1].set_xlabel("hours from t")
fig.supylabel("ppm below 1")
fig.tight_layout()
fig.savefig(out_png, dpi=80)

print("\n== a strict period through the four dips: least squares on n = 0, 25, 97, 99")
n = np.array([0, 25, 97, 99]); tt = np.array([1398.396, 2120.658, 4201.30, 4259.04])
A = np.vstack([np.ones(4), n]).T
(c0, p), res, *_ = np.linalg.lstsq(A, tt, rcond=None)
print(f"T0 {c0:.3f}, P {p:.5f}; residuals (h): " + " ".join(f"{(tt[i]-c0-p*n[i])*24:+.1f}" for i in range(4)))
for k in (98, 100):
    print(f"  predicted n={k}: {c0 + p*k:.3f}")
print("TOI's own ephemeris at P/25: " + " ".join(f"n={k}: {1398.395589 + k*722.2619756368/25:.3f}" for k in (97, 98, 99, 100)))
