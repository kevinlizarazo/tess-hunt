import json
from astroquery.mast import Catalogs
d = json.load(open('$TESS_HUNT_DATA/drafts/m3-r2/146282666-1/triceratops.json'))
ids = [int(s['ID']) for s in d['evidence']['stars']]
t = Catalogs.query_criteria(catalog='TIC', ID=ids)
cols = ['ID','Tmag','ra','dec','disposition','duplicate_id','GAIA','objType','mass','rad','Teff','plx','pmRA','pmDEC','d','lumclass']
for r in t:
    print({c: (str(r[c]) if c in t.colnames else None) for c in cols})
