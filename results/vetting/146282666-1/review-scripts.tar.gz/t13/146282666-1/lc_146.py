"""Read-only light-curve checks for 146282666-1 on the light curve vet-v3 saw.

Per-epoch depths and their scatter; each transit's coverage, edges and quality-flagged cadences nearby (momentum
dumps); TOI-4298.01's mask and its predicted S107 transit; the single dips SPOC's one-sector TCEs paired with our
transits; ModShift's phase-0.339 secondary by epoch; and a star-specific null for the fold.

Usage (repo root): lc_146.py CHECKS.json LC.npz FITS_DIR
"""
import glob
import json
import sys
import tomllib

import numpy as np
from astropy.io import fits
from astropy.timeseries import BoxLeastSquares
from scipy.stats import chi2 as c2

from tess_hunt.checks.photometry import box_depth
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris, in_transit
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1]))
lc = LightCurve.load(sys.argv[2])
fits_dir = sys.argv[3]
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
seen = lc.select(~np.isin(lc.sector, checks["dropped_suspect"]))
masked = [Ephemeris(**m) for m in checks["masked"]]
flat = detrend(seen, crit["detrend"], masked)
ok = np.isfinite(flat.flux) & np.isfinite(flat.flux_err)
t, f, e, sec = flat.time[ok], flat.flux[ok], flat.flux_err[ok], flat.sector[ok]
# The same light curve with nothing masked, to look inside TOI-4298.01's windows.
flat0 = detrend(seen, crit["detrend"], [])
ok0 = np.isfinite(flat0.flux) & np.isfinite(flat0.flux_err)
t0_, f0_, e0_, s0_ = flat0.time[ok0], flat0.flux[ok0], flat0.flux_err[ok0], flat0.sector[ok0]

e0 = checks["ephemeris"]
box = Ephemeris(e0["period"], e0["t0"], e0["duration"])
fp = checks["fit_prior"]["ephemeris"]
fitp = Ephemeris(fp["period"]["median"], fp["t0"]["median"], checks["window_duration"]["days"])
toi = Ephemeris(722.2619756368, 1398.395589, 0.3213595741358792)
print("box", box)
print("fit_prior", fitp)
print(f"cadences {len(t)} (masked LC), {len(t0_)} (nothing masked)")


def depth(mask, eph, frac=0.5, tt=None, ff=None, ee=None):
    tt = t if tt is None else tt
    ff = f if ff is None else ff
    ee = e if ee is None else ee
    return box_depth(tt[mask], ff[mask], ee[mask], eph, frac)


def line(label, d):
    print(f"{label}: depth {d[0]*1e6:7.1f} +- {d[1]*1e6:5.1f} ppm, n {d[2]}, z {d[0]/d[1]:5.2f}")


# Quality flags straight from the SPOC files (fetch read them with lightkurve's default bitmask).
qual = {}
for path in sorted(glob.glob(f"{fits_dir}/*_lc.fits")):
    with fits.open(path) as h:
        s = int(h[0].header["SECTOR"])
        d = h[1].data
        qual[s] = (np.asarray(d["TIME"], float), np.asarray(d["QUALITY"], int))
dumps = {s: tq[0][(tq[1] & 32) != 0] for s, tq in qual.items()}
dumps = {s: np.unique(np.round(x[np.isfinite(x)], 2)) for s, x in dumps.items()}
print("\n== momentum dumps (QUALITY bit 32) per sector, start-end of data")
for s, (tt, q) in sorted(qual.items()):
    fin = np.isfinite(tt)
    dd = dumps[s]
    # group consecutive dump cadences
    groups = []
    for x in dd:
        if not groups or x - groups[-1][-1] > 0.05:
            groups.append([x])
        else:
            groups[-1].append(x)
    print(f"S{s}: data {tt[fin].min():.2f}-{tt[fin].max():.2f}; dumps at " + ", ".join(f"{g[0]:.2f}" for g in groups))

print("\n== per epoch (box ephemeris; core = central half)")
ep = np.round((t - box.t0) / box.period).astype(int)
rows = []
for n in checks["catalogued"]["transits"]:
    m = ep == n
    tc = box.t0 + n * box.period
    s = int(sec[m][0])
    d = depth(m, box)
    df = depth(m, fitp)
    near = np.abs(t[m] - tc)
    win = m & (np.abs(t - tc) < 3 * box.duration)
    pre = int(np.sum(win & (t < tc - box.duration / 2)))
    post = int(np.sum(win & (t > tc + box.duration / 2)))
    full = int(np.sum(m & in_transit(t, box, 1.0)))
    tq, q = qual[s]
    dd = dumps[s]
    ddist = (dd - tc) * 24 if len(dd) else np.array([np.nan])
    nearest = ddist[np.argmin(np.abs(ddist))]
    flagged = np.isfinite(tq) & (np.abs(tq - tc) < 0.375) & ((q & 175) != 0)
    tmin, tmax = qual[s][0][np.isfinite(qual[s][0])].min(), qual[s][0][np.isfinite(qual[s][0])].max()
    rows.append((n, s, d[0], d[1], d[2]))
    print(f"epoch {n:3d} S{s:<3d} t {tc:9.3f} box {d[0]*1e6:6.0f} +- {d[1]*1e6:4.0f} (n {d[2]:3d}) fitp {df[0]*1e6:6.0f} +- {df[1]*1e6:4.0f} |"
          f" in-transit {full:3d}/{int(round(box.duration*720))} pre {pre:3d} post {post:3d} | nearest dump {nearest:+7.1f} h |"
          f" flagged within 9 h {int(flagged.sum()):3d} | from sector start {tc-tmin:5.2f} d, to end {tmax-tc:5.2f} d")
ds = np.array([r[2] for r in rows]); ss = np.array([r[3] for r in rows])
w = 1 / ss**2
mean = np.sum(w * ds) / np.sum(w)
chi2 = np.sum(((ds - mean) / ss) ** 2)
print(f"per-epoch (white errors) chi2 about {mean*1e6:.0f} ppm: {chi2:.1f} on {len(ds)-1} dof, p = {c2.sf(chi2, len(ds)-1):.3g}")
for n, s, d, err, k in rows:
    print(f"  epoch {n}: {(d-mean)/err:+.2f} sigma")
loo = []
for i in range(len(rows)):
    keep = np.ones(len(rows), bool); keep[i] = False
    loo.append(np.sum(w[keep] * ds[keep]) / np.sqrt(np.sum(w[keep])))
print("leave-one-epoch-out combined z (white):", " ".join(f"{rows[i][0]}:{loo[i]:.1f}" for i in range(len(rows))))
line("all (white errors)", depth(np.ones(len(t), bool), box))
line("without epoch 290", depth(ep != 290, box))
line("odd epochs", depth(ep % 2 == 1, box))
line("even epochs", depth(ep % 2 == 0, box))
line("even without 290", depth((ep % 2 == 0) & (ep != 290), box))

print("\n== TOI-4298.01 (722.26 d) windows, nothing masked")
for k in range(0, 5):
    tc = toi.t0 + k * toi.period
    m = np.abs(t0_ - tc) < 1.5
    if m.sum() == 0:
        print(f"TOI epoch {k} t {tc:.3f}: no data")
        continue
    d = depth(m, toi, 0.5, t0_, f0_, e0_)
    ours = (tc - box.t0) / box.period
    print(f"TOI epoch {k} t {tc:.3f} (our phase {ours % 1:.3f}, our epoch {ours:.2f}): core depth {d[0]*1e6:6.0f} +- {d[1]*1e6:4.0f} ppm (n {d[2]})")
# S107: the masked window against our transit 290
tc290 = box.t0 + 290 * box.period
tct = toi.t0 + 4 * toi.period
print(f"S107: TOI predicted mid {tct:.4f}, egress {tct+toi.duration/2:.4f}; mask {tct-toi.duration:.4f} to {tct+toi.duration:.4f};"
      f" our 290 ingress {tc290-box.duration/2:.4f} (box), {fitp.t0+290*fitp.period-fitp.duration/2:.4f} (fit_prior)")
m = (np.abs(t - tc290) < 0.5)
print(f"  masked LC near 290: first cadence {t[m].min():.4f} ({(t[m].min()-tc290)*24:+.2f} h), last {t[m].max():.4f} ({(t[m].max()-tc290)*24:+.2f} h)")
for lo, hi in ((-0.30, -0.10), (-0.10, 0.10), (0.10, 0.30), (0.30, 0.50)):
    mm = (t0_ - tc290 > lo) & (t0_ - tc290 <= hi)
    w0 = 1 / e0_[mm] ** 2
    print(f"  unmasked LC, {lo*24:+.1f} to {hi*24:+.1f} h from 290: mean {(1-np.sum(w0*f0_[mm])/np.sum(w0))*1e6:6.0f} +- {1e6/np.sqrt(np.sum(w0)):4.0f} ppm below 1 (n {mm.sum()})")
for lo, hi in ((-1.2, -0.9), (-0.9, -0.6), (-0.6, -0.3)):
    mm = (t0_ - tc290 > lo) & (t0_ - tc290 <= hi)
    if mm.sum():
        w0 = 1 / e0_[mm] ** 2
        print(f"  unmasked LC, {lo*24:+.1f} to {hi*24:+.1f} h from 290: mean {(1-np.sum(w0*f0_[mm])/np.sum(w0))*1e6:6.0f} +- {1e6/np.sqrt(np.sum(w0)):4.0f} ppm below 1 (n {mm.sum()})")
d290m = depth(ep == 290, box)
ep0 = np.round((t0_ - box.t0) / box.period).astype(int)
d290u = depth(ep0 == 290, box, 0.5, t0_, f0_, e0_)
line("epoch 290, TOI masked (vet)", d290m)
line("epoch 290, nothing masked", d290u)

print("\n== single dips SPOC's one-sector TCEs paired with ours (nothing masked; each TCE's duration)")
events = [("S3 TCE 2nd event = TOI", 1398.40, 0.2573), ("S30 TCE 1st event = TOI", 2120.66, 0.3191),
          ("S104 TCE 2nd event", 4187.93 + 13.3718, 0.2088), ("S104 TCE 3rd event?", 4187.93 + 2 * 13.3718, 0.2088),
          ("S106 TCE 1st event", 4236.91, 0.3639), ("S106 TCE 2nd event", 4236.91 + 22.1285, 0.3639),
          ("S30 TCE 2nd event", 2120.66 + 18.3425, 0.3191), ("S3 TCE 1st event", 1389.33, 0.2573)]
for label, tc, dur in events:
    eph = Ephemeris(1000.0, tc, dur)
    m = np.abs(t0_ - tc) < 1.0
    if m.sum() == 0:
        print(f"{label} t {tc:.2f}: no data")
        continue
    d = depth(m, eph, 0.5, t0_, f0_, e0_)
    ph = ((tc - box.t0) / box.period) % 1
    print(f"{label} t {tc:.2f} (our phase {ph:.3f}): core depth {d[0]*1e6:6.0f} +- {d[1]*1e6:4.0f} ppm (n {d[2]})")

print("\n== ModShift secondary phase 0.339 and tertiary 0.895, by epoch (masked LC, our duration)")
for ph in (checks["modshift"]["phs_sec"], checks["modshift"]["phs_ter"]):
    sh = Ephemeris(box.period, box.t0 + ph * box.period, box.duration)
    line(f"phase {ph:.3f} all", depth(np.ones(len(t), bool), sh))
    eps = np.round((t - sh.t0) / sh.period).astype(int)
    vals = []
    for n in np.unique(eps[in_transit(t, sh, 0.5)]):
        m = eps == n
        d = depth(m, sh)
        vals.append((n, sh.t0 + n * sh.period, d))
    vals.sort(key=lambda v: -v[2][0] / v[2][1])
    print("  strongest epochs: " + "; ".join(f"t {v[1]:.2f} {v[2][0]*1e6:.0f}+-{v[2][1]*1e6:.0f}" for v in vals[:4]))
    worst = vals[0][0]
    line(f"phase {ph:.3f} without t {vals[0][1]:.2f}", depth(eps != worst, sh))

print("\n== star-specific null: the fold's core depth at the same period and duration, t0 shifted (our transits masked)")
ours = in_transit(t, box, 3.0) | in_transit(t, fitp, 3.0)
keep = ~ours
real = depth(np.ones(len(t), bool), box)
nulls = []
for s in np.arange(2 * box.duration, box.period - 2 * box.duration, box.duration / 4):
    eph = Ephemeris(box.period, box.t0 + s, box.duration)
    d = depth(keep, eph)
    if d[2] >= 100:
        nulls.append(d[0] / d[1])
nulls = np.array(nulls)
print(f"real z {real[0]/real[1]:.2f} (white errors); {len(nulls)} shifted folds: z mean {nulls.mean():.2f}, sd {nulls.std(ddof=1):.2f}, max {nulls.max():.2f}, min {nulls.min():.2f}; real in null sds {(real[0]/real[1]-nulls.mean())/nulls.std(ddof=1):.2f}")

print("\n== BLS (objective snr) on the residual light curve, our transits masked (3 durations)")
bls = BoxLeastSquares(t[keep], f[keep], e[keep])
periods = np.exp(np.linspace(np.log(1.0), np.log(40.0), 150000))
res = bls.power(periods, [0.08, 0.125, 0.1875, 0.25, 0.33], objective="snr")
p = res.power
sde = (p - np.mean(p)) / np.std(p)
order = np.argsort(sde)[::-1]
shown = []
for i in order:
    if any(abs(periods[i] - q) / q < 0.01 for q in shown):
        continue
    shown.append(periods[i])
    print(f"  P {periods[i]:9.4f} d  SDE {sde[i]:5.2f}  depth {res.depth[i]*1e6:6.0f} ppm  dur {res.duration[i]:.3f}  t0 {res.transit_time[i]:.3f}")
    if len(shown) >= 8:
        break
bls_all = BoxLeastSquares(t, f, e)
res2 = bls_all.power(periods, [0.08, 0.125, 0.1875, 0.25, 0.33], objective="snr")
p2 = res2.power
sde2 = (p2 - np.mean(p2)) / np.std(p2)
j = np.argmax(sde2)
near = np.abs(periods - box.period) / box.period < 0.001
k = np.where(near)[0][np.argmax(sde2[near])]
print(f"same BLS, nothing of ours masked: top P {periods[j]:.4f} SDE {sde2[j]:.2f}; at ours P {periods[k]:.4f} SDE {sde2[k]:.2f} depth {res2.depth[k]*1e6:.0f}")
