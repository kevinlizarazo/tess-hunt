"""Which QUALITY bits are set within 9 h of each transit (SPOC files, as fetched; sha256 checked)."""
import glob
import numpy as np
from astropy.io import fits
P, T0, DUR = 9.995091231532186, 1389.3225568289126, 0.1875
for path in sorted(glob.glob("/tmp/t13/146282666-1/fits/*_lc.fits")):
    with fits.open(path) as h:
        s = h[0].header["SECTOR"]; d = h[1].data
        t = np.asarray(d["TIME"], float); q = np.asarray(d["QUALITY"], int)
    for n in range(int(np.ceil((np.nanmin(t) - T0) / P)), int(np.floor((np.nanmax(t) - T0) / P)) + 1):
        tc = T0 + n * P
        m = np.isfinite(t) & (np.abs(t - tc) < 0.375)
        bits = {}
        for b in range(16):
            k = int(np.sum(m & ((q >> b) & 1).astype(bool)))
            if k:
                bits[1 << b] = k
        inside = np.isfinite(t) & (np.abs(t - tc) < DUR / 2)
        bad_in = int(np.sum(inside & ((q & 175) != 0)))
        tf = t[m & ((q & 175) != 0)]
        span = f"{(tf.min()-tc)*24:+.1f} to {(tf.max()-tc)*24:+.1f} h" if len(tf) else "-"
        print(f"S{s} epoch {n} t {tc:.3f}: cadences {int(m.sum())}, bits {bits}, default-bitmask flagged in transit {bad_in}, flagged span {span}")
