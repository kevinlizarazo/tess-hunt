"""NFPP by star from the last TRICERATOPS run's scenario table (probs.csv)."""
import csv, json
rows = list(csv.DictReader(open("$TESS_HUNT_DATA/drafts/m3-r2/146282666-1/probs.csv")))
tri = json.load(open("$TESS_HUNT_DATA/drafts/m3-r2/146282666-1/triceratops.json"))["evidence"]
by = {}
for r in rows:
    if r["scenario"] in ("NTP", "NEB", "NEBx2P"):
        by[r["ID"]] = by.get(r["ID"], 0.0) + float(r["prob"])
nfpp = sum(by.values())
fpp = 1 - sum(float(r["prob"]) for r in rows if r["scenario"] in ("TP", "PTP", "DTP"))
print(f"last run: NFPP {nfpp:.6g} (recorded {tri['nfpp'][-1]:.6g}), FPP {fpp:.6g} (recorded {tri['fpp'][-1]:.6g})")
for k, v in sorted(by.items(), key=lambda kv: -kv[1])[:6]:
    print(f"  TIC {k}: {v:.4g} ({v/nfpp:.1%})")
rest = nfpp - by["146282663"]
print(f"without TIC 146282663: {rest:.4g}; renormalised {rest/(1-by['146282663']):.4g}")
print(f"mean NFPP over runs {tri['nfpp_mean']:.6g} sd {tri['nfpp_sd']:.3g}; mean scaled by the last run's share without 146282663: {tri['nfpp_mean']*rest/nfpp:.4g}")
for r in rows:
    if r["ID"] in ("146282663", "632015734") and r["scenario"] in ("NTP", "NEB"):
        print("  ", r["ID"], r["scenario"], "R_p", round(float(r["R_p"]), 2), "R_EB", round(float(r["R_EB"]), 3), "b", round(float(r["b"]), 3), "prob", r["prob"])
