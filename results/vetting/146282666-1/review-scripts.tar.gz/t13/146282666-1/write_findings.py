"""Writes /tmp/t13/146282666-1/findings.json (the Task 13 review of 146282666-1, full brief)."""
import json

D = "~/.cache/tess-hunt/drafts/m3-r2/146282666-1"
S = "/tmp/t13/146282666-1"

findings = [
    {
        "id": "F1",
        "lens": "on_star",
        "rating": "hold",
        "claim": (
            "A background star 6.0\" from the target (Gaia DR3 4967249906843757568, G 15.73) could make the dip with a "
            "7.4% eclipse, TESS's pixels can't separate it from the target and their centroids lean its way within the "
            "noise, and TRICERATOPS is inconclusive, so the public data can't place the dip on the target."
        ),
        "evidence": (
            f"{D}/neighbours.csv: Gaia DR3 4967249906843757568 at 6.016\" (J2016.0, from the target's DR3 position), G "
            "15.73, required_depth 0.0736; triceratops.json hosts[0]: TIC 632015734 at 0.0004\", tdepth 0.0734. Gaia DR3 "
            f"({S}/gaia.py, output gaia.txt, 2026-10-21): that star has parallax 0.285 +- 0.040 mas and pm (13.50, -6.55) "
            "mas/yr against the target's 8.029 mas and (-7.36, -115.00): a background star at about 3.5 kpc, not bound; "
            f"RUWE 1.18. {D}/probs.csv (last run; {S}/nfpp_share.py, output nfpp_share.txt): its NEB scenario (R_EB 0.40 "
            "on R 1.51, b 0.10) is 0.000474, 31.1% of that run's NFPP 0.00152924. Pixels: triage's pickles "
            "(~/.cache/tess-hunt/tdi/20261015T155441Z-triage-7b12e25-3f57/146282666-1/tic146282666/) refitted with "
            f"{S}/sector_detail.py (copied from /tmp/t13/399023421-1) on {S}/jobs.json, output detail.json, summarised by "
            f"{S}/summ.py into summ.txt; every refit reproduces the saved image. Fit east, north in arcsec: S30 (-23.4, "
            "1.3) q 0.395, S104 (6.0, 11.7) q 0.713, S105 (-14.4, -16.7) q 0.413, S106 (-5.2, -0.1) q 0.853, S107 (-6.1, "
            "-4.3) q 0.785. The neighbour sits at (-5.0, 4.1) in S106's catalogue. S106, the sector triage judged (SPOC, "
            "not timing-suspect; the images are TESScut cutouts), lands 5.2\" from the target and 4.2\" from the "
            "neighbour. Quality-weighted mean (-6.4, -0.5): 6.4\" from the target, 4.8\" from the neighbour, sky scatter "
            "12.3\", 1.16 standard errors from the target. The difference images are weak: target 3x3 box z over the sd "
            "of 16 null images 1.14, 1.51, 4.01, 4.38, 3.00 in S30, S104 to S107. Fixed-position fits of the target and "
            f"the neighbour ({S}/two_star.py on jobs_two.json and pairs.json, output two_star.json and two_star.txt) are "
            "degenerate at 0.3 pixel: the neighbour's fitted out-of-transit flux comes out 546 to 5577 e/s or negative "
            "where a T 15.36 star gives about 110. The hosts at 32.5\" and 33.2\" show no loss at their positions: TIC 146282669 "
            "amplitude z 0.31, -0.46, 0.94, -0.10, -0.50 against the target's 0.33, 1.88, 0.13, 3.03, 2.10 (TIC "
            "632015732, 1.1\" from it, the same), and probs.csv gives the pair 1.4e-6; the one at 31.4\" (TIC 632016189, "
            "needs 78.7%) gets z 0.78, 1.87, 1.01, 0.40, -1.09 against the target's 0.31, 1.62, 0.20, 2.36, 2.01, and "
            "probs.csv gives it 7e-17. Deciding evidence: "
            "seeing-limited ground-based photometry on a predicted transit that resolves 6\" and shows whether the G 15.7 "
            "star dims by about 7.4% (density-prior ephemeris P 9.995026 +- 2.5e-5 d, t0 BTJD 1389.3286 +- 0.0061, so "
            "about 14 min or less at a transit in early 2027). The SOAR speckle image (F9) and 2-min TESS data would not "
            "decide it. Clearing this star leaves TRICERATOPS over its bar on TIC 146282663 alone (F2)."
        ),
    },
    {
        "id": "F2",
        "lens": "on_star",
        "rating": "note",
        "claim": (
            "Two thirds of the NFPP that keeps TRICERATOPS over its pass bar comes from TIC 146282663, a T 11.6 star 69\" "
            "away whose position the difference images rule out as the source; without it the NFPP is 0.00048, under "
            "the 0.001 bar. The star list holds no TIC duplicate, so 399023421-1's duplicate defect does not touch this "
            "NFPP."
        ),
        "evidence": (
            f"{S}/nfpp_share.txt from {D}/probs.csv (last run, NFPP 0.00152924 as recorded): TIC 146282663 0.001053 "
            "(68.8%: NTP 0.000705 with R_p 19.8 Earth radii, NEB 0.000347), TIC 632015734 0.000475 (31.1%), the rest "
            "1.4e-6; without 146282663 0.000476, and the 10-run mean 0.00152612 scaled the same way 0.000475; "
            "criteria/vet-v3.toml nfpp_pass 0.001. triceratops.json stars: 146282663 tdepth 0.0237. It is 68.6\" from "
            "the target, outside the neighbour table's 1' radius, so the dossier never lists it. Fixed-position fits "
            f"({S}/two_star.json): its fractional loss -0.0006, 0.0003, -0.0001, 0.0002, 0.00004 in S30, S104 to S107, "
            "null sd 0.0002 to 0.0005, against the 0.0237 it would need: 50 to 110 null sds per sector. Gaia DR3 "
            "4967296807888366720 (its TIC GAIA id; gaia.txt): RUWE 1.90, astrometric_excess_noise_sig 94.6, "
            "rv_chisq_pvalue 0.0, rv_amplitude_robust 22.5 km/s over 54 transits: likely a binary itself, but not at our "
            f"ephemeris. Duplicates: MAST TIC for all 38 TRICERATOPS stars ({S}/tic_disp.py, output tic_disp.txt, "
            "astroquery Catalogs.query_criteria, 2026-10-21): disposition and duplicate_id empty for every one, and no "
            "two share a position (the nearest pair, TIC 146282669 and 632015732, are distinct Gaia sources 1.1\" apart). "
            "vet-v3 has no step that lets a star the pixels exclude leave the NFPP (decision 0026), so whether one may "
            "is a decision for a record, not a rerun. The margin is also smaller than the check's movement with its "
            "inputs (0032): Task 0's probe on this star gave NFPP 0.0139 to 0.0183 with TIC 146283232 about 55% of it "
            "(.superpowers/sdd/tess-hunt-m3-plan/progress.md, P2 entry), where production gives 146283232 about 5e-46 "
            "(probs.csv); and the fold TRICERATOPS ran on includes epoch 290 with TOI-4298.01's transit on it (F3)."
        ),
    },
    {
        "id": "F3",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "TOI-4298.01 is not a 722-d pair of single transits: the star dips every 28.896 d (close to 722.26/25 = "
            "28.890) in all six windows with data, and one of those transits falls on our epoch 290, which vet-v3 leaves unmasked because "
            "it masks the TOI at the catalog's 722-d ephemeris (empty in S107) and cuts that epoch's baseline instead; "
            "with the TOI masked at 28.896 d the depth checks still pass, at 8.5 sigma."
        ),
        "evidence": (
            f"{S}/lc_toi.py on vet-v3's light curve detrended by search-v2's biweight with every window held out "
            f"(output lc_toi.txt, lc_toi.png): best 7.7-h box 473 +- 40 ppm at BTJD 1398.36 (S3), 542 +- 45 at 2120.66 "
            "(S30), 382 +- 44 at 4201.24 (S104), 333 +- 43 at 4230.15 (S105, a time predicted from the other four before "
            f"it was measured), 289 +- 42 at 4259.04 (S106), 546 +- 45 at 4287.94 (S107). {S}/toi_period.py: linear "
            "ephemeris P 28.89622 d, T0 1398.3116, residuals +1.1, -1.4, -0.1, +0.2, +0.1, +0.2 h. The 722-d prediction "
            f"in S107, 4287.443, shows -192 +- 62 ppm ({S}/lc_146.py, output lc_146.txt). The P/2 alias's five half-way "
            f"epochs give 10 +- 19 ppm ({S}/lc_toi2.py, output lc_toi2.txt). ExoFOP ({S}/exofop.json, read 2026-10-21): "
            "P 722.2620 +- 0.0073 d, epoch 2458398.3956, 481 ppm, 7.71 h, sectors 3 and 30. The search's rank-2 signal "
            "on this star (checks.json other_signals: 28.89977 d, t0 1398.004, SDE 19.1) is this TOI. SPOC's one-sector "
            "TCEs each pair two of these dips: S3 9.0772 d = our epoch 0 and the TOI at 1398.40; S30 18.3425 d = the "
            "TOI at 2120.66 and our epoch 75; S104 13.3718 d = our epoch 280 and the TOI at 4201.30; S106 22.1285 d = an "
            "unexplained 369 +- 42 ppm dip at 4236.91 and the TOI at 4259.04. In S107 the vet's mask spans 4287.122 to "
            "4287.765 and leaves epoch 290 29 cadences before ingress within three durations (93 to 338 at the other "
            "epochs; first cadence -3.21 h), while the TOI's transit, about 4287.78 to 4288.10, covers epoch 290 "
            "(4287.81 to 4287.99): 290 is 393 +- 83 ppm in the vet (+1.85 sigma, the deepest) and 654 +- 59 ppm with the "
            "windows held out. The dossier's 'overlaps 0 of 13' is true of the catalog row, not of the TOI. lc_toi2.txt, "
            "with the vet run's red-noise betas: vet-v3's masks give 245.3 +- 25.6 ppm (z 9.59, as checks.json), "
            "odd/even 2.44 sigma, sector chi2 p 0.529, S107 327 +- 70; masked at 28.896 d instead, 229.8 +- 26.9 (z "
            "8.54 > 7), odd/even 1.89 sigma (< 3), p 0.724 (> 0.001), S107 160 +- 131 (epoch 288 only). Not recomputed: "
            "the two fits, shape, density and holdout season 2, which all include epoch 290; Rp and the ephemeris M4 "
            "uses come from that fit. The ratio 28.896 / 9.995 = 2.891 is no novelty harmonic. The check's input, not "
            "its code, is wrong (0021 masks catalog ephemerides), which belongs in a decision record; a CTOI should give "
            "the TOI's period."
        ),
    },
    {
        "id": "F4",
        "lens": "planet",
        "rating": "note",
        "claim": (
            "LEO-Vetter's ModShift secondary (3.27 sigma at phase 0.339) and tertiary (phase 0.895) are single dips, "
            "TOI-4298.01's S104 transit and the unexplained S106 dip, not a repeating eclipse; without them both phases "
            "are flat."
        ),
        "evidence": (
            f"checks.json modshift: sig_sec 3.27 at 0.3388 (62 ppm), sig_ter 3.00 at 0.8952, Fred 1.26. {S}/lc_146.txt "
            "(vet-v3's light curve, our duration, white errors): phase 0.339 60.2 +- 23.3 ppm, its strongest epoch BTJD "
            "4201.33 at 355 +- 81 (the TOI's S104 transit, F3), without it 33.4 +- 24.3 (1.37 sigma); phase 0.895 49.0 "
            "+- 24.7, strongest 4236.88 at 246 +- 77 (the S106 single dip), without it 26.4 +- 26.1 (1.01 sigma). Phase "
            "0.5: 1.5 sigma (the secondary check). So no eccentric secondary, and 0031's own-occultation case does not "
            "arise."
        ),
    },
    {
        "id": "F5",
        "lens": "planet",
        "rating": "note",
        "claim": (
            "Nothing points to an eclipsing binary on the target: the transit is U-shaped, the density agrees, Gaia's 40 "
            "RV epochs rule out a stellar companion on a 10-d orbit, and odd and even differ by 2.4 sigma (1.9 with the "
            "TOI's transit masked); a user-uploaded CHIRON fit's logg 3.24 is ruled out by the parallax."
        ),
        "evidence": (
            "checks.json: shape grazing 0%, b 0.45 (flat-prior fit), 0.18 (density-prior); density tension 1.3 sigma "
            "(transit 0.514 g/cm3 against TIC 0.883; Gaia FLAME's mass 1.09 and radius 1.28 give 0.74); Rp 1.99 Earth "
            f"radii. Gaia DR3 ({S}/gaia.txt): RV -13.10 +- 0.17 km/s over 40 transits, rv_amplitude_robust 3.19 km/s, "
            "rv_chisq_pvalue 0.071, non_single_star 0. At P 9.995 d and 1.14 solar masses K is about 86 m/s per Jupiter "
            "mass, so an 80-Jupiter-mass companion gives about 6.6 km/s (with the total mass), 13 km/s peak to peak. RAVE DR6 (2003-11-11): "
            f"-11.79 +- 3.03 km/s ({S}/viz.txt). Odd 187 and even 312 ppm, 2.44 sigma (checks.json, limit 3); with the "
            "TOI's transit masked 188 and 291, 1.89 sigma (lc_toi2.txt). probs.csv: EB 5e-43, EBx2P 1e-24, PEBx2P 1e-19. "
            "The search's other signal (28.90 d) is TOI-4298.01 (F3), whose 7.7-h dips are longer than our 4.5-h ones, "
            "not an eclipse pair of ours. ExoFOP stellar parameters (exofop.json, CHIRON, uploaded 2023-12-14): Teff "
            "5390 K, logg 3.24, [M/H] -0.56, vsini 4.7 km/s. With the TIC's luminosity 1.85 solar from the parallax, "
            "logg 3.24 needs R about 4.2 and L about 13 solar; Teff 5390 K alone gives R 1.56 and Rp about 2.5 Earth "
            "radii, still small. Gaia GSP-Phot: Teff 6000 K, logg 4.13, [M/H] -0.68: a metal-poor F dwarf."
        ),
    },
    {
        "id": "F6",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "The dip is real and periodic: 13 transits over eight years agree in depth, no single transit carries it, "
            "it stands 9 null sds above folds shifted in phase on the same light curve, and no transit sits on a "
            "momentum dump, a sector edge or a timing-suspect sector."
        ),
        "evidence": (
            f"{S}/lc_146.py on {D}/checks.json and ~/.cache/tess-hunt/lc/146282666.npz with the six SPOC files "
            f"({S}/fits/, each sha256 equal to checks.json sources), run through /tmp/t13/heavy.sh from the repo root; "
            "output lc_146.txt. Per-epoch core depths 118 to 393 ppm, chi2 16.0 on 12 dof (p 0.19); leave-one-epoch-out "
            "combined z 9.7 to 10.6 (white errors); 198 folds with t0 shifted by quarter durations, our transits masked: "
            "z mean -0.05, sd 1.18, max 3.22, against 10.63. Momentum dumps (QUALITY bit 32): nearest to any transit "
            f"+6.2 h after epoch 281's mid, outside it. {S}/quality.py (output quality.txt): manual-exclude (bit 128) "
            "cadences cut epoch 288 to 94 of 135 in-transit cadences (core n 26, depth 160 +- 132) and touch no other "
            "transit by more than 2 cadences (epoch 290). Every transit is at least 2.5 d from its sector's first or last cadence. All six "
            "sectors are SPOC 2-min; dropped_suspect is empty and the evidence-only vet is identical. The star has "
            "other single dips (F3), but none repeats at our period."
        ),
    },
    {
        "id": "F7",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "Holdout is inconclusive for lack of power, not of transits: the 2018 and 2020 seasons hold two transits "
            "each, below the 4-sigma expectation, while the 2026 season is found at 8.0 sigma where they put it; no TESS "
            "sector is coming, so the check blocks a pass under 0028's bar 1 until new photometry exists."
        ),
        "evidence": (
            "checks.json holdout: season 0 (S3) expected_snr 3.87 and season 1 (S30) 3.48, both underpowered against "
            "criteria/vet-v3.toml min_expected_snr 4.0; season 2 (S104 to S107) predicted from seasons 0 and 1 "
            "(training_seasons_with_transits 2) at period 9.994936, found at 8.04 sigma, depth 252 +- 31 ppm against "
            "194 +- 45 from training, tension 1.06. The refit starts from the search's period (refit_resolutions 5), so "
            "the prediction is not blind, and season 2 includes epoch 290 (F3). checks.json upcoming_sectors is empty "
            "(tess-point). What would make it testable: transits observed at about 240 ppm, from CHEOPS or a large "
            "ground-based telescope; a TESS season only if one is scheduled."
        ),
    },
    {
        "id": "F8",
        "lens": "real_new",
        "rating": "note",
        "claim": (
            "No catalog row, ExoFOP entry or paper reports a signal at 9.995 d or a harmonic; SPOC caught three of our "
            "transits singly and paired each with an unrelated dip, and the 13 hits are catalogues and one flare survey "
            "that lists the star as TOI-4298's host, so the signal is new, in a known-TOI system."
        ),
        "evidence": (
            "checks.json novelty pass, tce_matches and tce_period_matches empty. The catalogued rows' periods (722.26, "
            "9.0772, 18.3425, 13.3718, 22.1285, ExoMiner 9.0809 and 18.343, eumemic 22.157, 9.121, 13.313, 18.254 d) "
            "match none of 9.995, 4.998, 19.990, 3.332 and 29.985 d; the SPOC pairs are in F3. ExoFOP (exofop.json): TOI "
            "4298.01 only, no CTOI, no time series, no notes. Literature ("
            f"{D}/literature.json; VizieR rows in {S}/viz.py, output viz.txt): Howard et al. 2022 (flaring TOIs) lists "
            "TOI-4298.01 at 722.26 d with 0 flares, Binarity 0, Contam 0 (J/MNRAS/512/L60): flagged as naming the star "
            "a planet-candidate host. Dismissed: Houk 1982, F7 V with no remark (III/80); Cruzalebes et al. 2019 (MDFC), "
            "F7V, CalFlag 0, IRflag 1, which is a possible 22-micron excess (K - W4 0.39 +- 0.16 mag), not "
            "multiplicity (II/361 ReadMe); the HD catalogue; RAVE DR2 to DR6 (one 2003 spectrum, its RV in F5); JSDC v2; "
            "Ruiz-Dern et al. 2018 (a row in its low-extinction photometric sample, J/A+A/609/A116); Francis 2013 "
            "(RAVE distances). Olsen 1979 ('interesting Stromgren indices'): its groups are Ap, Am, metal-poor and "
            f"composite stars; I read its tables 1, 3, 4, 6 to 8, 10 to 14 and 16 in the ADS scan ({S}/olsen1979.pdf, "
            "rendered pages in olsen/) and did not find HD 14989, so why SIMBAD links it is not established; the star's "
            "[M/H] of -0.56 to -0.68 would make it an intermediate population II F dwarf, the paper's main subject."
        ),
    },
    {
        "id": "F9",
        "lens": "on_star",
        "rating": "note",
        "claim": (
            "No visual double or bound companion shows: SOAR speckle reaches 7.5 mag at 1\" with none noted, Gaia's "
            "RUWE is 1.04 with no multi-peak images and no co-moving star within 10', and crowding is 1.6% to 2.6% in "
            "each sector; the one oddity is Gaia's duplicated_source flag on the target."
        ),
        "evidence": (
            "exofop.json imaging: SOAR HRCam, I band, 2021-10-01, 'delta 7.5 mag @ 1\"', notes empty; "
            f"stellar_companions empty. gaia.txt: RUWE 1.039, ipd_frac_multi_peak 0, ipd_gof_harmonic_amplitude 0.027, "
            "astrometric_excess_noise_sig 18.3, non_single_star 0, duplicated_source true (also true in DR2 and EDR3 by "
            f"RAVE's cross-match, viz.txt). {S}/gaia_cpm.py (output gaia_cpm.txt): no other DR3 source within 10' with "
            "parallax 6.5 to 9.5 mas. WDS and VSX: nothing within 30\" (viz.txt). checks.json: CROWDSAP 0.974 to 0.984, "
            "TIC contratio 0.011; no QLP sector, so no QLP dilution. TRICERATOPS ran without a contrast curve "
            "(triceratops.json contrast []), because ExoFOP's SOAR curve is a PDF (pins.md, P4); its FPP of 0.0293 "
            "already passes its own bar without one."
        ),
    },
]

out = {
    "signal": "146282666-1",
    "summary": (
        "Full brief. I refitted triage's difference images, read TRICERATOPS's scenarios and star list against the TIC "
        "and Gaia DR3, re-measured the transits on vet-v3's light curve and the SPOC files, and screened ExoFOP and the "
        "13 hits. Nothing kills it: the 9.995-d dip is periodic, steady over 13 transits and eight years, U-shaped and "
        "new, but it holds on blending, since a background star 6\" out can make it with a 7.4% eclipse that TESS "
        "can't separate, while two thirds of the NFPP over the bar comes from a 69\" star the pixels exclude (no TIC "
        "duplicate is involved). TOI-4298.01 turns out to repeat every 28.896 d, not 722 d, and one of its transits "
        "sits unmasked on our epoch 290; masked properly, the depth checks still pass."
    ),
    "findings": findings,
    "hits_flagged": ["doi 10.1093/mnrasl/slac024, arXiv 2203.01954"],
}
json.dump(out, open("/tmp/t13/146282666-1/findings.json", "w"), indent=2, ensure_ascii=False)
print("wrote", len(findings), "findings")
