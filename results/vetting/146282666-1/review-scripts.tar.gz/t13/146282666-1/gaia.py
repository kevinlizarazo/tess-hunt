from astroquery.gaia import Gaia
ids = [4967249906845494144, 4967249906843757568, 4967249906844218112, 4967296803591446400,
       4967249872486553600, 4967249872484022400, 4967296807888366720]
q = f"""select source_id, ra, dec, phot_g_mean_mag, bp_rp, parallax, parallax_error, pmra, pmdec, ruwe,
 ipd_frac_multi_peak, ipd_gof_harmonic_amplitude, astrometric_excess_noise, astrometric_excess_noise_sig,
 duplicated_source, non_single_star, radial_velocity, radial_velocity_error, rv_nb_transits, rv_chisq_pvalue,
 rv_renormalised_gof, rv_amplitude_robust, phot_variable_flag, teff_gspphot, logg_gspphot, mh_gspphot
 from gaiadr3.gaia_source where source_id in ({",".join(map(str, ids))})"""
t = Gaia.launch_job(q).get_results()
for r in t:
    print({c: (round(float(r[c]), 4) if hasattr(r[c], '__float__') and c != 'source_id' else str(r[c])) for c in t.colnames})
q2 = """select source_id, phot_g_mean_mag, parallax, pmra, pmdec, ruwe,
 DISTANCE(POINT(35.9882136249855, -34.1094359375371), POINT(ra, dec))*3600 as sep
 from gaiadr3.gaia_source where 1=CONTAINS(POINT(ra, dec), CIRCLE(35.98821, -34.10994, 0.0333)) order by sep"""
t2 = Gaia.launch_job(q2).get_results()
print(len(t2), 'sources within 2 arcmin')
for r in t2:
    print(r['source_id'], round(float(r['sep']),1), round(float(r['phot_g_mean_mag']),2), r['parallax'], r['pmra'], r['pmdec'], r['ruwe'])
