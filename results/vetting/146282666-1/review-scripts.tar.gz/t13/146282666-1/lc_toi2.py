"""Read-only: our signal with TOI-4298.01 masked at the ~28.9-d ephemeris its dips follow, instead of vet-v3's 722-d
catalog ephemeris; and the TOI's 722.26/50-d alias tested at its extra epochs.

Depth errors use the vet run's per-sector red-noise betas (checks.json `red_noise`), as vet-v3's depth checks do, so
the numbers can be set beside checks.json's.

Usage (repo root): lc_toi2.py CHECKS.json LC.npz
"""
import json
import sys
import tomllib

import numpy as np
from scipy.stats import chi2 as c2

from tess_hunt.checks.photometry import box_depth
from tess_hunt.detrend import detrend
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.lightcurve import LightCurve

checks = json.load(open(sys.argv[1]))
lc = LightCurve.load(sys.argv[2])
crit = tomllib.load(open("criteria/search-v2.toml", "rb"))
e0 = checks["ephemeris"]
box = Ephemeris(e0["period"], e0["t0"], e0["duration"])
beta = {int(k): v["beta"] for k, v in checks["red_noise"].items()}
TOI_DUR = 0.3213595741358792
toi722 = Ephemeris(722.2619756368, 1398.395589, TOI_DUR)
toi289 = Ephemeris(28.89616, 1398.336, TOI_DUR)


def flat_for(masks):
    fl = detrend(lc, crit["detrend"], masks)
    ok = np.isfinite(fl.flux) & np.isfinite(fl.flux_err)
    err = fl.flux_err[ok] * np.array([beta[int(s)] for s in fl.sector[ok]])
    return fl.time[ok], fl.flux[ok], err, fl.sector[ok]


def report(label, masks):
    t, f, e, sec = flat_for(masks)
    ep = np.round((t - box.t0) / box.period).astype(int)

    def d(m):
        return box_depth(t[m], f[m], e[m], box, 0.5)

    a = d(np.ones(len(t), bool))
    print(f"\n== {label}: cadences {len(t)}")
    print(f"all: {a[0]*1e6:.1f} +- {a[1]*1e6:.1f} ppm (z {a[0]/a[1]:.2f}, n {a[2]})")
    o, v = d(ep % 2 == 1), d(ep % 2 == 0)
    print(f"odd {o[0]*1e6:.1f} +- {o[1]*1e6:.1f} (n {o[2]}), even {v[0]*1e6:.1f} +- {v[1]*1e6:.1f} (n {v[2]}); "
          f"difference {abs(o[0]-v[0])/np.hypot(o[1], v[1]):.2f} sigma")
    rows = []
    for s in sorted(np.unique(sec)):
        x = d(sec == s)
        if x[2]:
            rows.append((s, x))
    ds = np.array([r[1][0] for r in rows]); ss = np.array([r[1][1] for r in rows])
    w = 1 / ss**2
    mean = np.sum(w * ds) / np.sum(w)
    chi = np.sum(((ds - mean) / ss) ** 2)
    print("sectors: " + "; ".join(f"S{s} {x[0]*1e6:.0f}+-{x[1]*1e6:.0f} (n {x[2]})" for s, x in rows)
          + f"; chi2 {chi:.2f} on {len(rows)-1} dof, p {c2.sf(chi, len(rows)-1):.3f}")
    x = d(ep == 290)
    print(f"epoch 290: {x[0]*1e6:.0f} +- {x[1]*1e6:.0f} (n {x[2]})")
    x = d(ep != 290)
    print(f"without epoch 290: {x[0]*1e6:.1f} +- {x[1]*1e6:.1f} (z {x[0]/x[1]:.2f}, n {x[2]})")
    return t, f, e, sec


report("vet-v3's masks (TOI at 722.26 d)", [toi722])
report("TOI masked at 28.89616 d", [toi289])
t, f, e, sec = report("TOI masked at both", [toi722, toi289])

print("\n== TOI alias P/2 = 14.448 d: depth at the half-way epochs (our transits and the TOI's own masked; 7.7-h box)")
fl = detrend(lc, crit["detrend"], [box, toi289])
ok = np.isfinite(fl.flux) & np.isfinite(fl.flux_err)
tt, ff, ee = fl.time[ok], fl.flux[ok], fl.flux_err[ok]
half = Ephemeris(toi289.period, toi289.t0 + toi289.period / 2, TOI_DUR)
eps = np.round((tt - half.t0) / half.period).astype(int)
vals = []
for n in np.unique(eps):
    m = eps == n
    x = box_depth(tt[m], ff[m], ee[m], half, 1.0)
    if x[2] >= 0.6 * TOI_DUR * 720:
        vals.append((n, half.t0 + n * half.period, x))
for n, tc, x in vals:
    print(f"  half-way epoch at {tc:.2f}: {x[0]*1e6:5.0f} +- {x[1]*1e6:3.0f} ppm (n {x[2]})")
m = np.isin(eps, [v[0] for v in vals])
x = box_depth(tt[m], ff[m], ee[m], half, 1.0)
print(f"  all half-way epochs: {x[0]*1e6:.0f} +- {x[1]*1e6:.0f} ppm (n {x[2]})")
