"""Gaia DR3 stars within 10 arcmin that share the target's parallax and proper motion (a wide companion)."""
from astroquery.gaia import Gaia
q = """select source_id, phot_g_mean_mag, parallax, parallax_error, pmra, pmdec, ruwe,
 DISTANCE(POINT(35.98817, -34.10995), POINT(ra, dec))*3600 as sep
 from gaiadr3.gaia_source
 where 1=CONTAINS(POINT(ra, dec), CIRCLE(35.98817, -34.10995, 0.1667))
 and parallax between 6.5 and 9.5 order by sep"""
t = Gaia.launch_job(q).get_results()
print(len(t), "sources within 10' with parallax 6.5 to 9.5 mas")
for r in t:
    print(r["source_id"], round(float(r["sep"]), 1), round(float(r["phot_g_mean_mag"]), 2), round(float(r["parallax"]), 3), round(float(r["pmra"]), 2), round(float(r["pmdec"]), 2), r["ruwe"])
