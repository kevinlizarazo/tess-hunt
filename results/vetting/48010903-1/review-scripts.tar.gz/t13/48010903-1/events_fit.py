# Trapezoid fit to each eclipse on raw normalized flux with a local linear baseline (window +-1 d, S89's B event
# runs to the sector end so it gets +-0.7 d); mid-time, depth, total and flat durations.
import numpy as np
from scipy.optimize import least_squares
from tess_hunt.config import lc_dir
from tess_hunt.lightcurve import LightCurve
lc = LightCurve.load(lc_dir() / "48010903.npz")
T0A, PA = 1566.0768622858318, 34.45196281466231
def trap(t, tc, d, T14, T23):
    x = np.abs(t - tc); T23 = min(T23, T14)
    y = np.where(x <= T23 / 2, 1.0, np.where(x >= T14 / 2, 0.0, (T14 / 2 - x) / max((T14 - T23) / 2, 1e-6)))
    return -d * y
def fit(tc0, T140, half=1.0):
    m = np.abs(lc.time - tc0) < half
    t, f = lc.time[m], lc.flux[m] / np.median(lc.flux[m]) - 1
    sec = np.unique(lc.sector[m])
    res = lambda p: f - (p[0] + p[1] * (t - tc0) + trap(t, p[2], p[3], p[4], p[5]))
    best = None
    for dt in np.linspace(-0.05, 0.05, 11):
        r = least_squares(res, [0, 0, tc0 + dt, 0.005, T140, T140 / 3],
                          bounds=([-1, -1, tc0 - 0.2, 0, 0.02, 0], [1, 1, tc0 + 0.2, 0.05, 0.8, 0.8]))
        if best is None or r.cost < best.cost:
            best = r
    p = best.x
    J = best.jac; s2 = 2 * best.cost / (len(t) - len(p))
    try:
        err = np.sqrt(np.diag(np.linalg.inv(J.T @ J) * s2))
    except np.linalg.LinAlgError:
        err = np.full(len(p), np.nan)
    ph = ((p[2] - T0A) / PA) % 1
    print(f"S{sec} tc {p[2]:.4f} +/- {err[2]*1440:.1f} min, phase {ph:.4f}, depth {p[3]*1e6:.0f} +/- {err[3]*1e6:.0f} ppm, "
          f"T14 {p[4]*24:.2f} h, T23 {min(p[5], p[4])*24:.2f} h, n {len(t)}")
    return p[2], err[2]
print("A, the sharp eclipse (the signal):")
for tc in (1566.0768, 2289.5686, 3736.5504, 4046.617):
    fit(tc, 0.12)
print("B, the broad eclipse (search rank 2, 34.452 d):")
tb = [fit(2264.627, 0.42), fit(2299.079, 0.42), fit(3746.067, 0.42, half=0.7)]
t = np.array([x[0] for x in tb]); e = np.array([x[1] for x in tb]); k = np.round((t - t[0]) / PA)
A = np.vstack([np.ones(3), k]).T; w = 1 / e**2
cov = np.linalg.inv(A.T @ (A * w[:, None])); sol = cov @ (A.T @ (w * t))
print(f"B's own period from its 3 events: {sol[1]:.5f} +/- {np.sqrt(cov[1,1]):.5f} d (A's: {PA:.5f}); cycles {k}")
