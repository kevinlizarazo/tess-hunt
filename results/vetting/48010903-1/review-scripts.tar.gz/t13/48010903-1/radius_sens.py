# The radius check's sensitivity, from the vet run's own flat-prior samples (columns t0, period, rp_rs, b, log_rho, q1, q2).
import sys
import numpy as np
s = np.load(sys.argv[1])["samples"]
k, b = s[:, 2], s[:, 3]
R, eR, Rflame = 1.32527, 0.0638442, 1.3636376857757568   # checks.json star.rad, e_rad, radius_flame
rp = k * R * 109.076
print(f"median Rp {np.median(rp):.2f}; P(Rp>22) {np.mean(rp > 22):.3f}; grazing {np.mean(b + k > 1):.3f}")
ng = b + k < 1
print(f"non-grazing samples {ng.mean():.3f} of all, their Rp 16/50/84: {np.percentile(rp[ng], [16, 50, 84]).round(1)}, P(>22) {np.mean(rp[ng] > 22):.3f}")
for lab, r in (("TIC-1sd", R - eR), ("FLAME", Rflame)):
    print(f"{lab} {r:.3f} Rsun -> {np.median(k) * r * 109.076:.2f}")
for sec, c in (("S35", 0.92604893), ("S9", 0.95922446)):
    print(f"CROWDSAP {sec} {c} undone -> {np.median(k) * np.sqrt(c) * R * 109.076:.2f}; with TIC-1sd {np.median(k) * np.sqrt(c) * (R - eR) * 109.076:.2f}")
