# Seed and period robustness of the shape and radius outcomes; vet-v3's fit_transit and criteria throughout.
import json
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.detrend import detrend
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.fit import fit_transit

crit_s = load_criteria("criteria/search-v2.toml").values
crit_v = load_criteria("criteria/vet-v3.toml").values
lc = LightCurve.load(lc_dir() / "48010903.npz")
flat = detrend(good_timestamps(lc), crit_s["detrend"], [])
parts = split(flat, crit_v["families"])
pdc, qlp = parts["pdcsap"], parts["qlp"]
RAD = 1.32527
search = Ephemeris(24.948370273398364, 1566.0526256263609, 0.125, 0.0045749896410242)
alt = Ephemeris(29 * 24.947961342271636 / 21, 1566.0526256263609, 0.125, 0.0045749896410242)
E28 = 1566.0770557438036 + 28 * 24.947961342271636
no28 = pdc.select(np.abs(pdc.time - E28) > 1.0)
def cat(a, b):
    t = np.concatenate([a.time, b.time]); o = np.argsort(t)
    f = lambda x, y: np.concatenate([x, y])[o]
    return LightCurve(a.tic, t[o], f(a.flux, b.flux), f(a.flux_err, b.flux_err), f(a.sector, b.sector), a.sources)
def run(name, l, eph, seed):
    fit = fit_transit(l, eph, crit_v["fit"], rho_prior=None, seed=seed)
    b, k, lr = fit.column("b"), fit.column("rp_rs"), fit.column("log_rho")
    rp = k * RAD * 109.076
    print(json.dumps({"case": name, "seed": seed, "grazing": round(float(np.mean(b + k > 1)), 3),
        "b_med": round(float(np.median(b)), 3), "rp_med": round(float(np.median(rp)), 1),
        "p_rp_gt_22": round(float(np.mean(rp > 22)), 3), "log_rho_med": round(float(np.median(lr)), 3),
        "b_hist_0.2": np.histogram(b, bins=np.arange(0, 1.61, 0.2))[0].tolist()}), flush=True)
run("pdcsap_without_e28_at_vet_period_24.948", no28, search, 1)
for seed in (2, 3):
    run("pdcsap_without_e28_P34.452", no28, alt, seed)
for seed in (1, 2, 3):
    run("pdcsap_all_with_e28_P24.948", pdc, search, seed) if seed > 1 else None
for seed in (2, 3):
    run("S9_S36_S89_mixed_families_P34.452", cat(no28, qlp), alt, seed)
