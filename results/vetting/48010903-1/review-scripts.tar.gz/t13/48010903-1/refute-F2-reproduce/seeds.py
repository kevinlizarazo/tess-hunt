# More seeds for the radius outcome without epoch 28, vet-v3's configuration (PDCSAP only, fit_transit, [fit]).
import json
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.detrend import detrend
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.fit import fit_transit
from tess_hunt.checks.physical import radius

crit_s = load_criteria("criteria/search-v2.toml").values
crit_v = load_criteria("criteria/vet-v3.toml").values
lc = LightCurve.load(lc_dir() / "48010903.npz")
pdc = split(detrend(good_timestamps(lc), crit_s["detrend"], []), crit_v["families"])["pdcsap"]
RAD = 1.32527
search = Ephemeris(24.948370273398364, 1566.0526256263609, 0.125, 0.0045749896410242)
alt = Ephemeris(29 * 24.947961342271636 / 21, 1566.0526256263609, 0.125, 0.0045749896410242)
E28 = 1566.0770557438036 + 28 * 24.947961342271636
no28 = pdc.select(np.abs(pdc.time - E28) > 1.0)
for name, l, eph in (("no28_P34.452", no28, alt), ("no28_P24.948", no28, search), ("with28_P24.948", pdc, search)):
    for seed in range(4, 9):
        fit = fit_transit(l, eph, crit_v["fit"], rho_prior=None, seed=seed)
        b, k = fit.column("b"), fit.column("rp_rs")
        rp = k * RAD * 109.076
        r = radius(fit, RAD, 22.0)
        print(json.dumps({"case": name, "seed": seed, "radius": r.outcome, "rp_med": round(float(np.median(rp)), 1),
            "p_rp_gt_22": round(float(np.mean(rp > 22)), 3), "grazing": round(float(np.mean(b + k > 1)), 3)}), flush=True)
