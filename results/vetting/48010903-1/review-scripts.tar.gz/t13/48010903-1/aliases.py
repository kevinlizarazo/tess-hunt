# Which periods D/n fit the three sharp events (e0, e29, e87 of the 24.948 d ephemeris) and no other data?
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.detrend import detrend

lc = LightCurve.load(lc_dir() / "48010903.npz")
crit = load_criteria("criteria/search-v2.toml").values
flat = detrend(lc, crit["detrend"], [])  # all sectors incl. S99, evidence only
t, f = flat.time, (flat.flux - 1) * 1e6
e0, e29, e87 = 1566.0770557438036, 1566.0770557438036 + 29 * 24.947961342271636, 1566.0770557438036 + 87 * 24.947961342271636
D = e29 - e0
print(f"D = {D:.4f} d, (e87-e0)/D = {(e87-e0)/D:.4f}")
def depth_at(tc):
    inn = np.abs(t - tc) < 0.75 / 24          # central 1.5 h
    out = (np.abs(t - tc) > 3 / 24) & (np.abs(t - tc) < 8 / 24)
    if inn.sum() < 3 or out.sum() < 5:
        return None
    return np.median(f[inn]) - np.median(f[out]), inn.sum()
print("n, period, events with data other than e0/e29/e87: (time, sector, in-minus-out ppm)")
for n in range(1, 80):
    P = D / n
    ks = np.arange(np.floor((t.min() - e0) / P) - 1, np.ceil((t.max() - e0) / P) + 2)
    rows = []
    for k in ks:
        tc = e0 + k * P
        if min(abs(tc - e0), abs(tc - e29), abs(tc - e87)) < 0.1:
            continue
        d = depth_at(tc)
        if d is None:
            continue
        sec = int(np.median(flat.sector[np.abs(t - tc) < 0.5]))
        rows.append((round(tc, 3), sec, round(d[0])))
    bad = [r for r in rows if r[2] > -3000]
    flag = "ALLOWED" if not bad else f"{len(bad)} covered event(s) show no dip"
    if P > 8:
        print(n, round(P, 4), flag, rows)
