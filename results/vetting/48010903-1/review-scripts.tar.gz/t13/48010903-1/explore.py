import numpy as np, json
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.detrend import detrend
from tess_hunt.checks.families import good_timestamps

lc = LightCurve.load(lc_dir() / "48010903.npz")
crit = load_criteria("criteria/search-v2.toml").values
for s in np.unique(lc.sector):
    m = lc.sector == s
    t = lc.time[m]
    dt = np.diff(t)
    gaps = [(round(t[i],2), round(t[i+1],2)) for i in np.where(dt > 0.3)[0]]
    print(f"S{s}: {t.min():.3f}-{t.max():.3f} n={m.sum()} gaps>0.3d={gaps} raw median {np.median(lc.flux[m]):.5f}")
good = good_timestamps(lc)
flat = detrend(good, crit["detrend"], [])
P, T0 = 24.947961342271636, 1566.0770557438036
events = {"e0": T0, "e28": T0+28*P, "e29": T0+29*P, "e87": T0+87*P}
P2, T02 = 34.45207244842177, 1575.5859589596942
for k in range(-2, 80):
    t = T02 + k*P2
    if ((lc.time > t-0.3) & (lc.time < t+0.3)).sum() > 10:
        events[f"s2_{k}"] = t
print(events)
fig, axes = plt.subplots(len(events), 1, figsize=(10, 2.6*len(events)))
for ax, (name, tc) in zip(axes, events.items()):
    for src, l, c in ((lc, "raw", "0.6"), (flat, "flat", "C0")):
        m = np.abs(src.time - tc) < 1.0
        if not m.any():
            continue
        f = src.flux[m] / np.median(src.flux[m]) if l == "raw" else src.flux[m]
        tt = (src.time[m] - tc) * 24
        # 30-min bins
        bins = np.arange(-24, 24.01, 0.5)
        idx = np.digitize(tt, bins)
        bt = [tt[idx == i].mean() for i in np.unique(idx)]
        bf = [np.median(f[idx == i]) for i in np.unique(idx)]
        ax.plot(tt, (f - 1) * 1e6 + (0 if l == "flat" else 6000), ".", ms=1, color=c, alpha=0.4)
        ax.plot(bt, (np.array(bf) - 1) * 1e6 + (0 if l == "flat" else 6000), "o-", ms=3, color=c)
        if l == "flat":
            sec = np.unique(src.sector[m])
            print(name, f"{tc:.3f}", "sector", sec)
            for b0 in np.arange(-12, 12.01, 1.0):
                mm = (tt >= b0) & (tt < b0 + 1)
                if mm.any():
                    print(f"   {b0:+5.1f}h n={mm.sum():3d} flat {np.median((f[mm]-1)*1e6):8.0f}")
    ax.set_title(f"{name} t={tc:.3f}")
    ax.axvline(0, color="r", lw=0.5)
fig.tight_layout()
fig.savefig("/tmp/t13/48010903-1/events.png", dpi=80)
