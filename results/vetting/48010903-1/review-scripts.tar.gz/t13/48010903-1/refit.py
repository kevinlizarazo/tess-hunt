# Refit the flat-prior transit model (vet-v3's fit_transit, same criteria and seed) on subsets of the events.
import sys, json, time
import numpy as np
from tess_hunt.config import lc_dir, load_criteria
from tess_hunt.lightcurve import LightCurve
from tess_hunt.detrend import detrend
from tess_hunt.checks.families import good_timestamps, split
from tess_hunt.ephemeris import Ephemeris
from tess_hunt.fit import fit_transit
from tess_hunt.checks.physical import shape, radius

crit_s = load_criteria("criteria/search-v2.toml").values
crit_v = load_criteria("criteria/vet-v3.toml").values
lc = LightCurve.load(lc_dir() / "48010903.npz")
good = good_timestamps(lc)
flat = detrend(good, crit_s["detrend"], [])
parts = split(flat, crit_v["families"])
pdc, qlp = parts["pdcsap"], parts["qlp"]
RAD = 1.32527
search = Ephemeris(24.948370273398364, 1566.0526256263609, 0.125, 0.0045749896410242)
PB = 29 * 24.947961342271636 / 21
alt = Ephemeris(PB, 1566.0526256263609, 0.125, 0.0045749896410242)
E28 = 1566.0770557438036 + 28 * 24.947961342271636

def cat(*lcs):
    t = np.concatenate([l.time for l in lcs]); o = np.argsort(t)
    pick = lambda a: np.concatenate(a)[o]
    return LightCurve(48010903, t[o], pick([l.flux for l in lcs]), pick([l.flux_err for l in lcs]),
                      pick([l.sector for l in lcs]), lcs[0].sources)

no28 = pdc.select(np.abs(pdc.time - E28) > 1.0)
cases = {
    "a_vet_reproduce_pdcsap_all_P24.948": (pdc, search),
    "c_pdcsap_without_e28_P34.452": (no28, alt),
    "d_S9_only_2min": (pdc.select(pdc.sector == 9), alt),
    "e_S36_only_10min": (pdc.select(pdc.sector == 36), alt),
    "f_S89_qlp_only": (qlp, alt),
    "g_S9_S36_S89_sharp_events_P34.452": (cat(no28, qlp), alt),
}
only = sys.argv[1:] or list(cases)
for name in only:
    l, eph = cases[name]
    t1 = time.time()
    fit = fit_transit(l, eph, crit_v["fit"], rho_prior=None, seed=crit_v["fit"]["seed"])
    sh, ra = shape(fit, 0.5), radius(fit, RAD, 22.0)
    rp = fit.column("rp_rs") * RAD * 109.076
    s = fit.summary()
    out = {
        "case": name, "n_cadences": int(len(l.time)), "sectors": sorted(set(int(x) for x in np.unique(l.sector))),
        "shape": sh.reason, "grazing": sh.evidence["grazing_probability"],
        "b": [round(s["b"]["median"], 3), round(s["b"]["minus"], 3), round(s["b"]["plus"], 3)],
        "rp_rs": [round(s["rp_rs"]["median"], 4), round(s["rp_rs"]["minus"], 4), round(s["rp_rs"]["plus"], 4)],
        "radius": ra.reason, "rp_p16_p50_p84": [round(float(x), 1) for x in np.percentile(rp, [16, 50, 84])],
        "p_rp_gt_22": round(float(np.mean(rp > 22)), 3),
        "log_rho": [round(s["log_rho"]["median"], 3), round(s["log_rho"]["minus"], 3), round(s["log_rho"]["plus"], 3)],
        "q1": round(s["q1"]["median"], 3), "q2": round(s["q1"]["median"], 3) and round(s["q2"]["median"], 3),
        "acceptance": round(fit.acceptance, 3), "seconds": round(time.time() - t1),
    }
    print(json.dumps(out), flush=True)
    np.savez_compressed(f"/tmp/t13/48010903-1/samples_{name}.npz", samples=fit.samples)
