# Raw flux at the start of S99 (timing-suspect, evidence only), where a 34.452 d period puts the sharp eclipse.
import numpy as np
from tess_hunt.config import lc_dir
from tess_hunt.lightcurve import LightCurve
lc = LightCurve.load(lc_dir() / "48010903.npz")
e0, D = 1566.0770557438036, 29 * 24.947961342271636
PB = D / 21
print("P = D/21 =", PB)
for k in range(-1, 75):
    tc = e0 + k * PB
    m = np.abs(lc.time - tc) < 0.5
    if m.sum() > 5:
        print(f"k={k} tc={tc:.3f} sectors={np.unique(lc.sector[m])} n={m.sum()}")
tc = e0 + 72 * PB
m = (lc.sector == 99) & (lc.time < 4047.6)
t, f = lc.time[m], lc.flux[m]
base = np.median(f[(t > tc + 0.25)])
for a in np.arange(4046.40, 4047.6, 1/24):
    mm = (t >= a) & (t < a + 1/24)
    if mm.any():
        print(f"{a:.3f} ({(a - tc)*24:+5.1f} h) n={mm.sum()} {np.median((f[mm]/base - 1)*1e6):8.0f} ppm")
