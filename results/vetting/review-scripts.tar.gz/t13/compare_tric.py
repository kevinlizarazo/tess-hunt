"""Task 13 (0036): compare one signal's TRICERATOPS record before and after the fix.
Usage: compare_tric.py <old signal dir> <new signal dir>  (each holds triceratops.json and probs.csv)"""

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

old_dir, new_dir = Path(sys.argv[1]), Path(sys.argv[2])


def load(d):
    rec = json.loads((d / "triceratops.json").read_text())
    probs = list(csv.DictReader((d / "probs.csv").open()))
    return rec, rec["evidence"], probs


(ro, eo, po), (rn, en, pn) = load(old_dir), load(new_dir)


def rel(a, b):
    return (b - a) / a if a else float("nan")


print("outcome:", ro["outcome"], "->", rn["outcome"])
print("  old reason:", ro["reason"])
print("  new reason:", rn["reason"])
for k in ("fpp_mean", "nfpp_mean", "fpp_sd", "nfpp_sd"):
    print(f"{k}: {eo[k]:.6g} -> {en[k]:.6g} (rel {rel(eo[k], en[k]):+.3g})")
print("blockers:", eo["blockers"], "->", en["blockers"])
print("missing_hosts:", eo["missing_hosts"], "->", en["missing_hosts"])
print("stars:", len(eo["stars"]), "->", len(en["stars"]))
dropped = en.get("dropped_stars")
print("dropped_stars:", None if dropped is None else len(dropped), dict(Counter(d["disposition"] for d in dropped or [])))
for d in dropped or []:
    print("  ", d)

ho = {h["source_id"]: h for h in eo["hosts"]}
hn = {h["source_id"]: h for h in en["hosts"]}
print("hosts:", len(ho), "->", len(hn), "only old:", sorted(set(ho) - set(hn)), "only new:", sorted(set(hn) - set(ho)))
for sid in sorted(set(ho) & set(hn)):
    a, b = ho[sid], hn[sid]
    if a["tic"] != b["tic"] or abs(a["tdepth"] - b["tdepth"]) > 1e-12 * max(1, abs(a["tdepth"])):
        print(f"  {sid}: TIC {a['tic']} -> {b['tic']}, dist {a['distance_arcsec']:.4f} -> {b['distance_arcsec']:.4f}, "
              f"tdepth {a['tdepth']:.6g} -> {b['tdepth']:.6g}, sep {b['sep_arcsec']:.2f}")
zo, zn = set(eo["hosts_tdepth_zero"]), set(en["hosts_tdepth_zero"])
print("hosts_tdepth_zero:", len(zo), "->", len(zn), "only old:", sorted(zo - zn), "only new:", sorted(zn - zo))


def by(probs, key):
    out = defaultdict(float)
    for r in probs:
        out[key(r)] += float(r["prob"])
    return out


print("last run's probs.csv, by scenario (old -> new):")
so, sn = by(po, lambda r: r["scenario"]), by(pn, lambda r: r["scenario"])
for s in sorted(set(so) | set(sn), key=lambda s: -max(so.get(s, 0), sn.get(s, 0))):
    if max(so.get(s, 0), sn.get(s, 0)) > 1e-6:
        print(f"  {s}: {so.get(s, 0):.4g} -> {sn.get(s, 0):.4g}")
print("last run's NFPP by star (N* scenarios, old -> new; top 8 either side):")
near = lambda r: r["ID"] if r["scenario"].startswith("N") else None  # noqa: E731
no, nn = by(po, near), by(pn, near)
no.pop(None, None)
nn.pop(None, None)
top = sorted(set(no) | set(nn), key=lambda i: -max(no.get(i, 0), nn.get(i, 0)))[:8]
for i in top:
    print(f"  TIC {i}: {no.get(i, 0):.4g} -> {nn.get(i, 0):.4g}")
print(f"  total: {sum(no.values()):.4g} -> {sum(nn.values()):.4g}")
