"""Ruling AX: every check in the rerun must reproduce the old run's, except what 0034 and 0035 change: the neighbour
table (its rows, separations, reason and centre) and holdout's new per-season counts and 441010857-1's outcome.
Usage: compare_runs.py <old vetting run> <new vetting run>"""

import json
import sys
from pathlib import Path

old_run, new_run = Path(sys.argv[1]), Path(sys.argv[2])
EXPECTED_OUTCOME_CHANGES = {("441010857-1", "holdout")}


def strip_holdout(evidence: dict) -> dict:
    # 0035 adds per-season counts; every field the old run had must still match.
    out = dict(evidence)
    out["seasons"] = [
        {k: v for k, v in s.items() if k in old_keys.get(s.get("season"), s)}
        for s in evidence.get("seasons", [])
    ]
    return out


problems, notes = [], []
names = sorted(p.name for p in (old_run / "signals").iterdir() if (p / "checks.json").is_file())
new_names = sorted(p.name for p in (new_run / "signals").iterdir() if (p / "checks.json").is_file())
if names != new_names:
    problems.append(f"signal lists differ: {sorted(set(names) ^ set(new_names))}")
for name in names:
    old = json.loads((old_run / "signals" / name / "checks.json").read_text())
    new = json.loads((new_run / "signals" / name / "checks.json").read_text())
    for key in sorted(set(old) | set(new)):
        if key == "neighbours":
            # 0034: the table is expected to move; its outcome must not.
            a, b = old.get(key) or {}, new.get(key) or {}
            if a.get("outcome") != b.get("outcome"):
                problems.append(f"{name}: neighbours {a.get('outcome')} -> {b.get('outcome')}")
            if a.get("reason") != b.get("reason"):
                notes.append(f"{name}: neighbours ({b.get('outcome')}) '{a.get('reason')}' -> '{b.get('reason')}'")
        elif key != "checks" and old.get(key) != new.get(key):
            problems.append(f"{name}: top-level {key} differs")
    old_checks = {c["check"]: c for c in old["checks"]}
    new_checks = {c["check"]: c for c in new["checks"]}
    if set(old_checks) != set(new_checks):
        problems.append(f"{name}: check lists differ")
    for check in sorted(old_checks):
        a, b = old_checks[check], new_checks.get(check, {})
        changed = a.get("outcome") != b.get("outcome")
        if changed and (name, check) not in EXPECTED_OUTCOME_CHANGES:
            problems.append(f"{name}: {check} {a.get('outcome')} -> {b.get('outcome')}")
        elif changed:
            notes.append(f"{name}: {check} {a.get('outcome')} -> {b.get('outcome')} (expected, 0035)")
        if check == "neighbours":
            if a.get("reason") != b.get("reason"):
                notes.append(f"{name}: neighbours reason '{a.get('reason')}' -> '{b.get('reason')}'")
            continue
        if check == "holdout":
            old_keys = {s.get("season"): s for s in a.get("evidence", {}).get("seasons", [])}
            if (name, check) in EXPECTED_OUTCOME_CHANGES:
                continue
            if a.get("evidence") != strip_holdout(b.get("evidence", {})) or a.get("reason") != b.get("reason"):
                problems.append(f"{name}: holdout evidence or reason differs beyond 0035's new fields")
            continue
        if a != b:
            diff = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
            problems.append(f"{name}: {check} differs in {diff}")

print(f"{len(names)} signals compared, {old_run.name} -> {new_run.name}")
for n in notes:
    print("note:", n)
for p in problems:
    print("PROBLEM:", p)
print("reproduced" if not problems else f"{len(problems)} problem(s)")
