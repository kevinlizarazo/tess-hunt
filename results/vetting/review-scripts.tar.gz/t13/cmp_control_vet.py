import json, sys
from pathlib import Path
old, new = Path(sys.argv[1]), Path(sys.argv[2])
diffs = 0
for d in sorted((old / "signals").iterdir()):
    a = json.loads((d / "checks.json").read_text())
    nb = new / "signals" / d.name / "checks.json"
    b = json.loads(nb.read_text())
    ca = {c["check"]: c for c in a["checks"]}
    cb = {c["check"]: c for c in b["checks"]}
    for k in sorted(set(ca) | set(cb)):
        oa, ob = ca.get(k, {}).get("outcome"), cb.get(k, {}).get("outcome")
        if oa != ob:
            diffs += 1
            print(f"{d.name} {k}: {oa} -> {ob} | {cb.get(k, {}).get('reason')}")
    ha = len(ca.get("neighbours", {}).get("evidence", {}).get("possible_hosts", []) or [])
    hb = len(cb.get("neighbours", {}).get("evidence", {}).get("possible_hosts", []) or [])
    if ha != hb:
        print(f"{d.name} possible_hosts {ha} -> {hb}")
    ra, rb = ca.get("holdout", {}).get("reason"), cb.get("holdout", {}).get("reason")
    if ra != rb:
        print(f"{d.name} holdout reason: {ra!r} -> {rb!r}")
print("outcome changes:", diffs)
