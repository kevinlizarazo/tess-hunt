"""Task 13, after the 0034/0035 rerun: merge a review addendum workflow's output with the review it updates into
review.json (calls.load_review's schema). Findings marked unchanged keep their old refuters, and must match the old
text exactly; every old finding must still be there.
Usage: assemble_addendum.py <workflow output json> <old review.json> <date> <out path>"""

import json
import sys
from pathlib import Path

from tess_hunt.calls import load_review

out_file, old_file, date, dest = sys.argv[1], Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4])
wf = json.loads(Path(out_file).read_text())
result = wf["result"]
old = json.loads(old_file.read_text())
old_by_id = {f["id"]: f for f in old["findings"]}
models = {m.strip() for m in old["model"].split(",")} | {
    e["model"] for e in wf["workflowProgress"] if e.get("type") == "workflow_agent" and e.get("model")
}

problems = []
if result["short_of_two"]:
    problems.append(f"refuters missing for {result['short_of_two']}")
missing = sorted(set(old_by_id) - {f["id"] for f in result["findings"]})
if missing:
    problems.append(f"old findings dropped: {missing}")
findings = []
for f in result["findings"]:
    status, why = f.pop("status"), f.pop("why")
    print(f"{f['id']} {f['rating']} {status}: {why}")
    if status == "unchanged":
        o = old_by_id.get(f["id"])
        if o is None or any(o[k] != f[k] for k in ("lens", "rating", "claim", "evidence")):
            problems.append(f"{f['id']} is marked unchanged but differs from the old review")
            continue
        f["refuters"] = o["refuters"]
    findings.append(f)
if problems:
    sys.exit("; ".join(problems))

review = {
    "signal": result["signal"],
    "model": ", ".join(sorted(models)),
    "date": date,
    "summary": result["summary"],
    "findings": findings,
    "hits_flagged": result["hits_flagged"],
}
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(json.dumps(review, indent=2) + "\n")
load_review(dest)
print(dest, "models:", review["model"], "findings:", len(findings))
