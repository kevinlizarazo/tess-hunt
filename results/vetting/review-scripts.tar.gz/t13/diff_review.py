"""Show, per finding and for the summary, what an addendum changed against the original review (sentence diff)."""
import difflib, json, re, sys
from pathlib import Path
o, n = (json.loads(Path(p).read_text()) for p in sys.argv[1:3])
def sents(t): return re.split(r"(?<=[.;])\s+", t)
def show(label, a, b):
    if a == b: print(f"{label}: same"); return
    for line in difflib.unified_diff(sents(a), sents(b), lineterm="", n=0):
        if line.startswith(("---", "+++", "@@")): continue
        print(f"{label} {line[:700]}")
show("summary", o["summary"], n["summary"])
ob = {f["id"]: f for f in o["findings"]}
for f in n["findings"]:
    g = ob.get(f["id"])
    if not g: print(f"{f['id']} NEW {f['rating']}: {f['claim'][:500]}"); continue
    if g["rating"] != f["rating"]: print(f"{f['id']} rating {g['rating']} -> {f['rating']}")
    for k in ("claim", "evidence"): show(f"{f['id']}.{k}", g[k], f[k])
    print(f"{f['id']} refuters: {[r['refuted'] for r in g['refuters']]} -> {[r['refuted'] for r in f['refuters']]}")
print("hits_flagged same:", o["hits_flagged"] == n["hits_flagged"], "| '&gt;' in new file:", "&gt;" in json.dumps(n))
