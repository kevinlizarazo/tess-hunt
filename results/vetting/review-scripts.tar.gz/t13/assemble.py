"""Task 13: turn a review workflow's output into review.json (calls.load_review's schema), checked by the loader.
Usage: assemble.py <workflow output json> <date> <out path>"""

import json
import sys
from pathlib import Path

from tess_hunt.calls import load_review

out_file, date, dest = sys.argv[1], sys.argv[2], Path(sys.argv[3])
wf = json.loads(Path(out_file).read_text())
result = wf["result"]
models = sorted(
    {e["model"] for e in wf["workflowProgress"] if e.get("type") == "workflow_agent" and e.get("model")}
)
if result["short_of_two"]:
    sys.exit(f"refuters missing for {result['short_of_two']}; rerun them before writing review.json")
review = {
    "signal": result["signal"],
    "model": ", ".join(models),
    "date": date,
    "summary": result["summary"],
    "findings": result["findings"],
    "hits_flagged": result["hits_flagged"],
}
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(json.dumps(review, indent=2) + "\n")
load_review(dest)
print(dest, "models:", review["model"], "findings:", len(review["findings"]))
