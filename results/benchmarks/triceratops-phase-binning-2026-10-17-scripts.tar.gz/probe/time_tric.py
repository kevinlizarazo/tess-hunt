"""Pin P2 probe: time one TRICERATOPS calc_probs. Usage: time_tric.py TIC N PARALLEL(0|1) EXPTIME_S SECTORS(comma)"""

import builtins
import os
import sys
import time
from datetime import UTC, datetime

import numpy as np
import pandas as pd

_print = builtins.print


def tprint(*a, **k):
    _print(datetime.now(UTC).strftime("%H:%M:%S"), *a, **k, flush=True)


builtins.print = tprint

from tess_hunt.config import lc_dir, load_criteria  # noqa: E402
from tess_hunt.detrend import detrend  # noqa: E402
from tess_hunt.ephemeris import Ephemeris, in_transit, phase_days  # noqa: E402
from tess_hunt.lightcurve import LightCurve  # noqa: E402
from triceratops.triceratops import target  # noqa: E402

tic, n, par, exptime_s = int(sys.argv[1]), int(float(sys.argv[2])), bool(int(sys.argv[3])), float(sys.argv[4])
sectors = [int(s) for s in sys.argv[5].split(",")]

row = pd.read_csv(sys.argv[6]).set_index("tic").loc[tic]
eph = Ephemeris(row.period, row.t0, row.duration, row.depth)
lc = LightCurve.load(lc_dir() / f"{tic}.npz")
lc = lc.select(np.isin(lc.sector, sectors))
crit = load_criteria("criteria/search-v2.toml")
flat = detrend(lc, crit["detrend"], hold_out=in_transit(lc.time, eph, 2.0))
ph = phase_days(flat.time, eph)
win = np.abs(ph) < 2 * eph.duration
t, f = ph[win], flat.flux[win]
err = float(np.median(flat.flux_err[win]))
if os.environ.get("BIN"):
    # Phase bins one exposure wide: the same time sampling as the data, one point per bin instead of one per transit.
    w = exptime_s / 86400.0
    idx = np.floor(t / w).astype(int)
    keys, inv, counts = np.unique(idx, return_inverse=True, return_counts=True)
    t = (keys + 0.5) * w
    f = np.bincount(inv, weights=f) / counts
    err = float(np.median(err / np.sqrt(counts)))
    print(f"binned to {len(t)} points; median {np.median(counts):.0f} per bin")
print(f"tic {tic} sectors {sectors} points {win.sum()} err {err:.2e} depth {eph.depth:.2e} N {n} parallel {par}")

t0 = time.time()
tg = target(ID=tic, sectors=np.array(sectors))
print(f"target built in {time.time() - t0:.0f} s; {len(tg.stars)} stars; field population {isinstance(tg.trilegal_fname, str)}")
if len(sys.argv) > 7:
    from astropy.io import fits

    files = dict(kv.split("=") for kv in sys.argv[7].split(","))
    aps = []
    for i, s in enumerate(tg.sectors):
        with fits.open(files[str(int(s))]) as h:
            bits = h["APERTURE"].data.astype(int)
            c0, r0 = h["APERTURE"].header["CRVAL1P"], h["APERTURE"].header["CRVAL2P"]
        rows, cols = np.nonzero(bits & 2)
        ap = np.column_stack([cols + c0, rows + r0])
        tp = np.round(tg.pix_coords[i][0])
        inside = any((ap[:, 0] == tp[0]) & (ap[:, 1] == tp[1]))
        print(f"sector {s}: {len(ap)} aperture pixels; target pixel {tp.tolist()} inside: {inside}")
        aps.append(ap)
else:
    aps = tg.get_spoc_apertures()
    if any(a is None for a in aps):
        aps = None
tg.calc_depths(tdepth=eph.depth, all_ap_pixels=aps)
print(f"stars with tdepth > 0: {(tg.stars['tdepth'] > 0).sum()}")
t1 = time.time()
np.random.seed(int(os.environ.get("SEED", "0")))
tg.calc_probs(time=t, flux_0=f, flux_err_0=err, P_orb=float(eph.period), N=n, parallel=par, exptime=exptime_s / 86400.0, verbose=1)
print(f"calc_probs done in {time.time() - t1:.0f} s: FPP {tg.FPP} NFPP {tg.NFPP}")
