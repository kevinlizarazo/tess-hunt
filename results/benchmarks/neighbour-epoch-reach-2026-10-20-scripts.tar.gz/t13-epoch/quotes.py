"""Separations quoted in decisions 0025, 0026, 0032, 0033 and in the dossier drafts, old and corrected."""
import json, re
from pathlib import Path
import pandas as pd
from tess_hunt.tricera import _separation_arcsec as sep

R = pd.read_csv("/tmp/t13-epoch/rows.csv")
T = pd.read_csv("/tmp/t13-epoch/targets.csv")


def row(run, name, sid):
    x = R[(R.run == run) & (R.name == name) & (R.source_id == sid)]
    return None if x.empty else x.iloc[0]


print("== decisions")
for run, name, sid, quoted, where in (
    ("CONTROL_VET", "TOI-1058.01", 6757952648798471040, 20.90, "0025, 0026, 0032"),
    ("CONTROL_VET", "TOI-1175.01", 2039904204830247296, 23.53, "0025, 0026, 0032"),
    ("VET_RUN", "44926986-1", 5431607545963652864, 12.5, "0026"),
):
    r = row(run, name, sid)
    print(f"{name} {sid} quoted {quoted} ({where}): table {r.sep_old:.4f}  corrected {r.sep_new:.4f}  moved {r.sep_new - r.sep_old:+.4f}")
# The network test centres on benchmarks/pixel_controls.csv's ra and dec, not the targets table's TIC position.
pc = pd.read_csv("benchmarks/pixel_controls.csv", dtype={"toi": str}).set_index("toi")
for toi, tic, eb in (("1058.01", 31553893, 6757952648798471040), ("1175.01", 30329585, 2039904204830247296)):
    cone = pd.read_csv(f"/tmp/t13-epoch/cones/{tic}.csv").set_index("source_id")
    m = next(x for x in json.loads(Path("/tmp/t13-epoch/manifest.json").read_text()) if x["tic"] == tic)
    e = cone.loc[eb]
    print(f"TOI-{toi}: pixel_controls.csv centre {pc.loc[toi].ra}, {pc.loc[toi].dec}; targets table {m['ra']}, {m['dec']};"
          f" the two {float(sep(pc.loc[toi].ra, pc.loc[toi].dec, m['ra'], m['dec'])):.3f}\" apart;"
          f" EB from pixel_controls centre {float(sep(pc.loc[toi].ra, pc.loc[toi].dec, e.ra, e.dec)):.4f}")
# 0033 item 3: 423100454-1's possible hosts "from 6.5\" out".
x = R[(R.run == "VET_RUN") & (R.name == "423100454-1") & R.possible].sort_values("sep_old").head(3)
print("423100454-1 nearest possible hosts:\n", x[["source_id", "sep_old", "sep_new"]].to_string(index=False))
x = R[(R.run == "VET_RUN") & (R.name == "423100454-1") & R.possible].sort_values("sep_new").head(3)
print("423100454-1 nearest possible hosts, corrected order:\n", x[["source_id", "sep_old", "sep_new"]].to_string(index=False))

print("== dossier drafts")
moved = []
quoted_rows = 0
for d in sorted(Path.home().joinpath(".cache/tess-hunt/drafts/m3").iterdir()):
    text = (d / "dossier.md").read_text()
    for sid, s in re.findall(r"^\| Gaia DR3 (\d+) \| ([0-9.]+) \|", text, re.M):
        quoted_rows += 1
        r = row("VET_RUN", d.name, int(sid))
        assert abs(float(s) - r.sep_old) <= 0.05 + 1e-9, (d.name, sid, s, r.sep_old)
        if abs(r.sep_new - r.sep_old) > 0.5:
            moved.append(dict(draft=d.name, source_id=int(sid), quoted=float(s), corrected=round(r.sep_new, 1),
                              moved=round(r.sep_new - r.sep_old, 2)))
M = pd.DataFrame(moved)
print("host rows quoted in drafts:", quoted_rows, " moved > 0.5\":", len(M))
print(M.groupby("draft").agg(rows=("source_id", "size"), max_moved=("moved", lambda v: v.abs().max())).to_string())
M.to_csv("/tmp/t13-epoch/dossier_moved.csv", index=False)
print(M.to_string(index=False))
