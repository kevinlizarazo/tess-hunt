"""The neighbour check and TRICERATOPS's host cross-check rerun, offline, on the corrected cone: the stored cone's
stars re-centred on the target's DR3 position, through the repo's own required_depths, neighbour_check and
missing_hosts."""
import json, os
from pathlib import Path
import numpy as np
import pandas as pd
from tess_hunt import neighbours, tricera
import tomllib

cfg_all = tomllib.loads(Path("criteria/vet-v3.toml").read_text())
CFG, TCFG = cfg_all["neighbours"], cfg_all["triceratops"]
R = CFG["radius_arcmin"] * 60
TRIC = {"VET_RUN": [os.environ["TRIC_RUN"]], "CONTROL_VET": [os.environ["CONTROL_TRIC"], os.environ["CONTROL_TRIC_4307"]]}


def sep(ra1, dec1, ra2, dec2):
    return tricera._separation_arcsec(ra1, dec1, ra2, dec2)


out = []
for m in json.loads(Path("/tmp/t13-epoch/manifest.json").read_text()):
    cone = pd.read_csv(f"/tmp/t13-epoch/cones/{m['tic']}.csv")
    sid = int(m["source_id"])
    tgt = cone[cone.source_id == sid].iloc[0]
    cone["sep_arcsec"] = sep(tgt.ra, tgt.dec, cone.ra, cone.dec)
    fixed = cone[cone.sep_arcsec <= R][neighbours.COLUMNS].sort_values("sep_arcsec").reset_index(drop=True)
    table = neighbours.required_depths(fixed, m["depth"], m["tmag"], sid, CFG)
    new = neighbours.neighbour_check(table, None).to_dict()
    checks = json.loads((Path(os.environ[m["run"]]) / "signals" / m["name"] / "checks.json").read_text())
    old = checks["neighbours"]
    old_hosts = {h["source_id"] for h in old["evidence"]["possible_hosts"]}
    new_hosts = {h["source_id"] for h in new["evidence"]["possible_hosts"]}
    row = dict(run=m["run"], name=m["name"], old_outcome=old["outcome"], new_outcome=new["outcome"],
               old_reason=old["reason"], new_reason=new["reason"],
               old_no_g=len(old["evidence"].get("no_g") or []), new_no_g=len(new["evidence"].get("no_g") or []),
               hosts_old=len(old_hosts), hosts_new=len(new_hosts),
               hosts_added=sorted(new_hosts - old_hosts), hosts_dropped=sorted(old_hosts - new_hosts))
    # TRICERATOPS's cross-check on the corrected possible hosts, against the star list each run stored.
    for run in TRIC.get(m["run"], []):
        f = Path(run) / "signals" / m["name"] / "triceratops.json"
        if not f.is_file():
            continue
        t = json.loads(f.read_text())
        stars = t["evidence"]["stars"]
        if stars is None:
            continue
        stars = pd.DataFrame(stars)
        possible = table[table["possible"]]
        row[f"tric {Path(run).name[:16]}"] = dict(
            outcome=t["outcome"], missing_old=t["evidence"]["missing_hosts"],
            missing_new=tricera.missing_hosts(possible, stars, TCFG["match_arcsec"]),
            added_hosts_matched={int(h["source_id"]): (h["tic"], round(h["distance_arcsec"], 3))
                                 for h in tricera._hosts(possible, stars, TCFG["match_arcsec"])
                                 if h["source_id"] in row["hosts_added"]},
        )
    out.append(row)
Path("/tmp/t13-epoch/outcomes.json").write_text(json.dumps(out, indent=1, default=str))
for r in out:
    changed = (r["old_outcome"] != r["new_outcome"] or r["old_reason"] != r["new_reason"]
               or r["hosts_added"] or r["hosts_dropped"])
    tric = {k: v for k, v in r.items() if k.startswith("tric")}
    if changed or any(v["missing_old"] != v["missing_new"] for v in tric.values()):
        print(json.dumps(r, default=str))
print("tables:", len(out), " outcome changes:", sum(r["old_outcome"] != r["new_outcome"] for r in out),
      " reason changes:", sum(r["old_reason"] != r["new_reason"] for r in out))
