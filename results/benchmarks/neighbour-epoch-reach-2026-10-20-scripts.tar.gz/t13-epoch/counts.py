"""Counts for the report: line and cone crossings per run, and the suspect run against the main one."""
import pandas as pd

R = pd.read_csv("/tmp/t13-epoch/rows.csv")
C = pd.read_csv("/tmp/t13-epoch/changes.csv")
T = pd.read_csv("/tmp/t13-epoch/targets.csv")
a = R[R.run == "VET_RUN"].drop(columns="run").reset_index(drop=True)
b = R[R.run == "VET_SUSPECT_RUN"].drop(columns="run").reset_index(drop=True)
print("VET_SUSPECT_RUN tables identical to VET_RUN's:", a.equals(b))
print("changes identical:", C[C.run == "VET_RUN"].drop(columns="run").reset_index(drop=True).equals(
    C[C.run == "VET_SUSPECT_RUN"].drop(columns="run").reset_index(drop=True)))
for run in ("VET_RUN", "CONTROL_VET"):
    x = R[R.run == run]
    print(f"== {run}: tables {T[T.run == run].shape[0]}, over 0.5\" {(T[T.run == run].offset > 0.5).sum()}, rows {len(x)}")
    for line in (15, 20, 25):
        c = x[(x.sep_old < line) != (x.sep_new < line)]
        print(f"  {line}\": {len(c)} rows ({int(c.possible.sum())} possible hosts) in {c.name.nunique()} tables:",
              c.groupby("name").size().to_dict())
    cc = C[C.run == run]
    print(f"  60\" cone: added {int((cc.change == 'added').sum())} ({int(cc[cc.change == 'added'].possible.sum())} possible),"
          f" dropped {int((cc.change == 'dropped').sum())} ({int(cc[cc.change == 'dropped'].possible.sum())} possible),"
          f" in {cc.name.nunique()} tables:", cc.groupby("name").size().to_dict())
    print("  rows moved > 0.5\":", int((x.delta.abs() > 0.5).sum()), "of", len(x),
          "| possible hosts moved > 0.5\":", int(((x.delta.abs() > 0.5) & x.possible).sum()), "of", int(x.possible.sum()))
# Stars by offset over 0.5", unique stars
u = T.drop_duplicates("tic")
print("unique stars:", len(u), "over 0.5\":", int((u.offset > 0.5).sum()))
print(u[u.offset > 0.5].groupby("kind").size().to_dict())
