"""A 90" Gaia DR3 cone around each target's TIC position, with the archive's own DISTANCE to that position (the
quantity neighbours.gaia_cone records as sep_arcsec), and each target's own DR3 row. Cached per TIC."""
import json
from pathlib import Path
import pandas as pd
from tess_hunt.gaia import launch_gaia

RADIUS_ARCSEC = 90.0
QUERY = """
SELECT source_id, ra, dec, phot_g_mean_mag, bp_rp, pmra, pmdec, parallax, ref_epoch,
       DISTANCE(POINT('ICRS', ra, dec), POINT('ICRS', {ra:.10f}, {dec:.10f})) * 3600 AS sep_tic
FROM gaiadr3.gaia_source
WHERE 1 = CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra:.10f}, {dec:.10f}, {r:.10f}))
"""
m = json.loads(Path("/tmp/t13-epoch/manifest.json").read_text())
stars = {r["tic"]: r for r in m}
for tic, r in sorted(stars.items()):
    out = Path(f"/tmp/t13-epoch/cones/{tic}.csv")
    if out.is_file():
        continue
    raw = launch_gaia(QUERY.format(ra=r["ra"], dec=r["dec"], r=RADIUS_ARCSEC / 3600), None)
    raw.columns = [str(c).lower() for c in raw.columns]
    raw.sort_values("sep_tic").to_csv(out, index=False)
    print(tic, len(raw), "target in cone:", int(r["source_id"]) in set(raw.source_id), flush=True)
