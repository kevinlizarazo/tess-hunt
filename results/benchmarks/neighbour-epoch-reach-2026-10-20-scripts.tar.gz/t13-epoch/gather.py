"""Every M3 neighbour table: each signal's star row, its neighbours.csv and checks.json's neighbour record."""
import json, os
from pathlib import Path
import numpy as np
import pandas as pd

RUNS = ("VET_RUN", "VET_SUSPECT_RUN", "CONTROL_VET")
rows = []
for label in RUNS:
    run = Path(os.environ[label])
    for d in sorted((run / "signals").iterdir()):
        c = json.loads((d / "checks.json").read_text())
        s, nb = c["star"], c["neighbours"]
        csv = d / "neighbours.csv"
        t = pd.read_csv(csv) if csv.is_file() else None
        ev = nb["evidence"].get("table")
        same = None
        if t is not None and ev is not None and len(ev) == 0:
            same = len(t) == 0
        elif t is not None and ev is not None:
            e = pd.DataFrame(ev)
            same = bool(
                list(e["source_id"]) == list(t["source_id"])
                and np.allclose(e["sep_arcsec"], t["sep_arcsec"], rtol=0, atol=1e-9)
                and list(e["possible"].astype(bool)) == list(t["possible"].astype(bool))
            )
        rows.append(
            dict(
                run=label, run_id=run.name, name=d.name, kind=c["signal"]["kind"], tic=int(s["tic"]),
                ra=float(s["ra"]), dec=float(s["dec"]), source_id=s.get("dr3_source_id"),
                dr3_from=s.get("dr3_from"), tmag=s.get("tmag"),
                depth=nb["evidence"].get("depth"), outcome=nb["outcome"], reason=nb["reason"],
                csv=str(csv) if t is not None else None, n_rows=None if t is None else len(t),
                csv_equals_checks=same,
                possible=[h["source_id"] for h in nb["evidence"].get("possible_hosts") or []],
            )
        )
Path("/tmp/t13-epoch/manifest.json").write_text(json.dumps(rows, indent=1))
m = pd.DataFrame(rows)
print(m[["run", "name", "kind", "tic", "dr3_from", "outcome", "n_rows", "csv_equals_checks"]].to_string())
print("tables:", len(m), "unique TICs:", m.tic.nunique())
# One TIC position per star across runs?
print("positions per TIC:", m.groupby("tic")[["ra", "dec"]].nunique().max().to_dict())
print("no source id:", m[m.source_id.isna()][["run", "name"]].to_dict("records"))
