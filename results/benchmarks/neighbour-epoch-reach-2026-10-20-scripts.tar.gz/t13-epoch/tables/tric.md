| table | signal | TRICERATOPS run | outcome | missing hosts now | missing hosts corrected | added hosts matched (TIC, distance at J2000 in ") |
|---|---|---|---|---|---|---|
| 19 | 103312990-1 | 20261020T013408Z | inconclusive | none | none | 5365550055598557056: TIC 103313020 0.002 |
| 19 | 146282666-1 | 20261020T013408Z | inconclusive | none | none | no host added |
| 19 | 164767175-1 | 20261020T013408Z | pass | none | none | no host added |
| 19 | 296819076-1 | 20261020T013408Z | inconclusive | none | none | 5877911719540705408: TIC 1132493713 0.174; 5877911719540657024: TIC 1132493694 0.029 |
| 19 | 399023421-1 | 20261020T013408Z | inconclusive | none | none | no host added |
| 19 | 44926986-1 | 20261020T013408Z | fail | none | none | no host added |
| controls | TOI-1052.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-1058.01 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-107.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-1097.02 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-1175.01 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-118.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-1399.01 | 20261017T162256Z | fail | none | none | no host added |
| controls | TOI-144.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-188.01 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-191.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-2011.02 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-396.01 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-396.03 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-411.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-4307.01 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-4307.01 | 20261018T012940Z | pass | none | none | no host added |
| controls | TOI-4320.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-451.02 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-451.03 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-576.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-652.01 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-747.01 | 20261017T162256Z | inconclusive | none | none | no host added |
| controls | TOI-755.01 | 20261017T162256Z | pass | none | none | 6133384204027888128: TIC 73228631 0.002 |
| controls | TOI-763.02 | 20261017T162256Z | pass | none | none | no host added |
| controls | TOI-826.01 | 20261017T162256Z | pass | none | none | no host added |
