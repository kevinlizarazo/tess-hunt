| table | signal | outcome | reason now | reason corrected | possible hosts added | possible hosts dropped |
|---|---|---|---|---|---|---|
| 19 | 103312990-1 | pass (unchanged) | 20 of 54 neighbours could host the signal | 21 of 55 neighbours could host the signal | 5365550055598557056 | none |
| 19 | 173369850-1 | pass (unchanged) | 39 of 143 neighbours could host the signal | 39 of 144 neighbours could host the signal | none | none |
| 19 | 296819076-1 | inconclusive (unchanged) | 10 Gaia DR3 star(s) within the radius have no G magnitude | 10 Gaia DR3 star(s) within the radius have no G magnitude | 5877911719540657024 5877911719540705408 | 5877910924970222464 5877910929266500992 5877911749605067264 |
| 19 | 337885456-1 | pass (unchanged) | 40 of 233 neighbours could host the signal | 40 of 237 neighbours could host the signal | none | none |
| 19 | 399023421-1 | pass (unchanged) | 53 of 83 neighbours could host the signal | 53 of 82 neighbours could host the signal | none | none |
| 19 | 410399327-1 | pass (unchanged) | 11 of 23 neighbours could host the signal | 12 of 24 neighbours could host the signal | 6434209107919208064 | none |
| 19 | 423100454-1 | inconclusive (unchanged) | 1 Gaia DR3 star(s) within the radius have no G magnitude | 1 Gaia DR3 star(s) within the radius have no G magnitude | 5836452739533401088 | 5836452778233699456 5836452808248808320 5836452881313190784 5836453598524522240 |
| 19 | 44926986-1 | pass (unchanged) | 7 of 29 neighbours could host the signal | 6 of 28 neighbours could host the signal | none | 5431607644742487424 |
| 19 | 458290782-1 | inconclusive (unchanged) | 1 Gaia DR3 star(s) within the radius have no G magnitude | 2 Gaia DR3 star(s) within the radius have no G magnitude | 5971009602504628608 | none |
| controls | TOI-1052.01 | pass (unchanged) | 3 of 14 neighbours could host the signal | 3 of 16 neighbours could host the signal | none | none |
| controls | TOI-1058.01 | pass (unchanged) | 7 of 92 neighbours could host the signal | 7 of 91 neighbours could host the signal | none | none |
| controls | TOI-1175.01 | pass (unchanged) | 13 of 84 neighbours could host the signal | 13 of 82 neighbours could host the signal | none | none |
| controls | TOI-1399.01 | pass (unchanged) | 17 of 60 neighbours could host the signal | 17 of 61 neighbours could host the signal | none | none |
| controls | TOI-2011.02 | pass (unchanged) | 2 of 202 neighbours could host the signal | 2 of 193 neighbours could host the signal | none | none |
| controls | TOI-396.01 | pass (unchanged) | 1 of 8 neighbours could host the signal | 1 of 7 neighbours could host the signal | none | none |
| controls | TOI-396.03 | pass (unchanged) | 1 of 8 neighbours could host the signal | 1 of 7 neighbours could host the signal | none | none |
| controls | TOI-4307.01 | pass (unchanged) | 2 of 44 neighbours could host the signal | 2 of 41 neighbours could host the signal | none | none |
| controls | TOI-652.01 | pass (unchanged) | 3 of 11 neighbours could host the signal | 2 of 11 neighbours could host the signal | none | 5660492086942048384 |
| controls | TOI-755.01 | pass (unchanged) | 9 of 38 neighbours could host the signal | 10 of 39 neighbours could host the signal | 6133384204027888128 | none |
| controls | TOI-763.02 | pass (unchanged) | 2 of 14 neighbours could host the signal | 2 of 15 neighbours could host the signal | none | none |
