"""Each M3 neighbour table against the epoch-consistent one: separations from the target's own DR3 position (J2016)
to each DR3 star (J2016), and the 60" cone centred there."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from tess_hunt.neighbours import tess_mag, tess_mag_bright

RADIUS = 60.0  # criteria/vet-v3.toml [neighbours] radius_arcmin = 1.0
LINES = (15.0, 20.0, 25.0)
CFG = {"bp_rp_range": [0.0, 3.0], "max_required_depth": 1.0}


def sep(ra1, dec1, ra2, dec2):
    ra1, dec1, ra2, dec2 = (np.radians(np.asarray(v, dtype=float)) for v in (ra1, dec1, ra2, dec2))
    h = np.sin((dec2 - dec1) / 2) ** 2 + np.cos(dec1) * np.cos(dec2) * np.sin((ra2 - ra1) / 2) ** 2
    return np.degrees(2 * np.arcsin(np.sqrt(np.clip(h, 0, 1)))) * 3600


def judge(row, depth, t_target):
    g, c = row["phot_g_mean_mag"], row["bp_rp"]
    if pd.isna(g):
        return np.nan, np.nan, False, "none"
    t = tess_mag(g, c) if pd.notna(c) else tess_mag_bright(g, CFG["bp_rp_range"])
    rd = depth * 10 ** (0.4 * (t - t_target))
    return t, rd, bool(rd <= CFG["max_required_depth"]), "colour" if pd.notna(c) else "g_only"


manifest = json.loads(Path("/tmp/t13-epoch/manifest.json").read_text())
targets, rows, changes, repro = [], [], [], []
for m in manifest:
    cone = pd.read_csv(f"/tmp/t13-epoch/cones/{m['tic']}.csv")
    sid = int(m["source_id"])
    tgt = cone[cone.source_id == sid].iloc[0]
    others = cone[cone.source_id != sid].copy()
    others["sep_new"] = sep(tgt.ra, tgt.dec, others.ra, others.dec)
    old = others[others.sep_tic <= RADIUS]
    new = others[others.sep_new <= RADIUS]
    table = pd.read_csv(m["csv"]) if m["csv"] else None
    # The archive's DISTANCE to the TIC position must reproduce the table's sep_arcsec, star for star.
    t_ids = set() if table is None else set(table.source_id)
    merged = table.merge(old[["source_id", "sep_tic", "sep_new"]], on="source_id", how="left") if table is not None else None
    repro.append(dict(run=m["run"], name=m["name"], table_rows=len(t_ids), cone_rows=len(old),
                      same_stars=t_ids == set(old.source_id),
                      max_sep_diff=float((merged.sep_arcsec - merged.sep_tic).abs().max()) if merged is not None and len(merged) else 0.0,
                      target_self_sep=float(sep(tgt.ra, tgt.dec, tgt.ra, tgt.dec))))
    pm = float(np.hypot(tgt.pmra, tgt.pmdec)) if pd.notna(tgt.pmra) else np.nan
    targets.append(dict(run=m["run"], name=m["name"], kind=m["kind"], tic=m["tic"], source_id=sid,
                        offset=float(tgt.sep_tic), pm_masyr=pm, pm_x16=pm * 16 / 1000,
                        n_old=len(old), n_new=len(new), outcome=m["outcome"]))
    if merged is not None:
        for r in merged.itertuples():
            rows.append(dict(run=m["run"], name=m["name"], tic=m["tic"], source_id=r.source_id,
                             sep_old=r.sep_arcsec, sep_new=r.sep_new, possible=bool(r.possible),
                             g=r.phot_g_mean_mag))
    for kind, ids in (("added", set(new.source_id) - set(old.source_id)), ("dropped", set(old.source_id) - set(new.source_id))):
        for s in ids:
            r = others[others.source_id == s].iloc[0]
            t, rd, possible, frm = judge(r, m["depth"], m["tmag"])
            if kind == "dropped" and table is not None:
                tr = table[table.source_id == s].iloc[0]
                assert bool(tr.possible) == possible, (m["name"], s)
            changes.append(dict(run=m["run"], name=m["name"], tic=m["tic"], change=kind, source_id=int(s),
                                sep_old=float(r.sep_tic), sep_new=float(r.sep_new), g=r.phot_g_mean_mag,
                                bp_rp=r.bp_rp, tmag=t, tmag_from=frm, required_depth=rd, possible=possible))

T, R, C, P = map(pd.DataFrame, (targets, rows, changes, repro))
R["delta"] = R.sep_new - R.sep_old
for name, df in (("targets", T), ("rows", R), ("changes", C), ("repro", P)):
    df.to_csv(f"/tmp/t13-epoch/{name}.csv", index=False)
pd.set_option("display.width", 250)
print("== reproduction: stars equal in all tables:", P.same_stars.all(), " max |sep diff| arcsec:", P.max_sep_diff.max())
print(P[~P.same_stars].to_string())
print("== targets by offset (unique stars)")
u = T.drop_duplicates("tic").sort_values("offset", ascending=False)
print(u[["name", "kind", "tic", "source_id", "offset", "pm_masyr", "pm_x16", "n_old", "n_new"]].to_string(index=False))
print("== over 0.5\":", (u.offset > 0.5).sum(), "of", len(u), "stars;", (T.offset > 0.5).sum(), "of", len(T), "tables")
print("== cone changes")
print(C.sort_values(["run", "name"]).to_string(index=False))
print("== line crossings")
for line in LINES:
    x = R[(R.sep_old < line) != (R.sep_new < line)]
    print(f"-- {line}\"")
    print(x.to_string(index=False) if len(x) else "none")
print("== max |delta| per table vs offset")
mx = R.groupby(["run", "name"]).delta.apply(lambda d: d.abs().max()).rename("max_abs_delta").reset_index()
print(mx.merge(T[["run", "name", "offset"]]).query("offset > 0.5").to_string(index=False))
