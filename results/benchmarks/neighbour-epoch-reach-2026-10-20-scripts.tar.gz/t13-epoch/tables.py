"""The report's tables, written from the analysis CSVs so no number is copied by hand."""
import json
from pathlib import Path
import pandas as pd

D = Path("/tmp/t13-epoch")
T, R, C = (pd.read_csv(D / f) for f in ("targets.csv", "rows.csv", "changes.csv"))
O = json.loads((D / "outcomes.json").read_text())
M = pd.read_csv(D / "dossier_moved.csv")
R["delta"] = R.sep_new - R.sep_old


def md(df):
    cols = list(df.columns)
    out = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    out += ["| " + " | ".join(str(v) for v in row) + " |" for row in df.itertuples(index=False)]
    return "\n".join(out) + "\n"


def f(x, n=2):
    return "" if pd.isna(x) else f"{x:.{n}f}"


# 1. Every star over 0.5", one row per star with the signals and runs that carry it.
t = T[T.offset > 0.5].copy()
t["runs"] = t.run
g = t.groupby("tic")
rows = []
for tic, x in g:
    first = x.iloc[0]
    rr = R[(R.tic == tic) & R.run.isin(["VET_RUN", "CONTROL_VET"])]
    rows.append(dict(
        signal=", ".join(sorted(set(x.name))), kind=first.kind, TIC=tic, **{"Gaia DR3 id": first.source_id},
        **{"offset (\")": f(first.offset, 3), "DR3 pm (mas/yr)": f(first.pm_masyr, 1), "pm x 16 yr (\")": f(first.pm_x16, 3)},
        **{"tables": ", ".join(sorted(set(x.run))), "rows": int(first.n_old),
           "max shift (\")": f(rr.groupby("name").delta.apply(lambda d: d.abs().max()).max(), 3) if len(rr) else "no rows"},
    ))
(D / "tables/offsets.md").write_text(md(pd.DataFrame(rows).sort_values("offset (\")", key=lambda s: s.astype(float), ascending=False)))
under = T[T.offset <= 0.5].drop_duplicates("tic").sort_values("offset", ascending=False)
(D / "tables/under.md").write_text(", ".join(f"{n} {o:.3f}" for n, o in zip(under.name, under.offset)) + "\n")

# 2. Line crossings and cone changes, VET_RUN and CONTROL_VET (VET_SUSPECT_RUN repeats VET_RUN exactly).
x = R[R.run.isin(["VET_RUN", "CONTROL_VET"])]
lines = []
for line in (15, 20, 25):
    c = x[(x.sep_old < line) != (x.sep_new < line)].copy()
    c["line"] = f'{line}"'
    lines.append(c)
L = pd.concat(lines)
L = L.assign(table=L.run.map({"VET_RUN": "19", "CONTROL_VET": "controls"}))
L = L.sort_values(["table", "name", "line", "sep_old"])
(D / "tables/lines_all.md").write_text(md(pd.DataFrame({
    "table": L.table, "signal": L.name, "line": L.line, "Gaia DR3 id": L.source_id,
    "table sep (\")": L.sep_old.map(f), "corrected (\")": L.sep_new.map(f), "possible": L.possible})))
P = L[L.possible]
(D / "tables/lines_possible.md").write_text(md(pd.DataFrame({
    "table": P.table, "signal": P.name, "line": P.line, "Gaia DR3 id": P.source_id,
    "table sep (\")": P.sep_old.map(f), "corrected (\")": P.sep_new.map(f)})))
c = C[C.run.isin(["VET_RUN", "CONTROL_VET"])].copy()
c["table"] = c.run.map({"VET_RUN": "19", "CONTROL_VET": "controls"})
c = c.sort_values(["table", "name", "change", "sep_new"])
cone = pd.DataFrame({"table": c.table, "signal": c.name, "change": c.change, "Gaia DR3 id": c.source_id,
                     "table sep (\")": c.sep_old.map(f), "corrected (\")": c.sep_new.map(f),
                     "G": c.g.map(lambda v: f(v, 2) or "none"), "required depth": c.required_depth.map(lambda v: f(v, 3) or "none"),
                     "possible": c.possible})
(D / "tables/cone_all.md").write_text(md(cone))
key = cone[(cone.possible) | (cone.G == "none")]
(D / "tables/cone_key.md").write_text(md(key))

# 3. Outcome rows that change anything (VET_RUN and CONTROL_VET).
rows = []
for o in O:
    if o["run"] == "VET_SUSPECT_RUN":
        continue
    if o["old_reason"] == o["new_reason"] and not o["hosts_added"] and not o["hosts_dropped"]:
        continue
    rows.append({"table": {"VET_RUN": "19", "CONTROL_VET": "controls"}[o["run"]], "signal": o["name"],
                 "outcome": o["old_outcome"] + (" (unchanged)" if o["old_outcome"] == o["new_outcome"] else " -> " + o["new_outcome"]),
                 "reason now": o["old_reason"], "reason corrected": o["new_reason"],
                 "possible hosts added": " ".join(map(str, o["hosts_added"])) or "none",
                 "possible hosts dropped": " ".join(map(str, o["hosts_dropped"])) or "none"})
(D / "tables/outcomes.md").write_text(md(pd.DataFrame(rows)))
tri = []
for o in O:
    for k, v in o.items():
        if k.startswith("tric"):
            tri.append({"table": {"VET_RUN": "19", "CONTROL_VET": "controls"}[o["run"]], "signal": o["name"], "TRICERATOPS run": k[5:],
                        "outcome": v["outcome"], "missing hosts now": v["missing_old"] or "none",
                        "missing hosts corrected": v["missing_new"] or "none",
                        "added hosts matched (TIC, distance at J2000 in \")": "; ".join(f"{s}: TIC {t} {d}" for s, (t, d) in v["added_hosts_matched"].items()) or "no host added"})
(D / "tables/tric.md").write_text(md(pd.DataFrame(tri)))

# 4. Draft rows moved by more than 0.5".
(D / "tables/drafts_summary.md").write_text(md(M.groupby("draft").agg(
    **{"rows moved > 0.5\"": ("source_id", "size"), "largest shift (\")": ("moved", lambda v: f"{v.abs().max():.2f}")}).reset_index()))
(D / "tables/drafts_all.md").write_text(md(pd.DataFrame({"draft": M.draft, "Gaia DR3 id": M.source_id,
    "quoted (\")": M.quoted.map(lambda v: f"{v:.1f}"), "corrected (\")": M.corrected.map(lambda v: f"{v:.1f}"),
    "shift (\")": M.moved.map(lambda v: f"{v:+.2f}")})))
# Controls by proper motion, for the adjacent pixel-check note.
cs = T[T.run == "CONTROL_VET"].drop_duplicates("tic").sort_values("pm_masyr", ascending=False)
(D / "tables/controls_pm.md").write_text(md(pd.DataFrame({"control": [", ".join(sorted(T[(T.run == 'CONTROL_VET') & (T.tic == t)].name)) for t in cs.tic],
    "DR3 pm (mas/yr)": cs.pm_masyr.map(lambda v: f"{v:.1f}")}).head(8)))
for p in sorted((D / "tables").iterdir()):
    print(p.name, len(p.read_text().splitlines()))
