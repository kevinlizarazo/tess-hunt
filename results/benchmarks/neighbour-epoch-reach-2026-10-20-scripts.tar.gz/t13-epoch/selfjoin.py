"""The fix's query shape, tried read-only: a cone centred on the target's own DR3 row, in one ADQL self-join,
against the corrected cone computed offline."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from tess_hunt.gaia import launch_gaia
from tess_hunt.tricera import _separation_arcsec as sep

QUERY = """
SELECT g.source_id, g.ra, g.dec, g.phot_g_mean_mag, g.bp_rp,
       DISTANCE(POINT('ICRS', g.ra, g.dec), POINT('ICRS', t.ra, t.dec)) * 3600 AS sep_arcsec,
       g.pmra, g.pmdec, g.ref_epoch
FROM gaiadr3.gaia_source AS t, gaiadr3.gaia_source AS g
WHERE t.source_id = {sid}
  AND 1 = CONTAINS(POINT('ICRS', g.ra, g.dec), CIRCLE('ICRS', t.ra, t.dec, {r:.10f}))
"""
m = {x["tic"]: x for x in json.loads(Path("/tmp/t13-epoch/manifest.json").read_text())}
for tic in (136916387, 423100454):
    sid = int(m[tic]["source_id"])
    got = launch_gaia(QUERY.format(sid=sid, r=1.0 / 60), None)
    got.columns = [str(c).lower() for c in got.columns]
    cone = pd.read_csv(f"/tmp/t13-epoch/cones/{tic}.csv")
    t = cone[cone.source_id == sid].iloc[0]
    cone["sep_new"] = sep(t.ra, t.dec, cone.ra, cone.dec)
    want = cone[cone.sep_new <= 60]
    j = got.merge(want[["source_id", "sep_new"]], on="source_id", how="outer", indicator=True)
    print(tic, "rows", len(got), "offline", len(want), "same stars:", set(got.source_id) == set(want.source_id),
          "max |sep diff|:", float((j.sep_arcsec - j.sep_new).abs().max()))
