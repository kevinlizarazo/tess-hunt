"""What the J2000 position still touches: TESScut centres the cutout on it, and tess_PRF_centroid seeds its fit from
the flux centroid of the cutout's central 7 x 7 pixels. For each sector: where the target sits from the cutout's
centre pixel, and the fit's offset again with the seed taken from a 7 x 7 box centred on the target's pixel, and with
the seed at the target's own catalogue position.

Usage: seed_check.py LABEL ... (labels as in jobs.json)
"""
import json
import pickle
import sys
import warnings

import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, "/tmp/pixel-diag")
from sector_detail import fit, index_of, prf_model  # noqa: E402
from transitDiffImage import tessDiffImage, transitCentroids  # noqa: E402

warnings.filterwarnings("ignore")
jobs = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/jobs.json"))}


def offset_from(seed, prf, images, cat, pix):
    """The fit from this seed, as tess_PRF_centroid runs it: (offset in arcsec, quality)."""
    data = images["diffImage"].copy()
    r = minimize(transitCentroids.sim_image_data_diff, seed, method="L-BFGS-B", args=(prf, cat, data))
    quality = np.corrcoef(transitCentroids.render_prf(prf, r.x, cat).ravel(), data.ravel())[0, 1]
    ra, dec = tessDiffImage.pix_to_ra_dec(pix["sector"], pix["camera"], pix["ccd"], r.x[0], r.x[1])
    ra0, dec0 = float(cat["correctedRa"][0]), float(cat["correctedDec"][0])
    return float(np.hypot((ra - ra0) * np.cos(np.radians(dec0)), dec - dec0) * 3600), float(quality)


def verdict(rows):
    """The check's rule on a set of (offset, quality): the best-quality sector's offset against 15"."""
    off, q = max(rows, key=lambda x: x[1])
    return f'{"fail" if off > 15 else "pass"} ({off:.1f}", q {q:.2f})'


for label in sys.argv[1:]:
    job = jobs[label]
    print(f"== {label}")
    print("   S    target pixel from cutout centre (col, row)  recorded (q)    box on target (q)   seed at target (q)")
    runs = {"recorded": [], "box": [], "at": []}
    for s in job["sectors"]:
        with open(f'{job["star_dir"]}/imageData_{job["planet_id"]}_sector{s}.pickle', "rb") as fh:
            images, cat, pix, *_ = pickle.load(fh)
        prf = prf_model(images, cat, pix)
        ny, nx = images["diffImage"].shape
        r0, c0 = index_of(cat, pix, cat["ticColPix"][0], cat["ticRowPix"][0])
        f = fit(prf, images["diffImage"], cat, pix)
        recorded = (f["offset"], f["quality"])
        ext = cat["extent"]
        close = images["diffImage"][r0 - 3:r0 + 4, c0 - 3:c0 + 4]
        close_ext = [ext[0] + c0 - 3, ext[0] + c0 + 4, ext[2] + r0 - 3, ext[2] + r0 + 4]
        qfc = transitCentroids.quick_flux_centroid(close, close_ext)
        boxed = offset_from(np.array([qfc[0], qfc[1], 1, 0]), prf, images, cat, pix)
        at_target = offset_from(np.array([float(cat["ticColPix"][0]), float(cat["ticRowPix"][0]), 1, 0]),
                                prf, images, cat, pix)
        for key, val in (("recorded", recorded), ("box", boxed), ("at", at_target)):
            runs[key].append(val)
        print(f'   {s:<4d} ({c0 - nx // 2:+d}, {r0 - ny // 2:+d})                                   '
              + "   ".join(f'{o:6.1f}" ({q:.2f})' for o, q in (recorded, boxed, at_target)))
    print("   the rule on each:", "; ".join(f"{k} {verdict(v)}" for k, v in runs.items()))
