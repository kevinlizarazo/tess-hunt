"""Largest |check - DR3| per epoch_check printout: the position error at the sector's epoch, in arcsec."""
import re, sys
for path in sys.argv[1:]:
    vals = [float(m.group(1)) for line in open(path)
            if (m := re.match(r"\s+\d+\s+\d{4}\.\d+\s+\(\s*[-+]\d+\.\d+,\s*[-+]\d+\.\d+\)\s+(\d+\.\d+)", line))]
    print(f"{path}: {len(vals)} sectors, largest {max(vals):.2f}\"")
