"""jobs_triage.json: triage's own pixel-check pickles for the vetted signals that are not on the second list."""
import json
import os
from pathlib import Path

vet = Path(os.environ["VET_RUN"]) / "signals"
second = {p.name for p in (Path(os.environ["SECOND_RUN"]) / "signals").iterdir()}
tdi = Path.home() / ".cache/tess-hunt/tdi" / Path(os.environ["TRIAGE_RUN"]).name
jobs = []
for d in sorted(vet.iterdir()):
    if d.name in second:
        continue
    tic = d.name.split("-")[0]
    star_dir = tdi / d.name / f"tic{tic}"
    sectors = sorted((int(p.stem.split("sector")[1]) for p in star_dir.glob("imageData_*.pickle")), reverse=True)
    jobs.append({"label": d.name, "star_dir": str(star_dir), "planet_id": f"{tic}.1", "sectors": sectors})
json.dump(jobs, open("/tmp/pixel-diag/jobs_triage.json", "w"), indent=1)
print(" ".join(j["label"] for j in jobs))
