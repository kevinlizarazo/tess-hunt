"""Which position the pixel check measures its offset from, and how far that position sits from Gaia DR3's at each
sector's epoch.

For each signal and measured sector: the target position transit-diffImage used (catalogData correctedRa/Dec[0],
from the saved pickle), the TIC's J2000 position and the TIC's RA_orig/Dec_orig with its proper motion (MAST TIC),
Gaia DR3's position carried to the sector's mean time, and the fit (detail.json). Prints, in arcsec east and north:
  check - DR3: the error of the position the offset is measured from
  J2000 - DR3: what that error would be if the J2000 position had been used
  recorded:    the fit minus the check's position (the recorded offset)
  from DR3:    the fit minus DR3's position at the sector's epoch
Usage: [JOBS=jobs_triage.json] epoch_check.py LABEL ... (labels as in the jobs file; a signal with no fit in
detail.json gets the position columns only)
"""
import json
import os
import pickle
import sys
import warnings

import numpy as np

warnings.filterwarnings("ignore")
from astroquery.gaia import Gaia  # noqa: E402
from astroquery.mast import Catalogs  # noqa: E402

J2016 = 2457389.0 - 2457000  # Gaia DR3's epoch, J2016.0, in TESS BJD
labels = sys.argv[1:]
jobs = {j["label"]: j for j in json.load(open(os.environ.get("JOBS", "/tmp/pixel-diag/jobs.json")))}
detail = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/detail.json"))}


def star_of(label):
    run = os.environ["CONTROL_VET"] if label.startswith("TOI-") else os.environ["VET_RUN"]
    return json.load(open(f"{run}/signals/{label}/checks.json"))["star"]


stars = {label: star_of(label) for label in labels}
tics = sorted({int(stars[lb]["tic"]) for lb in labels})
tic = Catalogs.query_criteria(catalog="Tic", ID=tics)
tic = {int(r["ID"]): r for r in tic}
dr3_ids = sorted({int(stars[lb]["dr3_source_id"]) for lb in labels})
job = Gaia.launch_job(
    "select source_id, ra, dec, pmra, pmdec, ref_epoch, phot_g_mean_mag from gaiadr3.gaia_source where source_id in ("
    + ",".join(str(i) for i in dr3_ids) + ")")
dr3 = {int(r["source_id"]): r for r in job.get_results()}


def en(ra, dec, ra0, dec0):
    return (ra - ra0) * np.cos(np.radians(dec0)) * 3600, (dec - dec0) * 3600


for label in labels:
    st = stars[label]
    t = tic[int(st["tic"])]
    g = dr3[int(st["dr3_source_id"])]
    pm = float(np.hypot(g["pmra"], g["pmdec"]))
    j2000_vs_dr3 = en(float(t["ra"]), float(t["dec"]), float(g["ra"]), float(g["dec"]))
    print(f'== {label} TIC {int(st["tic"])}: POSflag {t["POSflag"]}, PMflag {t["PMflag"]}; DR3 {int(g["source_id"])} '
          f'G {float(g["phot_g_mean_mag"]):.2f}, pm {pm:.1f} mas/yr; TIC pm ({float(t["pmRA"]):.1f}, {float(t["pmDEC"]):.1f}) '
          f'vs DR3 ({float(g["pmra"]):.1f}, {float(g["pmdec"]):.1f}); TIC J2000 minus DR3 J2016: '
          f'{np.hypot(*j2000_vs_dr3):.1f}"; star table ra/dec equals TIC J2000: '
          f'{abs(st["ra"] - float(t["ra"])) < 1e-7 and abs(st["dec"] - float(t["dec"])) < 1e-7}')
    print("   S    years  check-DR3 (E,N)   |.|   J2000-DR3 |.|  recorded (E,N)    |.|   from DR3 (E,N)    |.|  "
          "code=TIC orig+pm")
    fits = {s["sector"]: s["fit"] for s in detail[label]["per_sector"]} if label in detail else {}
    jb = jobs[label]
    for s in jb["sectors"]:
        with open(f'{jb["star_dir"]}/imageData_{jb["planet_id"]}_sector{s}.pickle', "rb") as fh:
            _, cat, pix, *_ = pickle.load(fh)
        bjd = float(np.mean(pix["time"]))
        yrs = (bjd - J2016) / 365.25
        ra3 = float(g["ra"]) + float(g["pmra"]) * yrs / 3.6e6 / np.cos(np.radians(float(g["dec"])))
        dec3 = float(g["dec"]) + float(g["pmdec"]) * yrs / 3.6e6
        cra, cdec = float(cat["correctedRa"][0]), float(cat["correctedDec"][0])
        # transit-diffImage's own sum, from the TIC row, to show the pickle's position is RA_orig plus proper motion
        dt = (bjd - (2457206.375 - 2457000)) / 365
        ora = float(t["RA_orig"]) + dt * float(t["pmRA"]) / 3.6e6 / np.cos(np.radians(float(t["Dec_orig"])))
        odec = float(t["Dec_orig"]) + dt * float(t["pmDEC"]) / 3.6e6
        same = np.hypot(*en(ora, odec, cra, cdec)) < 0.01
        chk = en(cra, cdec, ra3, dec3)
        j2k = en(float(t["ra"]), float(t["dec"]), ra3, dec3)
        head = (f'   {s:<4d} {2016 + yrs:7.2f}  ({chk[0]:+6.2f},{chk[1]:+6.2f}) {np.hypot(*chk):5.2f}  '
                f'{np.hypot(*j2k):6.1f}   ')
        if s not in fits:
            print(head + f'{"(no fit in detail.json)":<44s} {same}')
            continue
        f = fits[s]
        rec = (f["east"], f["north"])
        frm = en(f["ra"], f["dec"], ra3, dec3)
        print(head + f'({rec[0]:+6.1f},{rec[1]:+6.1f}) {np.hypot(*rec):5.1f}   '
              f'({frm[0]:+6.1f},{frm[1]:+6.1f}) {np.hypot(*frm):5.1f}   {same}')
