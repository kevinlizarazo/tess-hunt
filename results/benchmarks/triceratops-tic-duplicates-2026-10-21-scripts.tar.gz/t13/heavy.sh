#!/bin/bash
# Runs one memory-heavy command for a Task 13 review: one at a time across every review agent (the lock), only once
# 6 GB is free (TRICERATOPS and the platform share this machine), and under the 6 GB cap.
# Usage: /tmp/t13/heavy.sh <command> [args...]
exec 9>/tmp/t13/heavy.lock
flock 9
for i in $(seq 1 20); do
  avail=$(free -m | awk '/Mem:/{print $7}')
  [ "$avail" -ge 6144 ] && exec systemd-run --user --scope -q -p MemoryMax=6G -p MemorySwapMax=0 nice -n 10 "$@"
  sleep 60
done
echo "heavy.sh: 6 GB never came free in 20 minutes ($avail MB available); command not run" >&2
exit 75
