"""The scenario side of the defect (question 3): for each run's signal with a weighed DUPLICATE or ARTIFACT star, the
share of the last run's probability (probs.csv) those stars' rows carry, and the NFPP and FPP without them,
renormalised. Then the 10-run means scaled two ways, since probs.csv holds only the last run (seed 9):
  share: each run's dropped mass is the last run's share of that run's NFPP;
  fixed: each run's dropped mass is the last run's.
Judged against criteria/vet-v3.toml's [triceratops] bars. Writes /tmp/t13-dup/effect.csv."""

import json
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path("/tmp/t13-dup")
RUNS = Path.home() / ".cache/tess-hunt/runs"
BARS = {"nfpp_pass": 0.001, "nfpp_fail": 0.1, "fpp_pass": 0.5}
DROP = ("DUPLICATE", "ARTIFACT")

flagged = pd.read_csv(OUT / "flagged.csv", dtype={"ID": str})
tic = pd.read_csv(OUT / "tic.csv", dtype={"ID": str}).drop_duplicates("ID").set_index("ID")
cases = flagged[flagged["weighed"] & flagged["disposition"].isin(DROP)][["run", "signal"]].drop_duplicates()
full = {n.name[:16] + n.name[-4:]: n.name for n in RUNS.iterdir()}


def outcome(f, n, blockers):
    if blockers:
        return "inconclusive (blocker)"
    if n > BARS["nfpp_fail"]:
        return "fail"
    if f < BARS["fpp_pass"] and n < BARS["nfpp_pass"]:
        return "pass"
    return "inconclusive"


rows = []
for run, signal in cases.itertuples(index=False):
    d = RUNS / full[run] / "signals" / signal
    ev = json.loads((d / "triceratops.json").read_text())["evidence"]
    probs = pd.read_csv(d / "probs.csv", dtype={"ID": str})
    p = probs["prob"].to_numpy()
    nfpp_last, fpp_last = p[15:].sum(), 1 - (p[0] + p[3] + p[9])
    disp = probs["ID"].map(tic["disposition"])
    drop_mask = disp.isin(DROP).to_numpy() & (np.arange(len(p)) >= 15)
    dropped = p[drop_mask].sum()
    by_star = probs[drop_mask].groupby("ID")["prob"].sum()
    fpp, nfpp = np.array(ev["fpp"]), np.array(ev["nfpp"])
    share = dropped / nfpp_last
    scaled = {}
    for how, d_r in (("share", share * nfpp), ("fixed", np.full(len(nfpp), dropped))):
        scaled[how] = (((nfpp - d_r) / (1 - d_r)).mean(), ((fpp - d_r) / (1 - d_r)).mean())
    blockers = ev["blockers"]
    rows.append(
        {
            "run": run,
            "signal": signal,
            "dropped_stars": "; ".join(f"{i} {tic.loc[i, 'disposition']} {v:.3g}" for i, v in by_star.items()),
            "probs_nfpp_last": nfpp_last,
            "evidence_nfpp_last": nfpp[-1],
            "probs_fpp_last": fpp_last,
            "evidence_fpp_last": fpp[-1],
            "dropped_last": dropped,
            "share_of_nfpp_last": share,
            "nfpp_last_without": (nfpp_last - dropped) / (1 - dropped),
            "fpp_last_without": (fpp_last - dropped) / (1 - dropped),
            "nfpp_mean": nfpp.mean(),
            "nfpp_sd": nfpp.std(ddof=1),
            "fpp_mean": fpp.mean(),
            "nfpp_mean_without_share": scaled["share"][0],
            "fpp_mean_without_share": scaled["share"][1],
            "nfpp_mean_without_fixed": scaled["fixed"][0],
            "fpp_mean_without_fixed": scaled["fixed"][1],
            "blockers": "; ".join(blockers),
            "outcome_now": outcome(fpp.mean(), nfpp.mean(), blockers),
            "outcome_without": outcome(scaled["share"][1], scaled["share"][0], blockers),
            "outcome_without_no_blockers": outcome(scaled["share"][1], scaled["share"][0], []),
        }
    )

e = pd.DataFrame(rows)
e.to_csv(OUT / "effect.csv", index=False)
pd.set_option("display.width", 200, "display.max_colwidth", 120)
for r in rows:
    print()
    for k, v in r.items():
        print(f"  {k:28s} {v:.6g}" if isinstance(v, float) else f"  {k:28s} {v}")
