"""The flux side of the defect (question 1b), measured: rebuild TRICERATOPS's target for one run's signal, run
calc_depths with the run's own apertures (the evidence's ccd_pixels) and depth, check it reproduces the run's tdepths,
then drop the TIC's DUPLICATE and ARTIFACT rows from both .stars and .pix_coords and run calc_depths again. Reports
each dropped star's share of every aperture's flux and how far every other star's tdepth moves.

Usage: depths.py <run name> <signal>. Writes /tmp/t13-dup/depths/<signal>.json. TESScut cutouts go to a
lightkurve cache under /tmp/t13-dup; the field-star population is never fetched (calc_depths doesn't use it)."""

import copy
import json
import sys
from pathlib import Path

import lightkurve
import numpy as np
import pandas as pd

OUT = Path("/tmp/t13-dup")
lightkurve.conf.cache_dir = str(OUT / "lkcache")
(OUT / "lkcache").mkdir(exist_ok=True)
(OUT / "depths").mkdir(exist_ok=True)

from triceratops.triceratops import target as Target  # noqa: E402

run, signal = sys.argv[1], sys.argv[2]
path = Path.home() / ".cache/tess-hunt/runs" / run / "signals" / signal / "triceratops.json"
ev = json.loads(path.read_text())["evidence"]
run_stars = pd.DataFrame(ev["stars"])
depth = float(ev["ephemeris"]["depth"])
tic = pd.read_csv(OUT / "tic.csv", dtype={"ID": str}).drop_duplicates("ID").set_index("ID")
tic_id = int(run_stars["ID"].iloc[0])

t = Target(ID=tic_id, sectors=np.array(ev["sectors"]), search_radius=10, trilegal_fname=str(OUT / "unused.csv"))
assert len(t.pix_coords) == len(ev["sectors"]), "TESScut skipped a sector"
same_list = list(t.stars["ID"].astype(str)) == list(run_stars["ID"].astype(str))
aps = [np.array(ev["apertures"][str(int(s))]["ccd_pixels"]) for s in t.sectors]


def depths(tt):
    tt.calc_depths(tdepth=depth, all_ap_pixels=aps, dilution_corrected=True)
    return tt.stars[["ID", "fluxratio", "tdepth"]].reset_index(drop=True)


def per_aperture(tt):
    """Each star's flux ratio in each aperture, from calc_depths run on that aperture alone."""
    out = []
    for k in range(len(aps)):
        one = copy.copy(tt)
        one.stars = tt.stars.copy()
        one.pix_coords = [tt.pix_coords[k]]
        one.calc_depths(tdepth=depth, all_ap_pixels=[aps[k]], dilution_corrected=True)
        out.append(one.stars["fluxratio"].to_numpy())
    return np.array(out)


with_rows = depths(t)
reproduces = bool(np.allclose(with_rows["tdepth"].to_numpy(), run_stars["tdepth"].to_numpy(), rtol=1e-9, atol=0))
shares = per_aperture(t)

disp = t.stars["ID"].astype(str).map(tic["disposition"])
drop = disp.isin(["DUPLICATE", "ARTIFACT"]).to_numpy()
kept = copy.copy(t)
kept.stars = t.stars[~drop].reset_index(drop=True).copy()
kept.pix_coords = [pc[~drop] for pc in t.pix_coords]
without = depths(kept)

before = with_rows[~drop].reset_index(drop=True)
assert list(before["ID"]) == list(without["ID"])
w_before, w_after = before["tdepth"] > 0, without["tdepth"] > 0
both = w_before & w_after
rel = (without["tdepth"][both] / before["tdepth"][both] - 1).abs()
dropped = [
    {
        "ID": str(t.stars["ID"].iloc[i]),
        "disposition": disp.iloc[i],
        "tdepth": float(with_rows["tdepth"].iloc[i]),
        "flux_share_per_aperture": [float(x) for x in shares[:, i]],
    }
    for i in np.flatnonzero(drop)
]
result = {
    "run": run,
    "signal": signal,
    "sectors": [int(s) for s in t.sectors],
    "depth": depth,
    "star_list_matches_run": same_list,
    "calc_depths_reproduces_run_tdepths": reproduces,
    "target_fluxratio_with": float(with_rows["fluxratio"].iloc[0]),
    "target_fluxratio_without": float(without["fluxratio"].iloc[0]),
    "target_tdepth_with": float(with_rows["tdepth"].iloc[0]),
    "target_tdepth_without": float(without["tdepth"].iloc[0]),
    "dropped": dropped,
    "dropped_total_flux_share_per_aperture": [float(x) for x in shares[:, drop].sum(axis=1)],
    "weighed_before": int(w_before.sum()),
    "weighed_after": int(w_after.sum()),
    "weighed_set_changed": [str(i) for i in before["ID"][w_before != w_after]],
    "max_rel_tdepth_change_kept": float(rel.max()) if len(rel) else 0.0,
    "max_rel_tdepth_change_star": str(before["ID"][both][rel.idxmax()]) if len(rel) else None,
}
(OUT / "depths" / f"{signal}.json").write_text(json.dumps(result, indent=1))
print(json.dumps({k: v for k, v in result.items() if k != "dropped"}, indent=1))
for d in dropped:
    print(d["ID"], d["disposition"], f"tdepth {d['tdepth']:.4g}", "share", [f"{x:.3g}" for x in d["flux_share_per_aperture"]])
