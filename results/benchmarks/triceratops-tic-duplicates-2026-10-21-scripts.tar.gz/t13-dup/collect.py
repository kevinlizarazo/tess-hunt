"""Every star in every M3 TRICERATOPS run's star lists, one row per (run, signal, star), to /tmp/t13-dup/stars.csv.
Also a per-signal summary (outcome, means, sectors, star count) to /tmp/t13-dup/signals.csv."""

import json
from pathlib import Path

import pandas as pd

RUNS = Path.home() / ".cache/tess-hunt/runs"
NAMES = [
    "20261020T181658Z-vetting-triceratops-61b5944-1bbf",
    "20261020T013408Z-vetting-triceratops-62882b5-e092",
    "20261017T162256Z-vetting-triceratops-62882b5-d0f8",
    "20261018T012940Z-vetting-triceratops-62882b5-e3d7",
    "20261021T025929Z-vetting-triceratops-61b5944-55f4",
]
OUT = Path("/tmp/t13-dup")

stars, signals = [], []
for name in NAMES:
    for sig in sorted((RUNS / name / "signals").iterdir()):
        path = sig / "triceratops.json"
        if not path.is_file():
            signals.append({"run": name, "signal": sig.name, "finished": False})
            continue
        d = json.loads(path.read_text())
        ev = d["evidence"]
        rows = ev.get("stars") or []
        signals.append(
            {
                "run": name,
                "signal": sig.name,
                "finished": True,
                "outcome": d["outcome"],
                "fpp_mean": ev.get("fpp_mean"),
                "fpp_sd": ev.get("fpp_sd"),
                "nfpp_mean": ev.get("nfpp_mean"),
                "nfpp_sd": ev.get("nfpp_sd"),
                "runs": len(ev.get("fpp") or []),
                "sectors": ev.get("sectors"),
                "n_stars": len(rows),
                "n_tdepth_pos": sum(1 for r in rows if (r.get("tdepth") or 0) > 0),
                "probs_csv": (sig / "probs.csv").is_file(),
                "blockers": "; ".join(ev.get("blockers") or []),
                "stopped": ev.get("stopped"),
            }
        )
        for i, r in enumerate(rows):
            stars.append({"run": name, "signal": sig.name, "row": i, **r})

pd.DataFrame(stars).to_csv(OUT / "stars.csv", index=False)
s = pd.DataFrame(signals)
s.to_csv(OUT / "signals.csv", index=False)
pd.set_option("display.width", 250, "display.max_columns", 30, "display.max_rows", 100)
print(s.drop(columns=["blockers"]))
print("star rows", len(stars), "unique IDs", len({r["ID"] for r in stars}))
