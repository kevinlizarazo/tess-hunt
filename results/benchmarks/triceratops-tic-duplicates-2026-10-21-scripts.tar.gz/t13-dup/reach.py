"""Join every star list (/tmp/t13-dup/stars.csv) to its TIC disposition (/tmp/t13-dup/tic.csv). Writes
/tmp/t13-dup/flagged.csv: every (run, signal, star) whose TIC row has a disposition or a duplicate_id, with whether
calc_probs weighed it (tdepth > 0), its separation from the target, and whether the star its duplicate_id names is in
the same list (and that star's tdepth)."""

import numpy as np
import pandas as pd

OUT = "/tmp/t13-dup"
stars = pd.read_csv(f"{OUT}/stars.csv", dtype={"ID": str})
tic = pd.read_csv(f"{OUT}/tic.csv", dtype={"ID": str, "duplicate_id": "Int64", "GAIA": "Int64"})
tic = tic.drop_duplicates("ID")
missing = sorted(set(stars["ID"]) - set(tic["ID"]))
print("star IDs MAST did not return:", len(missing), missing[:20])

m = stars.merge(tic[["ID", "disposition", "duplicate_id", "GAIA", "objType", "Tmag"]], on="ID", how="left",
                suffixes=("", "_tic"))
print("\nall star rows by disposition:")
print(m["disposition"].fillna("(none)").value_counts().to_string())
print("\nstar rows weighed by calc_probs (tdepth > 0) by disposition:")
print(m[m["tdepth"] > 0]["disposition"].fillna("(none)").value_counts().to_string())


def sep(ra1, dec1, ra2, dec2):
    ra1, dec1, ra2, dec2 = (np.radians(v) for v in (ra1, dec1, ra2, dec2))
    h = np.sin((dec2 - dec1) / 2) ** 2 + np.cos(dec1) * np.cos(dec2) * np.sin((ra2 - ra1) / 2) ** 2
    return np.degrees(2 * np.arcsin(np.sqrt(h))) * 3600


rows = []
for (run, signal), g in m.groupby(["run", "signal"], sort=False):
    g = g.sort_values("row")
    target = g.iloc[0]
    by_id = g.set_index("ID")
    flagged = g[g["disposition"].notna() | g["duplicate_id"].notna()]
    for _, r in flagged.iterrows():
        dup = r["duplicate_id"]
        dup_in = (not pd.isna(dup)) and str(dup) in by_id.index
        rows.append(
            {
                "run": run[:16] + run[-4:],
                "signal": signal,
                "target": target["ID"],
                "target_disposition": target["disposition"],
                "row": int(r["row"]),
                "ID": r["ID"],
                "disposition": r["disposition"],
                "duplicate_id": None if pd.isna(dup) else int(dup),
                "dup_in_list": dup_in,
                "dup_tdepth": float(by_id.loc[str(dup), "tdepth"]) if dup_in else None,
                "GAIA": None if pd.isna(r["GAIA"]) else int(r["GAIA"]),
                "Tmag": r["Tmag"],
                "sep_arcsec": round(float(sep(target["ra"], target["dec"], r["ra"], r["dec"])), 2),
                "tdepth": r["tdepth"],
                "weighed": bool(r["tdepth"] > 0),
            }
        )
f = pd.DataFrame(rows)
f.to_csv(f"{OUT}/flagged.csv", index=False)
pd.set_option("display.width", 250, "display.max_columns", 30, "display.max_rows", 500)
print("\nflagged rows by run and disposition (all / weighed):")
print(f.assign(disposition=f["disposition"].fillna("(dup_id only)"))
      .groupby(["run", "disposition"]).agg(rows=("ID", "size"), weighed=("weighed", "sum")).to_string())
print("\nflagged rows calc_probs weighed (tdepth > 0):")
print(f[f["weighed"]].to_string(index=False))
print("\ntargets with a disposition:")
print(f[f["row"] == 0].to_string(index=False))
