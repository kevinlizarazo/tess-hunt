"""TIC disposition and duplicate_id for every star ID in /tmp/t13-dup/stars.csv (and any extra IDs files given), from
MAST with Catalogs.query_criteria(catalog="TIC", ID=[...]) in batches. Writes /tmp/t13-dup/tic.csv, one row per ID
MAST returned, and reports any ID it did not return. Read-only public queries; resumable (skips IDs already in
tic.csv)."""

import sys
import time
from pathlib import Path

import pandas as pd
from astroquery.mast import Catalogs

OUT = Path("/tmp/t13-dup")
BATCH = 1000
COLUMNS = ["ID", "disposition", "duplicate_id", "GAIA", "objType", "typeSrc", "ra", "dec", "Tmag", "TWOMASS",
           "mass", "rad", "Teff", "plx"]

ids = set(pd.read_csv(OUT / "stars.csv", dtype={"ID": str})["ID"])
for extra in sys.argv[1:]:
    ids |= set(pd.read_csv(extra, dtype={"ID": str})["ID"])
ids = sorted(ids, key=int)
path = OUT / "tic.csv"
have = pd.read_csv(path, dtype={"ID": str}) if path.is_file() else pd.DataFrame(columns=COLUMNS)
todo = [i for i in ids if i not in set(have["ID"])]
print(f"{len(ids)} IDs, {len(todo)} to query", flush=True)
parts = [have]
for k in range(0, len(todo), BATCH):
    batch = todo[k : k + BATCH]
    t0 = time.time()
    table = Catalogs.query_criteria(catalog="TIC", ID=[int(i) for i in batch])
    df = table.to_pandas()[COLUMNS]
    df["ID"] = df["ID"].astype(str)
    parts.append(df)
    pd.concat(parts).to_csv(path, index=False)
    print(f"batch {k // BATCH}: {len(batch)} asked, {len(df)} returned, {time.time() - t0:.1f}s", flush=True)

tic = pd.concat(parts)
missing = sorted(set(ids) - set(tic["ID"]), key=int)
print("IDs MAST did not return:", len(missing), missing[:20])
print(tic["disposition"].fillna("(none)").value_counts())
