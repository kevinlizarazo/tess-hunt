"""Each weighed DUPLICATE beside the star it duplicates: the last run's probability each carries (NTP+NEB+NEBx2P) and
the host parameters calc_probs gave each."""
from pathlib import Path
import pandas as pd
RUNS = Path.home() / ".cache/tess-hunt/runs"
f = pd.read_csv("/tmp/t13-dup/flagged.csv", dtype={"ID": str})
d = f[(f.disposition == "DUPLICATE") & f.weighed]
full = {n.name[:16] + n.name[-4:]: n.name for n in RUNS.iterdir()}
for _, r in d.iterrows():
    p = pd.read_csv(RUNS / full[r.run] / "signals" / r.signal / "probs.csv", dtype={"ID": str})
    g = p.groupby("ID").agg(M_s=("M_s", "first"), R_s=("R_s", "first"), prob=("prob", "sum"))
    o = str(int(r.duplicate_id))
    print(r.run, r.signal, f"DUP {r.ID}: prob {g.loc[r.ID,'prob']:.3g} R_s {g.loc[r.ID,'R_s']:.3f} | "
          f"original {o}: prob {g.loc[o,'prob']:.3g} R_s {g.loc[o,'R_s']:.3f} | sep {r.sep_arcsec}\" tdepth {r.tdepth:.4f}")
