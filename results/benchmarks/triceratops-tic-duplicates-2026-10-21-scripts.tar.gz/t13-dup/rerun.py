"""Question 4: one seed of calc_probs with and without the TIC's DUPLICATE and ARTIFACT rows, on one signal of one
finished run. Rebuilds the run's fold as vetting._triceratops does (same checks.json, light curve, detrend, families,
ephemeris; hashes checked against the run's provenance), takes the run's own field-star file and apertures, and runs
the seed the run's probs.csv holds (the last, 9) so the with-rows run must reproduce it.

Usage: rerun.py <triceratops run> <signal> [seed]. Writes /tmp/t13-dup/rerun/<signal>/rerun.json and the two
probs tables beside it. Nothing is written outside /tmp/t13-dup."""

import copy
import json
import shutil
import sys
import time
from pathlib import Path

import lightkurve
import numpy as np
import pandas as pd

OUT = Path("/tmp/t13-dup")
lightkurve.conf.cache_dir = str(OUT / "lkcache")

from tess_hunt import tricera  # noqa: E402
from tess_hunt.checks.families import split  # noqa: E402
from tess_hunt.config import lc_dir, load_criteria  # noqa: E402
from tess_hunt.detrend import detrend  # noqa: E402
from tess_hunt.ephemeris import Ephemeris  # noqa: E402
from tess_hunt.lightcurve import LightCurve  # noqa: E402
from tess_hunt.provenance import sha256_file  # noqa: E402
from tess_hunt.vetting import _fold_ephemeris  # noqa: E402
from triceratops.triceratops import target as Target  # noqa: E402

REPO = Path.home() / "code/tess-hunt-run"
RUNS = Path.home() / ".cache/tess-hunt/runs"
run_name, signal = sys.argv[1], sys.argv[2]
seed = int(sys.argv[3]) if len(sys.argv) > 3 else 9
rdir = RUNS / run_name
sdir = rdir / "signals" / signal
prov = json.loads((rdir / "provenance.json").read_text())
rec = json.loads((sdir / "triceratops.json").read_text())
ev = rec["evidence"]
work = OUT / "rerun" / signal
work.mkdir(parents=True, exist_ok=True)

crit = {Path(c["file"]).name: c for c in prov["criteria"]}
for name in ("search-v2.toml", "vet-v3.toml"):
    assert sha256_file(REPO / "criteria" / name) == crit[name]["sha256"], f"{name} changed"
crit_search = load_criteria(REPO / "criteria/search-v2.toml")
crit_vet = load_criteria(REPO / "criteria/vet-v3.toml")
cfg = crit_vet["triceratops"]

checks_path = RUNS / rec["vetting_run"] / "signals" / signal / "checks.json"
assert sha256_file(checks_path) == prov["inputs"][f"checks_{signal}"]["sha256"], "checks.json changed"
checks = json.loads(checks_path.read_text())
tic = int(checks["star"]["tic"])
lc_path = lc_dir() / f"{tic}.npz"
assert sha256_file(lc_path) == prov["inputs"][f"light_curve_{tic}"]["sha256"], "light curve changed"
assert not rec["contrast"], "this driver takes no contrast curve"

# vetting._triceratops, step for step.
lc = LightCurve.load(lc_path)
seen = lc.select(~np.isin(lc.sector, checks["dropped_suspect"]))
flat = detrend(seen, crit_search["detrend"], [Ephemeris(**m) for m in checks["masked"]])
families = crit_vet["families"]
none = flat.select(np.zeros(len(flat.time), dtype=bool))
pdcsap = split(flat, families).get(families["fit"], none)
eph, _ = _fold_ephemeris(checks)
exposure, sectors, _ = tricera.cadence_group(pdcsap, eph, cfg["min_transits"])
assert sectors == ev["sectors"], (sectors, ev["sectors"])
group = tricera.to_exposure(pdcsap.select(np.isin(pdcsap.sector, sectors)), exposure)
t_fold, f_fold, err = tricera.fold(group, eph, exposure, cfg["bin_phase"])
assert len(t_fold) == ev["points"] and float(err) == ev["flux_err_0"], "fold differs from the run's"

background = work / Path(ev["field_population_file"]).name
shutil.copyfile(sdir / ev["field_population_file"], background)
target = Target(ID=tic, sectors=np.array(sectors), search_radius=cfg["search_radius_pixels"],
                trilegal_fname=str(background))
assert list(target.stars["ID"].astype(str)) == [s["ID"] for s in ev["stars"]], "star list differs"
aps = [np.array(ev["apertures"][str(int(s))]["ccd_pixels"]) for s in target.sectors]
depth = float(eph.depth)

tdisp = pd.read_csv(OUT / "tic.csv", dtype={"ID": str}).drop_duplicates("ID").set_index("ID")["disposition"]
drop = target.stars["ID"].astype(str).map(tdisp).isin(["DUPLICATE", "ARTIFACT"]).to_numpy()
without = copy.copy(target)
without.stars = target.stars[~drop].reset_index(drop=True).copy()
without.pix_coords = [pc[~drop] for pc in target.pix_coords]

result = {"run": run_name, "signal": signal, "seed": seed, "dropped": list(target.stars["ID"][drop].astype(str))}
for label, tt in (("with", target), ("without", without)):
    tt.calc_depths(tdepth=depth, all_ap_pixels=aps, dilution_corrected=True)
    np.random.seed(seed)
    t0 = time.time()
    tt.calc_probs(time=t_fold, flux_0=f_fold, flux_err_0=float(err), P_orb=float(eph.period),
                  contrast_curve_file=None, filt="TESS", N=cfg["draws"], parallel=False, exptime=exposure,
                  verbose=0, dilution_corrected=True)
    tt.probs.to_csv(work / f"probs_{label}.csv", index=False)
    result[label] = {"fpp": float(tt.FPP), "nfpp": float(tt.NFPP), "seconds": round(time.time() - t0, 1),
                     "weighed": int((tt.stars["tdepth"] > 0).sum())}
    print(label, result[label], flush=True)

run_probs = pd.read_csv(sdir / "probs.csv")
mine = pd.read_csv(work / "probs_with.csv")
result["with_reproduces_run"] = {
    "fpp": result["with"]["fpp"] == ev["fpp"][seed],
    "nfpp": result["with"]["nfpp"] == ev["nfpp"][seed],
    "probs_max_abs_diff": float(np.abs(mine["prob"].to_numpy() - run_probs["prob"].to_numpy()).max()),
}
p = run_probs["prob"].to_numpy()
d = p[run_probs["ID"].astype(str).isin(result["dropped"]).to_numpy() & (np.arange(len(p)) >= 15)].sum()
result["renormalised_prediction"] = {"nfpp": (p[15:].sum() - d) / (1 - d), "fpp": (1 - p[0] - p[3] - p[9] - d) / (1 - d)}
(work / "rerun.json").write_text(json.dumps(result, indent=1))
print(json.dumps(result, indent=1))
