"""Adjacent checks: whether any neighbour-table host was matched to a DUPLICATE or ARTIFACT TIC row in the runs'
evidence, and the parameters calc_probs used for the stars near 399023421."""
import json
from pathlib import Path
import pandas as pd
RUNS = Path.home() / ".cache/tess-hunt/runs"
tic = pd.read_csv("/tmp/t13-dup/tic.csv", dtype={"ID": str}).drop_duplicates("ID").set_index("ID")["disposition"]
for run in ["20261020T181658Z-vetting-triceratops-61b5944-1bbf", "20261020T013408Z-vetting-triceratops-62882b5-e092",
            "20261017T162256Z-vetting-triceratops-62882b5-d0f8", "20261018T012940Z-vetting-triceratops-62882b5-e3d7"]:
    for p in sorted((RUNS / run / "signals").glob("*/triceratops.json")):
        hosts = json.loads(p.read_text())["evidence"].get("hosts") or []
        for h in hosts:
            if h["tic"] is not None and isinstance(tic.get(h["tic"]), str):
                print(run[-4:], p.parent.name, "Gaia DR3", h["source_id"], "matched to TIC", h["tic"], tic[h["tic"]],
                      "tdepth", h["tdepth"])
probs = pd.read_csv(RUNS / "20261020T181658Z-vetting-triceratops-61b5944-1bbf/signals/399023421-1/probs.csv",
                    dtype={"ID": str})
near = probs[probs["ID"].isin(["993417193", "993417201", "399023424", "993417194"])]
print(near.groupby("ID").agg(M_s=("M_s", "first"), R_s=("R_s", "first"), prob=("prob", "sum")).to_string())
