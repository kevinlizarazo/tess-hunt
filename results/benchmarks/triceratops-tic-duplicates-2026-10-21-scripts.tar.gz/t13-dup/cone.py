"""Provisional reach for the five promoted second-list rows, whose TRICERATOPS run had not finished: the same TIC cone
TRICERATOPS's target() queries (Catalogs.query_object("TIC<id>", radius=10 x 20.25", catalog="TIC")), with every
DUPLICATE or ARTIFACT row in it, its separation, its Tmag against the target's, and whether the star its duplicate_id
names is in the cone. Which of them calc_depths would weigh needs the run's apertures and depth, so this only says
which could be. Writes /tmp/t13-dup/cone.csv."""

import astropy.units as u
import numpy as np
import pandas as pd
from astroquery.mast import Catalogs

TARGETS = [241522065, 277774870, 370977908, 438857197, 423100454]
rows, counts = [], []
for tic in TARGETS:
    df = Catalogs.query_object(f"TIC{tic}", radius=10 * 20.25 * u.arcsec, catalog="TIC").to_pandas()
    assert str(df["ID"].iloc[0]) == str(tic)
    t = df.iloc[0]
    ids = set(df["ID"].astype(str))
    counts.append({"target": tic, "stars": len(df),
                   **df["disposition"].fillna("(none)").value_counts().to_dict()})
    for _, r in df[df["disposition"].isin(["DUPLICATE", "ARTIFACT"])].iterrows():
        dup = r["duplicate_id"]
        rows.append({
            "target": tic,
            "target_Tmag": t["Tmag"],
            "ID": r["ID"],
            "disposition": r["disposition"],
            "duplicate_id": dup,
            "dup_in_cone": (not pd.isna(dup)) and str(int(float(dup))) in ids,
            "sep_arcsec": round(float(r["dstArcSec"]), 2),
            "Tmag": r["Tmag"],
            "flux_vs_target": 10 ** (-0.4 * (r["Tmag"] - t["Tmag"])),
        })
pd.set_option("display.width", 200, "display.max_rows", 200)
print(pd.DataFrame(counts).fillna(0).to_string(index=False))
c = pd.DataFrame(rows)
c.to_csv("/tmp/t13-dup/cone.csv", index=False)
print(c.sort_values(["target", "sep_arcsec"]).to_string(index=False))
