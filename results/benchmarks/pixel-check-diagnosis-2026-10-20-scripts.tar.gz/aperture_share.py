"""Depth a neighbour would need to make the light curve's dip, counting how much of its PRF falls in a 3x3
aperture on the target: depth x (F_target x f_target) / (F_neighbour x f_neighbour), F from Tmag, f the PRF fraction
in the aperture. A rough stand-in for the real apertures (SPOC's and QLP's differ), per sector."""
import json
import pickle
import sys

import numpy as np

sys.path.insert(0, "/tmp/pixel-diag")
from sector_detail import box, index_of, prf_model  # noqa: E402

pairs = {
    "173369850-1": [173369830], "295140687-1": [295140710, 295140717], "322826591-1": [322826642, 916591876],
    "337885456-1": [337885477], "423100454-1": [423100496], "458290782-1": [1343588382, 458290807],
}
jobs = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/jobs.json"))}
for label, tics in pairs.items():
    job = jobs[label]
    print(f'== {label} depth {job["depth"] * 1e6:.0f} ppm')
    for s in job["sectors"]:
        with open(f"{job['star_dir']}/imageData_{job['planet_id']}_sector{s}.pickle", "rb") as fh:
            images, cat, pix, *_ = pickle.load(fh)
        prf = prf_model(images, cat, pix)
        ids = np.asarray(cat["ticID"]).astype(int)
        mags = np.asarray(np.ma.filled(cat["ticMag"], np.nan), dtype=float)
        r0, c0 = index_of(cat, pix, cat["ticColPix"][0], cat["ticRowPix"][0])

        def frac(i):
            p = prf.evaluate(cat["ticColPix"][i] - float(cat["dCol"]) + 0.5, cat["ticRowPix"][i] - float(cat["dRow"]) + 0.5)
            return float(np.sum(box(p, r0, c0)) / np.sum(p))

        f_t = frac(0)
        parts = []
        for tic in tics:
            j = int(np.where(ids == tic)[0][0])
            f_n = frac(j)
            ratio = 10 ** (-0.4 * (mags[j] - mags[0]))
            need = job["depth"] * f_t / (ratio * f_n) if f_n > 0 else float("inf")
            parts.append(f"TIC {tic} f={f_n:.3f} need {need:.3g}")
        print(f"   S{s}: target f={f_t:.2f}; " + "; ".join(parts))
