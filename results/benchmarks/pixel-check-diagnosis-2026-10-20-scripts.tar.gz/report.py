"""Tables from detail.json: one row per measured sector, and one summary row per signal."""
import json
import sys

import numpy as np

rows = json.load(open("/tmp/pixel-diag/detail.json"))
groups = sys.argv[1:] or ["known", "second", "control"]


def near(s):
    others = [n for n in s["near_fit"] if not n["is_target"]]
    if not others:
        return "-"
    n = others[0]
    return f'TIC{n["tic"]} T{n["tmag"]:.1f} {n["sep_from_fit"]:.0f}"fit need{n["needed_depth"]:.2g}'


for job in rows:
    if job["group"] not in groups:
        continue
    print(f'== {job["label"]} ({job["group"]}) depth {job["depth"]} recorded best {job["offset_qual"]}')
    print("  S   cam ccd off   q     dcol  drow   E      N     Tmag sat_peak colHM tr_used/in n_in "
          "expSNR boxSNR dRatio fitSNR  nullQmax nullOff   nearest-other-to-fit")
    rec = {r["sector"]: r for r in (job["recorded"] or [])}
    for s in job["per_sector"]:
        if "error" in s:
            print("  ", s)
            continue
        f = s["fit"]
        nulls = [n for n in s["nulls"] if n["ok"] and n["phase"] > 0]
        nq = max((n["quality"] for n in nulls), default=np.nan)
        noff = "/".join(f'{n["offset"]:.0f}' for n in nulls)
        check = ""
        if s["sector"] in rec and abs(rec[s["sector"]]["offset_arcsec"] - f["offset"]) > 1e-6:
            check = " REFIT-MISMATCH"
        repro = [n.get("reproduces_saved_image") for n in s["nulls"] if n["phase"] == 0.0]
        if repro and repro[0] is not True:
            check += " REBUILD-MISMATCH"
        fsnr = s["fit_box"]["snr"] if s["fit_box"] else np.nan
        print(f'  {s["sector"]:<3d} {s["camera"]}   {s["ccd"]}  {f["offset"]:5.1f} {f["quality"]:.2f} '
              f'{f["dcol"]:5.2f} {f["drow"]:5.2f} {f["east"]:6.1f} {f["north"]:6.1f} {s["tmag"]:5.2f} '
              f'{s["saturation"]["peak_e_s"]:8.0f} {s["saturation"]["column_half_max_px"]:3d}   '
              f'{s["transits_used"]}/{s["transits_in_sector"]}      {s["n_in"]:4d} {s["expected_snr"]:6.1f} '
              f'{s["target_box"]["snr"]:6.1f} {s["depth_ratio"]:6.2f} {fsnr:6.1f}  {nq:5.2f}   {noff:<16s} '
              f'{near(s)}{check}{"" if s["fit_in_cutout"] else " FIT-OFF-CUTOUT"}')
    print()
