"""Per-signal summary of detail.json: where the fits land on the sky, how they compare with null images, and
which catalogued stars sit at the mean fitted position."""
import json
import sys

import numpy as np

PIX_ARCSEC = 21.0
rows = json.load(open(sys.argv[1] if len(sys.argv) > 1 else "/tmp/pixel-diag/detail.json"))
groups = sys.argv[2:] or ["known", "second", "control"]


def std(x):
    x = np.asarray([v for v in x if np.isfinite(v)])
    return float(np.std(x, ddof=1)) if len(x) > 2 else float("nan")


def per_sector(s, depth):
    nulls = [n for n in s["nulls"] if n["ok"] and n["phase"] > 0]
    sd_t = std([n["target_diff"] for n in nulls])
    sd_f = std([n["fit_diff"] for n in nulls])
    q = s["fit"]["quality"]
    near_real = [n for n in nulls if np.hypot(n["east"] - s["fit"]["east"], n["north"] - s["fit"]["north"]) < 10]
    return {
        "sector": s["sector"], "q": q, "off": s["fit"]["offset"], "east": s["fit"]["east"],
        "north": s["fit"]["north"], "dcol": s["fit"]["dcol"], "drow": s["fit"]["drow"],
        "n_null": len(nulls),
        "null_q_med": float(np.median([n["quality"] for n in nulls])) if nulls else np.nan,
        "null_q_ge": sum(n["quality"] >= q for n in nulls),
        "null_near_fit": len(near_real),
        "snr_target": s["target_box"]["diff"] / sd_t if sd_t > 0 else np.nan,
        "snr_fit": (s["fit_box"]["diff"] / sd_f) if s["fit_box"] and sd_f > 0 else np.nan,
        "snr_expected": depth * s["target_box"]["flux"] / sd_t if np.isfinite(depth) and sd_t > 0 else np.nan,
        "used": s["transits_used"], "in_sector": s["transits_in_sector"],
        "sat": s["saturation"]["peak_e_s"], "col_hm": s["saturation"]["column_half_max_px"],
    }


for job in rows:
    if job["group"] not in groups:
        continue
    depth = job["depth"] if job["depth"] is not None else np.nan
    secs = [s for s in job["per_sector"] if "error" not in s]
    errs = [s for s in job["per_sector"] if "error" in s]
    tmag = secs[0]["tmag"]
    ps = [per_sector(s, depth) for s in secs]
    w = np.array([p["q"] for p in ps])
    e = np.array([p["east"] for p in ps])
    n = np.array([p["north"] for p in ps])
    me, mn = float(np.average(e, weights=w)), float(np.average(n, weights=w))
    sky_scatter = float(np.sqrt(np.mean((e - me) ** 2 + (n - mn) ** 2)))
    dc = np.array([p["dcol"] for p in ps]) * PIX_ARCSEC
    dr = np.array([p["drow"] for p in ps]) * PIX_ARCSEC
    det_scatter = float(np.sqrt(np.mean((dc - dc.mean()) ** 2 + (dr - dr.mean()) ** 2)))
    along_col = float(np.mean(np.abs(dr) > 2 * np.abs(dc)))
    best = max(ps, key=lambda p: p["q"])
    print(f'== {job["label"]} ({job["group"]}) Tmag {tmag:.2f} depth {depth * 1e6:.0f} ppm; '
          f'best-quality S{best["sector"]} {best["off"]:.1f}" q {best["q"]:.2f}')
    print(f'   offsets {min(p["off"] for p in ps):.1f} to {max(p["off"] for p in ps):.1f}"; '
          f'quality-weighted mean fit E {me:+.1f}" N {mn:+.1f}" ({np.hypot(me, mn):.1f}" from target); '
          f'sky scatter {sky_scatter:.1f}"; detector-frame scatter {det_scatter:.1f}"; '
          f'share of fits along the column {along_col:.2f}')
    print("   S    q    off    E      N    dcol  drow  nulls nullQmed nQ>=q nNear  SNRtgt SNRfit SNRexp "
          "used/in  satpk  colHM")
    for p in ps:
        print(f'   {p["sector"]:<4d}{p["q"]:.2f} {p["off"]:5.1f} {p["east"]:6.1f} {p["north"]:6.1f} '
              f'{p["dcol"]:5.2f} {p["drow"]:5.2f}  {p["n_null"]:3d}   {p["null_q_med"]:.2f}    {p["null_q_ge"]:3d}  '
              f'{p["null_near_fit"]:3d}   {p["snr_target"]:6.1f} {p["snr_fit"]:6.1f} {p["snr_expected"]:6.1f}  '
              f'{p["used"]:2d}/{p["in_sector"]:<2d}  {p["sat"]:7.0f}  {p["col_hm"]:2d}')
    for s in errs:
        print("   ERROR", s)
    # Catalogued stars at the mean fitted position, from the best-quality sector's catalogue.
    cat = next(s for s in secs if s["sector"] == best["sector"])["catalogue"]
    tgt = cat[0]
    ra0, dec0 = tgt["ra"], tgt["dec"]
    fit_ra = ra0 + me / 3600 / np.cos(np.radians(dec0))
    fit_dec = dec0 + mn / 3600
    near = []
    for c in cat:
        sep = np.hypot((c["ra"] - fit_ra) * np.cos(np.radians(dec0)), c["dec"] - fit_dec) * 3600
        if sep < 12:
            need = depth * 10 ** (0.4 * (c["tmag"] - tmag)) if np.isfinite(depth) else np.nan
            near.append((sep, c, need))
    for sep, c, need in sorted(near, key=lambda x: x[0]):
        print(f'   star at mean fit: TIC {c["tic"]} Tmag {c["tmag"]:.2f}, {sep:.1f}" from mean fit, '
              f'{c["sep"]:.1f}" from target, needs depth {need:.3g}')
    print()
