"""Null-image fits for 423100454-1: do they land where the transit-phase fit did?"""
import json
d = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/detail.json"))}
j = d["423100454-1"]
for s in j["per_sector"]:
    f = s["fit"]
    print(f'S{s["sector"]}: transit-phase fit E {f["east"]:+.1f} N {f["north"]:+.1f} q {f["quality"]:.2f} amp {f["amp"]:.1f}')
    for n in s["nulls"]:
        if n["ok"] and n["phase"] > 0:
            print(f'    null phase {n["phase"]:.3f}: E {n["east"]:+7.1f} N {n["north"]:+7.1f} q {n["quality"]:.2f} amp {n["amp"]:8.1f}')
cat = {c["tic"]: c for c in j["per_sector"][0]["catalogue"]}
c = cat[423100496]
print("TIC 423100496", c)
