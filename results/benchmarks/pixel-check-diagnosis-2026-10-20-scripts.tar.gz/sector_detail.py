"""Per-sector detail of the pixel check, rebuilt read-only from transit-diffImage's saved pickles.

For each sector the pixel check measured: the PRF fit refitted (it must reproduce the recorded offset), where it
landed on the sky and on the detector, the difference image's SNR at the target, the depth the image shows against
the light curve's, saturation, the catalogued stars near the fit, and null difference images made the same way at
phases with no transit.

Usage: sector_detail.py OUT.json JOBS.json, where JOBS.json lists {label, star_dir, planet_id, sectors, depth}.
"""
import json
import pickle
import sys
import warnings

import numpy as np
from transitDiffImage import tessDiffImage, tessprfmodel, transitCentroids

warnings.filterwarnings("ignore")
MAX_NULLS = 16


def null_phases(period, duration_days):
    """Phases whose in- and out-of-transit windows stay clear of the transit and of phase 0.5."""
    margin = 2.5 * duration_days / period
    ok = [p for p in np.arange(0.05, 0.951, 0.025)
          if min(p, 1 - p) > margin and abs(p - 0.5) > margin]
    if len(ok) > MAX_NULLS:
        ok = [ok[i] for i in np.linspace(0, len(ok) - 1, MAX_NULLS).round().astype(int)]
    return tuple(float(p) for p in ok)


def flt(x):
    return float(np.ma.filled(np.asarray(x, dtype=float), np.nan))


def prf_model(images, cat, pix):
    return tessprfmodel.SimpleTessPRF(
        shape=images["diffImage"].shape,
        sector=pix["sector"],
        camera=pix["camera"],
        ccd=pix["ccd"],
        column=cat["extent"][0],
        row=cat["extent"][2],
    )


def fit(prf, diff, cat, pix):
    # As leo_vetter.pixel.prf_fit does it, keeping the fitted position and amplitude it discards.
    x, quality, _, _, _ = transitCentroids.tess_PRF_centroid(prf, cat["extent"], diff, cat)
    ra, dec = tessDiffImage.pix_to_ra_dec(pix["sector"], pix["camera"], pix["ccd"], x[0], x[1])
    ra0, dec0 = flt(cat["correctedRa"][0]), flt(cat["correctedDec"][0])
    east = (ra - ra0) * np.cos(np.radians(dec0)) * 3600
    north = (dec - dec0) * 3600
    return {
        "col": float(x[0]), "row": float(x[1]), "amp": float(x[2]), "const": float(x[3]),
        "quality": float(quality), "ra": float(ra), "dec": float(dec),
        "east": float(east), "north": float(north), "offset": float(np.hypot(east, north)),
        "dcol": float(x[0] - cat["ticColPix"][0]), "drow": float(x[1] - cat["ticRowPix"][0]),
    }


def index_of(cat, pix, col, row):
    """Image index (row, col) of a position in the catalogue pixel frame, as render_prf places a PRF."""
    jc = col - flt(cat["dCol"]) - pix["cornerCol"]
    jr = row - flt(cat["dRow"]) - pix["cornerRow"]
    return int(round(jr)), int(round(jc))


def box(arr, r, c, half=1):
    ny, nx = arr.shape
    return arr[max(r - half, 0):min(r + half + 1, ny), max(c - half, 0):min(c + half + 1, nx)]


def box_stats(images, r, c, half=1):
    # The difference image's median is taken off first: a sky level that differs between the in- and
    # out-of-transit cadences shifts every pixel, and the PRF fit's constant term absorbs it too.
    diff = images["diffImage"] - np.nanmedian(images["diffImage"])
    d = box(diff, r, c, half)
    s = box(images["diffImageSigma"], r, c, half)
    f = box(images["meanOutTransit"], r, c, half)
    flux = float(np.nansum(f))
    return {
        "flux": flux,
        "diff": float(np.nansum(d)),
        "snr": float(np.nansum(d) / np.sqrt(np.nansum(s**2))),
        "depth": float(np.nansum(d) / flux) if flux > 0 else float("nan"),
        "noise_depth": float(np.sqrt(np.nansum(s**2)) / flux) if flux > 0 else float("nan"),
    }


def catalogue(cat):
    ra = np.asarray(np.ma.filled(cat["correctedRa"], np.nan), dtype=float)
    dec = np.asarray(np.ma.filled(cat["correctedDec"], np.nan), dtype=float)
    mag = np.asarray(np.ma.filled(cat["ticMag"], np.nan), dtype=float)
    sep = np.asarray(np.ma.filled(cat["separation"], np.nan), dtype=float)
    keep = sep < 200
    return [{"tic": int(t), "ra": float(a), "dec": float(d), "tmag": float(m), "sep": float(s)}
            for t, a, d, m, s, k in zip(cat["ticID"], ra, dec, mag, sep, keep) if k]


def transits_used(pix, in_idx, period):
    if len(in_idx) == 0:
        return 0
    t = np.sort(pix["time"][np.asarray(in_idx, dtype=int)])
    return int(1 + np.sum(np.diff(t) > 0.5 * min(period, 1.0)))


def saturation(images, r, c):
    out = images["meanOutTransit"]
    ny, nx = out.shape
    column = out[:, min(max(c, 0), nx - 1)]
    peak = float(np.nanmax(box(out, r, c, 1)))
    # A saturated star bleeds charge along its column: count the column pixels above half the peak.
    return {
        "peak_e_s": peak,
        "column_half_max_px": int(np.sum(column > 0.5 * peak)),
        "row_half_max_px": int(np.sum(out[min(max(r, 0), ny - 1), :] > 0.5 * peak)),
    }


def neighbours_near(cat, f, depth, tmag0, n=4, radius=42.0):
    ra = np.asarray(np.ma.filled(cat["correctedRa"], np.nan), dtype=float)
    dec = np.asarray(np.ma.filled(cat["correctedDec"], np.nan), dtype=float)
    mag = np.asarray(np.ma.filled(cat["ticMag"], np.nan), dtype=float)
    sep = np.hypot((ra - f["ra"]) * np.cos(np.radians(f["dec"])), dec - f["dec"]) * 3600
    out = []
    for i in np.argsort(sep)[:n]:
        if sep[i] > radius:
            break
        need = depth * 10 ** (0.4 * (mag[i] - tmag0)) if np.isfinite(depth) else float("nan")
        out.append({
            "tic": int(cat["ticID"][i]), "tmag": float(mag[i]), "sep_from_fit": float(sep[i]),
            "sep_from_target": flt(cat["separation"][i]), "needed_depth": float(need), "is_target": bool(i == 0),
        })
    return out


def bright_in_cutout(cat, pix, images, tmag0):
    """Catalogued stars on the cutout no fainter than the target plus 2 mag, other than the target."""
    ny, nx = images["diffImage"].shape
    mag = np.asarray(np.ma.filled(cat["ticMag"], np.nan), dtype=float)
    out = []
    for i in range(1, len(mag)):
        if not np.isfinite(mag[i]) or mag[i] > tmag0 + 2:
            continue
        r, c = index_of(cat, pix, cat["ticColPix"][i], cat["ticRowPix"][i])
        if 0 <= r < ny and 0 <= c < nx:
            out.append({"tic": int(cat["ticID"][i]), "tmag": float(mag[i]), "sep": flt(cat["separation"][i])})
    return out


def null_images(pix, planet):
    obj = tessDiffImage.tessDiffImage.__new__(tessDiffImage.tessDiffImage)
    obj.allowedBadCadences = 0
    obj.allowedInTransitLossFraction = 0.8
    for phase in (0.0,) + null_phases(planet["period"], planet["durationHours"] / 24):
        p = dict(planet)
        p["epoch"] = planet["epoch"] + phase * planet["period"]
        q = dict(pix)
        q["quality"] = pix["quality"].copy()
        in_idx, _, _, images = obj.find_transits(q, p, allowedBadCadences=0)
        yield phase, in_idx, images


def sector(path, depth):
    with open(path, "rb") as fh:
        images, cat, pix, in_idx, out_idx, t_idx, planet = pickle.load(fh)
    prf = prf_model(images, cat, pix)
    f = fit(prf, images["diffImage"], cat, pix)
    tmag0 = flt(cat["ticMag"][0])
    r0, c0 = index_of(cat, pix, cat["ticColPix"][0], cat["ticRowPix"][0])
    rf, cf = index_of(cat, pix, f["col"], f["row"])
    ny, nx = images["diffImage"].shape
    snr = images["diffSNRImage"]
    imax = np.unravel_index(np.nanargmax(snr), snr.shape)
    target = box_stats(images, r0, c0)
    rec = {
        "sector": int(pix["sector"]), "camera": int(pix["camera"]), "ccd": int(pix["ccd"]),
        "shape": [ny, nx], "tmag": tmag0, "fit": f,
        "fit_in_cutout": bool(0 <= rf < ny and 0 <= cf < nx),
        "fit_px_from_edge": int(min(rf, cf, ny - 1 - rf, nx - 1 - cf)),
        "target_px_from_edge": int(min(r0, c0, ny - 1 - r0, nx - 1 - c0)),
        "n_in": int(len(in_idx)), "n_out": int(len(out_idx)), "transits_in_sector": int(len(t_idx)),
        "transits_used": transits_used(pix, in_idx, planet["period"]),
        "bad_cadence_alert": bool(planet.get("badCadenceAlert", False)),
        "snr_target_px": float(snr[r0, c0]) if 0 <= r0 < ny and 0 <= c0 < nx else float("nan"),
        "target_box": target,
        "expected_snr": float(depth / target["noise_depth"]) if np.isfinite(depth) else float("nan"),
        "depth_ratio": float(target["depth"] / depth) if np.isfinite(depth) else float("nan"),
        "fit_box": box_stats(images, rf, cf) if 0 <= rf < ny and 0 <= cf < nx else None,
        "max_snr": float(snr[imax]), "max_snr_px_from_target": float(np.hypot(imax[0] - r0, imax[1] - c0)),
        "saturation": saturation(images, r0, c0),
        "near_fit": neighbours_near(cat, f, depth, tmag0),
        "bright_in_cutout": bright_in_cutout(cat, pix, images, tmag0),
        "planet": {k: float(planet[k]) for k in ("period", "epoch", "durationHours")},
    }
    nulls = []
    for phase, idx, img in null_images(pix, planet):
        if not img or np.isnan(np.sum(img["diffImage"])):
            nulls.append({"phase": phase, "ok": False})
            continue
        nf = fit(prf, img["diffImage"], cat, pix)
        nb = box_stats(img, r0, c0)
        entry = {"phase": phase, "ok": True, "offset": nf["offset"], "quality": nf["quality"],
                 "east": nf["east"], "north": nf["north"], "amp": nf["amp"], "box_snr": nb["snr"],
                 "target_diff": nb["diff"],
                 "fit_diff": box_stats(img, rf, cf)["diff"] if rec["fit_box"] else float("nan"),
                 "n_in": int(len(idx))}
        if phase == 0.0:
            entry["reproduces_saved_image"] = bool(
                np.allclose(img["diffImage"], images["diffImage"], equal_nan=True))
        nulls.append(entry)
    rec["nulls"] = nulls
    rec["catalogue"] = catalogue(cat)
    return rec


def main():
    out_path, jobs_path = sys.argv[1], sys.argv[2]
    results = []
    for job in json.load(open(jobs_path)):
        depth = job["depth"] if job["depth"] is not None else float("nan")
        recs = []
        for s in job["sectors"]:
            path = f"{job['star_dir']}/imageData_{job['planet_id']}_sector{s}.pickle"
            try:
                recs.append(sector(path, depth))
            except Exception as exc:  # recorded, not hidden
                recs.append({"sector": s, "error": repr(exc)})
            print(job["label"], s, "done", flush=True)
        results.append({**job, "per_sector": recs})
        json.dump(results, open(out_path, "w"), indent=1, default=float)


if __name__ == "__main__":
    main()
