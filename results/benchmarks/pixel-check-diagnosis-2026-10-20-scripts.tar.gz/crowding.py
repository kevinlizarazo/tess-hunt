"""Star brightness and crowding as the vet runs recorded them: Tmag, the TIC contamination ratio, CROWDSAP per
SPOC or TESS-SPOC sector (QLP publishes none)."""
import json, os
runs = {"VET_RUN": ["173369850-1", "295140687-1", "322826591-1", "337885456-1", "423100454-1", "458290782-1"],
        "CONTROL_VET": ["TOI-144.01", "TOI-2011.02", "TOI-396.03", "TOI-4307.01", "TOI-396.01"]}
for var, names in runs.items():
    for name in names:
        d = json.load(open(f'{os.environ[var]}/signals/{name}/checks.json'))
        st = d["star"]
        crowd = {s: round(v["crowdsap"], 3) for s, v in sorted(d["sources"].items(), key=lambda x: int(x[0])) if v.get("crowdsap") is not None}
        print(f'{name}: Tmag {st["tmag"]}, contratio {st.get("contratio")}, Teff {st.get("teff")}, R {st.get("rad")}, '
              f'RUWE {st.get("ruwe")}, CROWDSAP {crowd}')
