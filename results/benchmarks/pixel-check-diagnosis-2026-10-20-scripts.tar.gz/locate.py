"""Where on the sky the in-transit loss comes from, pooling every measured sector.

The pixel check fits one PRF plus a constant to each sector's difference image by least squares and keeps the best
sector. Here the same least-squares fit is made with the PRF held at each point of a sky grid around the target,
so each point gets the share of the image it explains, S(p) = (P.D)^2 / (P.P) over mean-subtracted pixels, for a
positive amplitude only. Each sector's S is divided by that sector's pixel variance in null difference images (no
transit), and the sectors are summed: J(p) = sum_i S_i(p) / var_i, a joint chi-square improvement. The peak of J is
the pooled source position; J(peak) - J(target) says how much better the peak explains the images than the target
does (about chi-square with 2 degrees of freedom if the noise were white; it is not, so the known planets calibrate
it).

Usage: locate.py OUT.json JOBS.json [HALF_WIDTH_ARCSEC STEP_ARCSEC]
"""
import json
import pickle
import sys
import warnings

import numpy as np
from tess_stars2px import tess_stars2px_function_entry

sys.path.insert(0, "/tmp/pixel-diag")
from sector_detail import null_images, prf_model  # noqa: E402

warnings.filterwarnings("ignore")


def grid_pixels(pix, ra0, dec0, east, north):
    dec = dec0 + north / 3600
    ra = ra0 + east / 3600 / np.cos(np.radians(dec0))
    ids = np.arange(len(ra))
    out = tess_stars2px_function_entry(ids, ra, dec, aberrate=True, trySector=pix["sector"])
    sid, sec, cam, ccd, col, row = out[0], out[3], out[4], out[5], out[6], out[7]
    on = (sec == pix["sector"]) & (cam == pix["camera"]) & (ccd == pix["ccd"])
    cols = np.full(len(ra), np.nan)
    rows = np.full(len(ra), np.nan)
    cols[sid[on]] = col[on]
    rows[sid[on]] = row[on]
    return cols, rows


def explained(stack_p, image):
    pc = stack_p - stack_p.mean(axis=1, keepdims=True)
    d = image - image.mean()
    dot = pc @ d
    return np.where(dot > 0, dot**2 / np.sum(pc**2, axis=1), 0.0)


def sector_map(path, east, north):
    with open(path, "rb") as fh:
        images, cat, pix, _, _, _, planet = pickle.load(fh)
    ra0 = float(np.ma.filled(cat["correctedRa"][0], np.nan))
    dec0 = float(np.ma.filled(cat["correctedDec"][0], np.nan))
    prf = prf_model(images, cat, pix)
    cols, rows = grid_pixels(pix, ra0, dec0, east, north)
    ok = np.isfinite(cols)
    stack = np.zeros((len(east), images["diffImage"].size))
    for i in np.where(ok)[0]:
        stack[i] = prf.evaluate(cols[i] - float(cat["dCol"]) + 0.5, rows[i] - float(cat["dRow"]) + 0.5).ravel()
    ok &= stack.sum(axis=1) > 0.05  # a point whose PRF barely touches the cutout can't be measured
    nulls = [img["diffImage"].ravel() for phase, _, img in null_images(pix, planet)
             if phase > 0 and img and not np.isnan(np.sum(img["diffImage"]))]
    var = float(np.median([np.var(n) for n in nulls]))
    j = np.zeros(len(east))
    j[ok] = explained(stack[ok], images["diffImage"].ravel()) / var
    return j, ok, len(nulls)


def main():
    out_path, jobs_path = sys.argv[1], sys.argv[2]
    half = float(sys.argv[3]) if len(sys.argv) > 3 else 90.0
    step = float(sys.argv[4]) if len(sys.argv) > 4 else 3.0
    axis = np.arange(-half, half + step / 2, step)
    ee, nn = np.meshgrid(axis, axis)
    east, north = ee.ravel(), nn.ravel()
    t = int(np.argmin(np.hypot(east, north)))
    results = []
    for job in json.load(open(jobs_path)):
        per, total, seen = [], np.zeros(len(east)), np.ones(len(east), dtype=bool)
        for s in job["sectors"]:
            j, ok, n_null = sector_map(f"{job['star_dir']}/imageData_{job['planet_id']}_sector{s}.pickle", east, north)
            total += j
            seen &= ok
            i = int(np.argmax(j))
            per.append({"sector": int(s), "n_nulls": n_null, "peak": [float(east[i]), float(north[i])],
                        "dj_target": float(j[i] - j[t])})
        total[~seen] = np.nan
        i = int(np.nanargmax(total))
        results.append({
            "label": job["label"], "group": job["group"], "half": half, "step": step,
            "peak": [float(east[i]), float(north[i])], "j_peak": float(total[i]), "j_target": float(total[t]),
            "dj_target": float(total[i] - total[t]), "sectors": per,
            "map": total.tolist(), "east": east.tolist(), "north": north.tolist(),
        })
        r = results[-1]
        print(f'{job["label"]:<13s} pooled peak E {r["peak"][0]:+4.0f}" N {r["peak"][1]:+4.0f}" '
              f'({np.hypot(*r["peak"]):3.0f}" from target), J(peak) - J(target) {r["dj_target"]:8.1f} | '
              + "; ".join(f'S{p["sector"]} ({p["peak"][0]:+.0f},{p["peak"][1]:+.0f}) {p["dj_target"]:.1f}'
                          for p in per), flush=True)
    json.dump(results, open(out_path, "w"))


if __name__ == "__main__":
    main()
