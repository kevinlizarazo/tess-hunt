"""Puts the per-sector tables into the draft and writes the diagnosis."""
from pathlib import Path
d = Path("/tmp/pixel-diag")
text = (d / "pixel-diagnosis.draft.md").read_text()
for key, name in (("PERSEC_KNOWN", "persec_known.md"), ("PERSEC_SECOND", "persec_second.md"),
                  ("PERSEC_CONTROLS", "persec_controls.md")):
    assert text.count(key) == 1, key
    text = text.replace(key, (d / name).read_text().rstrip("\n"))
out = Path("/home/kevin/code/tess-hunt/.superpowers/sdd/tess-hunt-m3-plan/t11/pixel-diagnosis.md")
out.write_text(text)
lines = text.splitlines()
long_prose = [(i + 1, len(l)) for i, l in enumerate(lines) if len(l) > 120 and not l.startswith("|")]
long_table = [(i + 1, len(l)) for i, l in enumerate(lines) if len(l) > 120 and l.startswith("|")]
print("lines", len(lines), "| prose over 120:", long_prose, "| table rows over 120:", long_table)
print("em dashes:", text.count("—"), "en dashes:", text.count("–"))
