"""How often the fixed-position fit puts z >= 3 on the neighbour and more than on the target, per group."""
import json

two = json.load(open("/tmp/pixel-diag/two_star.json"))
saturated = {"TOI-144.01", "TOI-2011.02", "TOI-396.01", "TOI-396.03"}
groups = {"known, not saturated": [], "known, saturated hosts": [], "control": [], "second": []}
for j in two:
    g = ("known, saturated hosts" if j["label"] in saturated else "known, not saturated") if j["group"] == "known" \
        else j["group"]
    for s in j["per_sector"]:
        if "error" in s:
            continue
        groups[g].append((j["label"], s["sector"], s["snr_target"], s["snr_other"]))
for g, rows in groups.items():
    hits = [r for r in rows if r[3] >= 3 and r[3] > r[2]]
    print(f"{g}: {len(hits)} of {len(rows)} sectors: " + ", ".join(f"{a} S{b} ({c:.1f}/{d:.1f})" for a, b, c, d in hits))
