"""Markdown rows for pixel-diagnosis.md, from detail.json, two_star.json and locate.json."""
import json
import os

import numpy as np

detail = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/detail.json"))}
two = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/two_star.json"))}
loc = ({j["label"]: j for j in json.load(open("/tmp/pixel-diag/locate.json"))}
       if os.path.exists("/tmp/pixel-diag/locate.json") else {})
PIX = 21.0


def std(x):
    x = [v for v in x if np.isfinite(v)]
    return float(np.std(x, ddof=1)) if len(x) > 2 else float("nan")


def signal_row(label):
    job = detail[label]
    secs = [s for s in job["per_sector"] if "error" not in s]
    q = np.array([s["fit"]["quality"] for s in secs])
    e = np.array([s["fit"]["east"] for s in secs])
    n = np.array([s["fit"]["north"] for s in secs])
    off = np.array([s["fit"]["offset"] for s in secs])
    me, mn = np.average(e, weights=q), np.average(n, weights=q)
    sky = float(np.sqrt(np.mean((e - me) ** 2 + (n - mn) ** 2)))
    dc = np.array([s["fit"]["dcol"] for s in secs]) * PIX
    dr = np.array([s["fit"]["drow"] for s in secs]) * PIX
    det = float(np.sqrt(np.mean((dc - dc.mean()) ** 2 + (dr - dr.mean()) ** 2)))
    nulls_ge = [sum(m["quality"] >= s["fit"]["quality"] for m in s["nulls"] if m["ok"] and m["phase"] > 0)
                for s in secs]
    n_nulls = [sum(1 for m in s["nulls"] if m["ok"] and m["phase"] > 0) for s in secs]
    null_q = [float(np.median([m["quality"] for m in s["nulls"] if m["ok"] and m["phase"] > 0])) for s in secs]
    snr_t, snr_e = [], []
    for s in secs:
        nl = [m for m in s["nulls"] if m["ok"] and m["phase"] > 0]
        sd = std([m["target_diff"] for m in nl])
        snr_t.append(s["target_box"]["diff"] / sd)
        snr_e.append(job["depth"] * s["target_box"]["flux"] / sd if job["depth"] else np.nan)
    ts = two.get(label)
    t_snr = [p["snr_target"] for p in ts["per_sector"] if "error" not in p] if ts else []
    o_snr = [p["snr_other"] for p in ts["per_sector"] if "error" not in p] if ts else []
    lc = loc.get(label)
    return {
        "label": label, "tmag": secs[0]["tmag"], "depth_ppm": (job["depth"] or np.nan) * 1e6,
        "sectors": [s["sector"] for s in secs], "off_min": off.min(), "off_max": off.max(),
        "q_min": q.min(), "q_max": q.max(), "mean_off": float(np.hypot(me, mn)), "mean_en": (me, mn),
        "sky": sky, "det": det, "sig": float(np.hypot(me, mn) / (sky / np.sqrt(len(secs)))),
        "peak": (min(s["saturation"]["peak_e_s"] for s in secs), max(s["saturation"]["peak_e_s"] for s in secs)),
        "colhm": (min(s["saturation"]["column_half_max_px"] for s in secs),
                  max(s["saturation"]["column_half_max_px"] for s in secs)),
        "along_col": sum(abs(s["fit"]["drow"]) > 2 * abs(s["fit"]["dcol"]) and abs(s["fit"]["drow"]) > 1 for s in secs),
        "used": [f'{s["transits_used"]}/{s["transits_in_sector"]}' for s in secs],
        "nulls_ge": nulls_ge, "n_nulls": n_nulls, "null_q": null_q,
        "snr_t": snr_t, "snr_e": snr_e, "two_t": t_snr, "two_o": o_snr,
        "two_other": ts["per_sector"][0]["other_tic"] if ts else None,
        "loc_peak": lc["peak"] if lc else None, "loc_dj": lc["dj_target"] if lc else None,
    }


def fmt(x, f="{:.1f}"):
    return "/".join(f.format(v) for v in x)


groups = {
    "known fails": ["TOI-144.01", "TOI-2011.02", "TOI-396.03", "TOI-4307.01"],
    "known, same host, pass": ["TOI-396.01"],
    "known passes": ["TOI-411.01", "TOI-1052.01", "TOI-652.01", "TOI-4320.01", "TOI-451.02", "TOI-755.01",
                     "TOI-1097.02", "TOI-763.02", "TOI-451.03", "TOI-118.01", "TOI-576.01", "TOI-747.01",
                     "TOI-826.01", "TOI-107.01", "TOI-191.01"],
    "controls": ["TOI-1058.01", "TOI-1175.01", "TOI-1399.01"],
    "second-list fails": ["173369850-1", "295140687-1", "322826591-1", "337885456-1", "423100454-1",
                          "458290782-1"],
    "second-list passes": ["241522065-1", "277774870-1", "370977908-1", "438857197-1"],
}
for g, labels in groups.items():
    print(f"### {g}")
    print("| signal | Tmag | depth ppm | offsets | qualities | mean fit | sky scatter | detector scatter | "
          "mean/(scatter/rt n) | peak e-/s | column px > half peak | fits along column | "
          "transit at target, z per sector (expected) | two-star z target / neighbour | nulls with q >= real | "
          "pooled peak (E, N) | J(peak) - J(target) |")
    for label in labels:
        r = signal_row(label)
        pk = f'({r["loc_peak"][0]:+.0f}", {r["loc_peak"][1]:+.0f}")' if r["loc_peak"] else "-"
        dj = f'{r["loc_dj"]:.1f}' if r["loc_dj"] is not None else "-"
        print(f'| {label} | {r["tmag"]:.2f} | {r["depth_ppm"]:.0f} | {r["off_min"]:.1f} to {r["off_max"]:.1f}" | '
              f'{r["q_min"]:.2f} to {r["q_max"]:.2f} | {r["mean_off"]:.1f}" | {r["sky"]:.1f}" | {r["det"]:.1f}" | '
              f'{r["sig"]:.1f} | {r["peak"][0]:.0f} to {r["peak"][1]:.0f} | {r["colhm"][0]} to {r["colhm"][1]} | '
              f'{r["along_col"]} of {len(r["sectors"])} | {fmt(r["snr_t"])} ({fmt(r["snr_e"])}) | '
              f'{fmt(r["two_t"])} / {fmt(r["two_o"])} | '
              f'{"/".join(f"{a}of{b}" for a, b in zip(r["nulls_ge"], r["n_nulls"]))} | {pk} | {dj} |')
    print()
