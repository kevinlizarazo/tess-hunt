import json, sys
d = json.load(open(sys.argv[1]))
def short(v, n=600):
    s = json.dumps(v, default=str)
    return s if len(s) < n else s[:n] + " ..."
for k in ("star", "neighbours", "pixels", "checks", "catalogued", "sources", "evidence_only", "families", "other_signals", "triage_reason", "signal", "ephemeris"):
    print("==", k, ":", short(d.get(k), 1500))
