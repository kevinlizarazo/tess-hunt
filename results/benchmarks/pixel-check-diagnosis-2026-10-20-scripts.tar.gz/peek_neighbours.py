import json, os, sys
import pandas as pd
run = os.environ["VET_RUN"]
for name in sys.argv[1:]:
    d = json.load(open(f"{run}/signals/{name}/checks.json"))
    nb = d["neighbours"]
    ev = nb.get("evidence", {})
    print("==", name, nb.get("outcome"), "|", nb.get("reason"))
    print("   no_g:", ev.get("no_g"), " depth:", ev.get("depth"), " n possible:", len(ev.get("possible_hosts", [])))
    t = pd.read_csv(f"{run}/signals/{name}/neighbours.csv")
    print("   rows:", len(t), " possible:", int(t.possible.sum()), " max sep:", round(t.sep_arcsec.max(), 1))
    print(t[t.possible].sort_values("sep_arcsec")[["source_id", "sep_arcsec", "phot_g_mean_mag", "tmag", "tmag_from", "required_depth"]].head(12).to_string(index=False))
    st = d["star"]
    print("   star tmag", st.get("tmag"), "ruwe", st.get("ruwe"), "contratio", st.get("contratio"), "sectors", st.get("sectors"))
