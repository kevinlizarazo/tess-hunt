"""Checks that every refit reproduces the recorded offset and quality and every rebuilt image the saved one."""
import json
rows = json.load(open("/tmp/pixel-diag/detail.json"))
n = fit_ok = img_ok = rec_n = 0
worst = 0.0
for j in rows:
    rec = {r["sector"]: r for r in (j["recorded"] or [])}
    for s in j["per_sector"]:
        if "error" in s:
            print("error", j["label"], s); continue
        n += 1
        zero = [m for m in s["nulls"] if m["phase"] == 0.0][0]
        img_ok += zero.get("reproduces_saved_image") is True
        if s["sector"] in rec:
            rec_n += 1
            d = max(abs(rec[s["sector"]]["offset_arcsec"] - s["fit"]["offset"]), abs(rec[s["sector"]]["quality"] - s["fit"]["quality"]))
            worst = max(worst, d)
            fit_ok += d < 1e-9
print(f"{n} sectors; {rec_n} with a recorded offset, {fit_ok} reproduced to 1e-9 (largest difference {worst:.2e}); "
      f"{img_ok} rebuilt images equal to the saved ones")

# The controls' offsets and qualities, to compare with results/triage/pixel-controls-2026-10-16.txt.
for j in rows:
    if j["group"] == "control":
        print(j["label"], "; ".join(f'S{s["sector"]}: {s["fit"]["offset"]:.2f}" {s["fit"]["quality"]:.3f}' for s in j["per_sector"]))
