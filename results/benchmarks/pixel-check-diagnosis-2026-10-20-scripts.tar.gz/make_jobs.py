"""Jobs for sector_detail.py: the known planets, the second list and M2's nearby-binary pixel controls."""
import json
import os
from pathlib import Path

import pandas as pd

HOME = Path.home()
REPO = HOME / "code" / "tess-hunt"
PIXEL_COMPLETENESS = Path(os.environ["PIXEL_COMPLETENESS"])
SECOND_RUN = Path(os.environ["SECOND_RUN"])
TDI_KNOWN = HOME / ".cache/tess-hunt/tdi" / PIXEL_COMPLETENESS.name
CONTROLS = HOME / ".cache/tess-hunt/pixel-controls-2026-10-16"

jobs = []
known = pd.read_csv(REPO / "benchmarks/known_planets.csv", dtype={"toi": str})
for _, k in known.iterrows():
    ev = json.load(open(PIXEL_COMPLETENESS / "evidence" / f"{k.tic}-{k.toi}.json"))["evidence"]
    jobs.append({
        "group": "known", "label": f"TOI-{k.toi}", "tic": int(k.tic),
        "star_dir": str(TDI_KNOWN / f"{k.tic}-{k.toi}" / f"tic{k.tic}"), "planet_id": f"{k.tic}.1",
        "sectors": [s["sector"] for s in ev["sectors"]], "depth": float(k.depth_ppm) * 1e-6,
        "recorded": ev["sectors"], "offset_qual": ev["offset_qual_arcsec"],
    })

second = pd.read_csv(SECOND_RUN / "second-list.csv")
for _, r in second.iterrows():
    ev = json.load(open(SECOND_RUN / "signals" / r["name"] / "pixels.json"))["evidence"]
    jobs.append({
        "group": "second", "label": r["name"], "tic": int(r.tic),
        "star_dir": str(SECOND_RUN / "tdi" / r["name"] / f"tic{r.tic}"), "planet_id": f"{r.tic}.1",
        "sectors": [s["sector"] for s in ev["sectors"]], "depth": float(r.depth),
        "recorded": ev["sectors"], "offset_qual": ev["offset_qual_arcsec"],
    })

ctl = pd.read_csv(REPO / "benchmarks/pixel_controls.csv", dtype={"toi": str})
for _, c in ctl.iterrows():
    star_dir = next(CONTROLS.glob(f"test_real_nearby_eb_controls_*/tic{c.tic}"))
    sectors = sorted((int(p.stem.split("sector")[1]) for p in star_dir.glob("imageData_*.pickle")), reverse=True)
    jobs.append({
        "group": "control", "label": f"TOI-{c.toi}", "tic": int(c.tic), "star_dir": str(star_dir),
        "planet_id": f"{c.tic}.1", "sectors": sectors, "depth": None, "recorded": None, "offset_qual": None,
    })

json.dump(jobs, open("/tmp/pixel-diag/jobs.json", "w"), indent=1)
print(len(jobs), "jobs")
