"""The vet run's Gaia DR3 neighbour row for each candidate host star (matched by position to the TIC star the
difference images point at), with the depth it would need and whether the neighbour table calls it possible."""
import json
import os

import numpy as np
import pandas as pd

VET_RUN = os.environ["VET_RUN"]
detail = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/detail.json"))}
hosts = {
    "173369850-1": [173369830],
    "295140687-1": [295140710, 295140717],
    "322826591-1": [322826642, 916591898, 916591876],
    "337885456-1": [337885477],
    "423100454-1": [423100496],
    "458290782-1": [1343588382, 458290807],
}
for label, tics in hosts.items():
    job = detail[label]
    sec = job["per_sector"][0]
    cat = {c["tic"]: c for c in sec["catalogue"]}
    year = 2018.6 + (sec["sector"] - 1) * 27.4 / 365.25  # rough epoch of the sector, for proper motion
    nb = pd.read_csv(f"{VET_RUN}/signals/{label}/neighbours.csv")
    dt = year - nb["ref_epoch"]
    ra = nb["ra"] + (nb["pmra"].fillna(0) * dt / 3.6e6) / np.cos(np.radians(nb["dec"]))
    dec = nb["dec"] + nb["pmdec"].fillna(0) * dt / 3.6e6
    print(f"== {label} (neighbour table: {len(nb)} Gaia DR3 stars within {nb.sep_arcsec.max():.0f}\")")
    for tic in tics:
        c = cat.get(tic)
        if c is None:
            print(f"   TIC {tic}: not in the cutout catalogue")
            continue
        d = np.hypot((ra - c["ra"]) * np.cos(np.radians(c["dec"])), dec - c["dec"]) * 3600
        i = int(np.argmin(d))
        row = nb.iloc[i]
        if d[i] > 3:
            print(f'   TIC {tic} (Tmag {c["tmag"]:.2f}, {c["sep"]:.1f}" from target): no Gaia row within 3" '
                  f'(nearest {d[i]:.1f}"); outside the 1\' table' if c["sep"] > 60 else '')
            continue
        print(f'   TIC {tic} (Tmag {c["tmag"]:.2f}, {c["sep"]:.1f}" from target) = Gaia DR3 {row.source_id} '
              f'({d[i]:.1f}" apart): G {row.phot_g_mean_mag:.2f}, Tmag {row.tmag:.2f} ({row.tmag_from}), '
              f'{row.sep_arcsec:.1f}" from target, required depth {row.required_depth:.4f}, possible {row.possible}')
