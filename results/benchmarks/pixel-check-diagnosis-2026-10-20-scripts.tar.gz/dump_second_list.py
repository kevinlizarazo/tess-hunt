import os
import pandas as pd
d = pd.read_csv(os.path.join(os.environ["SECOND_RUN"], "second-list.csv"))
for _, r in d[d.pixels == "fail"].iterrows():
    print("=====", r["name"])
    for k, v in r.items():
        if k in ("dv_runs",): v = str(v)[:200]
        print(f"  {k}: {v}")
