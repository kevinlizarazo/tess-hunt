"""Per-sector markdown rows for pixel-diagnosis.md, from detail.json and two_star.json."""
import json
import sys

import numpy as np

detail = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/detail.json"))}
two = {j["label"]: j for j in json.load(open("/tmp/pixel-diag/two_star.json"))}


def std(x):
    x = [v for v in x if np.isfinite(v)]
    return float(np.std(x, ddof=1)) if len(x) > 2 else float("nan")


print('| Signal | S | Cam | Off | Q | E, N (") | dcol, drow | Tr | Peak | Col | z (exp) | Fixed z | Nulls >= Q |')
print("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
for label in sys.argv[1:]:
    job = detail[label]
    ts = {p["sector"]: p for p in two[label]["per_sector"]} if label in two else {}
    for s in job["per_sector"]:
        f = s["fit"]
        nl = [m for m in s["nulls"] if m["ok"] and m["phase"] > 0]
        sd = std([m["target_diff"] for m in nl])
        z = s["target_box"]["diff"] / sd
        ze = job["depth"] * s["target_box"]["flux"] / sd if job["depth"] else float("nan")
        ge = sum(m["quality"] >= f["quality"] for m in nl)
        t = ts.get(s["sector"])
        tz = f'{t["snr_target"]:.1f}/{t["snr_other"]:.1f}' if t and "error" not in t else "-"
        print(f'| {label} | {s["sector"]} | {s["camera"]}.{s["ccd"]} | {f["offset"]:.1f}" | {f["quality"]:.2f} | '
              f'{f["east"]:+.0f}, {f["north"]:+.0f} | {f["dcol"]:+.2f}, {f["drow"]:+.2f} | '
              f'{s["transits_used"]}/{s["transits_in_sector"]} | {s["saturation"]["peak_e_s"]:.0f} | '
              f'{s["saturation"]["column_half_max_px"]} | {z:.1f} ({"-" if np.isnan(ze) else f"{ze:.1f}"}) | {tz} | '
              f'{ge}/{len(nl)} |')
