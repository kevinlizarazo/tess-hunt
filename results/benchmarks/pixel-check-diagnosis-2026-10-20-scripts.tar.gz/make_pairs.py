"""Neighbour for two_star.py per signal: the star at the sky-fixed fitted position for the second list and the
controls (pairs.json), the next candidate there (pairs_alt.json), and for each known planet the brightest
catalogued star within 60" of it."""
import json

import numpy as np

detail = json.load(open("/tmp/pixel-diag/detail.json"))


def stars_near(job, east, north, radius=12.0):
    s = job["per_sector"][0]
    cat = s["catalogue"]
    ra0, dec0 = cat[0]["ra"], cat[0]["dec"]
    out = []
    for c in cat[1:]:
        e = (c["ra"] - ra0) * np.cos(np.radians(dec0)) * 3600
        n = (c["dec"] - dec0) * 3600
        d = float(np.hypot(e - east, n - north))
        if d < radius:
            out.append((d, c["tic"], c["tmag"], c["sep"]))
    return sorted(out)


by_label = {j["label"]: j for j in detail}
j = by_label["423100454-1"]
for s in j["per_sector"]:
    if s["sector"] in (102, 65):
        print("423100454-1 S", s["sector"], "fit", round(s["fit"]["east"], 1), round(s["fit"]["north"], 1))
        for row in stars_near(j, s["fit"]["east"], s["fit"]["north"]):
            print("   ", [round(x, 2) if isinstance(x, float) else x for x in row])

pairs = {
    "173369850-1": 173369830, "295140687-1": 295140710, "322826591-1": 322826642,
    "337885456-1": 337885477, "458290782-1": 1343588382,
    "TOI-1058.01": 31553886, "TOI-1175.01": 30329564, "TOI-1399.01": 66783350,
    # the star printed above, nearest the S102 fit and within 5.2" of the S65 one
    "423100454-1": 423100496,
}
alt = {"322826591-1": 916591876, "458290782-1": 458290807, "295140687-1": 295140717}
for job in detail:
    if job["group"] != "known":
        continue
    cat = job["per_sector"][0]["catalogue"]
    near = [c for c in cat[1:] if c["sep"] < 60 and np.isfinite(c["tmag"])]
    if near:
        pairs[job["label"]] = min(near, key=lambda c: c["tmag"])["tic"]
json.dump(pairs, open("/tmp/pixel-diag/pairs.json", "w"), indent=1)
json.dump(alt, open("/tmp/pixel-diag/pairs_alt.json", "w"), indent=1)
print(json.dumps(pairs))
